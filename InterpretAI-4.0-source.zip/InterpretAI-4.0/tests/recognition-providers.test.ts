import { describe, expect, it, vi } from "vitest";
import { defaultConfig } from "../lib/asl/config";
import {
  classifySequence,
  loadLocalModel,
  validateManifest,
  validateWeights,
  type DenseWeights,
  type LocalModelManifest,
} from "../lib/asl/local-recognition";
import { FEATURES_PER_FRAME } from "../lib/asl/landmark-sequence";
import {
  createDefaultRegistry,
  createHandshapeProvider,
  createLocalModelProvider,
  createRegistry,
  describeAvailability,
} from "../lib/asl/provider-registry";
import { RecognitionManager } from "../lib/asl/recognition-manager";
import { createSignSpeakProvider } from "../lib/asl/sign-speak";
import {
  RecognitionError,
  type ConsentState,
  type PublicRecognitionConfig,
  type RecognitionProvider,
} from "../lib/asl/types";
import { handFixture, observation, steadySequence } from "./fixtures/hands";

/* ---------- Synthetic local model (test fixture, not a real ASL model) ---------- */
const FRAMES = 4;
function fixtureModel(minScore = 0.6): {
  manifest: LocalModelManifest;
  weights: DenseWeights;
} {
  const inputs = FRAMES * FEATURES_PER_FRAME;
  // Output 0 "HAND-PRESENT" reads the Right-slot presence features; output 1
  // "__none__" is a constant reject class.
  const presence = Array.from({ length: inputs }, (_, i) =>
    i % FEATURES_PER_FRAME === 0 ? 2 : 0,
  );
  return {
    manifest: {
      format: "interpretai.local-model.v1",
      id: "test-fixture",
      version: "0.0.1",
      granularity: "isolated-sign",
      description: "Synthetic test fixture. Not trained on ASL.",
      vocabulary: ["HAND-PRESENT", "__none__"],
      rejectLabels: ["__none__"],
      license: { name: "MIT" },
      trainingData: {
        description: "None — hand-written weights for tests.",
        consent: "Not applicable.",
      },
      evaluation: {
        dataset: "none",
        signerIndependent: false,
        metrics: { accuracy: 0 },
        knownGaps: "Not a model of ASL.",
      },
      input: {
        sequence: "interpretai.landmarks.v1",
        frames: FRAMES,
        featuresPerFrame: FEATURES_PER_FRAME,
        smoothingAlpha: 0.6,
        minHandCoverage: 0.5,
      },
      decision: { minScore, minMargin: 0.1 },
      architecture: "dense-mlp",
      weightsUrl: "weights.json",
    },
    weights: {
      layers: [
        {
          weights: [presence, Array(inputs).fill(0)],
          bias: [0, 4],
          activation: "linear",
        },
      ],
    },
  };
}
const rightHand = () => [observation(handFixture([0]), "Right")];
const consent: ConsentState = { camera: true, thirdPartyUpload: null };

describe("Mode 2 — local model loading and out-of-vocabulary rejection", () => {
  it("refuses undocumented models", () => {
    const { manifest } = fixtureModel();
    for (const broken of [
      { ...manifest, license: {} },
      { ...manifest, evaluation: { ...manifest.evaluation, knownGaps: "" } },
      { ...manifest, trainingData: { description: "x" } },
      { ...manifest, granularity: "sentence" },
      { ...manifest, vocabulary: ["ONLY"] },
      { ...manifest, rejectLabels: ["missing"] },
      { ...manifest, input: { ...manifest.input, featuresPerFrame: 10 } },
    ])
      expect(() => validateManifest(broken)).toThrow(RecognitionError);
    expect(validateManifest(manifest).id).toBe("test-fixture");
  });
  it("refuses weights that do not match the manifest", () => {
    const { manifest, weights } = fixtureModel();
    expect(() =>
      validateWeights(
        { layers: [{ ...weights.layers[0], bias: [0] }] },
        manifest,
      ),
    ).toThrow();
    expect(() =>
      validateWeights(
        { layers: [{ weights: [[1]], bias: [0], activation: "relu" }] },
        manifest,
      ),
    ).toThrow();
  });
  it("returns a vocabulary label only when documented thresholds pass", () => {
    const { manifest, weights } = fixtureModel();
    const result = classifySequence(
      manifest,
      weights,
      steadySequence(6, rightHand),
    );
    expect(result.outcome).toBe("recognized");
    expect(result.hypotheses[0].text).toBe("HAND-PRESENT");
    expect(result.hypotheses[0].confidence.kind).toBe("model-score");
  });
  it("rejects the reject class, low scores, and low hand coverage as unknown", () => {
    const { manifest, weights } = fixtureModel();
    const leftOnly = steadySequence(6, () => [
      observation(handFixture([0]), "Left"),
    ]);
    expect(classifySequence(manifest, weights, leftOnly)).toMatchObject({
      outcome: "unknown",
      hypotheses: [],
    });
    const strict = fixtureModel(0.99999);
    expect(
      classifySequence(
        strict.manifest,
        strict.weights,
        steadySequence(6, rightHand),
      ).outcome,
    ).toBe("unknown");
    const sparse = steadySequence(6, rightHand);
    sparse.frames.slice(0, 4).forEach((f) => (f.hands = []));
    expect(classifySequence(manifest, weights, sparse).outcome).toBe("unknown");
  });
  it("loads manifest + weights over fetch and reports load failures", async () => {
    const { manifest, weights } = fixtureModel();
    const files: Record<string, unknown> = {
      "/models/t/manifest.json": manifest,
      "/models/t/weights.json": weights,
    };
    const fetcher = vi.fn(async (url: RequestInfo | URL) =>
      files[String(url)]
        ? Response.json(files[String(url)])
        : new Response("", { status: 404 }),
    ) as unknown as typeof fetch;
    const loaded = await loadLocalModel("/models/t/manifest.json", { fetcher });
    expect(loaded.weightsUrl).toBe("/models/t/weights.json");
    await expect(
      loadLocalModel("/models/missing.json", { fetcher }),
    ).rejects.toMatchObject({ code: "model-load-failed" });
  });
  it("is unavailable, not simulated, when no model is configured", async () => {
    const provider = createLocalModelProvider(defaultConfig);
    expect(
      (await provider.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("not-configured");
    await expect(
      provider.recognize({
        kind: "landmark-sequence",
        sequence: steadySequence(3, rightHand),
        consent,
      }),
    ).rejects.toMatchObject({ code: "not-configured" });
  });
});

describe("Mode 1 — experimental handshape provider keeps the L/Y rules", () => {
  it("needs the optional download before it is available", async () => {
    const provider = createHandshapeProvider(async () => false);
    expect(
      (await provider.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("needs-download");
  });
  it("reports a stable L-like handshape and leaves other shapes unknown", async () => {
    const provider = createHandshapeProvider(async () => true);
    const l = await provider.recognize({
      kind: "landmark-sequence",
      sequence: steadySequence(10, () => [observation(handFixture([0]))]),
      consent,
    });
    expect(l.outcome).toBe("recognized");
    expect(l.hypotheses[0]).toMatchObject({
      text: "L-like handshape",
      confidence: { kind: "none" },
    });
    const other = await provider.recognize({
      kind: "landmark-sequence",
      sequence: steadySequence(10, () => [observation(handFixture([1, 2]))]),
      consent,
    });
    expect(other).toMatchObject({ outcome: "unknown", hypotheses: [] });
    const twoHands = await provider.recognize({
      kind: "landmark-sequence",
      sequence: steadySequence(10, () => [
        observation(handFixture([0]), "Right"),
        observation(handFixture([0]), "Left", 0.2),
      ]),
      consent,
    });
    expect(twoHands.outcome).toBe("unknown");
  });
});

describe("Provider registry and selection", () => {
  it("offers the documented modes and falls back to 'unavailable' for unknown IDs", () => {
    const registry = createDefaultRegistry(defaultConfig, async () => false);
    expect(registry.list().map((p) => p.descriptor.id)).toEqual([
      "asl-signs",
      "fingerspelling",
      "experimental-handshape",
      "local-model",
      "sign-speak",
      "huggingface",
      "unavailable",
    ]);
    expect(registry.get("nope").descriptor.mode).toBe("unavailable");
    expect(registry.byMode("external-api").descriptor.id).toBe("sign-speak");
  });
  it("reports unconfigured cloud providers without making network calls", async () => {
    const { readFileSync } = await import("node:fs");
    const bundled = JSON.parse(
      readFileSync(
        new URL(
          "../public/models/asl-fingerspelling-v1/model.json",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    // Only the same-origin bundled model file may be fetched.
    const fetcher = vi.fn(async (url: RequestInfo | URL) => {
      if (String(url) === "/models/asl-fingerspelling-v1/model.json")
        return Response.json(bundled);
      throw new Error(`unexpected request ${String(url)}`);
    }) as unknown as typeof fetch & ReturnType<typeof vi.fn>;
    const registry = createDefaultRegistry(
      defaultConfig,
      async () => true,
      fetcher,
    );
    const status = await describeAvailability(registry, {
      online: true,
      simulatedOffline: false,
    });
    expect(status["sign-speak"].state).toBe("not-configured");
    expect(status["local-model"].state).toBe("not-configured");
    expect(status["experimental-handshape"].state).toBe("available");
    expect(status.unavailable.state).toBe("not-configured");
    expect(status.fingerspelling.state).toBe("available");
    expect(status.huggingface.state).toBe("not-configured");
    expect(
      (fetcher as unknown as { mock: { calls: unknown[][] } }).mock.calls.map(
        (c) => String(c[0]),
      ),
    ).toEqual(["/models/asl-fingerspelling-v1/model.json"]);
  });
  it("never reports a cloud provider as available offline or during the demo outage", async () => {
    const fake: RecognitionProvider = {
      descriptor: {
        ...createSignSpeakProvider(defaultConfig).descriptor,
        id: "cloud-x",
      },
      availability: async () => ({ state: "available" }),
      recognize: async () => {
        throw new Error("unused");
      },
    };
    const registry = createRegistry([fake]);
    expect(
      (
        await describeAvailability(registry, {
          online: false,
          simulatedOffline: false,
        })
      )["cloud-x"].state,
    ).toBe("offline");
    expect(
      (
        await describeAvailability(registry, {
          online: true,
          simulatedOffline: true,
        })
      )["cloud-x"].state,
    ).toBe("simulated-outage");
  });
});

describe("Recognition manager safety guarantees", () => {
  const config: PublicRecognitionConfig = {
    ...defaultConfig,
    proxyUrl: "http://127.0.0.1:8787",
  };
  const videoClip = {
    blob: new Blob([new Uint8Array(100)], { type: "video/webm" }),
    mimeType: "video/webm",
    durationMs: 2000,
  };
  const online = { online: true, simulatedOffline: false };

  it("refuses the unavailable mode and missing camera consent", async () => {
    const manager = new RecognitionManager(
      createDefaultRegistry(config, async () => true),
    );
    await expect(
      manager.run(
        "unavailable",
        {
          kind: "landmark-sequence",
          sequence: steadySequence(3, rightHand),
          consent,
        },
        online,
      ),
    ).rejects.toMatchObject({ code: "not-configured" });
    await expect(
      manager.run(
        "experimental-handshape",
        {
          kind: "landmark-sequence",
          sequence: steadySequence(3, rightHand),
          consent: { camera: false, thirdPartyUpload: null },
        },
        online,
      ),
    ).rejects.toMatchObject({ code: "consent-required" });
  });
  it("sends nothing to a cloud provider without per-clip consent, offline, or in the demo outage", async () => {
    const fetcher = vi.fn() as unknown as typeof fetch;
    const manager = new RecognitionManager(
      createDefaultRegistry(config, async () => true, fetcher),
    );
    await expect(
      manager.run(
        "sign-speak",
        { kind: "video-clip", clip: videoClip, consent },
        online,
      ),
    ).rejects.toMatchObject({ code: "consent-required" });
    const granted = {
      camera: true,
      thirdPartyUpload: { provider: "sign-speak", grantedAt: 1 },
    };
    await expect(
      manager.run(
        "sign-speak",
        { kind: "video-clip", clip: videoClip, consent: granted },
        { online: false, simulatedOffline: false },
      ),
    ).rejects.toMatchObject({ code: "offline" });
    await expect(
      manager.run(
        "sign-speak",
        { kind: "video-clip", clip: videoClip, consent: granted },
        { online: true, simulatedOffline: true },
      ),
    ).rejects.toMatchObject({ code: "simulated-outage" });
    await expect(
      manager.run(
        "sign-speak",
        {
          kind: "video-clip",
          clip: videoClip,
          consent: {
            camera: true,
            thirdPartyUpload: { provider: "other", grantedAt: 1 },
          },
        },
        online,
      ),
    ).rejects.toMatchObject({ code: "consent-required" });
    expect(fetcher).not.toHaveBeenCalled();
  });
  it("reports failures without falling back to another provider or scripted text", async () => {
    const other = vi.fn();
    const failing: RecognitionProvider = {
      descriptor: {
        ...createSignSpeakProvider(config).descriptor,
        id: "failing",
        thirdParty: null,
        capabilities: {
          ...createSignSpeakProvider(config).descriptor.capabilities,
          location: "on-device",
        },
      },
      availability: async () => ({ state: "available" }),
      recognize: async () => {
        throw new RecognitionError("network", "down");
      },
    };
    const backup: RecognitionProvider = {
      ...failing,
      descriptor: { ...failing.descriptor, id: "backup" },
      recognize: other,
    };
    const manager = new RecognitionManager(createRegistry([failing, backup]));
    await expect(
      manager.run(
        "failing",
        { kind: "video-clip", clip: videoClip, consent },
        online,
      ),
    ).rejects.toMatchObject({ code: "network" });
    expect(other).not.toHaveBeenCalled();
  });
  it("flags high-risk recognised text for interpreter escalation", async () => {
    const provider: RecognitionProvider = {
      ...createHandshapeProvider(async () => true),
      recognize: async () => ({
        providerId: "experimental-handshape",
        mode: "experimental-handshape",
        granularity: "handshape",
        location: "on-device",
        outcome: "recognized",
        hypotheses: [
          {
            text: "I am allergic to penicillin",
            confidence: { kind: "none", note: "" },
            startSec: null,
            endSec: null,
          },
        ],
        providerReference: null,
        modelVersion: null,
        receivedAt: 0,
      }),
    };
    const manager = new RecognitionManager(createRegistry([provider]));
    const outcome = await manager.run(
      "experimental-handshape",
      {
        kind: "landmark-sequence",
        sequence: steadySequence(3, rightHand),
        consent,
      },
      online,
    );
    expect(outcome.risk).toBe("Allergies");
  });
  it("cancels the previous request when a new one starts", async () => {
    let firstSignal: AbortSignal | undefined;
    const slow: RecognitionProvider = {
      ...createHandshapeProvider(async () => true),
      recognize: (request) =>
        new Promise((_, reject) => {
          firstSignal ??= request.signal;
          request.signal?.addEventListener("abort", () =>
            reject(new RecognitionError("cancelled", "c")),
          );
        }),
    };
    const manager = new RecognitionManager(createRegistry([slow]));
    const request = {
      kind: "landmark-sequence" as const,
      sequence: steadySequence(3, rightHand),
      consent,
    };
    const first = manager.run("experimental-handshape", request, online);
    expect(manager.busy).toBe(true);
    manager.cancel();
    await expect(first).rejects.toMatchObject({ code: "cancelled" });
    expect(firstSignal?.aborted).toBe(true);
  });
});

describe("documentation example", () => {
  it("the example local-model manifest matches the validated format", async () => {
    const { readFileSync } = await import("node:fs");
    const example = JSON.parse(
      readFileSync(
        new URL(
          "../docs/examples/local-model-manifest.example.json",
          import.meta.url,
        ),
        "utf8",
      ),
    );
    expect(validateManifest(example).input.featuresPerFrame).toBe(
      FEATURES_PER_FRAME,
    );
  });
});
