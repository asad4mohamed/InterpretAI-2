import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { expect, it } from "vitest";

/**
 * Runs ml/signs/evaluate.mjs on a 6-clip Kaggle-format dataset made from
 * the real held-out landmark clips (tests/fixtures/signs/mini-asl-signs).
 * This proves the evaluation tooling works; it is not a full evaluation.
 */
it("evaluation script produces per-class metrics and latency from parquet data", () => {
  const out = path.join(
    mkdtempSync(path.join(tmpdir(), "sign-eval-")),
    "report",
  );
  execFileSync(
    process.execPath,
    [
      "ml/signs/evaluate.mjs",
      "--data-dir",
      "tests/fixtures/signs/mini-asl-signs",
      "--participants",
      "heldout",
      "--out",
      out,
    ],
    { stdio: "pipe" },
  );
  const report = JSON.parse(readFileSync(`${out}.json`, "utf8"));
  expect(report.clips).toBe(6);
  expect(report.perClass).toHaveLength(250);
  expect(report.top1).toBeCloseTo(5 / 6, 5);
  expect(report.latencyMs.median).toBeGreaterThan(0);
  expect(readFileSync(`${out}.md`, "utf8")).toContain("| hello | 1 | 100.0% |");
}, 120000);
