import { readFileSync } from "node:fs";
import { beforeAll, describe, expect, it } from "vitest";
import * as ort from "onnxruntime-web";
import { decodeReplay, type ReplayClip } from "../../lib/asl/signs/replay";
import { modelInput } from "../../lib/asl/signs/features";
import {
  parseLabels,
  parseMeta,
  type ModelMeta,
  type SignLabel,
} from "../../lib/asl/signs/meta";
import { decide, type Decision } from "../../lib/asl/signs/decision";
import {
  Recognizer,
  type RecognizerEvent,
} from "../../lib/asl/signs/recognizer";
import {
  emptyFrame,
  LEFT_HAND_START,
  POSE_START,
  RIGHT_HAND_START,
  type Frame,
} from "../../lib/asl/signs/landmarks";
import {
  LiveMovementTracker,
  directionOf,
  smoothTrajectory,
  summarizeMovement,
} from "../../lib/asl/signs/movement";
import {
  emptySequence,
  glossLine,
  sequenceReducer,
  sequenceResolved,
  type SequenceState,
} from "../../lib/asl/signs/sequence";
import {
  PHRASE_PATTERNS,
  TARGET_COVERAGE,
  TARGET_PHRASES,
  matchPhrase,
  phraseCoverage,
} from "../../lib/asl/signs/phrases";
import {
  parseVocabulary,
  type Vocabulary,
} from "../../lib/asl/signs/vocabulary";
import { createSignModelProvider } from "../../lib/asl/provider-registry";
import { RecognitionManager } from "../../lib/asl/recognition-manager";
import { createRegistry } from "../../lib/asl/provider-registry";
import {
  classifyHand,
  handFeatures,
  validateStaticModel,
} from "../../lib/asl/fingerspelling";

const dir = new URL("../../public/models/asl-signs-v1/", import.meta.url);
const json = (name: string) =>
  JSON.parse(readFileSync(new URL(name, dir), "utf8"));
const meta: ModelMeta = parseMeta(json("model-meta.json"));
const labels: SignLabel[] = parseLabels(json("labels.json"), meta.classes);
const vocabulary: Vocabulary = parseVocabulary(json("vocabulary.json"), labels);
const metrics = json("metrics.json");
const clips: ReplayClip[] = decodeReplay(
  JSON.parse(
    readFileSync(
      new URL("../fixtures/signs/heldout-clips.json", import.meta.url),
      "utf8",
    ),
  ),
).clips;
let session: ort.InferenceSession;

beforeAll(async () => {
  ort.env.wasm.numThreads = 1;
  session = await ort.InferenceSession.create(
    readFileSync(new URL("model.onnx", dir)),
  );
}, 60000);

async function infer(frames: Frame[], fps: number) {
  const input = modelInput(frames, fps, meta);
  const out = await session.run({
    frames: new ort.Tensor("float32", input.data, [1, input.frames, input.dim]),
  });
  return out.logits!.data as Float32Array;
}
const shipped = labels.map((l) => l.shipped);

describe("vocabulary (100+ classes, documented, matches the model)", () => {
  it("has 250 classes, each with stable id, gloss, English, accuracy and notes", () => {
    expect(vocabulary.classes).toBe(250);
    expect(vocabulary.classes).toBeGreaterThanOrEqual(100);
    expect(new Set(vocabulary.signs.map((s) => s.id)).size).toBe(250);
    expect(new Set(vocabulary.signs.map((s) => s.gloss)).size).toBe(250);
    for (const s of vocabulary.signs) {
      expect(s.id).toMatch(/^asl-signs-v1:[a-z0-9-]+$/);
      expect(s.gloss).toMatch(/^[A-Z0-9/-]+$/);
      expect(s.english.length).toBeGreaterThan(0);
      expect(s.heldOutClips).toBeGreaterThan(0);
      expect(s.variantsNote.length).toBeGreaterThan(10);
    }
    expect(
      vocabulary.signs.find((s) => s.modelLabel === "thankyou")?.gloss,
    ).toBe("THANK-YOU");
  });
  it("every class has held-out evaluation results (all 250 evaluated upstream)", () => {
    expect(metrics.perSign).toHaveLength(250);
    expect(
      new Set(metrics.perSign.map((p: { sign: string }) => p.sign)),
    ).toEqual(new Set(labels.map((l) => l.sign)));
    const clipsTotal = metrics.perSign.reduce(
      (n: number, p: { clips: number }) => n + p.clips,
      0,
    );
    expect(clipsTotal).toBe(metrics.test.clips);
  });
  it("identifies ambiguous signs (confusions and near-synonyms)", () => {
    const awake = vocabulary.signs.find((s) => s.modelLabel === "awake")!;
    expect(awake.ambiguous).toBe(true);
    expect(awake.confusedWith.map((c) => c.sign)).toContain("wake");
    expect(vocabulary.signs.filter((s) => s.ambiguous).length).toBeGreaterThan(
      10,
    );
  });
  it("refuses a vocabulary that does not match the model one-to-one", () => {
    const raw = json("vocabulary.json");
    expect(() =>
      parseVocabulary({ ...raw, signs: raw.signs.slice(1) }, labels),
    ).toThrow(/entries/);
    const swapped = [...raw.signs];
    [swapped[0], swapped[1]] = [swapped[1], swapped[0]];
    expect(() => parseVocabulary({ ...raw, signs: swapped }, labels)).toThrow(
      /does not match/,
    );
  });
  it("dataset split has no signer leakage between train/val/test participants", () => {
    const test = new Set(metrics.data.testParticipants);
    for (const p of metrics.data.valParticipants)
      expect(test.has(p)).toBe(false);
    expect(meta.trainedOn).toMatchObject({
      heldOutParticipants: metrics.data.testParticipants,
    });
    // The bundled model is byte-for-byte the evaluated version (version embeds its hash).
    expect(meta.version).toBe("default-2fc9038cc4");
  });
});

describe("real model inference on real held-out signers", () => {
  it("validates input/output dimensions", () => {
    expect(session.inputNames).toEqual(["frames"]);
    expect(session.outputNames).toEqual(["logits", "embedding"]);
    expect(meta.featureDim).toBe(460);
  });
  it("recognises the bundled held-out clips (≥ 5 of 6 top-1; QUIET→SHH is a documented confusion)", async () => {
    const results: {
      truth: string;
      predicted: string;
      p: number;
      ms: number;
    }[] = [];
    for (const clip of clips) {
      const t0 = performance.now();
      const logits = await infer(clip.frames, clip.fps);
      const ms = performance.now() - t0;
      expect(logits).toHaveLength(250);
      const d = decide(logits, shipped, meta.calibration);
      const top = d.top[0]!;
      results.push({
        truth: clip.sign!,
        predicted: labels[top.index]!.sign,
        p: top.probability,
        ms,
      });
      expect(d.top.map((g) => labels[g.index]!.sign)).toContain(
        clip.sign === "quiet" ? "shhh" : clip.sign,
      );
    }
    const correct = results.filter((r) => r.truth === r.predicted).length;
    expect(correct).toBeGreaterThanOrEqual(5);
    // Latency is measured and logged for the report.
    console.log(
      "[real-clip inference]",
      results
        .map(
          (r) =>
            `${r.truth}->${r.predicted} ${(r.p * 100).toFixed(0)}% ${r.ms.toFixed(1)}ms`,
        )
        .join("; "),
    );
  }, 60000);
  it("rejects nonsense input as not sure / nothing instead of naming a sign", async () => {
    // A hand that does not move and has no body: unfamiliar input.
    const frames: Frame[] = [];
    for (let t = 0; t < 20; t++) {
      const f = emptyFrame();
      for (let i = 0; i < 21; i++) {
        f[(RIGHT_HAND_START + i) * 3] = 0.5 + (i % 3) * 0.04;
        f[(RIGHT_HAND_START + i) * 3 + 1] = 0.5 + Math.floor(i / 3) * 0.04;
        f[(RIGHT_HAND_START + i) * 3 + 2] = 0;
      }
      frames.push(f);
    }
    const d = decide(await infer(frames, 30), shipped, meta.calibration, {
      partial: true,
    });
    expect(d.kind).toBe("not-sure");
    const nan = new Float32Array(250).fill(Number.NaN);
    expect(decide(nan, shipped, meta.calibration).kind).toBe("nothing");
  });
});

/** Joins clips into one stream with rests between them, as a live camera would. */
function stream(sequence: ReplayClip[], gapFrames = 15, dropout = false) {
  const out: { frame: Frame; t: number; poses: number }[] = [];
  let t = 1000;
  for (const clip of sequence) {
    const step = 1000 / clip.fps;
    clip.frames.forEach((frame, i) => {
      let f = frame;
      if (dropout && i === Math.floor(clip.frames.length / 2)) {
        // One frame where tracking lost the hands (missing landmarks).
        f = new Float32Array(frame);
        for (const start of [LEFT_HAND_START, RIGHT_HAND_START])
          for (let k = 0; k < 21 * 3; k++) f[start * 3 + k] = Number.NaN;
      }
      out.push({ frame: f, t, poses: 1 });
      t += step;
    });
    const rest = emptyFrame(); // hands dropped: body only
    for (let k = 0; k < 33 * 3; k++)
      rest[POSE_START * 3 + k] = clip.frames[0]![POSE_START * 3 + k]!;
    for (let g = 0; g < gapFrames; g++) {
      out.push({ frame: rest, t, poses: 1 });
      t += 1000 / 30;
    }
  }
  return out;
}

async function runContinuous(
  sequence: ReplayClip[],
  dropout = false,
  gapFrames = 15,
) {
  const events: RecognizerEvent[] = [];
  const pending: Promise<void>[] = [];
  const recognizer = new Recognizer(
    meta,
    labels,
    (input) => {
      const p = session
        .run({
          frames: new ort.Tensor("float32", input.data, [
            1,
            input.frames,
            input.dim,
          ]),
        })
        .then((o) => ({
          logits: o.logits!.data as Float32Array,
          embedding: o.embedding!.data as Float32Array,
        }));
      pending.push(p.then(() => undefined));
      return p;
    },
    (e) => events.push(e),
  );
  for (const s of stream(sequence, gapFrames, dropout)) recognizer.push(s);
  recognizer.flush();
  await Promise.all(pending);
  await new Promise((r) => setTimeout(r, 0));
  const reduce = sequenceReducer(vocabulary);
  let state: SequenceState = emptySequence;
  let n = 0;
  for (const e of events)
    if (e.type === "result")
      state = reduce(state, {
        type: "result",
        id: `t${n++}`,
        result: {
          decision: e.result.decision,
          startT: e.result.segment.timestamps[0]!,
          endT: e.result.segment.timestamps.at(-1)!,
          endReason: e.result.endReason,
          movement: summarizeMovement(
            e.result.segment.frames,
            e.result.segment.timestamps,
          ),
        },
      });
  return { events, state };
}

describe("continuous recognition on a stream of real signing", () => {
  const byName = (name: string) => clips.find((c) => c.sign === name)!;
  it("segments signs at boundaries and builds the sequence HELLO … in order", async () => {
    const { state } = await runContinuous([
      byName("hello"),
      byName("police"),
      byName("blue"),
    ]);
    expect(
      state.tokens.map((t) => (t.kind === "sign" ? t.label : t.kind)),
    ).toEqual(["hello", "police", "blue"]);
    expect(glossLine(state.tokens)).toBe("HELLO POLICE BLUE");
  }, 60000);
  it("a sign with a pause inside it gives one token, not two (repeat filtering)", async () => {
    // Clip ends without the hands dropping: the segmenter returns two
    // segments (the signer pauses mid-sign); the history keeps one token.
    const { events, state } = await runContinuous([byName("quiet")], false, 0);
    expect(
      events.filter((e) => e.type === "result").length,
    ).toBeGreaterThanOrEqual(2);
    expect(state.tokens).toHaveLength(1);
    expect(state.merged).toBeGreaterThanOrEqual(1);
    // With the hands dropping afterwards, the trailing fragment is discarded
    // by the segmenter itself: still exactly one token.
    const dropped = await runContinuous([byName("quiet")]);
    expect(dropped.state.tokens).toHaveLength(1);
  }, 60000);
  it("a one-frame tracking dropout does not corrupt the sequence", async () => {
    const { state } = await runContinuous(
      [byName("hello"), byName("giraffe")],
      true,
    );
    expect(
      state.tokens.map((t) => (t.kind === "sign" ? t.label : t.kind)),
    ).toEqual(["hello", "giraffe"]);
  }, 60000);
  it("produces movement descriptions for each segment", async () => {
    const { state } = await runContinuous([byName("giraffe")]);
    const token = state.tokens[0]!;
    expect(token.kind).toBe("sign");
    if (token.kind === "sign") {
      expect(token.movement).not.toBeNull();
      expect(token.movement!.pathLength).toBeGreaterThan(0.2);
      expect(token.movement!.trajectory.length).toBeGreaterThan(2);
    }
  }, 60000);
});

describe("movement", () => {
  it("reports directions from the signer's point of view (unmirrored camera)", () => {
    // Image x decreasing = toward the signer's right.
    expect(directionOf(-1, 0)).toBe("signer-right");
    expect(directionOf(1, 0)).toBe("signer-left");
    expect(directionOf(0, -1)).toBe("up");
    expect(directionOf(0, 1)).toBe("down");
    expect(directionOf(0.01, 0.01)).toBe("still");
  });
  it("smooths positions over time and bridges short landmark gaps", () => {
    const frames: Frame[] = [];
    for (let i = 0; i < 10; i++) {
      const f = emptyFrame();
      f[(POSE_START + 11) * 3] = 0.6;
      f[(POSE_START + 11) * 3 + 1] = 0.6;
      f[(POSE_START + 12) * 3] = 0.4;
      f[(POSE_START + 12) * 3 + 1] = 0.6;
      if (i !== 4) {
        f[RIGHT_HAND_START * 3] = 0.3 + i * 0.02 + (i % 2 ? 0.02 : -0.02); // jitter
        f[RIGHT_HAND_START * 3 + 1] = 0.4;
      }
      frames.push(f);
    }
    const { points, missing } = smoothTrajectory(frames, RIGHT_HAND_START);
    expect(missing).toBe(1);
    expect(points[4]).toEqual(points[3]); // bridged
    const raw = frames.map((f) => f[RIGHT_HAND_START * 3]!);
    const rawJitter = Math.abs(raw[2]! - raw[1]!);
    const smoothJitter = Math.abs(points[2]!.x - points[1]!.x) * 0.2; // back to image units
    expect(smoothJitter).toBeLessThan(rawJitter);
  });
  it("live tracker flags motion and stillness", () => {
    const live = new LiveMovementTracker();
    const at = (x: number) => {
      const f = emptyFrame();
      f[RIGHT_HAND_START * 3] = x;
      f[RIGHT_HAND_START * 3 + 1] = 0.5;
      return f;
    };
    let m = live.push(at(0.5), 0);
    for (let i = 1; i <= 6; i++) m = live.push(at(0.5 - i * 0.03), i * 33);
    expect(m.moving).toBe(true);
    expect(m.direction).toBe("signer-right");
    for (let i = 7; i <= 30; i++) m = live.push(at(0.32), i * 33);
    expect(m.moving).toBe(false);
  });
});

const decision = (
  index: number,
  p: number,
  kind: Decision["kind"] = "sign",
): Decision => ({
  kind,
  top: [
    { index, probability: p },
    { index: (index + 1) % 250, probability: (1 - p) / 2 },
  ],
  ...(kind === "not-sure" ? { reason: "low-confidence" as const } : {}),
});
const idx = (label: string) => labels.findIndex((l) => l.sign === label);

describe("sequence history", () => {
  const reduce = sequenceReducer(vocabulary);
  const add = (
    s: SequenceState,
    label: string,
    startT: number,
    endT: number,
    endReason = "absent",
    p = 0.9,
  ) =>
    reduce(s, {
      type: "result",
      id: `${label}-${startT}`,
      result: {
        decision: decision(idx(label), p),
        startT,
        endT,
        endReason,
        movement: null,
      },
    });
  it("keeps deliberate repeats (hands dropped between them) but merges a paused sign", () => {
    let s = add(emptySequence, "hello", 0, 500, "absent");
    s = add(s, "hello", 1500, 2000, "absent");
    expect(s.tokens).toHaveLength(2);
    s = add(s, "hello", 2300, 2700, "still");
    s = add(s, "hello", 2900, 3300, "absent");
    expect(s.tokens).toHaveLength(3);
    expect(s.merged).toBe(1);
  });
  it("merges a sign cut by the 4-second limit", () => {
    let s = add(emptySequence, "water", 0, 4000, "max");
    s = add(s, "water", 4100, 4600, "absent");
    expect(s.tokens).toHaveLength(1);
  });
  it("low-confidence results need review, then can be resolved or removed; undo and clear work", () => {
    let s = reduce(emptySequence, {
      type: "result",
      id: "u1",
      result: {
        decision: decision(idx("water"), 0.2, "not-sure"),
        startT: 0,
        endT: 1,
        endReason: "absent",
        movement: null,
      },
    });
    expect(s.tokens[0]!.kind).toBe("uncertain");
    expect(sequenceResolved(s)).toBe(false);
    expect(matchPhrase(s.tokens).kind).toBe("uncertain");
    s = reduce(s, { type: "choose", id: "u1", label: "water" });
    expect(s.tokens[0]).toMatchObject({
      kind: "sign",
      label: "water",
      userChosen: true,
    });
    expect(sequenceResolved(s)).toBe(true);
    s = add(s, "please", 2000, 2500);
    expect(glossLine(s.tokens)).toBe("WATER PLEASE");
    s = reduce(s, { type: "undo" });
    expect(glossLine(s.tokens)).toBe("WATER");
    s = reduce(s, { type: "remove", id: "u1" });
    expect(s.tokens).toHaveLength(0);
    s = add(s, "hello", 0, 1);
    expect(reduce(s, { type: "clear" }).tokens).toHaveLength(0);
  });
  it("cannot choose a label that was not among the model's guesses", () => {
    let s = add(emptySequence, "hello", 0, 1);
    s = reduce(s, { type: "choose", id: s.tokens[0]!.id, label: "zebra" });
    expect(s.tokens[0]).toMatchObject({ label: "hello" });
  });
  it("adds fingerspelled words as #WORD tokens", () => {
    const s = reduce(emptySequence, {
      type: "spelled",
      id: "f",
      text: "help",
      t: 0,
    });
    expect(s.tokens[0]).toMatchObject({
      kind: "spelled",
      text: "HELP",
      gloss: "#HELP",
    });
  });
});

describe("phrases", () => {
  const reduce = sequenceReducer(vocabulary);
  const seq = (...labelsOrSpelled: string[]) =>
    labelsOrSpelled.reduce((s, item, i) => {
      if (item.startsWith("#"))
        return reduce(s, {
          type: "spelled",
          id: `s${i}`,
          text: item.slice(1),
          t: i,
        });
      return reduce(s, {
        type: "result",
        id: `r${i}`,
        result: {
          decision: decision(idx(item), 0.9),
          startT: i * 2000,
          endT: i * 2000 + 500,
          endReason: "absent",
          movement: null,
        },
      });
    }, emptySequence).tokens;
  it("every pattern uses only signs the model outputs", () => {
    expect(phraseCoverage(labels.map((l) => l.sign))).toEqual([]);
    expect(phraseCoverage(["hello"])).not.toEqual([]);
  });
  it("assembles the documented target phrases where the vocabulary allows", () => {
    expect(matchPhrase(seq("hello"))).toMatchObject({
      kind: "matched",
      suggestions: ["Hi.", "Hello."],
    });
    expect(matchPhrase(seq("fine"))).toMatchObject({
      suggestions: expect.arrayContaining(["I'm fine."]),
    });
    expect(matchPhrase(seq("thankyou"))).toMatchObject({
      suggestions: ["Thank you."],
    });
    expect(matchPhrase(seq("#HELP"))).toMatchObject({
      suggestions: ["I need help."],
    });
    expect(matchPhrase(seq("water"))).toMatchObject({
      suggestions: expect.arrayContaining(["I want water."]),
    });
    expect(matchPhrase(seq("drink", "water"))).toMatchObject({
      suggestions: ["I want to drink water."],
    });
    expect(matchPhrase(seq("potty", "where"))).toMatchObject({
      suggestions: ["Where is the bathroom?"],
    });
    expect(matchPhrase(seq("where", "potty"))).toMatchObject({
      suggestions: ["Where is the bathroom?"],
    });
  });
  it("reports unsupported sequences explicitly and never invents signs", () => {
    expect(matchPhrase(seq("hello", "giraffe"))).toEqual({
      kind: "unsupported",
      glosses: "HELLO GIRAFFE",
    });
    expect(matchPhrase(seq("who"))).toMatchObject({ kind: "unsupported" });
    expect(matchPhrase([])).toEqual({ kind: "empty" });
  });
  it("documents each required phrase honestly", () => {
    expect(Object.keys(TARGET_COVERAGE)).toEqual([...TARGET_PHRASES]);
    expect(TARGET_COVERAGE["What is your name?"].status).toBe("unsupported");
    for (const target of TARGET_PHRASES) {
      if (TARGET_COVERAGE[target].status === "unsupported")
        expect(PHRASE_PATTERNS.some((p) => p.target === target)).toBe(false);
      else expect(PHRASE_PATTERNS.some((p) => p.target === target)).toBe(true);
    }
  });
});

describe("sign-model provider and review workflow", () => {
  it("passes reviewed phrases into the review queue path with risk detection", async () => {
    const manager = new RecognitionManager(
      createRegistry([createSignModelProvider(async () => true)]),
    );
    const outcome = await manager.run(
      "asl-signs",
      {
        kind: "sign-sequence",
        english: "I need my medication dose",
        glosses: ["#MEDICINE"],
        minProbability: null,
        userWritten: true,
        modelVersion: "asl-signs-v1",
        consent: { camera: true, thirdPartyUpload: null },
      },
      { online: false, simulatedOffline: false },
    );
    expect(outcome.result.location).toBe("on-device"); // works offline
    expect(outcome.risk).toBe("Medication dosing");
    const ok = await manager.run(
      "asl-signs",
      {
        kind: "sign-sequence",
        english: "Thank you.",
        glosses: ["THANK-YOU"],
        minProbability: 0.93,
        userWritten: false,
        modelVersion: "asl-signs-v1",
        consent: { camera: true, thirdPartyUpload: null },
      },
      { online: true, simulatedOffline: false },
    );
    expect(ok.result.hypotheses[0]).toMatchObject({
      text: "Thank you.",
      confidence: { kind: "calibrated-probability", value: 0.93 },
    });
  });
  it("requires camera consent and rejects other inputs", async () => {
    const manager = new RecognitionManager(
      createRegistry([createSignModelProvider(async () => true)]),
    );
    await expect(
      manager.run(
        "asl-signs",
        {
          kind: "sign-sequence",
          english: "Hi.",
          glosses: ["HELLO"],
          minProbability: 0.9,
          userWritten: false,
          modelVersion: "x",
          consent: { camera: false, thirdPartyUpload: null },
        },
        { online: true, simulatedOffline: false },
      ),
    ).rejects.toMatchObject({ code: "consent-required" });
    expect(
      (
        await createSignModelProvider(async () => false).availability({
          online: true,
          simulatedOffline: false,
        })
      ).state,
    ).toBe("needs-download");
  });
});

describe("compatibility with the existing fingerspelling model", () => {
  it("Holistic hand landmarks feed the 3.0 letter model unchanged (same 21-point format)", () => {
    const model = validateStaticModel(
      JSON.parse(
        readFileSync(
          new URL(
            "../../public/models/asl-fingerspelling-v1/model.json",
            import.meta.url,
          ),
          "utf8",
        ),
      ),
    );
    const clip = clips.find((c) => c.sign === "blue")!;
    const frame = clip.frames.find((f) =>
      Number.isFinite(f[LEFT_HAND_START * 3]),
    )!;
    const hand = Array.from({ length: 21 }, (_, i) => ({
      x: frame[(LEFT_HAND_START + i) * 3]!,
      y: frame[(LEFT_HAND_START + i) * 3 + 1]!,
      z: 0,
    }));
    const features = handFeatures(hand, 640, 480);
    expect(features).toHaveLength(42);
    const decisionOut = classifyHand(model, features!);
    expect(decisionOut).toHaveProperty("letter");
  });
});
