import { describe, expect, it } from "vitest";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

const root = path.resolve(__dirname, "..");
function files(dir: string, exts: string[]): string[] {
  if (!existsSync(dir)) return [];
  return readdirSync(dir).flatMap((name) => {
    const full = path.join(dir, name);
    if (statSync(full).isDirectory()) return files(full, exts);
    return exts.some((e) => name.endsWith(e)) ? [full] : [];
  });
}
const clientSource = ["app", "components", "lib", "workers"].flatMap((d) =>
  files(path.join(root, d), [".ts", ".tsx", ".mjs"]),
);

describe("privacy and credential guards", () => {
  it("never reads private credentials in browser code", () => {
    for (const file of clientSource) {
      const text = readFileSync(file, "utf8");
      expect(text, file).not.toMatch(
        /process\.env\.(SIGN_SPEAK|HF_TOKEN|HF_ASL)|["'`]X-api-key["'`]|Bearer \$\{/i,
      );
    }
  });
  it("the built static export contains no private key variable", () => {
    const built = files(path.join(root, "out"), [".js", ".html", ".txt"]);
    for (const file of built)
      // Variable NAMES may appear in help text; token VALUES must never.
      expect(readFileSync(file, "utf8"), file).not.toMatch(
        /hf_[A-Za-z0-9]{20,}|process\.env\.(SIGN_SPEAK_API_KEY|HF_TOKEN)/,
      );
  });
  it(".env.example documents only placeholders", () => {
    const example = readFileSync(path.join(root, ".env.example"), "utf8");
    for (const line of example.split("\n").filter((l) => /^[A-Z_]+=/.test(l))) {
      const value = line.split("=").slice(1).join("=").trim();
      expect(value.length, line).toBeLessThan(40);
    }
    expect(example).toMatch(/^SIGN_SPEAK_API_KEY=$/m);
    expect(example).toMatch(/^HF_TOKEN=$/m);
    expect(example).not.toMatch(/NEXT_PUBLIC_HF/);
  });
  it("never records audio or requests the microphone", () => {
    for (const file of clientSource) {
      const text = readFileSync(file, "utf8");
      expect(text, file).not.toMatch(/audio:\s*true/);
    }
  });
  it("the service worker never caches POST, cross-origin, or video", () => {
    const sw = readFileSync(path.join(root, "scripts/build-sw.mjs"), "utf8");
    expect(sw).toContain(
      "event.request.method!=='GET'||url.origin!==self.location.origin",
    );
    expect(sw).not.toMatch(/video\/|MediaRecorder|blob:/);
  });
  it("no source sends data to analytics or third parties automatically", () => {
    for (const file of clientSource) {
      const text = readFileSync(file, "utf8");
      expect(text, file).not.toMatch(
        /google-analytics|gtag\(|segment\.io|mixpanel|sendBeacon/,
      );
    }
  });
  it("sign worker keeps face landmarks inside the worker (only a presence flag is posted)", () => {
    const worker = readFileSync(
      path.join(root, "workers/sign-tracker.worker.ts"),
      "utf8",
    );
    // The only face-derived field sent to the page is a boolean; no full
    // landmark frame (which contains the face mesh) is ever posted.
    expect(worker).toMatch(/facePresent: Number\.isFinite\(frame\[0\]\)/);
    const sendCalls = worker.match(/send\(\{[\s\S]*?\}\);/g) ?? [];
    for (const call of sendCalls)
      expect(call).not.toMatch(/\bface:|faceLandmarks|\bframe:|\bframes:\s*segment\.frames\s*[,}]/);
    // Overlay data sent per frame: hands (image x/y) and 7 upper-body points only.
    expect(worker).toContain("const UPPER = [0, 11, 12, 13, 14, 15, 16];");
  });
  it("sign recognition never stores landmarks or video in browser storage", () => {
    for (const file of [
      "components/sign-recognition-panel.tsx",
      "components/use-sign-tracker.ts",
      "workers/sign-tracker.worker.ts",
    ]) {
      const text = readFileSync(path.join(root, file), "utf8");
      expect(text, file).not.toMatch(
        /localStorage|sessionStorage|indexedDB|MediaRecorder/,
      );
    }
  });
});
