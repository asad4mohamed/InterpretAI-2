import { describe, expect, it } from "vitest";
import {
  emptyHandshape,
  explainHandshape,
  matchHandshape,
  steadyHandshape,
  type HandPoint,
} from "../lib/handshapes";

// Synthetic geometry fixtures exercise the rules only. They are not examples
// of real signers and do not measure model or linguistic accuracy.
function fixture(extended: number[], thumb = true): HandPoint[] {
  const points: HandPoint[] = Array.from({ length: 21 }, () => ({
    x: 0,
    y: 0,
    z: 0,
  }));
  points[1] = { x: -0.22, y: 0.17, z: 0 };
  points[2] = { x: -0.38, y: 0.28, z: 0 };
  points[3] = thumb ? { x: -0.58, y: 0.3, z: 0 } : { x: -0.2, y: 0.4, z: 0.1 };
  points[4] = thumb ? { x: -0.78, y: 0.32, z: 0 } : { x: 0, y: 0.46, z: 0.1 };
  [
    [-0.22, 0.55],
    [0, 0.62],
    [0.2, 0.57],
    [0.37, 0.45],
  ].forEach(([x, y], index) => {
    const base = [5, 9, 13, 17][index];
    points[base] = { x, y, z: 0 };
    points[base + 1] = { x, y: y + 0.3, z: 0 };
    points[base + 2] = extended.includes(index)
      ? { x, y: y + 0.5, z: 0 }
      : { x, y: y + 0.3, z: 0.18 };
    points[base + 3] = extended.includes(index)
      ? { x, y: y + 0.7, z: 0 }
      : { x, y: y + 0.02, z: 0.12 };
  });
  return points;
}
describe("Experimental L/Y handshape geometry, not ASL translation", () => {
  it("matches only the two supported synthetic handshape patterns", () => {
    expect(matchHandshape(fixture([0]))).toBe("L");
    expect(matchHandshape(fixture([3]))).toBe("Y");
  });
  it.each([[], [0, 1, 2, 3], [0, 3], [1, 2]])(
    "leaves unsupported finger pattern %s unknown",
    (...extended) => {
      expect(matchHandshape(fixture(extended.flat()))).toBeNull();
    },
  );
  it("rejects a closed thumb, missing points, nonfinite values, and collapsed geometry", () => {
    expect(matchHandshape(fixture([0], false))).toBeNull();
    expect(matchHandshape(fixture([3], false))).toBeNull();
    expect(matchHandshape([])).toBeNull();
    const invalid = fixture([0]);
    invalid[7].x = NaN;
    expect(matchHandshape(invalid)).toBeNull();
    expect(
      matchHandshape(Array.from({ length: 21 }, () => ({ x: 0, y: 0, z: 0 }))),
    ).toBeNull();
  });
  it("does not confuse hand size, screen mirroring, or translation with a different rule match", () => {
    const mirrored = fixture([0]).map((point) => ({
      x: 3 - point.x * 0.2,
      y: point.y * 0.2 - 2,
      z: point.z * 0.2,
    }));
    expect(matchHandshape(mirrored)).toBe("L");
  });
  it("requires multiple observations and a sustained interval, then clears immediately on unknown", () => {
    let state = { ...emptyHandshape };
    for (const now of [0, 200, 400]) {
      const result = steadyHandshape(state, "L", now);
      state = result.state;
      expect(result.candidate).toBeNull();
    }
    const stable = steadyHandshape(state, "L", 700);
    expect(stable.candidate).toBe("L");
    expect(steadyHandshape(stable.state, null, 710).candidate).toBeNull();
    expect(steadyHandshape(stable.state, "Y", 720).candidate).toBeNull();
  });
  it("does not accept one delayed frame as repeated evidence", () => {
    const first = steadyHandshape(emptyHandshape, "Y", 0);
    expect(steadyHandshape(first.state, "Y", 3000).candidate).toBeNull();
  });
});

describe("2.1.1 tolerance for natural, imperfect hands", () => {
  // Synthetic "imperfect" hands: thumb bent ~30°, index slightly curved,
  // depth noise on curled fingers. Still not real-signer data.
  function natural(letter: "L" | "Y") {
    const points = fixture(letter === "L" ? [0] : [3]);
    points[3] = { x: -0.56, y: 0.36, z: 0.03 };
    points[4] = { x: -0.72, y: 0.48, z: 0.05 };
    const base = letter === "L" ? 5 : 17;
    points[base + 2] = {
      ...points[base + 2],
      x: points[base + 2].x + 0.06,
      z: 0.04,
    };
    points[base + 3] = {
      ...points[base + 3],
      x: points[base + 3].x + 0.1,
      z: 0.06,
    };
    for (const b of [9, 13])
      points[b + 3] = { ...points[b + 3], z: points[b + 3].z + 0.05 };
    return points;
  }
  it("accepts slightly bent thumbs and fingers", () => {
    expect(matchHandshape(natural("L"))).toBe("L");
    expect(matchHandshape(natural("Y"))).toBe("Y");
  });
  it("explains why a shape did not match", () => {
    expect(explainHandshape(fixture([0], false)).hint).toMatch(/thumb/i);
    expect(explainHandshape(fixture([0, 1])).hint).toMatch(/middle and ring/i);
    expect(explainHandshape(fixture([0, 3])).hint).toMatch(/pinky|index/i);
    expect(explainHandshape(fixture([0])).hint).toBe("");
  });
  it("tolerates one dropped frame without restarting the hold, but not two", () => {
    let state = { ...emptyHandshape };
    for (const now of [0, 200, 400])
      state = steadyHandshape(state, "L", now).state;
    const miss = steadyHandshape(state, null, 500);
    expect(miss.candidate).toBeNull();
    expect(steadyHandshape(miss.state, "L", 700).candidate).toBe("L");
    const twoMisses = steadyHandshape(miss.state, null, 600);
    expect(steadyHandshape(twoMisses.state, "L", 700).candidate).toBeNull();
  });
});
