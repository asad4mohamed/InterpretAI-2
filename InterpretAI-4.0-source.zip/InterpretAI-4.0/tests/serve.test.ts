import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { spawn, type ChildProcess } from "node:child_process";
import path from "node:path";

const root = path.resolve(__dirname, "..");
const port = 3900 + Math.floor(Math.random() * 90);
let child: ChildProcess;

beforeAll(async () => {
  child = spawn(process.execPath, ["scripts/serve.mjs"], {
    cwd: root,
    env: {
      ...process.env,
      PORT: String(port),
      NEXT_PUBLIC_RECOGNITION_PROXY_URL: "http://127.0.0.1:8787",
      NEXT_PUBLIC_AVATAR_PROVIDER: "handtalk",
      SIGN_SPEAK_API_KEY: "server-only-secret",
    },
    stdio: "pipe",
  });
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error("serve.mjs did not start")),
      10000,
    );
    child.stdout?.on("data", (d) => {
      if (String(d).includes("production preview")) {
        clearTimeout(timer);
        resolve();
      }
    });
  });
});
afterAll(() => {
  child?.kill();
});

describe("production static server", () => {
  it("serves public runtime configuration without secrets", async () => {
    const response = await fetch(
      `http://127.0.0.1:${port}/runtime-config.json`,
    );
    expect(response.headers.get("cache-control")).toBe("no-store");
    const text = await response.text();
    expect(JSON.parse(text)).toMatchObject({
      proxyUrl: "http://127.0.0.1:8787",
      avatarProvider: "handtalk",
    });
    expect(text).not.toContain("server-only-secret");
  });
  it("extends the CSP only for configured providers", async () => {
    const response = await fetch(
      `http://127.0.0.1:${port}/runtime-config.json`,
    );
    const policy = response.headers.get("content-security-policy") ?? "";
    expect(policy).toMatch(
      /connect-src 'self' http:\/\/127\.0\.0\.1:8787 https:\/\/\*\.handtalk\.me/,
    );
    expect(policy).toMatch(
      /script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' https:\/\/\*\.handtalk\.me/,
    );
    expect(response.headers.get("permissions-policy")).toContain(
      "microphone=()",
    );
  });
  it("never serves files outside the static export", async () => {
    for (const probe of ["/%2e%2e/package.json", "/..%2fpackage.json"]) {
      const response = await fetch(`http://127.0.0.1:${port}${probe}`);
      expect(response.status).not.toBe(200);
      expect(await response.text()).not.toContain('"name": "interpretai"');
    }
  });
});
