import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import http from "node:http";
import type { AddressInfo } from "node:net";
import { createProxyServer, readConfig, hfStatus } from "../server/proxy.mjs";
import { defaultConfig } from "../lib/asl/config";
import {
  createHuggingFaceProvider,
  parseHfClassification,
  validateImage,
} from "../lib/asl/huggingface";
import type { ConsentState } from "../lib/asl/types";

/**
 * All Hugging Face traffic below goes to a LOCAL MOCK of the documented
 * image-classification contract. No real Hugging Face request is made, so
 * these tests do not prove that any live model or endpoint works.
 */
let mode:
  "ok" | "unauthorized" | "gone" | "loading-then-ok" | "garbage" | "slow" =
  "ok";
let calls = 0;
const seen: { auth?: string; type?: string; bytes: number }[] = [];
const hf = http.createServer((req, res) => {
  const chunks: Buffer[] = [];
  req.on("data", (c) => chunks.push(c));
  req.on("end", () => {
    calls++;
    seen.push({
      auth: req.headers.authorization,
      type: req.headers["content-type"],
      bytes: Buffer.concat(chunks).length,
    });
    const json = (status: number, data: unknown) => {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(data));
    };
    if (mode === "unauthorized")
      return json(401, { error: "Invalid credentials" });
    if (mode === "gone")
      return json(410, {
        error:
          "The requested model is deprecated and no longer supported by provider hf-inference.",
      });
    if (mode === "loading-then-ok" && calls === 1)
      return json(503, {
        error: "Model is currently loading",
        estimated_time: 0.01,
      });
    if (mode === "garbage") return json(200, { label: "A" });
    if (mode === "slow") return setTimeout(() => json(200, []), 500);
    return json(200, [
      { label: "B", score: 0.12 },
      { label: "A", score: 0.81 },
    ]);
  });
});
let hfUrl = "";
const servers: http.Server[] = [];
async function proxy(env: Record<string, string>) {
  const server = createProxyServer(
    readConfig({ PROXY_UPSTREAM_TIMEOUT_MS: "200", ...env }),
    { log: () => undefined },
  ) as http.Server;
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  servers.push(server);
  return `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
}
const jpeg = () => new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3, 4]);
const classify = (base: string, headers: Record<string, string> = {}) =>
  fetch(`${base}/v1/hf/classify-image`, {
    method: "POST",
    headers: {
      "Content-Type": "image/jpeg",
      "X-InterpretAI-Consent": "huggingface",
      ...headers,
    },
    body: jpeg(),
  });

beforeAll(async () => {
  await new Promise<void>((r) => hf.listen(0, "127.0.0.1", r));
  hfUrl = `http://127.0.0.1:${(hf.address() as AddressInfo).port}`;
});
afterAll(() => {
  hf.close();
  servers.forEach((s) => s.close());
});

describe("proxy: Hugging Face configuration", () => {
  it("reports missing token, missing target, and invalid model IDs", () => {
    expect(hfStatus(readConfig({}))).toMatchObject({
      configured: false,
      tokenSet: false,
    });
    expect(hfStatus(readConfig({ HF_TOKEN: "hf_x" }))).toMatchObject({
      configured: false,
      tokenSet: true,
      target: null,
    });
    expect(
      hfStatus(
        readConfig({ HF_TOKEN: "hf_x", HF_ASL_MODEL_ID: "not a model id!" }),
      ).target,
    ).toBeNull();
    expect(
      hfStatus(
        readConfig({
          HF_TOKEN: "hf_x",
          HF_ASL_ENDPOINT_URL: "http://evil.example/x",
        }),
      ).target,
    ).toBeNull();
    expect(
      hfStatus(
        readConfig({ HF_TOKEN: "hf_x", HF_ASL_MODEL_ID: "org/asl-model" }),
      ),
    ).toMatchObject({
      configured: true,
      target: "hf-inference",
      modelId: "org/asl-model",
    });
    expect(
      hfStatus(
        readConfig({
          HF_TOKEN: "hf_x",
          HF_ASL_ENDPOINT_URL: "https://x.endpoints.huggingface.cloud",
        }),
      ).target,
    ).toBe("dedicated-endpoint");
  });
  it("returns 503 for a missing token or missing endpoint/model", async () => {
    const noToken = await classify(await proxy({}));
    expect(noToken.status).toBe(503);
    expect((await noToken.json()).error.message).toMatch(/HF_TOKEN/);
    const noTarget = await classify(await proxy({ HF_TOKEN: "hf_secret" }));
    expect(noTarget.status).toBe(503);
    expect((await noTarget.json()).error.message).toMatch(
      /HF_ASL_ENDPOINT_URL or HF_ASL_MODEL_ID/,
    );
  });
});

describe("proxy: Hugging Face inference (mocked upstream)", () => {
  let base = "";
  beforeAll(async () => {
    base = await proxy({
      HF_TOKEN: "hf_secret_token",
      HF_ASL_ENDPOINT_URL: hfUrl,
      HF_ASL_MODEL_ID: "org/asl-letters",
    });
  });
  it("requires consent and a valid image type before forwarding", async () => {
    const before = calls;
    expect((await classify(base, { "X-InterpretAI-Consent": "" })).status).toBe(
      428,
    );
    expect(
      (await classify(base, { "Content-Type": "video/webm" })).status,
    ).toBe(415);
    expect(calls).toBe(before);
  });
  it("forwards raw image bytes with the server-side bearer token and returns validated labels", async () => {
    mode = "ok";
    const response = await classify(base);
    expect(response.status).toBe(200);
    const body = await response.json();
    expect(body).toMatchObject({
      status: "completed",
      target: "dedicated-endpoint",
      model: "org/asl-letters",
    });
    expect(body.result).toEqual([
      { label: "B", score: 0.12 },
      { label: "A", score: 0.81 },
    ]);
    const call = seen[seen.length - 1];
    expect(call).toMatchObject({
      auth: "Bearer hf_secret_token",
      type: "image/jpeg",
      bytes: 8,
    });
    expect(JSON.stringify(body)).not.toContain("hf_secret");
  });
  it("maps invalid token, retired models, invalid responses and timeouts", async () => {
    mode = "unauthorized";
    expect((await classify(base)).status).toBe(401);
    mode = "gone";
    const gone = await classify(base);
    expect(gone.status).toBe(404);
    expect((await gone.json()).error.code).toBe("model-unavailable");
    mode = "garbage";
    expect((await classify(base)).status).toBe(502);
    mode = "slow";
    expect((await classify(base)).status).toBe(504);
  });
  it("retries once while the model is loading", async () => {
    mode = "loading-then-ok";
    calls = 0;
    const response = await classify(base);
    expect(response.status).toBe(200);
    expect(calls).toBe(2);
    mode = "ok";
  });
});

describe("browser adapter (mocked proxy)", () => {
  const config = {
    ...defaultConfig,
    proxyUrl: "http://127.0.0.1:8787",
    requestTimeoutMs: 5000,
  };
  const consent: ConsentState = {
    camera: true,
    thirdPartyUpload: { provider: "huggingface", grantedAt: 1 },
  };
  const image = new Blob([jpeg()], { type: "image/jpeg" });
  const health = (hfPart: object) =>
    Response.json({
      ok: true,
      signSpeak: { recognition: false, production: false },
      huggingFace: hfPart,
    });

  it("explains each unconfigured state", async () => {
    expect(
      (
        await createHuggingFaceProvider(defaultConfig).availability({
          online: true,
          simulatedOffline: false,
        })
      ).state,
    ).toBe("not-configured");
    const noToken = createHuggingFaceProvider(
      config,
      vi.fn(async () =>
        health({
          configured: false,
          tokenSet: false,
          target: null,
          modelId: null,
        }),
      ) as unknown as typeof fetch,
    );
    expect(
      await noToken.availability({ online: true, simulatedOffline: false }),
    ).toMatchObject({
      state: "not-configured",
      detail: expect.stringMatching(/HF_TOKEN/),
    });
    const ready = createHuggingFaceProvider(
      config,
      vi.fn(async () =>
        health({
          configured: true,
          tokenSet: true,
          target: "hf-inference",
          modelId: "org/m",
        }),
      ) as unknown as typeof fetch,
    );
    expect(
      (await ready.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("available");
    expect(
      (await ready.availability({ online: false, simulatedOffline: false }))
        .state,
    ).toBe("offline");
  });
  it("validates images and consent before any request", async () => {
    const fetcher = vi.fn() as unknown as typeof fetch;
    const provider = createHuggingFaceProvider(config, fetcher);
    await expect(
      provider.recognize({
        kind: "still-image",
        image,
        consent: { camera: true, thirdPartyUpload: null },
      }),
    ).rejects.toMatchObject({ code: "consent-required" });
    await expect(
      provider.recognize({
        kind: "still-image",
        image: new Blob(["x"], { type: "text/plain" }),
        consent,
      }),
    ).rejects.toMatchObject({ code: "invalid-input" });
    expect(() =>
      validateImage(
        new Blob([new Uint8Array(2_000_001)], { type: "image/png" }),
      ),
    ).toThrow();
    expect(fetcher).not.toHaveBeenCalled();
  });
  it("shows the model's top labels with provider-reported scores", async () => {
    const fetcher = vi.fn(async () =>
      Response.json({
        status: "completed",
        model: "org/m",
        result: [
          { label: "B", score: 0.1 },
          { label: "A", score: 0.8 },
        ],
      }),
    ) as unknown as typeof fetch;
    const result = await createHuggingFaceProvider(config, fetcher).recognize({
      kind: "still-image",
      image,
      consent,
    });
    expect(result.outcome).toBe("recognized");
    expect(result.hypotheses[0]).toMatchObject({
      text: "A",
      confidence: { kind: "provider-reported", value: 0.8 },
    });
    expect(result.modelVersion).toBe("org/m");
  });
  it("reports low scores as unknown instead of guessing", async () => {
    const fetcher = vi.fn(async () =>
      Response.json({
        status: "completed",
        result: [{ label: "A", score: 0.3 }],
      }),
    ) as unknown as typeof fetch;
    const result = await createHuggingFaceProvider(config, fetcher).recognize({
      kind: "still-image",
      image,
      consent,
    });
    expect(result).toMatchObject({ outcome: "unknown", hypotheses: [] });
  });
  it("maps provider errors without displaying anything", async () => {
    const respond = (status: number, code: string) =>
      createHuggingFaceProvider(
        config,
        vi.fn(async () =>
          Response.json({ error: { code, message: code } }, { status }),
        ) as unknown as typeof fetch,
      ).recognize({ kind: "still-image", image, consent });
    await expect(respond(401, "auth-failed")).rejects.toMatchObject({
      code: "auth-failed",
    });
    await expect(respond(404, "model-unavailable")).rejects.toMatchObject({
      code: "model-unavailable",
    });
    await expect(respond(429, "rate-limited")).rejects.toMatchObject({
      code: "rate-limited",
    });
    await expect(respond(504, "timeout")).rejects.toMatchObject({
      code: "timeout",
    });
    await expect(
      createHuggingFaceProvider(
        config,
        vi.fn(async () => {
          throw new TypeError("down");
        }) as unknown as typeof fetch,
      ).recognize({ kind: "still-image", image, consent }),
    ).rejects.toMatchObject({ code: "network" });
  });
  it("rejects malformed classification payloads", () => {
    expect(() => parseHfClassification({ label: "A" })).toThrow();
    expect(() =>
      parseHfClassification([{ label: "A", score: "high" }]),
    ).toThrow();
    expect(parseHfClassification([])).toEqual([]);
  });
});
