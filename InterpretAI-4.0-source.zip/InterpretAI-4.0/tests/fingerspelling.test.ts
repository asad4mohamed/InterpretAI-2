import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";
import {
  classifyHand,
  defaultSpellerOptions,
  emptySpeller,
  handFeatures,
  loadFingerspellingModel,
  spelledText,
  stepSpeller,
  validateStaticModel,
  type SpellerState,
} from "../lib/asl/fingerspelling";

const root = path.resolve(__dirname, "..");
const model = validateStaticModel(
  JSON.parse(
    readFileSync(
      path.join(root, "public/models/asl-fingerspelling-v1/model.json"),
      "utf8",
    ),
  ),
);
// Real MediaPipe landmarks from photos of a signer NOT in the training data.
const external = JSON.parse(
  readFileSync(
    path.join(__dirname, "fixtures/external-landmarks.json"),
    "utf8",
  ),
) as {
  samples: {
    letter: string;
    w: number;
    h: number;
    image: { x: number; y: number; z: number }[];
  }[];
};

describe("bundled fingerspelling model", () => {
  it("is documented, versioned and limited to 24 static letters", () => {
    expect(model.version).toBe("1.0.0");
    expect(model.vocabulary).toHaveLength(24);
    expect(model.vocabulary).not.toContain("J");
    expect(model.vocabulary).not.toContain("Z");
    expect(model.evaluation.signerIndependent).toBe(false);
    expect(model.evaluation.knownGaps).toMatch(/P was read as Q/);
  });

  it("reproduces the documented external-signer results in the browser runtime", () => {
    const documented = (
      model.evaluation as unknown as {
        external: { letter: string; predicted: string }[];
      }
    ).external;
    let correct = 0;
    for (const sample of external.samples) {
      const features = handFeatures(sample.image, sample.w, sample.h)!;
      const decision = classifyHand(model, features);
      const expected = documented.find((d) => d.letter === sample.letter)!;
      expect(decision.top, sample.letter).toBe(expected.predicted);
      if (decision.letter === sample.letter) correct++;
    }
    // With thresholds applied: wrong letters may be rejected as unknown.
    expect(correct).toBeGreaterThanOrEqual(19);
    expect(model.evaluation.metrics.externalTop1).toBeCloseTo(21 / 24, 3);
  });

  it("rejects an unfamiliar shape instead of guessing", () => {
    const flat = Array.from({ length: 21 }, (_, i) => ({
      x: 0.5 + (i % 5) * 0.001,
      y: 0.5 + i * 0.02,
      z: 0,
    }));
    const decision = classifyHand(model, handFeatures(flat, 640, 480)!);
    expect(decision.letter).toBeNull();
    expect(["unfamiliar-shape", "low-score", "ambiguous"]).toContain(
      decision.reason,
    );
  });

  it("handles invalid landmark input", () => {
    expect(handFeatures([], 640, 480)).toBeNull();
    const zero = Array.from({ length: 21 }, () => ({ x: 0.5, y: 0.5, z: 0 }));
    expect(handFeatures(zero, 640, 480)).toBeNull();
    expect(handFeatures(external.samples[0].image, 0, 480)).toBeNull();
  });

  it("refuses undocumented or malformed models", () => {
    expect(() => validateStaticModel({ ...model, license: {} })).toThrow();
    expect(() =>
      validateStaticModel({ ...model, vocabulary: model.vocabulary.slice(1) }),
    ).toThrow();
    expect(() => validateStaticModel({ format: "other" })).toThrow();
  });

  it("reports load failures clearly", async () => {
    await expect(
      loadFingerspellingModel(async () => new Response("", { status: 404 })),
    ).rejects.toMatchObject({ code: "model-load-failed" });
    await expect(
      loadFingerspellingModel(async () => {
        throw new TypeError("offline");
      }),
    ).rejects.toMatchObject({ code: "model-load-failed" });
  });
});

describe("temporal speller", () => {
  const run = (frames: [string | null, number][], start = emptySpeller) => {
    let state: SpellerState = start;
    const committed: string[] = [];
    for (const [letter, t] of frames) {
      const step = stepSpeller(state, {
        letter,
        handPresent: letter !== null || t < 0,
        t,
      });
      state = step.state;
      if (step.committed) committed.push(step.committed);
    }
    return { state, committed };
  };
  const hold = (letter: string | null, from: number, ms: number, every = 100) =>
    Array.from(
      { length: Math.floor(ms / every) + 1 },
      (_, i) => [letter, from + i * every] as [string | null, number],
    );

  it("commits a letter once per steady hold", () => {
    const { committed, state } = run(hold("H", 0, 1500));
    expect(committed).toEqual(["H"]);
    expect(state.current).toBe("H");
  });
  it("ignores flickers shorter than the hold time", () => {
    const frames: [string | null, number][] = [];
    for (let t = 0; t < 2000; t += 100) frames.push([t % 200 ? "A" : "S", t]);
    expect(run(frames).committed).toEqual([]);
  });
  it("needs a release before repeating the same letter (LL)", () => {
    const noRelease = run([...hold("L", 0, 900), ...hold("L", 1000, 900)]);
    expect(noRelease.committed).toEqual(["L"]);
    const withRelease = run([
      ...hold("L", 0, 900),
      ...hold(null, 1000, 400),
      ...hold("L", 1500, 900),
    ]);
    expect(withRelease.committed).toEqual(["L", "L"]);
  });
  it("starts a new word after the hands are lowered", () => {
    const { state } = run([
      ...hold("H", 0, 900),
      ...hold("I", 1000, 900),
      ...hold(null, 2000, defaultSpellerOptions.wordGapMs + 200),
      ...hold("O", 4000, 900),
    ]);
    expect(spelledText(state)).toBe("HI O");
  });
});
