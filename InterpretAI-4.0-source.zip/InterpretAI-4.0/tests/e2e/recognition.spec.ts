import { test, expect, type Page, type Route } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

/**
 * Experimental live-recognition workspace. Every external API call is
 * MOCKED with page.route; no real Sign-Speak or Hand Talk request is made.
 */
test.use({
  launchOptions: {
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || undefined,
    args: [
      "--use-fake-device-for-media-stream",
      "--use-fake-ui-for-media-stream",
    ],
  },
});

const PROXY = "http://127.0.0.1:8787";

async function openLive(page: Page) {
  await page.goto("/communication/");
  await page
    .getByRole("tab", { name: /Experimental live recognition/ })
    .click();
  await expect(
    page.getByRole("group", { name: "Recognition mode" }),
  ).toBeVisible();
}

async function mockProxy(
  page: Page,
  recognize: (route: Route) => Promise<void> | void,
  options: { avatar?: "sign-speak" | "none" } = {},
) {
  const calls: string[] = [];
  await page.route("**/runtime-config.json", (route) =>
    route.fulfill({
      json: { proxyUrl: PROXY, avatarProvider: options.avatar ?? "none" },
    }),
  );
  await page.route(`${PROXY}/**`, async (route) => {
    const url = new URL(route.request().url());
    calls.push(`${route.request().method()} ${url.pathname}`);
    if (url.pathname === "/health")
      return route.fulfill({
        json: { ok: true, signSpeak: { recognition: true, production: true } },
      });
    if (url.pathname.startsWith("/v1/sign-speak/recognize"))
      return recognize(route);
    if (url.pathname === "/v1/sign-speak/produce")
      return route.fulfill({
        body: Buffer.from([0, 0, 0, 24, 102, 116, 121, 112]),
        contentType: "video/mp4",
      });
    return route.fulfill({ status: 404 });
  });
  return calls;
}

async function recordAndReview(page: Page) {
  await page.getByRole("radio", { name: /Sign-Speak/ }).check();
  await expect(page.getByRole("radio", { name: /Sign-Speak/ })).toBeChecked();
  await page
    .getByRole("checkbox", { name: /I agree to turn on my camera/ })
    .check();
  await page.getByRole("button", { name: "Start camera", exact: true }).click();
  await page.getByRole("button", { name: /Record clip/ }).click();
  await page.waitForTimeout(1500);
  await page
    .getByRole("button", { name: "Stop recording", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Review your clip before anything is sent",
    }),
  ).toBeVisible();
}

test("live workspace is separate, honest by default, and accessible", async ({
  page,
}) => {
  const external: string[] = [];
  page.on("request", (r) => {
    if (!r.url().startsWith("http://127.0.0.1:3000/")) external.push(r.url());
  });
  await page.goto("/communication/");
  await expect(
    page.getByRole("tab", { name: /Scripted scenarios/ }),
  ).toHaveAttribute("aria-selected", "true");
  await expect(page.getByLabel("Select Scenario")).toBeVisible();
  await page.getByRole("tab", { name: /Scripted scenarios/ }).focus();
  await page.keyboard.press("ArrowRight");
  await expect(
    page.getByRole("tab", { name: /Experimental live recognition/ }),
  ).toBeFocused();
  await expect(page.getByLabel("Select Scenario")).toHaveCount(0);
  const modes = page.getByRole("group", { name: "Recognition mode" });
  for (const name of [
    /Experimental handshape lab/,
    /Local trained model/,
    /Sign-Speak/,
    /Recognition off/,
  ])
    await expect(modes.getByRole("radio", { name })).toBeVisible();
  await expect(
    modes.getByRole("radio", { name: /Recognition off/ }),
  ).toBeChecked();
  await expect(
    page.getByRole("button", { name: "Start camera", exact: true }),
  ).toBeDisabled();
  await modes.getByRole("radio", { name: /Sign-Speak/ }).check();
  await expect(
    page.getByText(/No secure recognition proxy is configured/).first(),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Start camera", exact: true }),
  ).toBeDisabled();
  await modes.getByRole("radio", { name: /Local trained model/ }).check();
  await expect(
    page.getByText(/No trained local model is configured/).first(),
  ).toBeVisible();
  await modes
    .getByRole("radio", { name: /Experimental handshape lab/ })
    .check();
  await expect(
    page
      .getByText(/Download the optional on-device hand-tracking tools/)
      .first(),
  ).toBeVisible();
  await expect(
    page.getByText(/No signing-avatar provider is connected/),
  ).toBeVisible();
  await expect(
    page.getByText("No messages yet.", { exact: false }),
  ).toBeVisible();
  const report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((v) => ({
      id: v.id,
      nodes: v.nodes.map((n) => n.target),
    })),
  ).toEqual([]);
  expect(external).toEqual([]);
});

test.describe("mocked Sign-Speak recognition", () => {
  test.use({ bypassCSP: true, permissions: ["camera"] });
  test("provider text escalates high-risk topics and never machine-signs them", async ({
    page,
  }) => {
    const calls = await mockProxy(
      page,
      (route) => route.fulfill({ status: 500 }),
      { avatar: "sign-speak" },
    );
    await openLive(page);
    await page
      .getByLabel("Provider message · plain language")
      .fill("Let's talk about your medication dose.");
    await page.getByRole("button", { name: "Send message" }).click();
    await expect(
      page
        .getByRole("alert")
        .filter({ hasText: "HUMAN INTERPRETER RECOMMENDED" }),
    ).toContainText("Medication dosing");
    await expect(page.getByRole("log")).toContainText(
      "High-risk — qualified interpreter required",
    );
    expect(calls.filter((c) => c.includes("produce"))).toEqual([]);
    await page.getByRole("button", { name: "Clear conversation" }).click();
    await expect(
      page
        .getByRole("alert")
        .filter({ hasText: "HUMAN INTERPRETER RECOMMENDED" }),
    ).toHaveCount(0);
    await page
      .getByLabel("Provider message · plain language")
      .fill("Please have a seat.");
    await page.getByRole("button", { name: "Send message" }).click();
    // Signing output is only produced on explicit request.
    expect(calls.filter((c) => c.includes("produce"))).toEqual([]);
    await page.getByRole("button", { name: "Show in signing avatar" }).click();
    await expect(
      page.getByText(/Machine-generated signing video ready/),
    ).toBeVisible();
    await expect(
      page.getByText("MACHINE-GENERATED · UNVALIDATED"),
    ).toBeVisible();
    await expect(page.locator(".avatar-caption")).toContainText(
      "Please have a seat.",
    );
    expect(calls).toContain("POST /v1/sign-speak/produce");
  });

  test("nothing is uploaded until the patient reviews and consents; real returned text needs review", async ({
    page,
  }) => {
    const calls = await mockProxy(page, (route) =>
      route.fulfill({
        json: {
          status: "completed",
          result: {
            feedback_id: "fb",
            prediction: [
              {
                feedback_id: "fb",
                timestamp_start_sec: 0,
                timestamp_end_sec: 1,
                finished: true,
                prediction: "HELLO",
                confidence: 0.9,
              },
            ],
          },
        },
      }),
    );
    await openLive(page);
    await recordAndReview(page);
    const send = page.getByRole("button", {
      name: "Send clip for recognition",
    });
    await expect(send).toBeDisabled();
    expect(calls.filter((c) => c.startsWith("POST"))).toEqual([]);
    await page
      .getByRole("checkbox", { name: /Send this one clip to Sign-Speak/ })
      .check();
    await send.click();
    const review = page.locator(".review-queue");
    const log = page.getByRole("log");
    await expect(review).toContainText("HELLO");
    await expect(review).toContainText("Sign-Speak API · cloud");
    await expect(review).toContainText("Provider-reported score 90%");
    await expect(review).toContainText("Awaiting patient review");
    // Unconfirmed machine output never enters the conversation.
    await expect(log).not.toContainText("HELLO");
    expect(calls.filter((c) => c.startsWith("POST"))).toEqual([
      "POST /v1/sign-speak/recognize",
    ]);
    await page.getByRole("button", { name: "Correct", exact: true }).click();
    await page
      .getByLabel("Type what you meant")
      .fill("Hello, I am here for my appointment");
    await page.getByRole("button", { name: "Save correction" }).click();
    await expect(log).toContainText("Corrected by the patient");
    await expect(log).toContainText("Originally recognised as: “HELLO”");
    const track = await page.evaluateHandle(
      () =>
        (document.querySelector(".live-camera video") as HTMLVideoElement)
          .srcObject as MediaStream,
    );
    expect(await track.evaluate((s) => s.getAudioTracks().length)).toBe(0);
    await page.getByRole("button", { name: "Stop camera now" }).click();
    expect(
      await track.evaluate(
        (s) =>
          s.getVideoTracks().every((t) => t.readyState === "ended") ||
          s.getTracks().length === 0,
      ),
    ).toBe(true);
  });

  test("invalid credentials, network failures, and empty results never produce text", async ({
    page,
  }) => {
    let mode: "auth" | "network" | "empty" | "risk" = "auth";
    await mockProxy(page, (route) => {
      if (mode === "auth")
        return route.fulfill({
          status: 401,
          json: { error: { code: "auth-failed", message: "x" } },
        });
      if (mode === "network") return route.abort("connectionrefused");
      if (mode === "risk")
        return route.fulfill({
          json: {
            status: "completed",
            result: {
              feedback_id: "f",
              prediction: [
                { prediction: "I have chest pain", confidence: 0.5 },
              ],
            },
          },
        });
      return route.fulfill({
        json: {
          status: "completed",
          result: { feedback_id: "f", prediction: [] },
        },
      });
    });
    await openLive(page);
    const status = page.locator(".live-status");
    const sendOne = async () => {
      await page.getByRole("button", { name: /Record clip/ }).click();
      await page.waitForTimeout(1200);
      await page
        .getByRole("button", { name: "Stop recording", exact: true })
        .click();
      await page
        .getByRole("checkbox", { name: /Send this one clip to Sign-Speak/ })
        .check();
      await page
        .getByRole("button", { name: "Send clip for recognition" })
        .click();
    };
    await recordAndReview(page);
    await page
      .getByRole("checkbox", { name: /Send this one clip to Sign-Speak/ })
      .check();
    await page
      .getByRole("button", { name: "Send clip for recognition" })
      .click();
    await expect(status).toContainText("API authentication failed");
    await expect(status).toContainText("no scripted text was substituted");
    mode = "network";
    await sendOne();
    await expect(status).toContainText("could not be reached");
    mode = "empty";
    await sendOne();
    await expect(status).toContainText("Unknown or unrecognised sign");
    await expect(page.getByRole("log")).toContainText("No messages yet.");
    mode = "risk";
    await sendOne();
    await expect(
      page
        .getByRole("alert")
        .filter({ hasText: "HUMAN INTERPRETER RECOMMENDED" }),
    ).toContainText("Emergency symptoms");
    await expect(
      page.getByRole("button", { name: /Record clip/ }),
    ).toBeDisabled();
  });

  test("cloud recognition is unavailable offline and during the simulated outage", async ({
    page,
    context,
  }) => {
    await mockProxy(page, (route) => route.fulfill({ status: 500 }));
    await openLive(page);
    const signSpeak = page.getByRole("radio", { name: /Sign-Speak/ });
    await page.getByRole("button", { name: "Simulate outage" }).click();
    await expect(
      page.getByText("Simulated outage — browser network unchanged"),
    ).toBeVisible();
    await expect(
      page.locator(".mode-option").filter({ has: signSpeak }),
    ).toContainText("Demo outage");
    await page.getByRole("button", { name: "Restore demo connection" }).click();
    await expect(
      page.locator(".mode-option").filter({ has: signSpeak }),
    ).toContainText("Available");
    await context.setOffline(true);
    await expect(
      page.locator(".mode-option").filter({ has: signSpeak }),
    ).toContainText("Offline");
    await signSpeak.check();
    await expect(
      page.getByRole("button", { name: "Start camera", exact: true }),
    ).toBeDisabled();
    await context.setOffline(false);
  });
});

test("on-device handshape mode tracks a live camera, keeps blank input unknown, and cleans up", async ({
  page,
  context,
}) => {
  test.setTimeout(120000);
  await context.grantPermissions(["camera"]);
  await page.goto("/sample-lab/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await page
    .getByRole("button", { name: "Download recognition tools", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible({ timeout: 45000 });
  await page.goto("/communication/#live");
  await page.getByRole("radio", { name: /Experimental handshape lab/ }).check();
  await expect(
    page
      .locator(".mode-option")
      .filter({ hasText: "Experimental handshape lab" }),
  ).toContainText("Available");
  await page
    .getByRole("checkbox", { name: /I agree to turn on my camera/ })
    .check();
  await page.getByRole("button", { name: "Start camera", exact: true }).click();
  await expect(page.locator(".camera-state")).toContainText(
    "No hands detected",
    { timeout: 45000 },
  );
  await page.getByRole("button", { name: "Capture sign (3 s)" }).click();
  await expect(page.locator(".live-status")).toContainText(
    /Unknown or unrecognised sign|No hands were detected/,
    { timeout: 15000 },
  );
  await expect(page.getByRole("log")).toContainText("No messages yet.");
  const stream = await page.evaluateHandle(
    () =>
      (document.querySelector(".live-camera video") as HTMLVideoElement)
        .srcObject as MediaStream,
  );
  const track = await stream.evaluateHandle((s) => s.getVideoTracks()[0]);
  await page.getByRole("button", { name: "Stop camera now" }).click();
  expect(await track.evaluate((t) => t.readyState)).toBe("ended");
  await expect.poll(() => page.workers().length).toBe(0);
  await expect(page.locator(".live-status")).toContainText(
    "All camera tracks were released",
  );
});

test("live workspace fits a phone screen", async ({ page }) => {
  await page.setViewportSize({ width: 360, height: 780 });
  await page.goto("/communication/#live");
  await expect(
    page.getByRole("group", { name: "Recognition mode" }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "outputs/interpretai-live-mobile.png",
    fullPage: true,
  });
});
