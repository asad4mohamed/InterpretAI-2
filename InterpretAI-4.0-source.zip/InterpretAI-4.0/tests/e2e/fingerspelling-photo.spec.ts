import { test, expect, type Page } from "@playwright/test";
import { existsSync } from "node:fs";
import path from "node:path";

// Real-photo end-to-end check. The fake-camera video is generated locally
// from licensed example photos (ml/make-fake-camera.py) and is NOT shipped,
// so this file skips when it is absent.
const exe = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || undefined;
const fakeVideo = path.resolve("work/fake-camera/letters.y4m");
test.skip(
  !existsSync(fakeVideo),
  "Generate work/fake-camera/letters.y4m with ml/make-fake-camera.py.",
);
test.use({
  launchOptions: {
    executablePath: exe,
    args: [
      "--use-fake-device-for-media-stream",
      "--use-fake-ui-for-media-stream",
      `--use-file-for-fake-video-capture=${fakeVideo}`,
    ],
  },
  permissions: ["camera"],
});

async function downloadTools(page: Page) {
  await page.goto("/sample-lab/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await page
    .getByRole("button", { name: "Download recognition tools", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible({ timeout: 45000 });
}

test.describe("fingerspelling a REAL photo through the full camera pipeline", () => {
  test("camera → MediaPipe worker → trained model → speller → patient review → conversation", async ({
    page,
  }) => {
    test.setTimeout(150000);
    await downloadTools(page);
    await page.goto("/communication/#live");
    await page.getByRole("radio", { name: /ASL fingerspelling/ }).check();
    await page
      .getByRole("checkbox", { name: /I agree to turn on my camera/ })
      .check();
    await page
      .getByRole("button", { name: "Start camera", exact: true })
      .click();
    const spelled = page.locator(".fingerspell-text p");
    await expect(spelled).toContainText("L", { timeout: 60000 });
    await page.getByRole("button", { name: "Review this spelling" }).click();
    const review = page.locator(".review-queue");
    await expect(review).toContainText("Fingerspelling model · on-device");
    await expect(review).toContainText(/Model score \d+% \(not calibrated\)/);
    await expect(review).toContainText("interpretai-asl-fingerspelling@1.0.0");
    await expect(page.getByRole("log")).toContainText("No messages yet.");
    await review
      .getByRole("button", { name: "Yes, that’s what I signed" })
      .click();
    await expect(page.getByRole("log")).toContainText(
      "Fingerspelling model · on-device",
    );
    await expect(page.getByRole("log")).toContainText("Patient confirmed");
    await page.getByRole("button", { name: "Stop camera now" }).click();
  });
});
