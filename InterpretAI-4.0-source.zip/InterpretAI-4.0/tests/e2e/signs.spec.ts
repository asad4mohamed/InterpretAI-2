import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

/**
 * Continuous sign recognition (4.0). Uses the REAL worker: MediaPipe Holistic
 * + the bundled ONNX model, on real held-out landmark clips (replay) and on
 * Chrome's synthetic fake camera (no person in view). No mocks.
 */
const exe = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || undefined;
test.use({
  launchOptions: {
    executablePath: exe,
    args: [
      "--use-fake-device-for-media-stream",
      "--use-fake-ui-for-media-stream",
    ],
  },
  permissions: ["camera"],
});

const HELLO = "Replay clip 142292689";
const QUIET = "Replay clip 1993938790";
const GIRAFFE = "Replay clip 1744637309";

async function download(page: Page) {
  await page.getByRole("button", { name: "Download sign recognition" }).click();
  await expect(page.getByText("Downloaded · not loaded")).toBeVisible({
    timeout: 60000,
  });
}
async function replay(page: Page, name: string, tokens: number) {
  await page.getByRole("button", { name }).click();
  await expect(page.locator(".sign-token")).toHaveCount(tokens, {
    timeout: 60000,
  });
  await expect(page.getByRole("button", { name }).first()).toBeEnabled({
    timeout: 30000,
  });
}
async function axe(page: Page) {
  const report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((v) => ({
      id: v.id,
      nodes: v.nodes.map((n) => n.target),
    })),
  ).toEqual([]);
}

test("signs page: honest disclosures, vocabulary, real-clip recognition, history, phrases, confirm", async ({
  page,
}) => {
  test.setTimeout(180000);
  await page.goto("/signs/");
  await expect(
    page.getByRole("heading", { level: 1, name: "Sign recognition" }),
  ).toBeVisible();
  await expect(
    page.getByText("Experimental — Not Clinically Validated"),
  ).toBeVisible();
  // Vocabulary browser lists exactly the model's classes.
  await page.getByText(/Supported signs \(250\)/).click();
  await expect(
    page.locator(".sign-vocab .sign-vocab-table tbody tr"),
  ).toHaveCount(250);
  await page.getByLabel("Search").fill("water");
  await expect(
    page.locator(".sign-vocab .sign-vocab-table tbody tr"),
  ).toHaveCount(1);
  await expect(
    page.locator(".sign-vocab .sign-vocab-table tbody tr").first(),
  ).toContainText("WATER");
  await page.getByText("About this model").click();
  await expect(
    page.locator(".model-info").filter({ hasText: "Intended use" }),
  ).toContainText("accessibility-critical communication");
  await page.getByText("Short phrases: what is supported").click();
  await expect(
    page.locator("tr", { hasText: "What is your name?" }),
  ).toContainText("UNSUPPORTED");
  await axe(page);

  // Nothing works before the explicit download.
  await expect(
    page.getByRole("button", { name: "Start camera" }),
  ).toBeDisabled();
  await download(page);
  await page.getByRole("button", { name: "Show replay clips" }).click();

  // Real held-out clip → HELLO, top-3 with calibrated probabilities.
  await replay(page, HELLO, 1);
  await expect(page.locator(".sign-current-gloss")).toContainText("HELLO");
  await expect(page.locator(".sign-guesses li")).toHaveCount(3);
  await expect(page.locator(".sign-gloss-line")).toContainText("HELLO");
  await expect(page.locator(".sign-suggestions")).toContainText("Hi.");
  await expect(page.locator(".sign-movement-summary")).toContainText(
    "shoulder widths",
  );

  // A second real clip extends the sequence; unsupported combination is explicit.
  await replay(page, GIRAFFE, 2);
  await expect(page.locator(".sign-gloss-line")).toContainText("HELLO GIRAFFE");
  await expect(page.getByText(/No supported phrase pattern for/)).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Confirm phrase" }),
  ).toBeDisabled();

  // Undo the last sign → back to a supported phrase; edit it; confirm.
  await page.getByRole("button", { name: "Undo last sign" }).click();
  await expect(page.locator(".sign-token")).toHaveCount(1);
  const draft = page.getByLabel(/English to confirm/);
  await expect(draft).toHaveValue("Hi.");
  await draft.fill("Hi there.");
  await page.getByRole("button", { name: "Confirm phrase" }).click();
  await expect(page.locator(".sign-confirmed")).toContainText("Hi there.");
  await expect(page.locator(".sign-token")).toHaveCount(0);

  // A clip with a pause inside it yields one SHH token, not two.
  await replay(page, QUIET, 1);
  await expect(page.locator(".sign-token").first()).toContainText("SHH");

  // Reject clears; nothing is added.
  await page.getByRole("button", { name: "Reject" }).click();
  await expect(page.locator(".sign-token")).toHaveCount(0);
  await expect(page.locator(".sign-confirmed li")).toHaveCount(1);

  // A high-risk phrase stops automation and offers an interpreter.
  await replay(page, HELLO, 1);
  await page.getByLabel(/English to confirm/).fill("I need my medication dose");
  await page.getByRole("button", { name: "Confirm phrase" }).click();
  await expect(
    page
      .getByRole("alert")
      .filter({ hasText: "HUMAN INTERPRETER RECOMMENDED" }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: /Replay clip/ }).first(),
  ).toBeDisabled();
  await axe(page);
});

test("live camera: Holistic runs on device, status, pause/resume, stop releases the camera", async ({
  page,
}) => {
  test.setTimeout(150000);
  await page.goto("/signs/");
  await download(page);
  await page.getByLabel(/I agree to turn on my camera/).check();
  await page.getByRole("button", { name: "Start camera" }).click();
  await expect(
    page.getByRole("button", { name: "Stop camera now" }),
  ).toBeVisible({ timeout: 60000 });
  const bar = page.locator(".sign-status-bar");
  // Chrome's synthetic camera shows no person: the app must say so, not guess.
  await expect(bar).toContainText("No one in view", { timeout: 30000 });
  await expect(bar).toContainText("Watching for a sign");
  await expect(bar).toContainText("250 signs · on device");
  await expect(page.locator(".sign-token")).toHaveCount(0);
  await page.getByRole("button", { name: "Pause recognition" }).click();
  await expect(bar).toContainText("Paused");
  await page.getByRole("button", { name: "Resume recognition" }).click();
  await expect(bar).toContainText("Watching for a sign");
  // Fingerspelling sub-mode loads the 3.0 letter model alongside.
  await page.getByLabel(/Fingerspell a word instead/).check();
  await expect(page.getByLabel("Fingerspelling a word")).toBeVisible();
  await page.getByRole("button", { name: "Stop camera now" }).click();
  await expect(
    page.getByRole("button", { name: "Start camera" }),
  ).toBeVisible();
  expect(
    await page.evaluate(() =>
      [...document.querySelectorAll("video")].every(
        (v) => v.srcObject === null,
      ),
    ),
  ).toBe(true);
  // Withdrawing consent disables the camera again.
  await page.getByLabel(/I agree to turn on my camera/).uncheck();
  await expect(
    page.getByRole("button", { name: "Start camera" }),
  ).toBeDisabled();
});

test("workspace: ASL signs mode feeds the review queue; only confirmed text enters the conversation", async ({
  page,
}) => {
  test.setTimeout(150000);
  await page.goto("/communication/#live");
  await page.getByRole("radio", { name: /ASL signs, continuous/ }).check();
  await expect(
    page.locator(".mode-option").filter({ hasText: "ASL signs" }),
  ).toContainText("Download needed");
  await download(page);
  await expect(
    page.locator(".mode-option").filter({ hasText: "ASL signs" }),
  ).toContainText("Available");
  await page.getByRole("button", { name: "Show replay clips" }).click();
  await replay(page, HELLO, 1);
  await page.getByRole("button", { name: "Review this phrase" }).click();
  const queue = page.locator(".review-queue");
  await expect(queue).toContainText("Hi.");
  await expect(queue).toContainText("calibrated on held-out signers");
  await expect(page.locator(".live-log")).not.toContainText("Hi.");
  await queue.getByRole("button", { name: /Yes, that/ }).click();
  await expect(page.locator(".live-log")).toContainText("Hi.");
  await expect(page.locator(".live-log")).toContainText(
    "Sign model (250 signs)",
  );
  // Rejected output never enters the conversation.
  await replay(page, GIRAFFE, 1);
  await page.getByLabel(/English to send for review/).fill("A giraffe.");
  await page.getByRole("button", { name: "Review this phrase" }).click();
  await queue.getByRole("button", { name: /not what I signed/ }).click();
  await expect(page.locator(".live-log")).not.toContainText("A giraffe.");
  await axe(page);
});

test("offline: after the download, sign recognition works with the network off", async ({
  page,
  context,
}) => {
  test.setTimeout(150000);
  await page.goto("/signs/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await download(page);
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByText("Downloaded · not loaded")).toBeVisible({
    timeout: 30000,
  });
  await page.getByRole("button", { name: "Show replay clips" }).click();
  await replay(page, HELLO, 1);
  await expect(page.locator(".sign-current-gloss")).toContainText("HELLO");
  await context.setOffline(false);
});

test("camera denied: a clear message, and replay still works", async ({
  page,
}) => {
  test.setTimeout(150000);
  await page.goto("/signs/");
  await download(page);
  // Simulate the user pressing "Block" in the browser permission prompt.
  await page.evaluate(() => {
    navigator.mediaDevices.getUserMedia = () =>
      Promise.reject(new DOMException("Permission denied", "NotAllowedError"));
  });
  await page.getByLabel(/I agree to turn on my camera/).check();
  await page.getByRole("button", { name: "Start camera" }).click();
  await expect(
    page
      .getByRole("alert")
      .filter({ hasText: "Camera permission was declined" }),
  ).toBeVisible({
    timeout: 60000,
  });
  await page.getByRole("button", { name: "Show replay clips" }).click();
  await replay(page, HELLO, 1);
});

test("mobile: sign page fits 360 px and controls remain reachable", async ({
  page,
}) => {
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto("/signs/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.getByRole("button", { name: "Download sign recognition" }).focus();
  await expect(
    page.getByRole("button", { name: "Download sign recognition" }),
  ).toBeFocused();
});

test("keyboard only: download, replay, review and undo; results are announced to screen readers", async ({
  page,
}) => {
  test.setTimeout(150000);
  await page.goto("/signs/");
  const download = page.getByRole("button", {
    name: "Download sign recognition",
  });
  await download.focus();
  await page.keyboard.press("Enter");
  await expect(page.getByText("Downloaded · not loaded")).toBeVisible({
    timeout: 60000,
  });
  await page.getByRole("button", { name: "Show replay clips" }).focus();
  await page.keyboard.press("Enter");
  const hello = page.getByRole("button", { name: HELLO });
  await hello.focus();
  await page.keyboard.press("Space");
  await expect(page.locator(".sign-token")).toHaveCount(1, { timeout: 60000 });
  // Polite live region carries the result for screen readers.
  await expect(
    page.locator(".sign-panel > p.sr-only[aria-live='polite']"),
  ).toContainText("Recognised HELLO");
  // Tab order reaches the history controls and the phrase box.
  const undo = page.getByRole("button", { name: "Undo last sign" });
  await undo.focus();
  await page.keyboard.press("Enter");
  await expect(page.locator(".sign-token")).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "Confirm phrase" }),
  ).toBeDisabled();
});

test("offline before any download: the page and vocabulary still load, and the camera stays disabled", async ({
  page,
  context,
}) => {
  await page.goto("/signs/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByText(/Supported signs \(250\)/)).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Start camera" }),
  ).toBeDisabled();
  await expect(
    page.getByText("One-time download needed", { exact: false }),
  ).toBeVisible();
  await context.setOffline(false);
});
