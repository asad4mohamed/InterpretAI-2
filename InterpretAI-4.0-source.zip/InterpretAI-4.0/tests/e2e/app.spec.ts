import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { writeFileSync } from "node:fs";
test("patient overview, accessible interpreter workflow, and focus restoration", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await page.getByRole("link", { name: "Explore Patient Experience" }).click();
  await expect(
    page.getByRole("heading", { name: "Your next visit, in focus." }),
  ).toBeVisible();
  const request = page
    .getByRole("button", { name: "Request Qualified Interpreter", exact: true })
    .first();
  await request.click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await dialog.getByRole("radio", { name: /Video remote interpreter/ }).check();
  await dialog.getByRole("button", { name: "Try simulated request" }).click();
  await expect(dialog.getByText(/No request was sent/)).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(request).toBeFocused();
  expect(errors).toEqual([]);
});
test("scenario confirmation, correction, safeguards, reset, and patient choice", async ({
  page,
}) => {
  await page.goto("/communication/");
  const next = page.getByRole("button", { name: "Next", exact: true });
  await next.click();
  await expect(next).toBeDisabled();
  await page.getByRole("button", { name: "Correct", exact: true }).click();
  await expect(
    page.getByText("Choose how to correct this message."),
  ).toBeVisible();
  await page.getByRole("button", { name: "Repeat this example" }).click();
  await expect(next).toBeDisabled();
  await page.getByRole("button", { name: "Yes, that’s my message" }).click();
  await expect(next).toBeEnabled();
  await next.click();
  await page.getByLabel("Select Scenario").selectOption("medication");
  await next.click();
  await expect(
    page.getByRole("heading", {
      name: "This conversation needs a qualified interpreter.",
    }),
  ).toBeVisible();
  await expect(next).toBeDisabled();
  await page.getByRole("button", { name: "Restart", exact: true }).click();
  await expect(next).toBeEnabled();
  await page
    .getByLabel("Provider note · demo text only")
    .fill("I have an allergy.");
  await page.getByRole("button", { name: "Add note" }).click();
  await expect(next).toBeDisabled();
  await expect(
    page.getByRole("alert").filter({ hasText: "CONVERSATION PAUSED" }),
  ).toContainText("Allergies");
  await page.getByLabel("Select Scenario").selectOption("interpreter");
  await next.click();
  await expect(
    page.getByRole("heading", { name: "Your choice is respected." }),
  ).toBeVisible();
});
test("preparation checklist, resource companions, and preferences work", async ({
  page,
}) => {
  await page.goto("/preventive-care/");
  const detail = page.getByRole("region", {
    name: "Annual wellness visit preparation",
  });
  const complete = page.getByRole("button", {
    name: "Mark preparation complete",
  });
  await expect(complete).toBeDisabled();
  for (const box of await detail.getByRole("checkbox").all()) await box.check();
  await complete.click();
  await expect(
    page.getByRole("status").filter({ hasText: "Preparation complete" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Vaccination", exact: true }).click();
  await expect(
    page.getByRole("button", { name: /Vaccination appointment/ }),
  ).toBeVisible();
  await page.goto("/resources/");
  await page
    .getByRole("button", { name: "Read companion text" })
    .first()
    .click();
  await expect(
    page.getByRole("heading", { name: "Plain-language companion" }),
  ).toBeVisible();
  await page.goto("/preferences/");
  await page
    .getByLabel("My preferred interpretation support")
    .selectOption("video");
  await page.getByRole("button", { name: "Save demo preferences" }).click();
  await expect(
    page.getByRole("status").filter({ hasText: "Demo preferences saved" }),
  ).toContainText("video remote interpreter");
});

test("preventive preparation includes a correctable teach-back without scoring comprehension", async ({
  page,
}) => {
  await page.goto("/communication/");
  await page.getByLabel("Select Scenario").selectOption("screening");
  const next = page.getByRole("button", { name: "Next", exact: true });
  await next.click();
  await page.getByRole("button", { name: "Yes, that’s my message" }).click();
  await next.click();
  await next.click();
  await page.getByRole("button", { name: "Yes, that’s my message" }).click();
  await next.click();
  await next.click();
  await expect(
    page.getByRole("heading", { name: "Teach-back practice", exact: true }),
  ).toBeVisible();
  await expect(next).toBeDisabled();
  await page.getByRole("button", { name: "Yes, that’s my message" }).click();
  await page.getByRole("button", { name: "Correct", exact: true }).click();
  await expect(next).toBeDisabled();
  await page.getByRole("button", { name: "Repeat this example" }).click();
  await page.getByRole("button", { name: "Yes, that’s my message" }).click();
  await next.click();
  await expect(page.getByRole("log")).toContainText(
    "No comprehension score was calculated",
  );
});

test("Texas research proposal has functional measures, technology pathways, equity lenses, and budget views", async ({
  page,
}) => {
  await page.goto("/research/");
  await expect(
    page.getByRole("region", { name: "Proposed research scope" }),
  ).toContainText("10–12");
  await expect(
    page.getByRole("region", { name: "Proposed research scope" }),
  ).toContainText("$5M");
  await page
    .getByRole("button", { name: "Patient experience", exact: true })
    .click();
  await expect(
    page.getByRole("status").filter({ hasText: "2 proposed measures" }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", {
      name: "Teach-back comprehension",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByText("Proposed evaluation method", { exact: true })
    .first()
    .click();
  await expect(
    page.getByText(/A message-confirmation click is not a comprehension score/),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "English → ASL", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Clinician English → patient ASL",
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByText(/an ASL-interpreting avatar is not implemented/),
  ).toBeVisible();
  await page.getByRole("button", { name: "Black ASL", exact: true }).focus();
  await page.keyboard.press("Enter");
  await expect(
    page.getByRole("heading", {
      name: "Include Black ASL users in research leadership.",
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Cumulative", exact: true }).click();
  await expect(
    page.getByRole("img", { name: /^Cumulative proposed budget/ }),
  ).toHaveAttribute("aria-label", /year 5, \$5.00 million/);
  await page.getByText("View budget as a table", { exact: true }).click();
  await expect(
    page.getByRole("row", { name: "Total $5.00M", exact: true }),
  ).toBeVisible();
  const report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((violation) => ({
      id: violation.id,
      nodes: violation.nodes.map((node) => node.target),
    })),
  ).toEqual([]);
});
test("competition demo can be completed, replayed, and simulate an outage honestly", async ({
  page,
}) => {
  await page.goto("/demo/");
  await expect(
    page.getByRole("heading", { name: "Access starts with being understood." }),
  ).toBeVisible();
  for (let i = 0; i < 3; i++)
    await page.getByRole("button", { name: "Next demo step" }).click();
  await page.getByRole("button", { name: "Simulate outage" }).click();
  await expect(
    page.getByText("Simulated outage — browser network unchanged"),
  ).toBeVisible();
  await expect(page.getByText("Online", { exact: true })).toBeVisible();
  for (let i = 0; i < 4; i++)
    await page.getByRole("button", { name: "Next demo step" }).click();
  await expect(
    page.getByRole("heading", {
      name: "AI should expand access, not replace human choice.",
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Run demo again" }).click();
  await expect(
    page.getByRole("heading", { name: "Access starts with being understood." }),
  ).toBeVisible();
});
test("full toolkit works after actual browser network loss, including first visits to routes", async ({
  page,
  context,
}) => {
  await page.goto("/dashboard/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await context.setOffline(true);
  await page.goto("/communication/");
  await expect(
    page
      .getByText(
        "Offline Mode — Prevalidated communication tools remain available.",
        { exact: true },
      )
      .first(),
  ).toBeVisible();
  await page.getByLabel("Select Scenario").selectOption("outage");
  await page.getByRole("button", { name: "Next", exact: true }).click();
  await expect(page.getByRole("log")).toContainText(
    "Predefined cards remain available offline",
  );
  await page.reload();
  await expect(page.getByLabel("Select Scenario")).toBeVisible();
  await page.goto("/research/");
  await page
    .getByRole("button", { name: "English → ASL", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Clinician English → patient ASL",
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Age groups", exact: true }).click();
  await expect(
    page.getByRole("heading", {
      name: "Study usability and understanding across ages.",
    }),
  ).toBeVisible();
  for (const [route, title] of [
    ["/preventive-care/", "Prepare for a visit"],
    ["/resources/", "ASL resources"],
    ["/safety/", "Safety & patient rights"],
    ["/research/", "Research & impact"],
    ["/demo/", "Competition demo"],
  ]) {
    await page.goto(route);
    await expect(
      page.getByRole("heading", { name: title, exact: true }),
    ).toBeVisible();
  }
  await page
    .getByRole("button", { name: "Request Qualified Interpreter", exact: true })
    .first()
    .click();
  await expect(page.getByRole("dialog")).toContainText(
    "Offline: this form is a local simulation",
  );
  await context.setOffline(false);
});
test("mobile navigation, layout, and interpreter action remain usable", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/dashboard/");
  await expect(
    page
      .getByRole("button", {
        name: "Request Qualified Interpreter",
        exact: true,
      })
      .last(),
  ).toBeVisible();
  await page.getByRole("button", { name: "Open navigation" }).click();
  await page.getByRole("link", { name: "Communication", exact: true }).click();
  await expect(page.getByLabel("Select Scenario")).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "outputs/interpretai-mobile.png",
    fullPage: true,
  });
});
test("camera preview is optional and a denied camera does not block communication", async ({
  page,
}) => {
  await page.goto("/communication/");
  await page
    .getByRole("button", { name: "Enable local camera preview" })
    .click();
  await expect(
    page.getByText(
      /Camera access was declined or unavailable|Camera preview is unavailable/,
    ),
  ).toBeVisible();
  await page.getByRole("button", { name: "Next", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Yes, that’s my message" }),
  ).toBeEnabled();
});
test("core routes pass automated WCAG A/AA checks", async ({ page }) => {
  const violations: unknown[] = [];
  for (const route of [
    "/",
    "/dashboard/",
    "/communication/",
    "/preventive-care/",
    "/preferences/",
    "/resources/",
    "/safety/",
    "/research/",
    "/sample-lab/",
    "/demo/",
    "/signs/",
  ]) {
    await page.goto(route);
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    const report = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    if (report.violations.length)
      violations.push({
        route,
        violations: report.violations.map((v) => ({
          id: v.id,
          nodes: v.nodes.map((n) => ({
            target: n.target,
            summary: n.failureSummary,
          })),
        })),
      });
  }
  writeFileSync(
    "work/accessibility-audit.json",
    JSON.stringify(violations, null, 2),
  );
  expect(
    violations.length,
    "See work/accessibility-audit.json for details",
  ).toBe(0);
});
test("interpreter dialog and safety stop pass accessibility checks", async ({
  page,
}) => {
  await page.goto("/communication/");
  await page.getByLabel("Select Scenario").selectOption("medication");
  await page.getByRole("button", { name: "Next", exact: true }).click();
  let report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((v) => ({
      id: v.id,
      nodes: v.nodes.map((n) => ({
        target: n.target,
        summary: n.failureSummary,
      })),
    })),
  ).toEqual([]);
  await page
    .getByRole("button", { name: "Request Qualified Interpreter", exact: true })
    .first()
    .click();
  report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((v) => ({
      id: v.id,
      nodes: v.nodes.map((n) => ({
        target: n.target,
        summary: n.failureSummary,
      })),
    })),
  ).toEqual([]);
});
test("small mobile and tablet layouts do not overflow", async ({ page }) => {
  const problems: unknown[] = [];
  for (const width of [320, 768]) {
    await page.setViewportSize({ width, height: 900 });
    for (const route of [
      "/",
      "/dashboard/",
      "/communication/",
      "/preventive-care/",
      "/research/",
      "/sample-lab/",
      "/demo/",
      "/signs/",
    ]) {
      await page.goto(route);
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
      const overflow = await page.evaluate(() =>
        Array.from(document.querySelectorAll("body *"))
          .filter((e) => {
            const r = e.getBoundingClientRect();
            return r.width > 0 && r.right > window.innerWidth + 1;
          })
          .map((e) => ({
            tag: e.tagName,
            css: e.className,
            right: e.getBoundingClientRect().right,
          }))
          .slice(0, 20),
      );
      if (
        await page.evaluate(
          () => document.documentElement.scrollWidth > window.innerWidth,
        )
      )
        problems.push({ width, route, overflow });
    }
  }
  writeFileSync("work/layout-audit.json", JSON.stringify(problems, null, 2));
  expect(problems.length, "See work/layout-audit.json").toBe(0);
});
test("mobile navigation manages keyboard focus and closes with Escape", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/dashboard/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await expect(
    page.getByRole("link", { name: "My overview", exact: true }),
  ).not.toBeVisible();
  const toggle = page.getByRole("button", { name: "Open navigation" });
  await toggle.click();
  const navigation = page.getByRole("dialog", { name: "Main navigation" });
  await expect(navigation).toBeVisible();
  await page.keyboard.press("Shift+Tab");
  await expect(
    navigation.getByRole("button", { name: "Request Qualified Interpreter" }),
  ).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(navigation.getByRole("link").first()).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(navigation).not.toBeVisible();
  await expect(toggle).toBeFocused();
});
test("capture desktop overview and landing", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1050 });
  await page.goto("/dashboard/");
  await expect(
    page.getByRole("heading", { name: "Your next visit, in focus." }),
  ).toBeVisible();
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({
    path: "outputs/interpretai-dashboard.png",
    fullPage: true,
  });
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await page.screenshot({
    path: "outputs/interpretai-landing.png",
    fullPage: true,
  });
  await page.screenshot({
    path: "outputs/interpretai-redesign.png",
    fullPage: false,
  });
  await page.goto("/communication/");
  await expect(page.getByLabel("Select Scenario")).toBeVisible();
  await page.screenshot({
    path: "outputs/interpretai-workspace.png",
    fullPage: true,
  });
  await page.goto("/research/");
  await expect(
    page.getByRole("heading", { name: "Research & impact", exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: "outputs/interpretai-research.png",
    fullPage: true,
  });
});
