import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
test.use({
  launchOptions: {
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || undefined,
    args: [
      "--use-fake-device-for-media-stream",
      "--use-fake-ui-for-media-stream",
    ],
  },
});

test("scripted avatar works without downloading models and never fabricates a camera result", async ({
  page,
}) => {
  const optionalRequests: string[] = [];
  page.on("request", (request) => {
    if (request.url().includes("/lab-assets/"))
      optionalRequests.push(request.url());
  });
  await page.goto("/sample-lab/");
  await expect(
    page.getByRole("button", {
      name: "Download recognition tools",
      exact: true,
    }),
  ).toBeEnabled();
  await expect(
    page.getByRole("button", { name: "Play pose transition", exact: true }),
  ).toBeEnabled();
  await page.getByRole("button", { name: "Handshape Y", exact: true }).click();
  await page
    .getByRole("combobox", { name: "Playback speed", exact: true })
    .selectOption("0.5");
  await page
    .getByRole("combobox", { name: "Avatar view", exact: true })
    .selectOption("angled");
  await page
    .getByRole("button", { name: "Play pose transition", exact: true })
    .click();
  await expect(
    page.getByRole("img", {
      name: /Scripted avatar pose illustration for the Y handshape/,
    }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", {
      name: "Candidate handshape: Unknown",
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", {
      name: "Confirm & preview handshape",
      exact: true,
    }),
  ).toBeDisabled();
  expect(optionalRequests).toEqual([]);
  const report = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
    .analyze();
  expect(
    report.violations.map((violation) => ({
      id: violation.id,
      nodes: violation.nodes.map((node) => node.target),
    })),
  ).toEqual([]);
  await page.setViewportSize({ width: 1440, height: 1100 });
  await page.getByRole("button", { name: "Handshape L", exact: true }).click();
  await page.getByRole("button", { name: "Handshape Y", exact: true }).click();
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.screenshot({
    path: "outputs/interpretai-sample-lab.png",
    fullPage: true,
  });
});

test("real local tracker runs on a blank fake camera, rejects it, stops tracks, and initializes offline after explicit download", async ({
  page,
  context,
}) => {
  test.setTimeout(120000);
  await context.grantPermissions(["camera"]);
  const externalRequests: string[] = [];
  page.on("request", (request) => {
    if (
      /^https?:/.test(request.url()) &&
      !request.url().startsWith("http://127.0.0.1:3000/")
    )
      externalRequests.push(request.url());
  });
  await page.goto("/sample-lab/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Download recognition tools", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible({ timeout: 45000 });
  await page
    .getByRole("button", {
      name: "Enable camera & handshape matching",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("button", { name: "Stop camera & tracking", exact: true }),
  ).toBeVisible({ timeout: 45000 });
  await expect(
    page.getByText("No hand detected. Move one hand into the frame.", {
      exact: true,
    }),
  ).toBeVisible({ timeout: 20000 });
  await expect(
    page.getByRole("heading", {
      name: "Candidate handshape: Unknown",
      exact: true,
    }),
  ).toBeVisible();
  const firstTrack = await page.evaluateHandle(
    () =>
      (
        document.querySelector("video")!.srcObject as MediaStream
      ).getVideoTracks()[0],
  );
  await page
    .getByRole("button", { name: "Stop camera & tracking", exact: true })
    .click();
  expect(await firstTrack.evaluate((track) => track.readyState)).toBe("ended");
  await context.setOffline(true);
  await page.reload();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Enable camera & handshape matching",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("button", { name: "Stop camera & tracking", exact: true }),
  ).toBeVisible({ timeout: 45000 });
  await expect(
    page.getByText("No hand detected. Move one hand into the frame.", {
      exact: true,
    }),
  ).toBeVisible({ timeout: 20000 });
  const secondTrack = await page.evaluateHandle(
    () =>
      (
        document.querySelector("video")!.srcObject as MediaStream
      ).getVideoTracks()[0],
  );
  expect(
    await page.evaluate(
      () =>
        (
          document.querySelector("video")!.srcObject as MediaStream
        ).getAudioTracks().length,
    ),
  ).toBe(0);
  await page.getByRole("link", { name: "Communication", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Communication workspace", exact: true }),
  ).toBeVisible();
  await expect
    .poll(() => secondTrack.evaluate((track) => track.readyState))
    .toBe("ended");
  await expect.poll(() => page.workers().length).toBe(0);
  await context.setOffline(false);
  expect(externalRequests).toEqual([]);
});

test("camera cancellation and a simulated permission denial leave no worker running and preserve the core offline toolkit", async ({
  page,
  context,
}) => {
  test.setTimeout(90000);
  await page.goto("/sample-lab/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Download recognition tools", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible({ timeout: 45000 });
  await page
    .getByRole("button", {
      name: "Enable camera & handshape matching",
      exact: true,
    })
    .click();
  await page
    .getByRole("button", { name: /Cancel camera start|Stop camera & tracking/ })
    .click();
  await expect.poll(() => page.workers().length).toBe(0);
  await page.evaluate(() => {
    navigator.mediaDevices.getUserMedia = async () => {
      throw new DOMException("Test denial", "NotAllowedError");
    };
  });
  await page
    .getByRole("button", {
      name: "Enable camera & handshape matching",
      exact: true,
    })
    .click();
  await expect(
    page
      .getByRole("alert")
      .filter({ hasText: /Camera permission was declined/ }),
  ).toBeVisible({ timeout: 45000 });
  await expect.poll(() => page.workers().length).toBe(0);
  await page
    .getByRole("button", { name: "Remove downloaded tools", exact: true })
    .click();
  await expect(
    page.getByRole("button", {
      name: "Enable camera & handshape matching",
      exact: true,
    }),
  ).toBeDisabled();
  await context.setOffline(true);
  await page.goto("/communication/");
  await expect(page.getByLabel("Select Scenario")).toBeVisible();
  await context.setOffline(false);
});

test.describe("optional download failure", () => {
  test.use({ serviceWorkers: "block" });
  test("a failed optional download leaves the scripted avatar and interpreter choice usable", async ({
    page,
  }) => {
    await page.route("**/lab-assets/**", (route) => route.abort());
    await page.goto("/sample-lab/");
    await page
      .getByRole("button", { name: "Download recognition tools", exact: true })
      .click();
    await expect(
      page.getByRole("alert").filter({ hasText: /fetch|download/i }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", {
        name: "Enable camera & handshape matching",
        exact: true,
      }),
    ).toBeDisabled();
    await page
      .getByRole("button", { name: "Handshape Y", exact: true })
      .click();
    await expect(
      page.getByRole("button", { name: "Play pose transition", exact: true }),
    ).toBeEnabled();
    await page
      .getByRole("button", {
        name: "Request Qualified Interpreter",
        exact: true,
      })
      .first()
      .click();
    await expect(page.getByRole("dialog")).toBeVisible();
  });
});
