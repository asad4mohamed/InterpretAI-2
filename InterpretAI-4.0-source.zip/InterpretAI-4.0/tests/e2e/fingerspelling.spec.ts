import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

const exe = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || undefined;

async function downloadTools(page: Page) {
  await page.goto("/sample-lab/");
  await expect(
    page.getByText("Offline toolkit ready", { exact: true }),
  ).toBeVisible({ timeout: 30000 });
  await page
    .getByRole("button", { name: "Download recognition tools", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Recognition tools downloaded",
      exact: true,
    }),
  ).toBeVisible({ timeout: 45000 });
}

test.use({
  launchOptions: {
    executablePath: exe,
    args: [
      "--use-fake-device-for-media-stream",
      "--use-fake-ui-for-media-stream",
    ],
  },
  permissions: ["camera"],
});

test.describe("fingerspelling with a blank fake camera", () => {
  test("honest model information, live readout, pause/resume, latency, and cleanup", async ({
    page,
  }) => {
    test.setTimeout(120000);
    await downloadTools(page);
    await page.goto("/communication/#live");
    await page.getByRole("radio", { name: /ASL fingerspelling/ }).check();
    const info = page.locator(".model-info");
    await expect(info).toContainText("24 static letters");
    await expect(info).toContainText("J and Z (movement) are not supported");
    await expect(info).toContainText("Not signer-independent");
    await expect(
      info.getByRole("listitem").filter({ hasText: "Fingerspelling" }),
    ).toHaveClass(/yes/);
    await expect(
      info.getByRole("listitem").filter({ hasText: "Sentence translation" }),
    ).toHaveClass(/no/);
    await expect(
      page.locator(".mode-option").filter({ hasText: "ASL fingerspelling" }),
    ).toContainText("Available");
    const report = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      report.violations.map((v) => ({
        id: v.id,
        nodes: v.nodes.map((n) => n.target),
      })),
    ).toEqual([]);
    await page
      .getByRole("checkbox", { name: /I agree to turn on my camera/ })
      .check();
    await page
      .getByRole("button", { name: "Start camera", exact: true })
      .click();
    const readout = page.locator(".fingerspell-readout");
    await expect(readout).toContainText("Show one hand to the camera", {
      timeout: 45000,
    });
    await expect(readout).toContainText(/Tracking \d+ ms\/frame/);
    await expect(
      page.getByRole("button", { name: "Review this spelling" }),
    ).toBeDisabled();
    await page.getByRole("button", { name: "Pause recognition" }).click();
    await expect(readout).toContainText("Paused");
    await page.getByRole("button", { name: "Resume recognition" }).click();
    await expect(readout).toContainText("Show one hand to the camera");
    await page.getByRole("button", { name: "Stop camera now" }).click();
    await expect.poll(() => page.workers().length).toBe(0);
  });
});

test("the fingerspelling model works offline after the first visit; cloud modes do not", async ({
  page,
  context,
}) => {
  test.setTimeout(120000);
  await downloadTools(page);
  await page.goto("/communication/#live");
  await page.getByRole("radio", { name: /ASL fingerspelling/ }).check();
  await expect(page.locator(".model-info")).toContainText("Ready");
  await context.setOffline(true);
  await page.reload();
  await page.getByRole("radio", { name: /ASL fingerspelling/ }).check();
  await expect(
    page.locator(".mode-option").filter({ hasText: "ASL fingerspelling" }),
  ).toContainText("Available");
  await expect(
    page.locator(".mode-option").filter({ hasText: "Hugging Face" }),
  ).toContainText(/Not configured|Offline/);
  await page
    .getByRole("checkbox", { name: /I agree to turn on my camera/ })
    .check();
  await page.getByRole("button", { name: "Start camera", exact: true }).click();
  await expect(page.locator(".fingerspell-readout")).toContainText(
    "Show one hand to the camera",
    { timeout: 45000 },
  );
  await page.getByRole("button", { name: "Stop camera now" }).click();
  await context.setOffline(false);
});

test.describe("Hugging Face photo recognition (mocked proxy)", () => {
  test.use({ bypassCSP: true });
  test("one photo, per-photo consent, real returned labels, review, and model-unavailable errors", async ({
    page,
  }) => {
    const PROXY = "http://127.0.0.1:8787";
    let gone = false;
    const posts: string[] = [];
    await page.route("**/runtime-config.json", (route) =>
      route.fulfill({ json: { proxyUrl: PROXY } }),
    );
    await page.route(`${PROXY}/**`, async (route) => {
      const url = new URL(route.request().url());
      if (url.pathname === "/health")
        return route.fulfill({
          json: {
            ok: true,
            signSpeak: { recognition: false, production: false },
            huggingFace: {
              configured: true,
              tokenSet: true,
              target: "dedicated-endpoint",
              modelId: "org/asl-letters",
            },
          },
        });
      posts.push(
        `${route.request().method()} ${url.pathname} ${route.request().headers()["content-type"]}`,
      );
      if (gone)
        return route.fulfill({
          status: 404,
          json: {
            error: {
              code: "model-unavailable",
              message:
                "This model is not served at the configured Hugging Face target.",
            },
          },
        });
      return route.fulfill({
        json: {
          status: "completed",
          model: "org/asl-letters",
          result: [
            { label: "A", score: 0.81 },
            { label: "S", score: 0.1 },
          ],
        },
      });
    });
    await page.goto("/communication/#live");
    await page.getByRole("radio", { name: /Hugging Face/ }).check();
    await expect(page.locator(".model-info")).toContainText(
      "org/asl-letters via Dedicated Inference Endpoint",
    );
    await page
      .getByRole("checkbox", { name: /I agree to turn on my camera/ })
      .check();
    await page
      .getByRole("button", { name: "Start camera", exact: true })
      .click();
    await page.getByRole("button", { name: "Take photo" }).click();
    await expect(
      page.getByRole("img", { name: /still photo you took/ }),
    ).toBeVisible();
    const send = page.getByRole("button", {
      name: "Send photo for recognition",
    });
    await expect(send).toBeDisabled();
    expect(posts).toEqual([]);
    await page
      .getByRole("checkbox", { name: /Send this one photo to Hugging Face/ })
      .check();
    await send.click();
    const review = page.locator(".review-queue");
    await expect(review).toContainText("Hugging Face model · cloud");
    await expect(review).toContainText("Provider-reported score 81%");
    expect(posts).toEqual(["POST /v1/hf/classify-image image/jpeg"]);
    await review
      .getByRole("button", { name: "That’s not what I signed" })
      .click();
    await expect(page.getByRole("log")).toContainText("No messages yet.");
    gone = true;
    await page.getByRole("button", { name: "Take photo" }).click();
    await page
      .getByRole("checkbox", { name: /Send this one photo to Hugging Face/ })
      .check();
    await page
      .getByRole("button", { name: "Send photo for recognition" })
      .click();
    await expect(page.locator(".live-status")).toContainText(
      "not served at the configured Hugging Face target",
    );
    await page.getByRole("button", { name: "Stop camera now" }).click();
  });
});
