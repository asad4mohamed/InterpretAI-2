import { describe, expect, it } from "vitest";
import {
  defaultConfig,
  loadPublicConfig,
  normalizeConfig,
} from "../lib/asl/config";
import {
  parseSignSpeakRecognition,
  validateClip,
  validateSequence,
} from "../lib/asl/validation";
import {
  FEATURES_PER_FRAME,
  SequenceRecorder,
  handCoverage,
  normalizeHandShape,
  sequenceToFeatures,
  signerHandedness,
  smoothSequence,
} from "../lib/asl/landmark-sequence";
import { RecognitionError } from "../lib/asl/types";
import {
  handFixture,
  observation,
  sequenceOf,
  steadySequence,
} from "./fixtures/hands";

const clip = (bytes: number, type = "video/webm", durationMs = 2000) => ({
  blob: new Blob([new Uint8Array(bytes)], { type }),
  mimeType: type,
  durationMs,
});
const code = (fn: () => unknown) => {
  try {
    fn();
  } catch (failure) {
    return failure instanceof RecognitionError ? failure.code : "other";
  }
  return "none";
};

describe("public configuration never trusts unsafe values", () => {
  it("accepts loopback HTTP and HTTPS proxies, rejects remote HTTP and script URLs", () => {
    expect(
      normalizeConfig({ proxyUrl: "http://127.0.0.1:8787/" }, "build-env")
        .proxyUrl,
    ).toBe("http://127.0.0.1:8787");
    expect(
      normalizeConfig({ proxyUrl: "https://proxy.example.org" }, "build-env")
        .proxyUrl,
    ).toBe("https://proxy.example.org");
    expect(
      normalizeConfig({ proxyUrl: "http://proxy.example.org" }, "build-env")
        .proxyUrl,
    ).toBeNull();
    expect(
      normalizeConfig({ proxyUrl: "javascript:alert(1)" }, "build-env")
        .proxyUrl,
    ).toBeNull();
  });
  it("only allows same-origin model manifests and known avatar providers", () => {
    expect(
      normalizeConfig(
        { localModelManifestUrl: "/models/a/manifest.json" },
        "build-env",
      ).localModelManifestUrl,
    ).toBe("/models/a/manifest.json");
    expect(
      normalizeConfig(
        { localModelManifestUrl: "//evil.example/m.json" },
        "build-env",
      ).localModelManifestUrl,
    ).toBeNull();
    expect(
      normalizeConfig(
        { localModelManifestUrl: "https://evil.example/m.json" },
        "build-env",
      ).localModelManifestUrl,
    ).toBeNull();
    expect(
      normalizeConfig({ avatarProvider: "other" }, "build-env").avatarProvider,
    ).toBe("none");
  });
  it("bounds clip limits", () => {
    expect(
      normalizeConfig({ maxClipSeconds: 999 }, "build-env").maxClipSeconds,
    ).toBe(30);
    expect(
      normalizeConfig({ maxClipSeconds: "abc" }, "build-env").maxClipSeconds,
    ).toBe(defaultConfig.maxClipSeconds);
  });
  it("falls back to safe defaults when runtime config is missing", async () => {
    const config = await loadPublicConfig(
      async () => new Response("", { status: 404 }),
    );
    expect(config.proxyUrl).toBeNull();
    expect(config.avatarProvider).toBe("none");
    const failing = await loadPublicConfig(async () => {
      throw new TypeError("offline");
    });
    expect(failing.source).toBe("defaults");
  });
});

describe("clip validation happens before any upload", () => {
  const limits = { maxClipBytes: 1000, maxClipSeconds: 10 };
  it("accepts WebM and MP4 within limits", () => {
    expect(validateClip(clip(10), limits)).toBe("video/webm");
    expect(validateClip(clip(10, "video/mp4"), limits)).toBe("video/mp4");
    expect(validateClip(clip(10, "video/webm;codecs=vp9"), limits)).toBe(
      "video/webm",
    );
  });
  it.each([
    ["wrong type", clip(10, "image/png")],
    ["empty", clip(0)],
    ["too large", clip(5000)],
    ["too short", clip(10, "video/webm", 100)],
    ["too long", clip(10, "video/webm", 20000)],
  ])("rejects %s", (_, input) =>
    expect(code(() => validateClip(input, limits))).toBe("invalid-input"),
  );
});

describe("Sign-Speak response parsing follows the documented shape only", () => {
  it("keeps provider text and labels provider-reported confidence", () => {
    const parsed = parseSignSpeakRecognition({
      feedback_id: "f1",
      prediction: [
        {
          feedback_id: "f1",
          timestamp_start_sec: 0,
          timestamp_end_sec: 1.2,
          finished: true,
          prediction: "HELLO",
          confidence: 0.82,
        },
      ],
    });
    expect(parsed.reference).toBe("f1");
    expect(parsed.hypotheses[0].text).toBe("HELLO");
    expect(parsed.hypotheses[0].confidence).toMatchObject({
      kind: "provider-reported",
      value: 0.82,
    });
  });
  it("never invents confidence or text", () => {
    const parsed = parseSignSpeakRecognition({
      prediction: [{ prediction: "YES" }, { prediction: "  " }],
    });
    expect(parsed.hypotheses).toHaveLength(1);
    expect(parsed.hypotheses[0].confidence.kind).toBe("none");
    expect(parseSignSpeakRecognition({ prediction: [] }).hypotheses).toEqual(
      [],
    );
  });
  it.each([
    null,
    "text",
    {},
    { prediction: "HELLO" },
    { prediction: [{ text: "x" }] },
  ])("rejects malformed response %j", (data) =>
    expect(code(() => parseSignSpeakRecognition(data))).toBe(
      "invalid-response",
    ),
  );
});

describe("temporal landmark sequences", () => {
  it("corrects MediaPipe's mirrored handedness for unmirrored frames", () => {
    expect(signerHandedness("Left")).toBe("Right");
    expect(signerHandedness("Right")).toBe("Left");
    expect(signerHandedness("Unknown")).toBeNull();
  });
  it("normalises hand shape for size and position but not rotation", () => {
    const hand = handFixture([0]);
    const moved = hand.map((p) => ({
      x: p.x * 3 + 5,
      y: p.y * 3 - 2,
      z: p.z * 3,
    }));
    const a = normalizeHandShape(hand)!;
    const b = normalizeHandShape(moved)!;
    a.forEach((p, i) => {
      expect(b[i].x).toBeCloseTo(p.x, 6);
      expect(b[i].y).toBeCloseTo(p.y, 6);
    });
    const rotated = hand.map((p) => ({ x: -p.y, y: p.x, z: p.z }));
    expect(normalizeHandShape(rotated)![8].x).not.toBeCloseTo(a[8].x, 2);
    expect(
      normalizeHandShape(
        Array.from({ length: 21 }, () => ({ x: 0, y: 0, z: 0 })),
      ),
    ).toBeNull();
  });
  it("keeps absent hands as explicit zero-presence slots", () => {
    const seq = steadySequence(4, () => [
      observation(handFixture([0]), "Left"),
    ]);
    const features = sequenceToFeatures(seq, 4);
    expect(features.length).toBe(4 * FEATURES_PER_FRAME);
    expect(features[0]).toBe(0); // Right slot absent
    expect(features[FEATURES_PER_FRAME / 2]).toBe(1); // Left slot present
  });
  it("does not interpolate a hand into frames where it was absent", () => {
    const seq = sequenceOf([
      { t: 0, hands: [observation(handFixture([0]))] },
      { t: 100, hands: [] },
      { t: 200, hands: [observation(handFixture([0]))] },
    ]);
    const features = sequenceToFeatures(seq, 5);
    const presence = Array.from(
      { length: 5 },
      (_, k) => features[k * FEATURES_PER_FRAME],
    );
    expect(presence).toContain(0);
    expect(handCoverage(seq)).toBeCloseTo(2 / 3);
  });
  it("smooths jitter and resets smoothing when a hand disappears", () => {
    const base = handFixture([0]);
    const jitter = base.map((p) => ({ ...p, x: p.x + 0.2 }));
    const smoothed = smoothSequence(
      sequenceOf([
        { t: 0, hands: [observation(base)] },
        { t: 100, hands: [observation(jitter)] },
        { t: 200, hands: [] },
        { t: 300, hands: [observation(jitter)] },
      ]),
      0.5,
    );
    expect(smoothed.frames[1].hands[0].world[8].x).toBeCloseTo(base[8].x + 0.1);
    expect(smoothed.frames[3].hands[0].world[8].x).toBeCloseTo(jitter[8].x);
  });
  it("validates sequences strictly", () => {
    expect(
      code(() => validateSequence(sequenceOf([{ t: 0, hands: [] }]))),
    ).toBe("invalid-input");
    expect(
      code(() =>
        validateSequence(
          sequenceOf([
            { t: 0, hands: [] },
            { t: 0, hands: [] },
          ]),
        ),
      ),
    ).toBe("invalid-input");
    expect(code(() => validateSequence(steadySequence(3, () => [])))).toBe(
      "invalid-input",
    );
    const broken = steadySequence(3, () => [observation(handFixture([0]))]);
    broken.frames[1].hands[0].world = broken.frames[1].hands[0].world.slice(
      0,
      10,
    );
    expect(code(() => validateSequence(broken))).toBe("invalid-input");
    expect(
      code(() =>
        validateSequence(
          steadySequence(3, () => [observation(handFixture([0]))]),
        ),
      ),
    ).toBe("none");
  });
  it("records only strictly increasing frames up to a cap, then clears", () => {
    const recorder = new SequenceRecorder(2);
    expect(recorder.push({ t: 1, hands: [] })).toBe(true);
    expect(recorder.push({ t: 1, hands: [] })).toBe(false);
    expect(recorder.push({ t: 2, hands: [] })).toBe(true);
    expect(recorder.push({ t: 3, hands: [] })).toBe(false);
    expect(recorder.finish().frames).toHaveLength(2);
    expect(recorder.size).toBe(0);
  });
});
