import { expect, it } from "vitest";
import { staticExportPath } from "../lib/static-export-path.mjs";
it("maps flattened Next.js segment payloads to their actual static files", () => {
  expect(staticExportPath("/dashboard/__next.dashboard.__PAGE__.txt")).toBe(
    "/dashboard/__next.dashboard/__PAGE__.txt",
  );
  expect(staticExportPath("/research/__next.research.__PAGE__.txt")).toBe(
    "/research/__next.research/__PAGE__.txt",
  );
});
it("preserves navigation, normal assets, and already exported segment paths", () => {
  for (const pathname of [
    "/sample-lab/",
    "/__next._tree.txt",
    "/dashboard/__next.dashboard/__PAGE__.txt",
    "/lab-assets/mp1.1.1-model1/vision_bundle.mjs",
  ])
    expect(staticExportPath(pathname)).toBe(pathname);
});
