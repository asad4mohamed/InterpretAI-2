import { afterAll, beforeAll, describe, expect, it } from "vitest";
import http from "node:http";
import type { AddressInfo } from "node:net";
import { createProxyServer, readConfig } from "../server/proxy.mjs";

/**
 * Exercises server/proxy.mjs against a local MOCK of Sign-Speak's documented
 * REST shape. No request reaches the real Sign-Speak service.
 */
type Captured = { method?: string; url?: string; key?: string; body: string };
const seen: Captured[] = [];
let mode: "ok" | "async" | "unauthorized" | "slow" | "garbage" = "ok";
let polls = 0;
const upstream = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    seen.push({
      method: req.method,
      url: req.url,
      key: String(req.headers["x-api-key"]),
      body,
    });
    const json = (status: number, data: unknown) => {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(data));
    };
    if (mode === "unauthorized") return json(401, { detail: "bad key" });
    if (mode === "slow") return setTimeout(() => json(200, {}), 500);
    if (mode === "garbage") {
      res.writeHead(200);
      return res.end("not json");
    }
    if (req.url === "/recognize-sign" && mode === "async")
      return json(202, { batch_id: "batch-1" });
    if (req.url === "/recognize-sign/batch-1") {
      polls++;
      return polls < 2
        ? json(202, {})
        : json(200, {
            feedback_id: "fb",
            prediction: [{ prediction: "HELLO", confidence: 0.9 }],
          });
    }
    if (req.url === "/recognize-sign")
      return json(200, {
        feedback_id: "fb",
        prediction: [{ prediction: "HELLO", confidence: 0.9 }],
      });
    if (req.url === "/produce-sign") {
      res.writeHead(200, { "Content-Type": "application/octet-stream" });
      const mp4 = Buffer.alloc(32);
      mp4.write("ftyp", 4, "ascii");
      return res.end(mp4);
    }
    json(404, {});
  });
});

let upstreamUrl = "";
const logs: string[] = [];
const start = async (env: Record<string, string>) => {
  const server = createProxyServer(
    readConfig({
      SIGN_SPEAK_API_BASE: upstreamUrl,
      PROXY_UPSTREAM_TIMEOUT_MS: "200",
      PROXY_MAX_UPLOAD_BYTES: "1000",
      ...env,
    }),
    { log: (line: string) => logs.push(line) },
  ) as http.Server;
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return { server, base };
};
const video = (bytes = 50) => new Uint8Array(bytes).fill(7);
const post = (
  base: string,
  headers: Record<string, string> = {},
  body: BodyInit = video(),
) =>
  fetch(`${base}/v1/sign-speak/recognize`, {
    method: "POST",
    headers: {
      "Content-Type": "video/webm",
      "X-InterpretAI-Consent": "sign-speak",
      Origin: "http://127.0.0.1:3000",
      ...headers,
    },
    body,
  });

let withKey: { server: http.Server; base: string };
let withoutKey: { server: http.Server; base: string };
beforeAll(async () => {
  await new Promise<void>((r) => upstream.listen(0, "127.0.0.1", r));
  upstreamUrl = `http://127.0.0.1:${(upstream.address() as AddressInfo).port}`;
  withKey = await start({ SIGN_SPEAK_API_KEY: "test-secret-key-123" });
  withoutKey = await start({});
});
afterAll(() => {
  upstream.close();
  withKey.server.close();
  withoutKey.server.close();
});

describe("optional secure proxy", () => {
  it("reports configuration without revealing the key", async () => {
    const health = await (await fetch(`${withKey.base}/health`)).text();
    expect(JSON.parse(health)).toEqual({
      ok: true,
      signSpeak: { recognition: true, production: true },
      huggingFace: {
        configured: false,
        tokenSet: false,
        target: null,
        modelId: null,
      },
    });
    expect(health).not.toContain("test-secret");
    expect(
      await (await fetch(`${withoutKey.base}/health`)).json(),
    ).toMatchObject({ signSpeak: { recognition: false } });
  });
  it("returns 503 when no key is configured", async () => {
    const response = await post(withoutKey.base);
    expect(response.status).toBe(503);
    expect((await response.json()).error.code).toBe("not-configured");
  });
  it("enforces CORS origin, consent header, media type, and size limits before forwarding", async () => {
    const before = seen.length;
    expect(
      (await post(withKey.base, { Origin: "https://evil.example" })).status,
    ).toBe(403);
    expect(
      (await post(withKey.base, { "X-InterpretAI-Consent": "" })).status,
    ).toBe(428);
    expect(
      (await post(withKey.base, { "Content-Type": "image/png" })).status,
    ).toBe(415);
    expect((await post(withKey.base, {}, video(5000))).status).toBe(413);
    expect(seen.length).toBe(before);
  });
  it("adds the server-side key, base64-encodes the clip, and relays the documented result", async () => {
    mode = "ok";
    const response = await post(withKey.base);
    expect(response.status).toBe(200);
    expect(response.headers.get("access-control-allow-origin")).toBe(
      "http://127.0.0.1:3000",
    );
    expect(response.headers.get("cache-control")).toBe("no-store");
    const data = await response.json();
    expect(data).toMatchObject({
      status: "completed",
      result: { prediction: [{ prediction: "HELLO" }] },
    });
    const call = seen[seen.length - 1];
    expect(call.key).toBe("test-secret-key-123");
    const sent = JSON.parse(call.body);
    expect(sent).toMatchObject({
      request_class: "BLOCKING",
      single_recognition_mode: true,
      model: "SLR.2.sm",
    });
    expect(Buffer.from(sent.payload, "base64")).toEqual(Buffer.from(video()));
    expect(JSON.stringify(data)).not.toContain("test-secret");
  });
  it("converts Sign-Speak's 202 batch_id into an opaque request ID and polls", async () => {
    mode = "async";
    polls = 0;
    const first = await post(withKey.base);
    expect(first.status).toBe(202);
    const { requestId } = await first.json();
    expect(requestId).not.toBe("batch-1");
    const poll = () =>
      fetch(`${withKey.base}/v1/sign-speak/recognize/${requestId}`);
    expect((await poll()).status).toBe(202);
    const done = await poll();
    expect(done.status).toBe(200);
    expect((await done.json()).status).toBe("completed");
    expect((await poll()).status).toBe(404); // completed requests are forgotten
    expect(
      (await fetch(`${withKey.base}/v1/sign-speak/recognize/made-up-id`))
        .status,
    ).toBe(404);
  });
  it("maps upstream auth failures, timeouts, and malformed responses", async () => {
    mode = "unauthorized";
    expect((await post(withKey.base)).status).toBe(401);
    mode = "slow";
    expect((await post(withKey.base)).status).toBe(504);
    mode = "garbage";
    expect((await post(withKey.base)).status).toBe(502);
    mode = "ok";
  });
  it("relays production video and validates text input", async () => {
    const produce = (body: unknown) =>
      fetch(`${withKey.base}/v1/sign-speak/produce`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    const response = await produce({ english: "Hello" });
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("video/mp4");
    expect((await produce({ english: "" })).status).toBe(400);
    expect((await produce({ english: "x".repeat(600) })).status).toBe(400);
  });
  it("never logs request bodies, recognised text, or keys", () => {
    const all = logs.join("\n");
    expect(all).not.toMatch(/HELLO|test-secret|Bwc|payload/);
    expect(all).toMatch(/POST \/v1\/sign-speak\/recognize 200/);
  });
});
