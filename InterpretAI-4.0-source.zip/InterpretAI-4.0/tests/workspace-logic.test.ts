import { describe, expect, it, vi } from "vitest";
import { defaultConfig } from "../lib/asl/config";
import {
  avatarAvailability,
  avatarDescriptors,
  checkAvatarText,
  produceSignSpeakVideo,
} from "../lib/asl/avatar";
import {
  conversationReducer,
  emptyConversation,
  phaseForError,
  phaseLabels,
} from "../lib/asl/recognition-state";
import type { RecognitionResult } from "../lib/asl/types";
import {
  classifyCameraError,
  monotonicTimestamp,
  nextFrameInterval,
  stopStream,
  trackingState,
  updateAverage,
} from "../lib/camera";

const result = (texts: string[]): RecognitionResult => ({
  providerId: "sign-speak",
  mode: "external-api",
  granularity: "continuous-english",
  location: "cloud",
  outcome: texts.length ? "recognized" : "unknown",
  hypotheses: texts.map((text) => ({
    text,
    confidence: { kind: "provider-reported", value: 0.5, note: "" },
    startSec: null,
    endSec: null,
  })),
  providerReference: null,
  modelVersion: null,
  receivedAt: 0,
});

describe("Patient correction and conversation state", () => {
  it("never adds unknown results to the conversation", () => {
    expect(
      conversationReducer(emptyConversation, {
        type: "recognized",
        id: "a",
        result: result([]),
      }),
    ).toBe(emptyConversation);
  });
  it("starts recognised text as pending review and only the patient decides", () => {
    let state = conversationReducer(emptyConversation, {
      type: "recognized",
      id: "a",
      result: result(["HELLO"]),
    });
    expect(state.entries[0]).toMatchObject({
      status: "pending-review",
      source: "sign-speak",
      location: "cloud",
    });
    state = conversationReducer(state, { type: "confirm", id: "a" });
    expect(state.entries[0].status).toBe("confirmed");
    expect(conversationReducer(state, { type: "confirm", id: "a" })).toBe(
      state,
    );
  });
  it("rejects and corrects while keeping the original recognised text visible", () => {
    let state = conversationReducer(emptyConversation, {
      type: "recognized",
      id: "a",
      result: result(["HELLO"]),
    });
    expect(
      conversationReducer(state, { type: "reject", id: "a" }).entries[0].status,
    ).toBe("rejected");
    state = conversationReducer(state, {
      type: "correct",
      id: "a",
      text: "Hi there",
    });
    expect(state.entries[0]).toMatchObject({
      text: "Hi there",
      correctedFrom: "HELLO",
      status: "corrected",
      source: "typed",
      confidence: undefined,
    });
    expect(
      conversationReducer(state, { type: "correct", id: "a", text: "   " }),
    ).toBe(state);
  });
  it("escalates high-risk recognised, corrected, and provider text, and clears fully", () => {
    let state = conversationReducer(emptyConversation, {
      type: "recognized",
      id: "a",
      result: result(["chest pain"]),
      risk: "Emergency symptoms",
    });
    expect(state.escalation).toBe("Emergency symptoms");
    expect(state.entries[0].status).toBe("escalated");
    state = conversationReducer(state, {
      type: "provider-text",
      id: "b",
      text: "Take 2 pills",
      risk: "Medication dosing",
    });
    expect(state.escalation).toBe("Medication dosing");
    expect(conversationReducer(state, { type: "clear" })).toEqual(
      emptyConversation,
    );
  });
  it("does not let provider entries be confirmed as patient messages", () => {
    const state = conversationReducer(emptyConversation, {
      type: "provider-text",
      id: "b",
      text: "Welcome",
    });
    expect(conversationReducer(state, { type: "confirm", id: "b" })).toBe(
      state,
    );
    expect(conversationReducer(state, { type: "reject", id: "b" })).toBe(state);
  });
  it("labels every required UX state and maps errors to visible states", () => {
    for (const key of [
      "camera-ready",
      "permission-required",
      "tracking",
      "no-hands",
      "model-loading",
      "handshape-detected",
      "processing",
      "completed",
      "unavailable",
      "unknown",
      "auth-failed",
      "offline",
      "interpreter-recommended",
    ] as const)
      expect(phaseLabels[key]).toBeTruthy();
    expect(phaseForError("auth-failed")).toBe("auth-failed");
    expect(phaseForError("offline")).toBe("offline");
    expect(phaseForError("not-configured")).toBe("unavailable");
    expect(phaseForError("timeout")).toBe("error");
  });
});

describe("Signing-avatar adapters", () => {
  it("blocks high-risk and over-length text before any provider call", () => {
    const handtalk = avatarDescriptors.handtalk;
    expect(checkAvatarText("Please take a seat", handtalk)).toEqual({
      ok: true,
      text: "Please take a seat",
    });
    expect(checkAvatarText("Your medication dose", handtalk)).toMatchObject({
      ok: false,
      risk: "Medication dosing",
    });
    expect(
      checkAvatarText("Do you consent to surgery?", handtalk),
    ).toMatchObject({ ok: false });
    expect(checkAvatarText("x".repeat(1001), handtalk).ok).toBe(false);
    expect(
      checkAvatarText("x".repeat(501), avatarDescriptors["sign-speak"]).ok,
    ).toBe(false);
    expect(checkAvatarText("   ", handtalk).ok).toBe(false);
  });
  it("shows a clear unavailable state when no provider is connected", () => {
    const online = { online: true, simulatedOffline: false };
    expect(avatarAvailability(defaultConfig, online, null).state).toBe(
      "not-configured",
    );
    expect(
      avatarAvailability(
        { ...defaultConfig, avatarProvider: "handtalk" },
        online,
        null,
      ).state,
    ).toBe("not-configured");
    expect(
      avatarAvailability(
        { ...defaultConfig, avatarProvider: "sign-speak" },
        online,
        null,
      ).state,
    ).toBe("not-configured");
    const proxied = {
      ...defaultConfig,
      avatarProvider: "sign-speak" as const,
      proxyUrl: "http://127.0.0.1:8787",
    };
    expect(avatarAvailability(proxied, online, null).state).toBe("error");
    expect(avatarAvailability(proxied, online, false).state).toBe(
      "not-configured",
    );
    expect(avatarAvailability(proxied, online, true).state).toBe("available");
    expect(
      avatarAvailability(
        proxied,
        { online: false, simulatedOffline: false },
        true,
      ).state,
    ).toBe("offline");
    expect(
      avatarAvailability(
        proxied,
        { online: true, simulatedOffline: true },
        true,
      ).state,
    ).toBe("simulated-outage");
  });
  it("returns Sign-Speak production video only when a real video comes back (mocked)", async () => {
    const config = { ...defaultConfig, proxyUrl: "http://127.0.0.1:8787" };
    const ok = vi.fn(
      async () =>
        new Response(new Uint8Array([1, 2, 3]), {
          headers: { "Content-Type": "video/mp4" },
        }),
    ) as unknown as typeof fetch;
    expect(
      (await produceSignSpeakVideo(config, "Hello", undefined, ok)).type,
    ).toBe("video/mp4");
    const notVideo = vi.fn(
      async () =>
        new Response("oops", { headers: { "Content-Type": "text/plain" } }),
    ) as unknown as typeof fetch;
    await expect(
      produceSignSpeakVideo(config, "Hello", undefined, notVideo),
    ).rejects.toMatchObject({ code: "invalid-response" });
    const denied = vi.fn(
      async () => new Response("", { status: 401 }),
    ) as unknown as typeof fetch;
    await expect(
      produceSignSpeakVideo(config, "Hello", undefined, denied),
    ).rejects.toMatchObject({ code: "auth-failed" });
    await expect(
      produceSignSpeakVideo(defaultConfig, "Hello"),
    ).rejects.toMatchObject({ code: "not-configured" });
  });
});

describe("Camera helpers", () => {
  it("classifies permission and device failures", () => {
    expect(classifyCameraError(new DOMException("x", "NotAllowedError"))).toBe(
      "permission-denied",
    );
    expect(classifyCameraError(new DOMException("x", "NotFoundError"))).toBe(
      "not-found",
    );
    expect(classifyCameraError(new DOMException("x", "NotReadableError"))).toBe(
      "in-use",
    );
    expect(classifyCameraError(new Error("?"))).toBe("unknown");
  });
  it("stops every track when a stream is released", () => {
    const tracks = [{ stop: vi.fn() }, { stop: vi.fn() }];
    stopStream({
      getTracks: () => tracks,
      removeTrack: vi.fn(),
    } as unknown as MediaStream);
    tracks.forEach((track) => expect(track.stop).toHaveBeenCalledOnce());
    expect(() => stopStream(null)).not.toThrow();
  });
  it("adapts frame pacing for slow devices", () => {
    expect(nextFrameInterval(0)).toBe(110);
    expect(nextFrameInterval(20)).toBe(100);
    expect(nextFrameInterval(200)).toBe(320);
    expect(nextFrameInterval(2000)).toBe(500);
    expect(updateAverage(0, 50)).toBe(50);
    expect(updateAverage(50, 100)).toBe(60);
  });
  it("distinguishes no hands, tracking, and tracking lost", () => {
    expect(trackingState(0, null, 1000)).toBe("no-hands");
    expect(trackingState(2, null, 1000)).toBe("tracking");
    expect(trackingState(0, 900, 1000)).toBe("tracking-lost");
    expect(trackingState(0, 900, 5000)).toBe("no-hands");
  });
  it("keeps MediaPipe timestamps strictly increasing", () => {
    expect(monotonicTimestamp(10, 20.4)).toBe(20);
    expect(monotonicTimestamp(20, 20)).toBe(21);
    expect(monotonicTimestamp(20, 5)).toBe(21);
  });
});
