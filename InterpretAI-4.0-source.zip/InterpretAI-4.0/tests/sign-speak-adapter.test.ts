import { describe, expect, it, vi } from "vitest";
import { defaultConfig } from "../lib/asl/config";
import {
  createSignSpeakProvider,
  fetchProxyHealth,
} from "../lib/asl/sign-speak";
import type { ConsentState, PublicRecognitionConfig } from "../lib/asl/types";

// All network calls are mocked. No real Sign-Speak request is made.
const config: PublicRecognitionConfig = {
  ...defaultConfig,
  proxyUrl: "http://127.0.0.1:8787",
  requestTimeoutMs: 5000,
};
const clip = {
  blob: new Blob([new Uint8Array(64)], { type: "video/webm" }),
  mimeType: "video/webm",
  durationMs: 2000,
};
const consent: ConsentState = {
  camera: true,
  thirdPartyUpload: { provider: "sign-speak", grantedAt: 1 },
};
const completed = {
  status: "completed",
  result: {
    feedback_id: "fb",
    prediction: [
      {
        feedback_id: "fb",
        timestamp_start_sec: 0,
        timestamp_end_sec: 1,
        finished: true,
        prediction: "THANK YOU",
        confidence: 0.7,
      },
    ],
  },
};
const fetchOf = (...responses: (Response | Error)[]) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const fn = vi.fn(async (..._args: unknown[]) => {
    const next = responses.shift();
    if (!next) throw new Error("unexpected call");
    if (next instanceof Error) throw next;
    return next;
  });
  return fn as unknown as typeof fetch & typeof fn;
};

describe("Sign-Speak adapter (via secure proxy, mocked)", () => {
  it("is unavailable without a proxy, offline, or in the demo outage", async () => {
    const fetcher = fetchOf();
    expect(
      (
        await createSignSpeakProvider(defaultConfig, fetcher).availability({
          online: true,
          simulatedOffline: false,
        })
      ).state,
    ).toBe("not-configured");
    const provider = createSignSpeakProvider(config, fetcher);
    expect(
      (await provider.availability({ online: false, simulatedOffline: false }))
        .state,
    ).toBe("offline");
    expect(
      (await provider.availability({ online: true, simulatedOffline: true }))
        .state,
    ).toBe("simulated-outage");
    expect(fetcher).not.toHaveBeenCalled();
  });
  it("distinguishes a reachable proxy without a key from an unreachable proxy", async () => {
    const noKey = createSignSpeakProvider(
      config,
      fetchOf(
        Response.json({
          ok: true,
          signSpeak: { recognition: false, production: false },
        }),
      ),
    );
    expect(
      (await noKey.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("not-configured");
    const down = createSignSpeakProvider(
      config,
      fetchOf(new TypeError("refused")),
    );
    expect(
      (await down.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("error");
    const ready = createSignSpeakProvider(
      config,
      fetchOf(
        Response.json({
          ok: true,
          signSpeak: { recognition: true, production: true },
        }),
      ),
    );
    expect(
      (await ready.availability({ online: true, simulatedOffline: false }))
        .state,
    ).toBe("available");
    expect(
      await fetchProxyHealth(
        "http://127.0.0.1:1",
        fetchOf(new Response("x", { status: 500 })),
      ),
    ).toBeNull();
  });
  it("uploads only the reviewed clip with the consent header and displays the real returned text", async () => {
    const fetcher = fetchOf(Response.json(completed));
    const result = await createSignSpeakProvider(config, fetcher).recognize({
      kind: "video-clip",
      clip,
      consent,
    });
    expect(result.hypotheses[0]).toMatchObject({
      text: "THANK YOU",
      confidence: { kind: "provider-reported", value: 0.7 },
    });
    expect(result.location).toBe("cloud");
    const [url, init] = fetcher.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("http://127.0.0.1:8787/v1/sign-speak/recognize");
    expect(
      (init.headers as Record<string, string>)["X-InterpretAI-Consent"],
    ).toBe("sign-speak");
    expect(JSON.stringify(init.headers)).not.toMatch(/api-key/i);
  });
  it("polls documented asynchronous (202) responses until completion", async () => {
    const fetcher = fetchOf(
      Response.json(
        { status: "pending", requestId: "abc-123" },
        { status: 202 },
      ),
      Response.json(
        { status: "pending", requestId: "abc-123" },
        { status: 202 },
      ),
      Response.json(completed),
    );
    const statuses: string[] = [];
    const result = await createSignSpeakProvider(config, fetcher, 1).recognize(
      { kind: "video-clip", clip, consent },
      (s) => statuses.push(s.phase),
    );
    expect(result.outcome).toBe("recognized");
    expect(fetcher).toHaveBeenCalledTimes(3);
    expect(String(fetcher.mock.calls[1][0])).toBe(
      "http://127.0.0.1:8787/v1/sign-speak/recognize/abc-123",
    );
    expect(statuses).toContain("polling");
  });
  it.each([
    [401, "auth-failed"],
    [403, "auth-failed"],
    [429, "rate-limited"],
    [413, "invalid-input"],
    [503, "not-configured"],
    [504, "timeout"],
    [502, "provider-error"],
  ])("maps HTTP %i to %s without displaying anything", async (status, code) => {
    const fetcher = fetchOf(
      Response.json({ error: { code: "x", message: "m" } }, { status }),
    );
    await expect(
      createSignSpeakProvider(config, fetcher).recognize({
        kind: "video-clip",
        clip,
        consent,
      }),
    ).rejects.toMatchObject({ code });
  });
  it("reports network failures, invalid responses, and bad request IDs", async () => {
    await expect(
      createSignSpeakProvider(config, fetchOf(new TypeError("down"))).recognize(
        { kind: "video-clip", clip, consent },
      ),
    ).rejects.toMatchObject({ code: "network" });
    await expect(
      createSignSpeakProvider(
        config,
        fetchOf(new Response("<html>", { status: 200 })),
      ).recognize({ kind: "video-clip", clip, consent }),
    ).rejects.toMatchObject({ code: "invalid-response" });
    await expect(
      createSignSpeakProvider(
        config,
        fetchOf(Response.json({ status: "completed", result: { nope: 1 } })),
      ).recognize({ kind: "video-clip", clip, consent }),
    ).rejects.toMatchObject({ code: "invalid-response" });
    await expect(
      createSignSpeakProvider(
        config,
        fetchOf(Response.json({ requestId: "../../x" }, { status: 202 })),
      ).recognize({ kind: "video-clip", clip, consent }),
    ).rejects.toMatchObject({ code: "invalid-response" });
  });
  it("times out a request that never answers", async () => {
    const hanging = vi.fn(
      (_url: string, init: RequestInit) =>
        new Promise((_, reject) =>
          init.signal?.addEventListener("abort", () =>
            reject(new DOMException("aborted", "AbortError")),
          ),
        ),
    ) as unknown as typeof fetch;
    const fast = { ...config, requestTimeoutMs: 20 };
    await expect(
      createSignSpeakProvider(fast, hanging).recognize({
        kind: "video-clip",
        clip,
        consent,
      }),
    ).rejects.toMatchObject({ code: "timeout" });
  });
  it("cancels when the caller aborts", async () => {
    const controller = new AbortController();
    const hanging = vi.fn(
      (_url: string, init: RequestInit) =>
        new Promise((_, reject) =>
          init.signal?.addEventListener("abort", () =>
            reject(new DOMException("aborted", "AbortError")),
          ),
        ),
    ) as unknown as typeof fetch;
    const pending = createSignSpeakProvider(config, hanging).recognize({
      kind: "video-clip",
      clip,
      consent,
      signal: controller.signal,
    });
    controller.abort();
    await expect(pending).rejects.toMatchObject({ code: "cancelled" });
  });
  it("returns 'unknown' — never placeholder text — when the provider recognises nothing", async () => {
    const result = await createSignSpeakProvider(
      config,
      fetchOf(
        Response.json({
          status: "completed",
          result: { feedback_id: "f", prediction: [] },
        }),
      ),
    ).recognize({ kind: "video-clip", clip, consent });
    expect(result).toMatchObject({ outcome: "unknown", hypotheses: [] });
  });
  it("rejects invalid clips before any network call", async () => {
    const fetcher = fetchOf();
    const bad = { ...clip, blob: new Blob([], { type: "video/webm" }) };
    await expect(
      createSignSpeakProvider(config, fetcher).recognize({
        kind: "video-clip",
        clip: bad,
        consent,
      }),
    ).rejects.toMatchObject({ code: "invalid-input" });
    expect(fetcher).not.toHaveBeenCalled();
  });
});
