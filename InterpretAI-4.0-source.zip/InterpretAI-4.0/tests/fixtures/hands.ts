import type { HandPoint } from "../../lib/handshapes";
import type {
  HandObservation,
  LandmarkFrame,
  LandmarkSequence,
} from "../../lib/asl/types";

// Synthetic geometry fixtures only. They are not recordings of real signers
// and say nothing about recognition accuracy.
export function handFixture(extended: number[], thumb = true): HandPoint[] {
  const points: HandPoint[] = Array.from({ length: 21 }, () => ({
    x: 0,
    y: 0,
    z: 0,
  }));
  points[1] = { x: -0.22, y: 0.17, z: 0 };
  points[2] = { x: -0.38, y: 0.28, z: 0 };
  points[3] = thumb ? { x: -0.58, y: 0.3, z: 0 } : { x: -0.2, y: 0.4, z: 0.1 };
  points[4] = thumb ? { x: -0.78, y: 0.32, z: 0 } : { x: 0, y: 0.46, z: 0.1 };
  [
    [-0.22, 0.55],
    [0, 0.62],
    [0.2, 0.57],
    [0.37, 0.45],
  ].forEach(([x, y], index) => {
    const base = [5, 9, 13, 17][index];
    points[base] = { x, y, z: 0 };
    points[base + 1] = { x, y: y + 0.3, z: 0 };
    points[base + 2] = extended.includes(index)
      ? { x, y: y + 0.5, z: 0 }
      : { x, y: y + 0.3, z: 0.18 };
    points[base + 3] = extended.includes(index)
      ? { x, y: y + 0.7, z: 0 }
      : { x, y: y + 0.02, z: 0.12 };
  });
  return points;
}

export function observation(
  world: HandPoint[],
  handedness: "Left" | "Right" = "Right",
  offset = 0.5,
): HandObservation {
  return {
    handedness,
    handednessScore: 0.9,
    world,
    image: world.map((p) => ({
      x: offset + p.x * 0.1,
      y: 0.5 + p.y * 0.1,
      z: p.z * 0.1,
    })),
  };
}

export function sequenceOf(
  frames: { t: number; hands: HandObservation[] }[],
): LandmarkSequence {
  return {
    format: "interpretai.landmarks.v1",
    frames: frames as LandmarkFrame[],
  };
}

/** n frames, 100 ms apart, each with the given hands. */
export function steadySequence(n: number, hands: () => HandObservation[]) {
  return sequenceOf(
    Array.from({ length: n }, (_, i) => ({ t: i * 100, hands: hands() })),
  );
}
