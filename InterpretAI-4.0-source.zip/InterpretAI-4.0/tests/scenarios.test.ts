import { describe, it, expect } from "vitest";
import {
  initialState,
  scenarioReducer,
  scenarios,
  detectRisk,
  scenarioFor,
} from "../lib/scenarios";
describe("Scripted scenario engine", () => {
  it("requires patient confirmation before advancing", () => {
    const patient = scenarioReducer(initialState, { type: "next" });
    expect(patient.index).toBe(1);
    expect(scenarioReducer(patient, { type: "next" }).index).toBe(1);
    const confirmed = scenarioReducer(patient, { type: "confirm" });
    expect(scenarioReducer(confirmed, { type: "next" }).index).toBe(2);
  });
  it("correction revokes confirmation and blocks progression", () => {
    const patient = scenarioReducer(initialState, { type: "next" });
    const corrected = scenarioReducer(
      scenarioReducer(patient, { type: "confirm" }),
      { type: "correct" },
    );
    expect(corrected.confirmed).toEqual([]);
    expect(scenarioReducer(corrected, { type: "next" }).index).toBe(1);
  });
  it("supports back, restart, selection and bounded steps", () => {
    expect(scenarioReducer(initialState, { type: "back" }).index).toBe(0);
    const next = scenarioReducer(initialState, { type: "next" });
    expect(scenarioReducer(next, { type: "back" }).index).toBe(0);
    expect(scenarioReducer(next, { type: "restart" })).toEqual(initialState);
    expect(scenarioReducer(next, { type: "select", id: "outage" })).toEqual({
      ...initialState,
      scenarioId: "outage",
    });
    expect(scenarioFor("unknown").id).toBe("check-in");
  });
  for (const scenario of scenarios) {
    it(`completes or safely pauses scenario ${scenario.letter}`, () => {
      let state = { ...initialState, scenarioId: scenario.id };
      for (let i = 0; i < 20; i++) {
        state = scenarioReducer(state, { type: "confirm" });
        state = scenarioReducer(state, { type: "next" });
      }
      expect(state.index).toBe(scenario.steps.length - 1);
      expect(state.stopped).toBe(
        ["medication", "interpreter"].includes(scenario.id),
      );
    });
  }
  it("high-risk stops cannot be bypassed with Back, Next or confirmation", () => {
    const state = scenarioReducer(
      { ...initialState, scenarioId: "medication" },
      { type: "next" },
    );
    expect(state.risk).toBe("Medication dosing");
    for (const type of ["next", "back", "confirm", "correct"] as const)
      expect(scenarioReducer(state, { type })).toEqual(state);
    expect(scenarioReducer(state, { type: "restart" }).stopped).toBe(false);
  });
  it("respects an explicit patient interpreter request", () => {
    const state = scenarioReducer(
      { ...initialState, scenarioId: "interpreter" },
      { type: "next" },
    );
    expect(state.stopped).toBe(true);
    expect(state.risk).toBe("Patient choice");
  });
  it("requires explicit confirmation at the preventive visit teach-back, including after correction", () => {
    const scenario = scenarioFor("screening");
    const index = scenario.steps.findIndex(
      (step) => step.purpose === "teach-back",
    );
    expect(index).toBeGreaterThan(0);
    const state = { ...initialState, scenarioId: "screening", index };
    expect(scenarioReducer(state, { type: "next" })).toEqual(state);
    const confirmed = scenarioReducer(state, { type: "confirm" });
    const corrected = scenarioReducer(confirmed, { type: "correct" });
    expect(scenarioReducer(corrected, { type: "next" }).index).toBe(index);
    expect(scenarioReducer(confirmed, { type: "next" }).index).toBe(index + 1);
    expect(scenario.steps[index].hint).toContain(
      "does not measure clinical comprehension",
    );
  });
});
describe("Limited demonstration keyword safeguards", () => {
  it.each([
    ["What dose should I take?", "Medication dosing"],
    ["I have allergies.", "Allergies"],
    ["Explain this diagnosis", "Diagnoses"],
    ["I need medical consent", "Medical consent"],
    ["Let us discuss treatment", "Treatment decisions"],
    ["I have chest pain", "Emergency symptoms"],
  ])("flags %s as %s", (text, topic) => expect(detectRisk(text)).toBe(topic));
  it("handles case and common emergency wording", () => {
    expect(detectRisk("I CANNOT BREATHE")).toBe("Emergency symptoms");
  });
  it("does not flag ordinary scheduling or word substrings", () => {
    expect(detectRisk("The appointment is at 10.")).toBeUndefined();
    expect(detectRisk("A stroke of luck")).toBe("Emergency symptoms");
    expect(detectRisk("The village is quiet")).toBeUndefined();
  });
  it("intentionally demonstrates a limitation rather than claiming semantic detection", () =>
    expect(
      detectRisk("My chest feels like an elephant is sitting on it"),
    ).toBeUndefined());
});
