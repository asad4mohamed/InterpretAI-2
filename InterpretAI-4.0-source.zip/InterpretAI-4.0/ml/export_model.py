"""Wrap train.py's result.json into public/models/asl-fingerspelling-v1/model.json."""
import json
r = json.load(open("result.json"))
ext = r["ext"]
model = {
    "format": "interpretai.static-hand-model.v1",
    "id": "interpretai-asl-fingerspelling",
    "version": "1.0.0",
    "granularity": "fingerspelling-static-letter",
    "description": "Small MLP that classifies ONE hand's MediaPipe landmarks as one of 24 static ASL manual-alphabet letters. Not sign recognition, not translation. J and Z (motion letters) are not supported.",
    "vocabulary": r["labels"],
    "license": {"name": "MIT (model weights by InterpretAI; training data MIT, AkramOM606/American-Sign-Language-Detection)", "url": "https://github.com/AkramOM606/American-Sign-Language-Detection/blob/main/LICENSE.md"},
    "trainingData": {
        "description": "keypoint.csv from AkramOM606/American-Sign-Language-Detection (MediaPipe hand landmarks, 2D, wrist-relative, max-abs normalised). Cleaned: removed artificial upside-down copies, exact duplicates, two-hand rows, and J/Z. 24,509 samples after cleaning; 19,607 train / 4,902 held out. Augmented with ±15° rotation, horizontal mirroring, aspect and noise jitter.",
        "consent": "Public MIT-licensed dataset; signer identities, number of signers and consent process are NOT documented by the source.",
        "signers": None,
    },
    "evaluation": {
        "dataset": "(a) random 20% sample-level hold-out of the same dataset, 50% mirrored; (b) 24 real photos (one per letter) of a different signer from ecabestadistica/ASL-App Examples (CC BY-NC 4.0, used for testing only, not redistributed), landmarks extracted with the same MediaPipe model.",
        "signerIndependent": False,
        "metrics": {"heldOutTop1": round(r["acc"], 4), "externalTop1": round(r["ext_acc"], 4), "externalSamples": len(ext)},
        "external": ext,
        "knownGaps": "Sample-level split only (signer overlap likely). External test is just 24 photos of one signer: C was low-confidence (rejected), P was read as Q and T as S with high confidence. Not evaluated across skin tones, lighting, ages, regional variation, Black ASL, or left-handed signers. Static frames only: fingerspelling movement, J and Z are not modelled.",
    },
    "input": {"features": "mediapipe-image-landmarks-2d", "featuresPerFrame": 42, "normalization": "pixel coordinates (x*width, y*height) minus wrist, flattened [x0,y0..x20,y20], divided by max absolute value"},
    "decision": {"minScore": 0.8, "minMargin": 0.3, "maxCentroidDistance": round(r["thr"], 3)},
    "architecture": "dense-mlp",
    "layers": r["layers"],
    "centroids": r["centroids"],
}
json.dump(model, open("model.json", "w"), separators=(",", ":"))
print("wrote model.json")
