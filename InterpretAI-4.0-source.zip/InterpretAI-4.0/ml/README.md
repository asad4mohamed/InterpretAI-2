# ml/ — reproducing the fingerspelling model

| File | Purpose |
|---|---|
| `prep.py` | Loads `keypoint.csv` from AkramOM606/American-Sign-Language-Detection (MIT), removes upside-down augmentation artefacts, duplicates, two-hand rows and J/Z, and writes `data.npz` |
| `train.py` | Trains the 42→128→64→24 MLP (scikit-learn), augments the data, evaluates the hold-out and external sets, and exports weights and centroids |
| `extract-external.mjs` | Runs the app's own MediaPipe Hand Landmarker (headless Chromium) on external photos to produce real test landmarks |
| `make-fake-camera.py` | Builds a Y4M "fake camera" video from letter photos for the real-photo end-to-end test |

Paths at the top of each script point to the original build machine; edit them for yours. `export_model.py` wraps `result.json` with the model-card fields into `model.json`; copy it to `public/models/asl-fingerspelling-v1/`.

External photos (ecabestadistica/ASL-App, CC BY-NC 4.0) are **not** redistributed. Only derived landmarks are included, in `tests/fixtures/external-landmarks.json`, for non-commercial evaluation.
