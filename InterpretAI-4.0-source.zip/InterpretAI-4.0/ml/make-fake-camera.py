"""Build a Y4M 'fake camera' video from letter photos for end-to-end tests.

Usage: python3 ml/make-fake-camera.py <examples_dir> <out.y4m> L,B
Photos are NOT shipped with InterpretAI (licence). The e2e test skips when
the generated video is absent.
"""
import sys
from PIL import Image

src, out, letters = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
W, H, FPS = 640, 480, 15

def frame_for(img):
    canvas = Image.new("RGB", (W, H), (200, 200, 200))
    if img is not None:
        im = img.convert("RGB")
        im.thumbnail((W, H))
        canvas.paste(im, ((W - im.width) // 2, (H - im.height) // 2))
    y, u, v = canvas.convert("YCbCr").split()
    return y.tobytes() + u.resize((W // 2, H // 2)).tobytes() + v.resize((W // 2, H // 2)).tobytes()

with open(out, "wb") as f:
    f.write(f"YUV4MPEG2 W{W} H{H} F{FPS}:1 Ip A1:1 C420jpeg\n".encode())
    for letter in letters:
        data = frame_for(Image.open(f"{src}/{letter}.webp"))
        for _ in range(FPS * 3):
            f.write(b"FRAME\n" + data)
        blank = frame_for(None)
        for _ in range(int(FPS * 2)):
            f.write(b"FRAME\n" + blank)
