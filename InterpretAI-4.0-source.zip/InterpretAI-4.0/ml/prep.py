import csv, collections, numpy as np, json
src='/home/claude/cands/AkramOM606_American-Sign-Language-Detection/model/keypoint_classifier/keypoint.csv'
labels=[l.strip().lstrip('﻿') for l in open(src.replace('keypoint.csv','keypoint_classifier_label.csv'),encoding='utf-8-sig').read().split('\n') if l.strip()]
X=[];Y=[]
for r in csv.reader(open(src)):
    if len(r)!=43: continue
    X.append([float(v) for v in r[1:]]); Y.append(int(r[0]))
X=np.array(X,dtype=np.float32); Y=np.array(Y)
print('rows',len(X),'labels',labels)
ang=np.degrees(np.arctan2(X[:,19],X[:,18]))  # wrist->middle MCP; -90 up, +90 down
down=(ang>45)&(ang<135)
keep=np.zeros(len(X),bool)
for i,l in enumerate(labels):
    m=Y==i
    # The source pipeline appended a vertically flipped copy of each image.
    # P, Q, G, H are naturally sideways/downward, so their flips stay plausible;
    # for every other letter a hand pointing down is an upside-down artifact.
    k=m if l in ('P','Q','G','H') else m&~down
    keep|=k
    print(l, int(m.sum()), 'upright' if l not in 'PQGH' else '', int(k.sum()))
# exclude motion letters J,Z
static=[l for l in labels if l not in ('J','Z')]
idx={l:i for i,l in enumerate(static)}
sel=keep & np.isin(Y,[labels.index(l) for l in static])
Xs=X[sel]; Ys=np.array([idx[labels[y]] for y in Y[sel]])
# dedupe exact duplicates
_,u=np.unique(np.round(Xs,4),axis=0,return_index=True)
Xs=Xs[np.sort(u)]; Ys=Ys[np.sort(u)]
print('kept',len(Xs),'classes',len(static))
np.savez('/home/claude/train/data.npz',X=Xs,Y=Ys,labels=np.array(static))
