import numpy as np, json, hashlib
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
rng=np.random.default_rng(7)
d=np.load('/home/claude/train/data.npz'); X=d['X']; Y=d['Y']; labels=[str(l) for l in d['labels']]

def normalize(rel):  # rel: (n,21,2) wrist-relative pixel coords
    flat=rel.reshape(len(rel),-1)
    m=np.abs(flat).max(1,keepdims=True); m[m==0]=1
    return (flat/m).astype(np.float32)

def augment(X,copies=3):
    pts=X.reshape(-1,21,2); out=[normalize(pts)]
    for _ in range(copies):
        th=np.radians(rng.uniform(-15,15,len(pts)))
        c,s=np.cos(th),np.sin(th)
        R=np.stack([np.stack([c,-s],-1),np.stack([s,c],-1)],-2)
        p=np.einsum('nij,nkj->nki',R,pts)
        p[:,:,0]*=rng.uniform(0.85,1.15,(len(p),1))   # aspect/perspective jitter
        flip=rng.random(len(p))<0.5; p[flip,:,0]*=-1      # left/right hand
        p+=rng.normal(0,0.015,p.shape)*np.abs(p).max((1,2),keepdims=True)
        out.append(normalize(p))
    return np.concatenate(out)

Xtr,Xte,Ytr,Yte=train_test_split(X,Y,test_size=0.2,stratify=Y,random_state=0)
Xa=augment(Xtr); Ya=np.tile(Ytr,4)
# test set also gets a random mirror so handedness invariance is measured
pte=Xte.reshape(-1,21,2).copy(); f=rng.random(len(pte))<0.5; pte[f,:,0]*=-1; Xte_m=normalize(pte)
clf=MLPClassifier(hidden_layer_sizes=(128,64),activation='relu',alpha=1e-4,batch_size=256,learning_rate_init=1e-3,max_iter=60,early_stopping=True,validation_fraction=0.1,n_iter_no_change=6,random_state=0)
clf.fit(Xa,Ya)
pred=clf.predict(Xte_m); acc=accuracy_score(Yte,pred)
proba=clf.predict_proba(Xte_m)
print('held-out (sample-level, mirrored 50%) accuracy',round(acc,4),'n',len(Yte))
per={labels[i]:round(float((pred[Yte==i]==i).mean()),3) for i in range(len(labels))}
print('per-class',per)

# external, different signer
ext=json.load(open('/home/claude/train/external.json'))
def feats_from_image(e):
    pts=np.array([[p['x']*e['w'],p['y']*e['h']] for p in e['image']])
    return normalize((pts-pts[0])[None])
ext_rows=[(e['letter'],feats_from_image(e)) for e in ext if e['image']]
ext_res=[]
for l,f in ext_rows:
    pr=clf.predict_proba(f)[0]; top=int(pr.argmax()); s=sorted(pr)[-2:]
    ext_res.append({'letter':l,'predicted':labels[top],'score':round(float(pr[top]),3),'margin':round(float(s[1]-s[0]),3)})
ext_acc=np.mean([r['letter']==r['predicted'] for r in ext_res])
print('external (other signer, 1 photo/letter) top-1',round(float(ext_acc),3), len(ext_res))
for r in ext_res: print(r)

# centroid distance for out-of-distribution rejection
H=np.maximum(0,Xa@clf.coefs_[0]+clf.intercepts_[0]); H=np.maximum(0,H@clf.coefs_[1]+clf.intercepts_[1])
cent=np.stack([H[Ya==i].mean(0) for i in range(len(labels))])
dist=np.array([np.linalg.norm(H[j]-cent[Ya[j]]) for j in range(0,len(H),7)])
thr=float(np.percentile(dist,99))
print('ood threshold (99th pct hidden-space distance)',round(thr,3))
json.dump({'acc':acc,'per':per,'ext':ext_res,'ext_acc':float(ext_acc),'n_test':int(len(Yte)),'n_train':int(len(Ytr)),'thr':thr,
  'layers':[{'weights':W.T.round(6).tolist(),'bias':b.round(6).tolist(),'activation':'relu' if i<2 else 'linear'} for i,(W,b) in enumerate(zip(clf.coefs_,clf.intercepts_))],
  'centroids':cent.round(5).tolist(),'labels':labels},open('/home/claude/train/result.json','w'))
