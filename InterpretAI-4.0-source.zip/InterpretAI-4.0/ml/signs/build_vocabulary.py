"""Build public/models/asl-signs-v1/vocabulary.json from the model's own
labels.json and the upstream held-out metrics.json.

Every class the model outputs gets: a stable id, an ASL gloss, an English
meaning, a category, held-out accuracy (measured upstream on 3 signers never
used in training), documented variants/notes, and the signs it is most often
confused with. Run:  python3 ml/signs/build_vocabulary.py
"""
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[2]
MODEL = ROOT / "public" / "models" / "asl-signs-v1"
labels = json.loads((MODEL / "labels.json").read_text())["signs"]
metrics = json.loads((MODEL / "metrics.json").read_text())
per_sign = {p["sign"]: p for p in metrics["perSign"]}

# Compound / special labels from the PopSign (asl-signs) label set.
GLOSS = {
    "TV": "TV", "callonphone": "CALL-ON-PHONE", "frenchfries": "FRENCH-FRIES",
    "glasswindow": "WINDOW", "haveto": "HAVE-TO", "hesheit": "HE/SHE/IT",
    "icecream": "ICE-CREAM", "minemy": "MY/MINE", "weus": "WE/US",
    "thankyou": "THANK-YOU", "shhh": "SHH",
}
ENGLISH = {
    "TV": "TV, television", "callonphone": "call on the phone",
    "frenchfries": "french fries", "glasswindow": "window (glass)",
    "haveto": "have to, must", "hesheit": "he, she, or it (pointing)",
    "icecream": "ice cream", "minemy": "my, mine", "weus": "we, us",
    "thankyou": "thank you", "shhh": "shh, be quiet", "owie": "owie, hurt (child word)",
    "potty": "potty, toilet", "can": "can, able to", "close": "close, shut",
    "fall": "fall (down)", "will": "will (future)", "orange": "orange (color or fruit)",
    "fine": "fine", "kitty": "kitty, cat", "puppy": "puppy, dog", "dryer": "clothes dryer",
    "drop": "drop", "dry": "dry", "awake": "awake", "wake": "wake up", "nap": "nap",
    "yucky": "yucky, gross", "hello": "hello, hi", "bye": "bye, goodbye",
    "time": "time (what time)", "yourself": "yourself", "that": "that",
    "there": "there (pointing)", "for": "for", "into": "into", "on": "on", "if": "if",
}
NOTES = {
    "TV": "Fingerspelled T-V in most recordings.",
    "hesheit": "A point toward a third person or thing. Meaning depends on where the signer points; easily confused with THAT and THERE.",
    "there": "A point; meaning depends on context.",
    "that": "Often confused with STAY (similar handshape).",
    "minemy": "Flat hand on the chest; confused with PLEASE (circular motion on the chest).",
    "please": "Confused with MY/MINE (flat hand on the chest).",
    "owie": "Child-directed label from the PopSign vocabulary. A Deaf reviewer should confirm it matches the adult HURT sign before clinical-style use.",
    "potty": "Child-directed label from the PopSign vocabulary. Adults usually sign TOILET/BATHROOM; a Deaf reviewer should confirm whether the recorded sign matches.",
    "awake": "Usually the same or nearly the same sign as WAKE (eyes opening). The model rarely separates them.",
    "wake": "Usually the same or nearly the same sign as AWAKE.",
    "quiet": "Overlaps with SHH (finger to lips) in many recordings.",
    "shhh": "Overlaps with QUIET.",
    "sleep": "Overlaps with NAP.",
    "nap": "Overlaps with SLEEP.",
    "pen": "Overlaps with PENCIL.",
    "pencil": "Overlaps with PEN.",
    "cat": "Overlaps with KITTY (same whisker sign).",
    "kitty": "Overlaps with CAT (same whisker sign).",
    "orange": "One sign covers both the color and the fruit.",
    "fine": "Open 5-hand, thumb taps the chest.",
}
CATEGORY_WORDS = {
    "Greetings and social": "hello bye thankyou please yes no fine sorry",
    "People and family": "aunt boy brother child dad girl grandma grandpa man mom person uncle fireman police cowboy clown",
    "Pronouns and pointing": "hesheit minemy weus yourself that there",
    "Questions": "who why where",
    "Body": "arm cheek chin ear eye face feet finger hair head lips mouth nose tongue tooth",
    "Health and needs": "sick owie potty hungry thirsty sleepy awake wake sleep nap tired hot wet dirty clean bath shower toothbrush stuck",
    "Feelings": "happy sad mad cry smile hate like cute pretty yucky loud quiet noisy shhh",
    "Food and drink": "apple carrot cereal chocolate drink food frenchfries gum icecream milk nuts orange pizza snack water taste",
    "Home and objects": "bed bedroom chair closet drawer dryer garbage glasswindow home kitchen lamp napkin pen pencil penny radio refrigerator room scissors stairs table TV vacuum book gift balloon flag puzzle toy doll backyard",
    "Clothing": "hat jacket jeans mitten pajamas shirt shoe underwear zipper",
    "Animals": "alligator animal bee bird bug cat cow dog donkey duck elephant fish frog giraffe goose hen horse kitty lion mouse owl pig puppy tiger wolf zebra",
    "Nature and outdoors": "cloud flower grass moon outside pool rain snow sun tree farm",
    "Vehicles and places": "airplane boat car helicopter store",
    "Colors": "black blue brown green red white yellow",
    "Time": "after before first later morning night now time tomorrow yesterday finish",
    "Actions": "blow callonphone close cut dance drop dry fall find give go have haveto hear hide jump kiss listen look make open pretend read ride say see stay talk think touch wait will",
}
CATEGORY = {}
for cat, words in CATEGORY_WORDS.items():
    for w in words.split():
        CATEGORY.setdefault(w, cat)

# Manually documented near-synonym groups (same or nearly the same sign).
SYNONYMS = [("awake", "wake"), ("quiet", "shhh"), ("sleep", "nap"), ("pen", "pencil"), ("cat", "kitty"), ("dog", "puppy")]

confusions = {}
for pair in metrics["confusedPairs"]:
    confusions.setdefault(pair["true"], []).append(
        {"sign": pair["predicted"], "rate": round(pair["rate"], 3)})
for a, b in SYNONYMS:
    for x, y in ((a, b), (b, a)):
        lst = confusions.setdefault(x, [])
        if not any(c["sign"] == y for c in lst):
            lst.append({"sign": y, "rate": None})


def slug(sign: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", sign.lower()).strip("-")


entries = []
for item in labels:
    sign = item["sign"]
    stats = per_sign[sign]
    top1 = round(stats["top1"], 4)
    entries.append({
        "index": item["index"],
        "id": f"asl-signs-v1:{slug(sign)}",
        "modelLabel": sign,
        "gloss": GLOSS.get(sign, sign.upper()),
        "english": ENGLISH.get(sign, sign),
        "category": CATEGORY.get(sign, "Descriptions and other words"),
        "heldOutClips": stats["clips"],
        "heldOutTop1": top1,
        "reliability": "high" if top1 >= 0.75 else "medium" if top1 >= 0.5 else "low",
        "variantsNote": NOTES.get(sign, "Recorded variants come from the asl-signs (PopSign) signers; regional or personal variants may not be recognised."),
        "confusedWith": confusions.get(sign, []),
        "ambiguous": bool(confusions.get(sign)),
    })

ids = [e["id"] for e in entries]
assert len(ids) == len(set(ids)) == 250, "ids must be unique"
glosses = [e["gloss"] for e in entries]
assert len(glosses) == len(set(glosses)), "glosses must be unique"
assert [e["index"] for e in entries] == list(range(250)), "index order must match the model"

out = {
    "format": "interpretai.sign-vocabulary.v1",
    "model": "asl-signs-v1 (GestureSign transformer, upstream version default-2fc9038cc4)",
    "source": "Google - Isolated Sign Language Recognition (Kaggle asl-signs, from the PopSign project), CC BY 4.0",
    "heldOutSigners": metrics["data"]["testParticipants"],
    "classes": len(entries),
    "signs": entries,
}
(MODEL / "vocabulary.json").write_text(json.dumps(out, indent=1) + "\n")
by = {}
for e in entries:
    by[e["reliability"]] = by.get(e["reliability"], 0) + 1
print("wrote", len(entries), "classes;", by, "; ambiguous:", sum(e["ambiguous"] for e in entries))

# Human-readable reference, generated from the same data.
lines = [
    "# Sign vocabulary (asl-signs-v1)",
    "",
    "Generated by `python3 ml/signs/build_vocabulary.py` from the model's `labels.json` and the upstream held-out "
    "evaluation (`metrics.json`). Do not edit by hand. Accuracy = top-1 on 3 signers never used in training "
    f"({', '.join(str(p) for p in metrics['data']['testParticipants'])}), measured by the model's authors.",
    "",
    f"{len(entries)} classes · reliability: {by.get('high', 0)} high (≥75%), {by.get('medium', 0)} medium (50–74%), "
    f"{by.get('low', 0)} low (<50%) · {sum(e['ambiguous'] for e in entries)} flagged ambiguous.",
    "",
    "| # | ID | Gloss | English | Category | Held-out clips | Top-1 | Confused with / notes |",
    "|---:|---|---|---|---|---:|---:|---|",
]
glosses_by_label = {e["modelLabel"]: e["gloss"] for e in entries}
for e in entries:
    conf = ", ".join(glosses_by_label.get(c["sign"], c["sign"]) for c in e["confusedWith"])
    note = (f"Confused with {conf}. " if conf else "") + (NOTES.get(e["modelLabel"], ""))
    lines.append(
        f"| {e['index']} | `{e['id']}` | {e['gloss']} | {e['english']} | {e['category']} | {e['heldOutClips']} | "
        f"{e['heldOutTop1'] * 100:.1f}% | {note.strip()} |"
    )
(ROOT / "docs" / "VOCABULARY-SIGNS.md").write_text("\n".join(lines) + "\n")
print("wrote docs/VOCABULARY-SIGNS.md")
