// Evaluates the bundled sign model with InterpretAI's OWN feature code and
// decision rules on Google's Isolated Sign Language Recognition data
// (Kaggle "asl-signs", CC BY 4.0), held-out signers by default.
//
//   npm run eval:signs -- --data-dir ~/datasets/asl-signs [--limit 2000]
//        [--participants 16069,37055,61333] [--out reports/sign-eval]
//
// Expects the Kaggle layout: train.csv (path, participant_id, sequence_id,
// sign) and train_landmark_files/<participant>/<sequence>.parquet with columns
// frame, type, landmark_index, x, y, z. Writes <out>.json and <out>.md with
// overall top-1/top-5, "Not sure" rate, per-class accuracy for every class,
// the most confused pairs and inference latency.
import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { performance } from "node:perf_hooks";
import { asyncBufferFromFile, parquetReadObjects } from "hyparquet";
import * as ort from "onnxruntime-web";
import { createRequire } from "node:module";
import ts from "typescript";

const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, value, i, all) => {
    if (value.startsWith("--")) acc.push([value.slice(2), all[i + 1] ?? ""]);
    return acc;
  }, []),
);
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../..");
const dataDir = path.resolve(args["data-dir"] ?? "");
if (!args["data-dir"]) {
  console.error("Usage: npm run eval:signs -- --data-dir <folder with train.csv>");
  process.exit(2);
}
const limit = Number(args.limit ?? Infinity);
const participants = new Set(
  (args.participants ?? "16069,37055,61333").split(",").map((p) => p.trim()),
);
const out = path.resolve(args.out ?? path.join(root, "reports", "sign-eval"));

// Load the app's TypeScript modules (features, meta, decision) without a bundler.
async function loadTs(rel, cache = new Map()) {
  const file = path.join(root, rel);
  if (cache.has(file)) return cache.get(file);
  const source = await readFile(file, "utf8");
  const js = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const mod = { exports: {} };
  const local = createRequire(file);
  const require = (spec) => {
    if (spec.startsWith("./")) {
      const dep = path.join(path.dirname(rel), spec + ".ts");
      if (!cache.has(path.join(root, dep))) throw new Error(`load ${dep} first`);
      return cache.get(path.join(root, dep));
    }
    return local(spec);
  };
  new Function("module", "exports", "require", js)(mod, mod.exports, require);
  cache.set(file, mod.exports);
  return mod.exports;
}
const cache = new Map();
const landmarks = await loadTs("lib/asl/signs/landmarks.ts", cache);
const features = await loadTs("lib/asl/signs/features.ts", cache);
const decision = await loadTs("lib/asl/signs/decision.ts", cache);
const metaMod = await loadTs("lib/asl/signs/meta.ts", cache);

const modelDir = path.join(root, "public/models/asl-signs-v1");
const meta = metaMod.parseMeta(JSON.parse(await readFile(path.join(modelDir, "model-meta.json"), "utf8")));
const labels = metaMod.parseLabels(
  JSON.parse(await readFile(path.join(modelDir, "labels.json"), "utf8")),
  meta.classes,
);
const indexOf = new Map(labels.map((l) => [l.sign, l.index]));
const shipped = labels.map((l) => l.shipped);
ort.env.wasm.numThreads = 1;
const session = await ort.InferenceSession.create(await readFile(path.join(modelDir, "model.onnx")));

const csv = (await readFile(path.join(dataDir, "train.csv"), "utf8")).trim().split(/\r?\n/);
const header = csv.shift().split(",");
const col = (name) => header.indexOf(name);
const rows = csv
  .map((line) => line.split(","))
  .filter((r) => participants.has(r[col("participant_id")]))
  .slice(0, limit);
if (!rows.length) throw new Error("No clips for the selected participants.");

const TYPE_START = {
  face: 0,
  left_hand: landmarks.LEFT_HAND_START,
  pose: landmarks.POSE_START,
  right_hand: landmarks.RIGHT_HAND_START,
};
async function framesOf(file) {
  const records = await parquetReadObjects({ file: await asyncBufferFromFile(file) });
  const byFrame = new Map();
  for (const r of records) {
    const f = Number(r.frame);
    let frame = byFrame.get(f);
    if (!frame) byFrame.set(f, (frame = landmarks.emptyFrame()));
    const point = TYPE_START[r.type] + Number(r.landmark_index);
    for (const [k, v] of [[0, r.x], [1, r.y], [2, r.z]])
      frame[point * 3 + k] = v === null || v === undefined ? Number.NaN : Number(v);
  }
  return [...byFrame.keys()].sort((a, b) => a - b).map((k) => byFrame.get(k));
}

const perClass = new Map(labels.map((l) => [l.sign, { clips: 0, top1: 0, top5: 0 }]));
const confusion = new Map();
let n = 0, top1 = 0, top5 = 0, notSure = 0, correctWhenAnswered = 0;
const latencies = [];
for (const row of rows) {
  const sign = row[col("sign")];
  const target = indexOf.get(sign);
  if (target === undefined) throw new Error(`Label ${sign} is not in the model vocabulary`);
  const frames = await framesOf(path.join(dataDir, row[col("path")]));
  // Dataset clips are 30 fps recordings.
  const input = features.modelInput(frames, 30, meta);
  const t0 = performance.now();
  const outputs = await session.run({
    frames: new ort.Tensor("float32", input.data, [1, input.frames, input.dim]),
  });
  latencies.push(performance.now() - t0);
  const logits = outputs.logits.data;
  const d = decision.decide(logits, shipped, meta.calibration, {}, 5);
  const ranked = d.top.map((g) => g.index);
  const stats = perClass.get(sign);
  stats.clips++;
  n++;
  if (ranked[0] === target) {
    top1++;
    stats.top1++;
  }
  else {
    const key = `${sign}→${labels[ranked[0]].sign}`;
    confusion.set(key, (confusion.get(key) ?? 0) + 1);
  }
  if (ranked.includes(target)) {
    top5++;
    stats.top5++;
  }
  if (d.kind === "not-sure") notSure++;
  else if (ranked[0] === target) correctWhenAnswered++;
  if (n % 500 === 0) console.log(`${n}/${rows.length} clips… top-1 ${(top1 / n * 100).toFixed(1)}%`);
}
latencies.sort((a, b) => a - b);
const q = (p) => latencies[Math.min(latencies.length - 1, Math.floor(p * latencies.length))];
const report = {
  model: meta.version,
  pipeline: "InterpretAI lib/asl/signs (features, decision) + ONNX Runtime Web (WASM, Node)",
  participants: [...participants],
  clips: n,
  top1: top1 / n,
  top5: top5 / n,
  notSureRate: notSure / n,
  precisionWhenAnswered: correctWhenAnswered / Math.max(1, n - notSure),
  latencyMs: { median: q(0.5), p95: q(0.95) },
  perClass: [...perClass].map(([sign, s]) => ({
    sign,
    clips: s.clips,
    top1: s.clips ? s.top1 / s.clips : null,
    top5: s.clips ? s.top5 / s.clips : null,
  })),
  confusedPairs: [...confusion].sort((a, b) => b[1] - a[1]).slice(0, 20).map(([pair, count]) => ({ pair, count })),
};
await mkdir(path.dirname(out), { recursive: true });
await writeFile(`${out}.json`, JSON.stringify(report, null, 1));
const pct = (v) => (v === null ? "—" : `${(v * 100).toFixed(1)}%`);
await writeFile(
  `${out}.md`,
  [
    `# Sign model evaluation (${meta.version})`,
    "",
    `Participants ${report.participants.join(", ")} · ${n} clips · top-1 ${pct(report.top1)} · top-5 ${pct(report.top5)} · "Not sure" ${pct(report.notSureRate)} · precision when answered ${pct(report.precisionWhenAnswered)} · inference median ${report.latencyMs.median.toFixed(1)} ms (p95 ${report.latencyMs.p95.toFixed(1)} ms)`,
    "",
    "| Sign | Clips | Top-1 | Top-5 |",
    "|---|---:|---:|---:|",
    ...report.perClass.map((c) => `| ${c.sign} | ${c.clips} | ${pct(c.top1)} | ${pct(c.top5)} |`),
    "",
    "| Most confused | Count |",
    "|---|---:|",
    ...report.confusedPairs.map((c) => `| ${c.pair} | ${c.count} |`),
    "",
  ].join("\n"),
);
console.log(
  `Done: ${n} clips, top-1 ${pct(report.top1)}, top-5 ${pct(report.top5)}. Wrote ${out}.json and ${out}.md`,
);
