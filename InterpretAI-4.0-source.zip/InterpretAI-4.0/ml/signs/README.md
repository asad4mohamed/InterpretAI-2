# ml/signs — sign model: vocabulary, evaluation, retraining

InterpretAI did **not** train the 250-sign model. It integrates GestureSign's trained model (MIT) and checks it. This folder holds what InterpretAI adds, plus exact instructions to reproduce training upstream.

| File | Purpose | Executed here? |
|---|---|---|
| `build_vocabulary.py` | Builds `public/models/asl-signs-v1/vocabulary.json` and `docs/VOCABULARY-SIGNS.md` from the model's labels and upstream metrics; asserts unique IDs and glosses and model order | Yes |
| `evaluate.mjs` (`npm run eval:signs`) | Evaluates the model with **InterpretAI's own** feature code and decision rules on Kaggle asl-signs parquet files: top-1/top-5, "Not sure" rate, per-class accuracy for all 250 classes, confusions, latency | Yes, on the 6-clip sample `tests/fixtures/signs/mini-asl-signs` (5/6 top-1). **Not** on the full test set (Kaggle unreachable here) |

## Full evaluation on your machine

```bash
# after downloading asl-signs (docs/DATASET-SIGNS.md)
npm run eval:signs -- --data-dir ~/datasets/asl-signs                 # 3 held-out signers, ~14,396 clips
npm run eval:signs -- --data-dir ~/datasets/asl-signs --limit 500     # quick check
# writes reports/sign-eval.json and reports/sign-eval.md
```

Expected: close to the upstream 72.1% top-1 / 88.1% top-5. A large gap would indicate a feature-pipeline mismatch.

## Retraining (upstream pipeline; not executed here)

Requirements: Python 3.12, [uv](https://docs.astral.sh/uv/), the Kaggle data, about 80 minutes on an Apple M4 (MPS) or a CUDA GPU.

```bash
git clone https://github.com/shashank11yadav/GestureSign.git && cd GestureSign
git checkout 26e8fa4aabb238e4ae54483ed49a0b37b1388d34
mkdir -p ../_datasets/asl-signs && cp ~/Downloads/asl-signs.zip ../_datasets/asl-signs/
cd pipeline
uv sync
uv run gesturesign smoke        # whole chain on synthetic data, seconds (sanity check)
uv run gesturesign prepare      # parquet -> landmark cache (~3 min)
uv run gesturesign train        # checkpoints, early stopping on validation top-1, seed 42
uv run gesturesign evaluate     # held-out metrics, per-class results, calibration
uv run gesturesign export       # model.onnx, model-meta.json, labels.json
```

Configuration and the fixed seed are in `pipeline/configs/default.toml` upstream (AdamW, cosine decay, label smoothing, landmark augmentation; 47 epochs, epoch-39 checkpoint shipped).

To use a retrained model in InterpretAI:

1. Copy `model.onnx`, `model-meta.json`, `labels.json` and `pipeline/reports/metrics.json` into `public/models/asl-signs-v1/` (or a new versioned folder).
2. `python3 ml/signs/build_vocabulary.py` (fails loudly if labels, IDs or glosses do not line up).
3. `npm run prepare:signs` (recomputes the integrity manifest), `npm test`, `npm run eval:signs -- --data-dir …`, `npm run build`.

The app refuses a model whose feature version or input size differs from its feature code (`parseMeta`) and a vocabulary that does not match the labels (`parseVocabulary`).

## Why training was not run here

The build environment can reach only package registries and GitHub. Kaggle (data), Hugging Face, Google Cloud Storage and the PyTorch wheel index are blocked, and there is no GPU. Training on anything other than the real data would produce a fake model, so none was produced.
