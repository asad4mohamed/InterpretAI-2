import { chromium } from "/home/claude/src/InterpretAI-2/node_modules/playwright/index.mjs";
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
const dir = "/home/claude/ecabestadistica/asl-app/Examples";
const images = readdirSync(dir).filter(f => f.endsWith(".webp")).map(f => ({ letter: f[0], url: "data:image/webp;base64," + readFileSync(`${dir}/${f}`).toString("base64") }));
const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
const page = await browser.newPage();
await page.goto("http://127.0.0.1:3000/");
const out = await page.evaluate(async (images) => {
  const root = "/lab-assets/mp1.1.1-model1";
  const src = `import { FilesetResolver, HandLandmarker } from "${location.origin}${root}/vision_bundle.mjs";
  let hl;
  self.onmessage = async (e) => {
    if (!hl) {
      const fileset = await FilesetResolver.forVisionTasks("${location.origin}${root}/wasm", true);
      hl = await HandLandmarker.createFromOptions(fileset, { baseOptions: { modelAssetPath: "${location.origin}${root}/hand_landmarker.task", delegate: "CPU" }, runningMode: "IMAGE", numHands: 1, minHandDetectionConfidence: 0.3 });
    }
    const r = hl.detect(e.data.bitmap);
    self.postMessage({ image: r.landmarks[0] ?? null, world: r.worldLandmarks[0] ?? null, handedness: r.handedness[0]?.[0]?.categoryName ?? null, hands: r.landmarks.length });
  };`;
  const worker = new Worker(URL.createObjectURL(new Blob([src], { type: "text/javascript" })), { type: "module" });
  const results = [];
  for (const im of images) {
    const img = new Image(); img.src = im.url; await img.decode();
    const bitmap = await createImageBitmap(img);
    const r = await new Promise((res, rej) => { worker.onmessage = (e) => res(e.data); worker.onerror = (e) => rej(new Error(e.message)); worker.postMessage({ bitmap }, [bitmap]); });
    results.push({ letter: im.letter, w: img.naturalWidth, h: img.naturalHeight, ...r });
  }
  return results;
}, images);
writeFileSync("/home/claude/train/external.json", JSON.stringify(out));
console.log(out.map(o => `${o.letter}:${o.hands}`).join(" "));
await browser.close();
