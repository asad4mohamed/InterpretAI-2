# Short conversational phrases

Phrases come from a **fixed table of 22 gloss patterns** (`lib/asl/signs/phrases.ts`), not from translation. A sequence gets an English suggestion only if it matches a pattern exactly and contains no unresolved "Not sure" sign. Every pattern is checked against the model's labels when the page loads and in unit tests, so no pattern can use a sign the model does not output. Suggestions are always editable and must be confirmed by the patient (and, in the workspace, confirmed again in the review queue).

Anything else is reported as **"No supported phrase pattern for …"**, with the recognised glosses shown. The patient may then write their own English, which is labelled as patient-written. The system never adds a sign that was not recognised.

## Required phrases

| Phrase | Status | Pathway | Verified how |
|---|---|---|---|
| "Hi, how are you?" | **Partial** | HELLO → "Hi." / "Hello." HOW and YOU are not in the vocabulary. | HELLO: real held-out clip through the browser worker (e2e) and Node (unit), 93% probability; upstream held-out top-1 79.3%. |
| "I am fine" | **Pathway implemented; not verified with a real clip** | FINE → "I'm fine." (ME implied) | Pattern unit test; upstream held-out top-1 for FINE 71.9%. No FINE clip is available here. |
| "What is your name?" | **Unsupported** | WHAT, YOUR and NAME are not in the vocabulary. The app says so. | Unit test asserts no pattern exists and that the sequence is reported as unsupported. |
| "Thank you" | **Pathway implemented; not verified with a real clip** | THANK-YOU → "Thank you." | Pattern unit test; upstream top-1 83.9%. |
| "I need help" | **Partial** | HELP is not a vocabulary sign. Fingerspell #HELP with the 3.0 letter model inside sign mode → "I need help." | Pattern + spelled-token unit tests; letter model verified in 3.0 (21/24 real letters, real-photo e2e). Not verified end to end with a live signer. |
| "I want water" | **Pathway implemented; not verified with a real clip** | WATER, DRINK WATER, WATER PLEASE, THIRSTY WATER → "I want water." (WANT implied) | Pattern unit tests; upstream top-1: WATER 94.7%, DRINK 85.3%, PLEASE 89.7%, THIRSTY 93.0%. |
| "Where is the bathroom?" | **Partial** | POTTY WHERE / WHERE POTTY → "Where is the bathroom?" POTTY is a child-directed PopSign label; Deaf review is needed to confirm it matches the adult TOILET sign. | Pattern unit tests; upstream top-1: POTTY 85.7%, WHERE 92.7%. |

"Verified with a real clip" is only possible for HELLO here: the only real recordings available in this environment are six held-out clips (BLUE, POLICE, QUIET, GIRAFFE, SMILE, HELLO).

## Other patterns

HELLO FINE · THIRSTY · POTTY ("I need the bathroom.") · SICK · OWIE ("It hurts.") · HUNGRY · SLEEPY · HOT · YES · NO · WAIT · BYE.

## Limitations

Word order, facial grammar (e.g. raised brows marking a question), mouth morphemes, pointing and context are not modelled. The same gloss sequence can mean different things. An English suggestion is an aid for the patient to check, never an interpretation.
