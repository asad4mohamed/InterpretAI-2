# Experimental handshape and avatar sample

The lab is separate from clinical conversation scenarios. It demonstrates a local perception pipeline and a scripted visual output. It does not implement ASL interpretation or establish linguistic or clinical accuracy.

## Actual recognition path

Consented camera frame -> MediaPipe Hand Landmarker -> 21 hand landmarks -> original geometry rules -> L-like / Y-like / Unknown -> explicit user confirmation -> selected scripted pose.

- **Landmarks:** `@mediapipe/tasks-vision` 1.1.1, Apache-2.0, with the official float16 Hand Landmarker bundle, model version 1. The model estimates hand anatomy; it is not trained here as an ASL classifier.
- **Model source:** https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
- **Model SHA-256:** `fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1`
- **Runtime:** local ES-module WebAssembly loader and binary from the pinned npm package. `lib/lab-assets.json` records byte counts and SHA-256 hashes for all four optional files.
- **Worker packaging:** `scripts/prepare-lab.mjs` transpiles the TypeScript worker and geometry rules into native ES modules in `public/lab-engine/`. This preserves the upstream runtime's dynamic WebAssembly module import without bundler rewriting. The generated files are rebuilt by both `npm run dev` and `npm run build`; no separate compiler command is required.
- **Inference:** dedicated worker, CPU delegate, one in-flight frame, roughly eight frames per second at most. Two-hand/absent-hand results are unknown. No frame or landmark sequence is recorded or persisted.
- **Rules:** extended/folded finger geometry and thumb separation for L/Y only. Multiple sustained observations are required before showing a candidate. The rules do not assess palm orientation, motion, language variation, nonmanual features, meaning, or comprehension. False matches and missed matches remain possible.
- **Clinical boundary:** the separate communication workspace remains scripted. No camera match is inserted into a clinical conversation. There is no model-confidence percentage or arbitrary text-to-sign function.

The official [MediaPipe model guide](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker) links to the [model card](<https://storage.googleapis.com/mediapipe-assets/Model%20Card%20Hand%20Tracking%20(Lite_Full)%20with%20Fairness%20Oct%202021.pdf>), which lists Apache License 2.0 and describes experimental-use limitations. These upstream evaluations do not validate InterpretAI or its geometry rules. A local copy of the Apache license is in `public/third-party/mediapipe-Apache-2.0.txt`.

## Scripted avatar path

The Three.js 0.186.1 viewer uses original procedural mannequin geometry and two authored finger poses. It has no external avatar mesh, signing corpus, motion-capture clip, texture, or generative language model. Three.js is MIT-licensed; its notice is in `public/third-party/three-MIT.txt`.

These poses have not been reviewed by Deaf ASL experts. They are labeled **SCRIPTED POSE - UNREVIEWED** and must not be treated as ASL instruction or as interpreting a clinical message. Replay interpolates finger joints; it does not generate linguistically validated sign motion. Slow playback, front/angled views, a text description, a WebGL-unavailable fallback, and reduced-motion behavior are provided.

[ASL University's manual-alphabet reference](https://www.lifeprint.com/asl101/fingerspelling/abc.htm) is linked for context. No Lifeprint photo, video, or drawing is copied or redistributed.

## Download and privacy

- The optional model/runtime total is about 21.8 MB. They are excluded from automatic core service-worker precaching.
- The user explicitly downloads and hash-verifies the files into a separate versioned cache. The service worker serves only those allowlisted optional paths from that cache.
- The avatar, explanatory page, and application code work after the core application is cached. Offline hand tracking additionally requires the optional files, a supported secure browser, available camera hardware, and camera permission.
- Startup can be canceled. Stop, route unmount, or hiding the tab releases camera tracks and terminates the worker. Late permission results are stopped. Audio is never requested.
- Removing optional files does not clear the core communication toolkit. Clearing browser storage removes offline downloads. No camera-derived material is retained.

## Evaluation boundary and next work

Synthetic-landmark unit tests check geometry and temporal gating. Browser tests can check real model initialization, unknown results on a blank fake camera, offline initialization, track cleanup, failure handling, accessibility, and UI behavior. They do not validate recognition on real signers, pose legibility, clinical safety, or subgroup equity. Deaf-led review and properly consented, representative technical evaluation are required before extending the vocabulary or making performance claims.
