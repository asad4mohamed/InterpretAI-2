# Known limitations

## Sign recognition (4.0)

- **Isolated signs only, 250 of them.** Each sign must be separated by a short pause or by lowering the hands. Natural, fast, co-articulated signing will be segmented poorly. No ASL grammar, facial grammar, classifiers, role shift, or sentence translation.
- **Vocabulary is from a children's word list (PopSign).** Most healthcare signs are missing: PAIN, HELP, NEED, WANT, MEDICINE, DOCTOR, NURSE, NAME, YOU, ME, WHAT, HOW. Child-directed labels (POTTY, OWIE) need Deaf review before adult use.
- **Accuracy:** 72.1% top-1 on 3 held-out signers (authors' measurement; 32 classes below 50%). Re-checked here on only 6 real clips (5/6). **No live-webcam, Deaf-user, or clinical evaluation has been done** (WEBCAM-MANUAL-TEST.md is ready but not yet run).
- **Out-of-vocabulary signs** can be confidently mapped to a similar supported sign; the "Not sure" threshold reduces but does not prevent this. Everything is reviewed by the patient.
- **Required phrases:** "What is your name?" is unsupported; "Hi, how are you?", "I need help" and "Where is the bathroom?" are partial; only HELLO was verified with a real recording. See PHRASES.md.
- **The model's authors say it should not be used for accessibility-critical communication.** InterpretAI uses it only as a research prototype.
- **Not retrained or fully re-evaluated here:** the Kaggle data, GPUs and PyTorch were not reachable in the build environment. `npm run eval:signs` reproduces the evaluation on your machine.
- **Performance** measured only in a Linux container with headless Chromium (Holistic ≈ 20 ms/frame on an empty scene, CPU delegate; model 2.5–9 ms per sign). Not measured on a Mac, with a real person in view, or on low-end hardware.
- **One person at a time;** a second person pauses recognition. Lighting, distance (head and shoulders must be visible) and camera quality matter.
- **Phrase table** is 22 hand-written patterns, not linguistically validated.

## Recognition (3.0)

- **Fingerspelling only for real recognition.** The bundled working model reads 24 static manual-alphabet letters. It does **not** recognise ASL signs, movement (J, Z), facial grammar, or sentences. Evaluation is limited (MODEL-CARD-FINGERSPELLING.md): 94.5% on a same-source hold-out and 21/24 on one unseen signer. P→Q and T→S errors were observed with high confidence. Not validated with Deaf fingerspellers at natural speed.
- **Hugging Face** works only with a model you deploy (a Dedicated Endpoint is recommended). No ASL model was found that is served by an HF Inference Provider, and a single photo cannot capture movement.

- **No arbitrary ASL translation.** Nothing in this build translates arbitrary ASL. Mode 1 detects two handshapes. Mode 2 needs a supplied model, and none is bundled. Mode 3 depends on Sign-Speak's service, whose accuracy InterpretAI has not evaluated.
- **No real-service testing.** Sign-Speak and Hand Talk integrations were tested only against mocks. Endpoint details for Sign-Speak come from its official SDK because the documentation site could not be read programmatically. Video size and length limits, error bodies, pricing and the batch-delete call remain unverified.
- **Confidence values** come from providers or the model. They are labelled, but InterpretAI has not verified their calibration.
- **Hands only.** No face or pose landmarks (see NONMANUAL-FEATURES.md). Location features are camera-relative.
- **L/Y rules** need one hand, roughly frontal, and steady. They ignore palm orientation and can be fooled by similar shapes.
- **Handedness** depends on MediaPipe's classification and on frames being unmirrored. Unusual camera drivers that pre-mirror video would invert it.

## Safety

- Keyword safeguards are English-only and simplistic. They miss paraphrases ("my chest feels tight", "elephant on my chest") and may flag harmless phrases ("a stroke of luck").
- Escalation pauses automation but cannot force a clinic to provide an interpreter. Interpreter requests are simulated.
- Patient confirmation shows agreement with displayed text, not comprehension.

## Privacy and compliance

- Not HIPAA assessed. Not medically approved. Fictional data only.
- When Mode 3 is used, the clip is processed by Sign-Speak under its own terms. Review a business associate agreement and data retention terms before any real use.
- The Hand Talk token is visible to the browser. That is inherent to its SDK.

## Platform

- The static export has no server routes. Cloud features require running `npm run proxy` (or deploying it).
- CSP extensions are applied by `scripts/serve.mjs`. Other static hosts must be configured to match.
- The Hand Talk CSP uses `https://*.handtalk.me` because the exact hosts are undocumented.
- Browser support: tested in Chromium. Safari's MediaRecorder produces MP4. That is accepted by the validators but has not been tested end-to-end.
- Offline: first-ever offline visits cannot install the app, and browser storage eviction removes caches.
- Text-to-speech uses the browser's voices. Quality and availability vary, and nothing is spoken unless enabled.

## Process

- No Deaf-led review of any vocabulary, avatar output, or UI copy has happened yet.
- Automated accessibility checks are not a substitute for testing with Deaf users and assistive technology.
