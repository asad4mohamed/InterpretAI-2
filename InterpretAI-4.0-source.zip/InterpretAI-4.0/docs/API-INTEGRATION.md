# API integration guide

InterpretAI runs fully without any API credentials. This guide covers how to connect the two optional external providers once you have approved access:

| Provider | Used for | Where the credential lives | Status in this build |
|---|---|---|---|
| **Sign-Speak** | ASL video → English text (recognition), English → ASL video (production) | **Server only**: `SIGN_SPEAK_API_KEY` in the proxy process | Integration-ready, awaiting credentials. Tested only against a local mock. |
| **Hand Talk for Devs** | English → ASL 3D signing avatar (browser SDK) | Browser token `NEXT_PUBLIC_HANDTALK_TOKEN` (the SDK is client-side by design) | Integration-ready, awaiting a token. Not live-tested. |
| **Hugging Face** | One still photo → labels from your image-classification model (e.g. ASL letters) | **Server only**: `HF_TOKEN` (+ `HF_ASL_ENDPOINT_URL` or `HF_ASL_MODEL_ID`) in the proxy | Integration-ready, awaiting your token and endpoint. Tested only against a local mock. |
| *(none)* — bundled | On-device fingerspelling, 24 static letters | No credentials | **Working**: trained and evaluated in this repo (MODEL-CARD-FINGERSPELLING.md) |

None of the external integrations was exercised against the real service while building this release, because no approved credentials were available and huggingface.co was unreachable from the build environment. Treat all three as **untested against production** until you complete the checklist at the end of this page.

---

## 1. How the pieces fit

```
Browser (static export)                 Optional proxy (Node, no deps)          Provider
┌─────────────────────────┐  HTTPS/   ┌──────────────────────────────┐ HTTPS  ┌──────────────┐
│ Experimental workspace  │ loopback  │ server/proxy.mjs             │ ─────▶ │ Sign-Speak   │
│  • records a clip only  │ ────────▶ │  • holds SIGN_SPEAK_API_KEY  │        │ api.sign-    │
│    on request           │           │  • CORS allow-list           │ ◀───── │ speak.com    │
│  • sends only after     │ ◀──────── │  • size/type/consent checks  │        └──────────────┘
│    per-clip consent     │           │  • 202 batch polling relay   │
│  • never sees the key   │           │  • no body logging, no-store │
└─────────────────────────┘           └──────────────────────────────┘
          │ Hand Talk SDK (token, browser) ─────────────────────────────────▶ *.handtalk.me
```

Next.js `output: "export"` produces static files only. It **cannot** run server-side API routes, which is why the secure proxy is a separate, optional process.

---

## 2. Sign-Speak

### 2.1 Where the integration details come from

The public documentation at <https://app.theneo.io/sign-speak/sign-speak-api/api-specifications> is a JavaScript application whose endpoint pages could not be machine-read during development. Every endpoint, header and field used here was therefore taken from **Sign-Speak's own official SDK**, `@sign-speak/react-sdk` **0.7.3** (npm, published by `sign-speak`), files `dist/network/rest.js`, `rest.d.ts`, `websockets.js`, and its README:

| Item | Value used | Source in SDK 0.7.3 |
|---|---|---|
| Base URL | `https://api.sign-speak.com` | `rest.js`: `API_BASE` |
| Authentication | HTTP header `X-api-key: <key>` | `rest.js`: `requestHeaders.set("X-api-key", …)` |
| Recognition | `POST /recognize-sign` JSON `{ payload: <base64 video>, single_recognition_mode: true, request_class: "BLOCKING", model: "SLR.2.sm" }` | `recognizeSign()` defaults |
| Production (avatar video) | `POST /produce-sign` JSON `{ english, request_class: "BLOCKING", resolution: 512 }` → video blob | `produceSign()` defaults |
| Async processing | HTTP `202` with `{ batch_id }`; poll `GET /<endpoint>/<batch_id>` until non-202 | `runRequest()` |
| SDK polling | 1 s interval, 30 attempts | `runRequest()` defaults |
| Recognition response | `{ feedback_id, prediction: [{ feedback_id, timestamp_start_sec, timestamp_end_sec, finished, prediction, confidence }] }` | `RecognitionResult` type |
| Request classes | BLOCKING (falls back to batch after ~30 s), BATCH, WebSocket streaming | README "Request Types and Modes" |
| WebSocket | `wss://api.sign-speak.com/stream-recognize-sign`, API key sent in the first message | `websockets.js` |
| Rate limits / quotas | Per-account requests-per-minute and monthly processed minutes; see the developer dashboard | README "Known Limitations" |
| Key types | PRIVATE keys server-side only; PUBLIC keys for client-side inference | README "API Keys & Security" |
| Feedback | `POST /feedback/{feedback_id}` | `submitFeedback()`; **not used** by InterpretAI |

**Not documented in the material reviewed, so not invented:** maximum video length or file size, accepted container formats, specific error codes and bodies, pricing, and the HTTP method/path of "Delete Batch Result" (listed in the docs menu only). InterpretAI therefore:

- Applies its **own** conservative limits before upload: WebM or MP4, ≤ 10 s by default, ≤ 8 MB. These are application limits, not provider limits.
- Maps HTTP status classes rather than specific provider error codes. 401/403 → *authentication failed*, 429 → *rate limited*, other 4xx → *rejected*, 5xx → *provider error*, no answer → *timeout*.
- Implements **cancellation as a local abort**: polling stops and the proxy forgets the request. It does **not** call an undocumented delete endpoint. Add one once you have confirmed its exact form in the docs.
- Does **not** use WebSocket streaming. The reviewed-clip flow matches the consent model better. Streaming would need a separate consent design.

If your Sign-Speak documentation differs, change only `server/proxy.mjs` (endpoint paths and request fields) and `lib/asl/validation.ts` (`parseSignSpeakRecognition`). Nothing else depends on the provider's wire format.

### 2.2 Run the proxy locally (macOS)

```bash
cp .env.example .env.local
# edit .env.local:
#   SIGN_SPEAK_API_KEY=<your approved private key>
#   NEXT_PUBLIC_RECOGNITION_PROXY_URL=http://127.0.0.1:8787
#   NEXT_PUBLIC_AVATAR_PROVIDER=sign-speak      # optional, for English → ASL video

# terminal 1 — secure proxy
npm run proxy
# → InterpretAI secure proxy on http://127.0.0.1:8787

# terminal 2 — app (either)
npm run dev                       # development (inlines NEXT_PUBLIC_* at start)
npm run build && npm run start    # production; serves /runtime-config.json from .env.local
```

Check: `curl http://127.0.0.1:8787/health` returns `{"ok":true,"signSpeak":{"recognition":true,"production":true}}`. The key itself is never returned.

### 2.3 Proxy API (what the browser calls)

| Route | Purpose | Notes |
|---|---|---|
| `GET /health` | Is a key configured? | No secrets in the response |
| `POST /v1/sign-speak/recognize` | Body: raw `video/webm` or `video/mp4`. Header `X-InterpretAI-Consent: sign-speak` is required (`428` without it). | `200 {status:"completed", result}` or `202 {status:"pending", requestId}` |
| `GET /v1/sign-speak/recognize/:requestId` | Poll | `requestId` is an opaque UUID issued by the proxy. It is not the provider's batch ID, and unknown IDs return `404`. |
| `POST /v1/sign-speak/produce` | JSON `{ english }`, max 500 characters | Returns the video bytes, or `202` while pending |
| `GET /v1/sign-speak/produce/:requestId` | Poll | |

Errors: `{ "error": { "code", "message" } }` with 400/401/403/404/413/415/428/429/502/503/504.

### 2.4 Proxy environment variables

| Variable | Default | Purpose |
|---|---|---|
| `SIGN_SPEAK_API_KEY` | — | **Required** for Sign-Speak. Private; never prefix with `NEXT_PUBLIC_`. |
| `SIGN_SPEAK_API_BASE` | `https://api.sign-speak.com` | Override for testing/mocks |
| `SIGN_SPEAK_RECOGNITION_MODEL` | `SLR.2.sm` | The SDK default model |
| `PROXY_HOST` / `PROXY_PORT` | `127.0.0.1` / `8787` | Bind address |
| `PROXY_ALLOWED_ORIGINS` | `http://127.0.0.1:3000,http://localhost:3000` | Comma-separated browser origins |
| `PROXY_MAX_UPLOAD_BYTES` | `8000000` | Upload ceiling |
| `PROXY_MAX_TEXT_CHARS` | `500` | Production text ceiling |
| `PROXY_UPSTREAM_TIMEOUT_MS` | `40000` | Per upstream call |
| `PROXY_RATE_LIMIT_PER_MINUTE` | `20` | Per client IP |

### 2.5 Deploying the proxy

- Run it on a server you control, behind HTTPS (for example a reverse proxy with TLS). The browser accepts plain HTTP **only** for loopback proxy URLs.
- Set `PROXY_ALLOWED_ORIGINS` to the exact origin of your deployed app.
- Set `NEXT_PUBLIC_RECOGNITION_PROXY_URL` where the app is served. `scripts/serve.mjs` reads it at start and adds the proxy origin to the page's `Content-Security-Policy` `connect-src`. Other static hosts need the same CSP change and their own `/runtime-config.json`, or must bake the value in at build time.
- Keep the key in the host's secret store, not in files you ship.
- Do not enable request/body logging on the reverse proxy.

---

## 3. Hugging Face (image classification)

### 3.1 Verified contract

From the Hugging Face Inference Providers documentation for image classification (<https://huggingface.co/docs/api-inference/tasks/image-classification>):

| Item | Value |
|---|---|
| Authentication | `Authorization: Bearer hf_…`, using a user access token with the **Inference Providers** permission |
| Request | The image as a **raw bytes payload** (or base64 `inputs` with optional `parameters`). InterpretAI sends raw bytes with `Content-Type: image/jpeg`. |
| Response | Array of `{ "label": string, "score": number }` |
| Model availability | Providers serve a **defined set** of models, not every Hub model. The docs point to `hf models ls --warm --pipeline-tag image-classification`. |

The serverless route the proxy uses for Option B is `https://router.huggingface.co/hf-inference/models/<model id>`, the HF Inference provider path. A Hugging Face forum thread (<https://discuss.huggingface.co/t/hf-inference-api-error-on-image-classification-models/173325>) reports HTTP **410** "no longer supported by provider hf-inference" for image-classification models on that route. The ASL model pages reviewed (MODEL-SELECTION.md) state "This model isn't deployed by any Inference Provider". So **a Dedicated Inference Endpoint is the reliable option**.

### 3.2 Setup

```bash
# .env.local  (server-only values — never NEXT_PUBLIC_)
HF_TOKEN=hf_your_token_here
HF_ASL_ENDPOINT_URL=https://<your-endpoint>.endpoints.huggingface.cloud   # Option A (preferred)
HF_ASL_MODEL_ID=owner/model-name                                          # Option B, or label for A
NEXT_PUBLIC_RECOGNITION_PROXY_URL=http://127.0.0.1:8787
```

How to get the credentials:
1. **Token:** huggingface.co → Settings → Access Tokens → *Create new token* → Fine-grained. Enable "Make calls to Inference Providers", plus access to your Inference Endpoints if you use one.
2. **Endpoint:** model page → *Deploy* → *Inference Endpoints*, choosing the image-classification task. Hugging Face bills per hour while it runs.

Restart `npm run proxy`. It prints which target it is using. `curl http://127.0.0.1:8787/health` shows `"huggingFace":{"configured":true,…}` without revealing the token.

### 3.3 Proxy route

`POST /v1/hf/classify-image` takes a raw `image/jpeg|png|webp` body (≤ 2 MB). The header `X-InterpretAI-Consent: huggingface` is required (`428` without it).

- `200 {status:"completed", model, target, result:[{label,score}…max 5]}`
- Error codes: `401 auth-failed`, `404 model-unavailable` (HF 404/410), `429 rate-limited`, `503 not-configured` or `model-loading` (one automatic retry after `estimated_time`, capped at 8 s), `502 invalid-response/provider-error`, `504 timeout`
- The image buffer is zero-filled after the call. Bodies and labels are never logged.

In the browser, labels with score < 0.5 are reported as **Unknown**. Results go to the patient's review queue, never straight into the conversation.

### 3.4 Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "HF_TOKEN is not set on the proxy" | Add it to `.env.local` and restart `npm run proxy` |
| "API authentication failed" | The token is wrong or expired, or lacks the Inference Providers or endpoint permission |
| "not served at the configured Hugging Face target" | Option B with a model that no provider serves. Use a Dedicated Endpoint (Option A). |
| "model is still loading" | The endpoint is scaled to zero or cold. Wait and retry, or keep it running. |
| Mode shows "Unavailable – proxy could not be reached" | Run `npm run proxy` and check `NEXT_PUBLIC_RECOGNITION_PROXY_URL` |

## 4. Hand Talk for Devs

Verified from the Hand Talk developer documentation (<https://api-docs.handtalk.me/v1/en/javascript/getting-start> and the beta reference pages for Configs and Methods & Props):

| Item | Documented value |
|---|---|
| SDK | `<script src="https://api-cdn.handtalk.me/sdk/latest/ht-api-sdk.min.js">`; exposes `window.HTApi`; loads asynchronously |
| Construct | `new HTApi({ token, … })`, then `active()` before any other method |
| Sign language | `signLanguage`: `"ptBR-bzs"` (default) or `"en-ase"`. `ase` is the ISO 639-3 code for American Sign Language, and the introduction page lists ASL as supported. |
| UI language | `language`: `ptBR`, `enUS`, `esES` (labels only) |
| Placement | `parentElementSelector` (falls back to `body`) |
| Methods used | `translate(sentence)`, `pause()`, `resume()`, `stop()`, `repeat()`, `changeAnimationSpeed("normal"\|"slow"\|"fast")`, `disable()` |
| Text limit | 1,000 characters per translation request (HTTP 400 above) |
| Browser | Web pages in browsers **with WebGL support** only |
| Token | Must match the release channel (`beta` vs `latest`). Domain restrictions are **not described** on the pages reviewed; ask Hand Talk and restrict the token if possible. |

Setup:

```bash
# .env.local
NEXT_PUBLIC_AVATAR_PROVIDER=handtalk
NEXT_PUBLIC_HANDTALK_TOKEN=<your Hand Talk token>
```

`scripts/serve.mjs` then allows `https://*.handtalk.me` in the CSP for scripts, styles, images, fonts, media and connections. The exact set of hosts the SDK contacts is not documented, so this wildcard is a starting point. Tighten it after observing real traffic.

InterpretAI applies these rules before **any** provider is asked to sign:

1. Text is trimmed and must fit the provider limit (Hand Talk 1,000 documented; Sign-Speak 500 application limit).
2. Keyword safeguards block medication, allergies, diagnosis, consent, treatment and emergency topics, and recommend a qualified interpreter instead.
3. The English text stays visible under the avatar, and the output is labelled **Machine-generated · Unvalidated**.
4. Signing is paused while the conversation is escalated.

---

## 5. Verification checklist once you have credentials

- [ ] `npm run proxy` prints "Sign-Speak key loaded…"; `/health` shows `recognition: true`.
- [ ] Record a 2–5 s clip in the experimental workspace. Confirm that nothing is sent before you tick the per-clip consent.
- [ ] Inspect the proxy console. Only method, route, status and duration should be logged.
- [ ] Confirm the returned text matches the provider dashboard/usage. Note any confidence scale the provider documents.
- [ ] Try an invalid key and confirm the workspace shows **API authentication failed**.
- [ ] Hand Talk: confirm the avatar loads with `signLanguage: "en-ase"`, and check playback controls and the 1,000-character limit.
- [ ] Hugging Face: `/health` shows `configured: true`. Take a photo of a clear static letter, consent, send, and compare the label with the model's own widget or Space.
- [ ] Record outcomes in `docs/IMPLEMENTATION-STATUS.md`, changing "Integration-ready, awaiting credentials" only for what you actually verified.
