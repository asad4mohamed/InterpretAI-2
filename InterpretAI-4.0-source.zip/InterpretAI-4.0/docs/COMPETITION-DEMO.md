# Competition demo instructions

## Before you present (5 minutes)

```bash
npm install            # once
npm run build
npm run start          # http://127.0.0.1:3000
```

1. Open `/dashboard/` and wait for **Offline toolkit ready** in the footer.
2. Optional: open `/sample-lab/`, select **Download recognition tools** (21.8 MB), and wait for **Recognition tools downloaded**. This enables the on-device live mode.
3. Use Chrome or Edge on the same computer (localhost is a secure context for the camera).
4. With Sign-Speak credentials, also run `npm run proxy` (see API-INTEGRATION.md). Without credentials, present the *Not configured* state as the honest outcome.

## Core walkthrough (3–5 minutes): unchanged

Follow the eight steps on `/demo/` (also listed in README §Demonstrate). All scripted scenarios, the outage simulation, the medication stop and the interpreter request work exactly as in 2.0.

## Add-on 0 (recommended): continuous sign recognition (3 minutes)

Before the demo: open `/signs/` and press **Download sign recognition** (47.7 MB, once).

1. Sidebar → **Sign recognition**. Read the disclaimer and open **About this model**: 250 isolated signs, 72.1% on signers never seen in training, not sentence translation, not for accessibility-critical use.
2. **Show replay clips** → replay the last clip (HELLO). Point out the top-3 calibrated probabilities, the movement path, and that the model was not told the answer.
3. Replay the GIRAFFE clip: "HELLO GIRAFFE" has **no supported phrase**, and Confirm is disabled. Undo → "Hi." suggested → edit → Confirm.
4. With a camera: Start camera, step back so shoulders show, sign HELLO / THANK-YOU / WATER with pauses. Show Pause, Undo, and "Not sure" handling.
5. Open **Short phrases: what is supported** and say plainly which required phrases are partial or unsupported.
6. In Communication → Experimental live recognition → **ASL signs, continuous**: Review this phrase → review queue → confirm → conversation.

## Add-on A: real on-device fingerspelling (2 minutes)

1. **Communication → Experimental live recognition → ASL fingerspelling.** Read the "About this mode" panel aloud: 24 static letters, trained here, 94.5% / 87.5% evaluations, not signer-independent, not sentence translation.
2. Tick camera consent → **Start camera**. Fingerspell slowly, holding each letter about 1 s (e.g. **L-O-V-E** or **C-A-B**; avoid J and Z). Watch the letter tile fill, then commit.
3. Show **Delete last letter**, **Add space**, and **Pause recognition** (the camera stays on, nothing is processed).
4. Click **Review this spelling**. The output appears in *Machine output awaiting your review*, with model score and version. Confirm it and it moves into the conversation; or correct or reject it.
5. Point out the latency line (tracking ms/frame, model ms) and that it works with the network off.

## Add-on B: experimental live recognition, other modes (2 minutes)

1. **Communication → Experimental live recognition.** Point out that this tab is separate from the scripted scenarios, and that *Recognition off* is the default.
2. Show the four modes and their honest states: *Download needed* or *Available* (handshape lab), *Not configured* (local model: "we ship no trained model"), *Not configured* or *Available* (Sign-Speak).
3. Select **Experimental handshape lab**, tick camera consent, **Start camera**. Show two-hand tracking, the hand count, and the *No hands detected* / *Tracking lost* states. Hold an L handshape, **Capture sign (3 s)**, then confirm or reject the pending result.
4. In the care-team panel, type *"Let's review your medication dose."* The conversation escalates to **Human interpreter recommended**, and recognition and machine signing pause.
5. **Stop camera now.** The camera light turns off immediately. Finish with "AI should expand access, not replace human choice."

If Sign-Speak is configured: switch to Sign-Speak, **Record clip**, show the review screen and the per-clip consent. Then send and show the returned text with its source and the provider-reported confidence label.

## Talking points

- Real versus simulated is always labelled: scripted cards say *Simulation / Prevalidated Example*. Live results name their provider and processing location.
- Nothing is sent to the cloud without per-clip consent, and the API key never reaches the browser.
- Failures never fall back to scripted text.
