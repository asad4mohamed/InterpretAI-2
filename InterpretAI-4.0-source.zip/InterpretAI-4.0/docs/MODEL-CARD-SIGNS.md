# Model card: asl-signs-v1 (continuous isolated-sign recognition)

| | |
|---|---|
| **What it does** | Recognises **one isolated ASL sign at a time** from a closed vocabulary of **250 signs**, using hand, upper-body and lip landmarks over time. InterpretAI segments a live stream into signs, so several signs form a sequence. |
| **What it does not do** | Translate ASL sentences; understand ASL grammar, facial grammar, classifiers, role shift or fingerspelled words; recognise signs outside the 250; identify people. |
| **Origin** | Trained by the GestureSign project (Shashank Yadav, MIT licence), commit `26e8fa4`, model version `default-2fc9038cc4`. **Not trained by InterpretAI.** InterpretAI integrates it unchanged and verifies it (below). |
| **Files** | `public/models/asl-signs-v1/model.onnx` (5.6 MB, SHA-256 `2fc9038cc409…`, the hash prefix in the version name), `model-meta.json`, `labels.json`, `metrics.json` (upstream evaluation), `vocabulary.json` (InterpretAI, generated). |
| **Architecture** | Three blocks of depthwise temporal convolution + transformer, masked mean pooling, 128-d L2-normalised embedding, cosine-similarity logits. 1,395,520 parameters. ONNX opset 17. |
| **Input** | `frames`: float32 `[1, T, 460]`, T ≤ 64 frames at 30 fps. Per frame: dominant hand and other hand (21 points each), 11 upper-body pose points and 40 lip points, all relative to the shoulder midpoint and scaled by shoulder width; hand shapes relative to the wrist; presence flags; frame-to-frame velocity. Left-handed signing and mirrored cameras are canonicalised. Validated at load (`parseMeta`: feature version 2, feature dim 460). |
| **Output** | `logits` `[1, 250]`, `embedding` `[1, 128]`. Output count is checked against the vocabulary in the worker. |
| **Landmarks** | MediaPipe Holistic Landmarker (Google, Apache 2.0), float16 v1, pinned SHA-256 `e2dab611…`, CPU delegate, run in a Web Worker. The training data was produced with MediaPipe Holistic, so the input pipeline matches training. |
| **Runtime** | ONNX Runtime Web 1.30.0 (WASM, single thread), in the same worker. |

## Training data

Google – Isolated Sign Language Recognition (Kaggle competition `asl-signs`, from the PopSign project), **CC BY 4.0**. About 94,000 clips of 250 signs from 21 signers, recorded on phones, supplied as MediaPipe Holistic landmarks (no video). Split **by signer**: 70,272 clips for training, 9,809 for validation (participants 26734, 49445), 14,396 for testing (participants 16069, 37055, 61333). See [DATASET-SIGNS.md](DATASET-SIGNS.md).

Training (upstream): AdamW with warm-up and cosine decay, label smoothing, landmark augmentation (rotation, scale, shear, time stretch, dropped frames and hands), early stopping on validation top-1; stopped after 47 epochs; the epoch-39 checkpoint ships; seed 42.

## Evaluation

| Measure | Value | Who measured it |
|---|---|---|
| Top-1, 250 signs, 3 held-out signers, 14,396 clips | **72.1%** | Model authors |
| Top-5 | **88.1%** | Model authors |
| Top-3 | 85.3% | Model authors |
| Validation top-1 (2 signers) | 74.4% | Model authors |
| Answers given (not "Not sure") at threshold 0.29 | 91.8% of clips, **77.1% correct** when answered | Model authors |
| Per-class top-1, all 250 classes | 11% (AWAKE) to 100%; 124 classes ≥ 75%, 32 classes < 50% | Model authors ([VOCABULARY-SIGNS.md](VOCABULARY-SIGNS.md)) |
| **Re-check in InterpretAI**, 6 bundled held-out clips, InterpretAI's own pipeline | **5 / 6 top-1** (QUIET → SHH, a documented near-synonym confusion); same result in Node, in the browser worker, and in `ml/signs/evaluate.mjs` | InterpretAI (`tests/signs/interpretai-signs.test.ts`, `tests/e2e/signs.spec.ts`) |
| Inference latency (model only) | Node: 4–49 ms per sign on the 6 clips (first run includes warm-up; median ≈ 9 ms in `evaluate.mjs`). Chromium worker: first sign ≈ 59 ms, then 2.5–9 ms | InterpretAI (Linux container, single WASM thread) |
| Holistic tracking latency | ≈ 20 ms per frame on an empty scene, CPU delegate, headless Chromium | InterpretAI (Linux container). Not measured with a real person or on a Mac. |

**Not done here:** the full 14,396-clip evaluation was not re-run, because the Kaggle data cannot be downloaded in the build environment. `npm run eval:signs -- --data-dir <asl-signs>` reproduces it on your machine with InterpretAI's exact pipeline ([ml/signs/README.md](../ml/signs/README.md)). No evaluation with Deaf users of this app, live webcams, natural continuous signing, or clinical settings has been done.

## Decision rules (unknown-sign rejection)

- Softmax with temperature **T = 0.883** (calibrated upstream on held-out signers). Probabilities are shown as "calibrated probability".
- Top probability **< 0.29 → "Not sure"**. The token shows the top-3 guesses and must be resolved (pick one, or remove it) before any phrase can be suggested.
- If the shoulders were out of frame for most of the sign → "Not sure (partial)".
- More than one person in view → recognition pauses ("crowded").
- Segments shorter than 8 frames are discarded.
- **Limitation:** a sign outside the vocabulary can still be mapped to a similar supported sign with high probability. This is why every result is reviewed by the patient.

## Segmentation (sign boundaries)

A sign starts when a hand moves faster than 0.6 shoulder widths/s and ends when hands are still or absent for 300 ms (or after 4 s). Held signs do not repeat: after a still ending the segmenter waits for new motion. InterpretAI additions: (1) dropouts ≤ 150 ms keep the previous hand speed, so one lost frame does not cut a sign (found with real clips); (2) the history merges a same-sign segment that follows a short still pause (< 700 ms) or the 4-second cut, while a repeat after the hands dropped is kept as deliberate.

## Intended use

The model authors state that it is for learning and practising ASL vocabulary and showing how on-device recognition works, and that **it should not be used where a misrecognised sign could matter, such as accessibility-critical communication**. Healthcare communication is such a setting. InterpretAI therefore uses it only inside a research prototype with mandatory patient review, high-risk escalation, and qualified interpreter access. It must not be used for real clinical communication.

## Known failure modes

Near-synonym pairs (AWAKE/WAKE, QUIET/SHH, SLEEP/NAP, PEN/PENCIL, CAT/KITTY); pointing signs (HE/SHE/IT, THAT, THERE); signers, body types, framings and cameras unlike the 21 training signers; dim or back-lit scenes (landmarks degrade); fast co-articulated signing without pauses; signs from regional variants or Black ASL not represented in PopSign; one person only. Child-directed labels from PopSign (POTTY, OWIE, KITTY, PUPPY) need Deaf review before adult use.
