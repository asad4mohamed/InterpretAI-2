# InterpretAI — delivery and verification

Implemented in the current workspace with Next.js 16.4.2 App Router, React 19.3.1, strict TypeScript, Tailwind CSS 4, local DM Sans, and Lucide icons. No API keys, external service integrations, database, account, or analytics are required.

## Delivered

Ten responsive routes: landing, patient overview, communication workspace, preventive care, preferences, resources, safety, research impact, competition demo, and sample lab. All five scripted scenarios operate with navigation, confirmation/correction, restart, and high-risk/patient-choice stops. Qualified interpreter requests use an accessible, explicitly fictional workflow. The production PWA precaches 106 core static export assets, including every route, the scripted avatar, and local fonts. Four optional hand-tracking files (21.8 MB) are excluded from automatic downloads.

The visual revision replaces floating mockups, pastel icon tiles, and repeated slogan cards with editorial typography, a restrained navy/olive palette, clearer section rules, a direct conversation preview, and an appointment-focused patient overview. Page labels are explicit across the application. Existing scenario, interpreter, privacy, and offline behavior is preserved.

The October 23 executive-summary update adds the proposed 10–12 rural Texas FQHC scope, a five-year $5M planning envelope, revised approval-gated phases, eight filterable evaluation measures with baselines pending, two proposed technology pathways, subgroup evaluation lenses, and a sustainability hypothesis. Scenario B now includes scripted teach-back of visit logistics with confirmation and correction; no comprehension score is calculated. Landing, dashboard, safety center, competition demo, and documentation reflect the proposal.

The separate sample lab adds actual local MediaPipe hand-landmark inference in a worker, followed by original geometric rules for L-like and Y-like handshapes only. Sustained observations and explicit user confirmation are required. Unsupported inputs remain unknown. The model is not an ASL classifier. An original Three.js mannequin demonstrates two fixed, unreviewed finger poses with replay, slow playback, and front/angled views. Manual pose selection never creates a camera result. The optional download is hash-verified and can be removed independently of the core toolkit. Camera frames and landmarks are not uploaded or persisted; microphone access is never requested.

## Verification results

| Check | Result |
|---|---|
| Dependency installation | Passed; npm lockfile included |
| ESLint | Passed, zero errors or warnings |
| TypeScript | Passed; route types generated before checking |
| Production static build | Passed; all routes exported |
| Unit tests | 31 passed: scenario/safety rules, handshape geometry/temporal gating, and static-export navigation mapping |
| Playwright browser tests | 18 passed in Chromium; clean exit in 32.8 seconds against a separately started production preview |
| Automated accessibility | No violations of tested WCAG A/AA tags across all ten main pages, interpreter modal, and high-risk stop |
| Real offline test | Passed: browser network disabled after first download; reload and direct navigation to previously unvisited core routes worked |
| Outage simulation | Passed; clearly distinguished from actual browser status |
| Camera denial | Passed; scripted communication remains usable without a camera |
| Local model inference | Passed: real model initializes and processes synthetic camera frames; blank frames remain unknown, with no confidence score |
| Optional offline recognition | Passed: explicitly downloaded model/runtime initialize again after actual browser network loss and reload; no external runtime HTTP requests observed |
| Camera lifecycle | Passed: stop and route navigation end video tracks and terminate the worker; startup cancellation and simulated permission denial leave no worker running; no audio tracks |
| Optional download failure/removal | Passed: failure leaves avatar and interpreter choice usable; removing optional files preserves core offline scenarios |
| Avatar interaction | Passed: manual L/Y selection, replay, speed/view controls, and independence from camera results; no optional model download is triggered by avatar use |
| Modal and mobile navigation keyboard behavior | Passed: focus containment, hidden-menu exclusion, Escape to close, and focus restoration |
| Reflow | Passed at 320px, 390px, and 768px for tested routes; desktop screenshots at 1440px |
| Executive-summary research controls | Passed: category filters, evaluation methods, both technology directions, keyboard-operated subgroup lens, cumulative $5M chart, and budget table |
| Scripted teach-back | Passed: explicit confirmation required, correction blocks progression, and completion reports that no comprehension score was calculated |
| Offline research interactions | Passed: technology direction and age-group evaluation controls operate after actual browser network loss |

Windows in this environment intermittently denied concurrent nested build-folder creation and failed to start Turbopack’s CSS worker. The build script uses Next.js’s supported Webpack compiler and serializes libuv filesystem work on Windows. Other platforms retain the default compiler; the development command uses Webpack for consistent local previews. No application runtime behavior is affected.

## Run

From the project root, with Node.js 22+ and npm:

```powershell
npm install
npm run build
npm run start
```

Open http://127.0.0.1:3000. For development use `npm run dev`; offline caching is deliberately disabled in development. Start the guided walkthrough at `/demo/`. For a real offline demonstration, wait for **Offline toolkit ready**, disable the browser network, then reload `/communication/`.

```powershell
npm run lint
npm run typecheck
npm test
npm run test:setup
npm run test:e2e
```

The setup script downloads Chromium to the ignored `work/browsers/` directory. E2E tests use the production build and start their own local server if one is not already running.

## Limits

- **Simulated — Not Clinically Validated.** Clinical conversations remain scripted. The sample lab has a real local landmark model and two experimental geometry rules; it does not translate ASL.
- Continuous ASL recognition, speech input/output, an ASL-interpreting avatar, and telehealth integration are proposed research only. The two mannequin poses are unreviewed technical illustrations. No enrolled Texas clinics, funding awards, subscription prices, or subgroup validation are claimed. HIPAA compliance has not been assessed.
- ASL videos are labeled placeholders, and authored English examples have not undergone clinical/linguistic validation. The competition label “Simulation / Prevalidated Example” does not establish real validation.
- Interpreter requests do not contact or book anyone. Real interpretation follows the clinic’s actual process. VRI requires connectivity.
- Safety checks use fixed scenarios and limited English keywords; they can miss topics and produce false positives.
- All patients, appointments, reminders, and requests are fictional. Research baselines and performance targets are not yet set. The $5M total is a proposed envelope; annual allocations are planning illustrations, not measured outcomes or actual spending.
- Checklists, notes, and preferences reset on reload; only public demo assets are cached. No real health information should be entered.
- Offline operation requires a successful first download and can be lost if browser storage is cleared or evicted.
- Recognition on real signers, physical camera hardware, pose clarity, Safari/Firefox, screen-reader experiences, clinical use, and Deaf-led usability have not been validated here. Synthetic geometry and blank-camera tests establish implementation behavior, not recognition accuracy. Automated checks do not establish complete WCAG conformance.

Qualified human interpretation and patient choice remain central. The prototype cannot replace the right to effective communication or appropriate qualified interpretation.

## Version 2.1.0 update (23 October 2026)

Added the experimental live-recognition workspace, the provider-independent recognition layer (`lib/asl/`), the shared camera and tracker lifecycle with two-hand tracking, a local-model interface, the Sign-Speak adapter with an optional secure proxy, signing-avatar adapters, runtime configuration, and new documentation. Fixed a pre-existing issue: offline precaching failed on macOS and Linux builds because Next.js writes flattened segment payloads there.

| Check | Result |
|---|---|
| ESLint / TypeScript | Passed, zero errors and warnings |
| Unit tests | 119 passed (31 existing + 88 new) |
| Production build | Passed, 11 routes; 95 core assets precached |
| Playwright | 25 passed (18 existing + 7 new), Chromium, fake camera |
| External APIs | Mocked only. No live Sign-Speak or Hand Talk test (no credentials). |

Details: [TEST-RESULTS.md](TEST-RESULTS.md) and [IMPLEMENTATION-STATUS.md](IMPLEMENTATION-STATUS.md).
