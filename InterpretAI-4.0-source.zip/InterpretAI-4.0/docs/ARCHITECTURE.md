# Architecture (3.0)

InterpretAI 2.1 is still one Next.js 16 App Router project exported as static files (`output: "export"`). The release adds a provider-independent recognition layer and one optional backend: the secure proxy. Without the proxy, the app behaves as before.

## Directory map

```
app/                     Routes (static). /communication now hosts two tabs.
components/
  communication-modes.tsx      Tabs: Scripted scenarios | Experimental live recognition
  communication-workspace.tsx  Unchanged five scripted scenarios (shared camera helpers)
  recognition-workspace.tsx    Experimental two-panel workspace (patient / care team)
  signing-avatar-panel.tsx     Optional English → ASL provider output
  use-hand-tracker.ts          ONE camera + MediaPipe worker lifecycle (lab + live)
  use-recognition-config.ts    Public config, provider registry, availability
  handshape-lab.tsx            Sample lab, now built on use-hand-tracker
  avatar-sample.tsx / avatar-scene.ts   Three.js mannequin (unchanged)
lib/
  camera.ts                    Permission errors, constraints, cleanup, frame pacing
  asl/types.ts                 Provider, request, result, consent, error contracts
  asl/config.ts                Public runtime config (never secrets)
  asl/validation.ts            Clip, sequence and provider-response validation
  asl/landmark-sequence.ts     Temporal landmark format, normalisation, smoothing
  asl/local-recognition.ts     Mode 2 manifest/weights validation + dense-MLP runtime
  asl/sign-speak.ts            Mode 3 client (talks to the proxy only)
  asl/provider-registry.ts     Modes 1–4 and availability resolution
  asl/recognition-manager.ts   Consent, offline and cancellation rules; no fallback
  asl/recognition-state.ts     UI phases + conversation reducer (review/correct)
  asl/avatar.ts                Signing-avatar adapters (Sign-Speak video, Hand Talk SDK)
  asl/fingerspelling.ts        3.0: bundled model loader, features, classifier + rejection, speller
  asl/huggingface.ts           3.0: Hugging Face image-classification adapter (via proxy)
components/recognition-parts.tsx  3.0: review/conversation cards, model info panel, live readout
public/models/asl-fingerspelling-v1/model.json  3.0: trained model (precached for offline)
ml/                            3.0: data prep, training, export, evaluation scripts
  handshapes.ts                L/Y geometry rules (unchanged)
workers/hand-tracker.worker.ts MediaPipe Hand Landmarker, 2 hands + handedness
server/proxy.mjs               OPTIONAL secure proxy (Node, zero dependencies)
scripts/serve.mjs              Static server + /runtime-config.json + CSP
scripts/build-sw.mjs           Service worker generator
```

## Recognition modes (3.0)

| Mode | Provider ID | Input | Runs | Output | Confidence |
|---|---|---|---|---|---|
| **ASL fingerspelling (bundled, trained)** | `fingerspelling` | Live landmarks, every processed frame | On device, offline | Spelled letters (24 static), after patient review | Model softmax, labelled *not calibrated* |
| Experimental handshape | `experimental-handshape` | Live landmarks (3 s capture) | On device | L-like / Y-like | None |
| Local trained model (supplied) | `local-model` | Landmark sequence | On device | Isolated sign from manifest vocabulary | Model softmax |
| Sign-Speak | `sign-speak` | Reviewed video clip | Cloud via proxy | Provider English text | Provider-reported |
| Hugging Face | `huggingface` | One reviewed still photo | Cloud via proxy | Labels of your model | Provider-reported |
| Off | `unavailable` | — | — | Nothing | — |

Real-time behaviour, stated precisely: fingerspelling processes frames live (about 8–10 fps on a fast machine, adapting down to 2 fps). Sign-Speak is **clip-based**, Hugging Face is **single-photo**, and neither streams.

## Earlier table: the four 2.1 recognition modes

| Mode | Provider ID | Input | Runs | Output granularity | Confidence |
|---|---|---|---|---|---|
| 1 Experimental handshape | `experimental-handshape` | Live landmarks (3 s capture) | On device | `handshape` (L-like / Y-like) | None (rules give no score) |
| 2 Local trained model | `local-model` | Landmark sequence | On device | `isolated-sign` from a closed vocabulary | Model softmax score, labelled *not calibrated* |
| 3 External API | `sign-speak` | Reviewed video clip | Cloud via proxy | `continuous-english` text from provider | Provider-reported, labelled as such |
| 4 Unavailable | `unavailable` | — | — | Nothing | — |

Every provider implements `RecognitionProvider { descriptor, availability(ctx), recognize(request, onStatus) }`. A descriptor declares its capabilities: granularity, input kind, processing location, whether it reports confidence, cancellability, offline support and vocabulary. The UI is driven by these declarations, so a new provider needs no UI changes.

## Guarantees enforced in code (and tested)

| Guarantee | Where | Test |
|---|---|---|
| No upload without per-clip third-party consent | `RecognitionManager.run`, `createSignSpeakProvider`, proxy `428` | `recognition-providers`, `sign-speak-adapter`, `proxy`, e2e |
| Cloud refused offline / in demo outage | manager + availability | unit + e2e |
| No fallback to another provider or scripted text after failure | manager | unit + e2e |
| Unknown results never become conversation text | `conversationReducer` | unit + e2e |
| Confidence never invented | `parseSignSpeakRecognition`, `classifySequence` | unit |
| Recognised text starts *pending review*; only the patient confirms/corrects/rejects | reducer | unit + e2e |
| High-risk text (recognised, corrected, typed) escalates and pauses automation | manager + reducer + avatar gate | unit + e2e |
| Private key never in browser code or build | proxy-only env | `privacy-guards`, `serve` |

## Camera pipeline

`use-hand-tracker.ts` is the only place that creates the tracking worker and the camera stream for the lab and the live workspace:

1. `start({ track })` → (if tracking) spawn the module worker `/lab-engine/hand-tracker.mjs`. The worker reports `progress: runtime → model`, then `ready`.
2. `getUserMedia({ video, audio: false })` runs only after an explicit click. A grant that arrives after a cancel is stopped immediately.
3. Frames are copied into transferable `ImageBitmap`s, one in flight at a time. Pacing adapts to the measured processing time (100–500 ms; `nextFrameInterval`). Slow devices see a notice.
4. The worker enforces strictly increasing timestamps, returns **up to two hands** with landmarks, world landmarks and handedness (corrected for unmirrored frames), and runs the L/Y rules only when exactly one hand is visible.
5. `stop()`, unmount, tab hide, or unchecking consent terminates the worker and stops every track.

The scripted workspace's simple preview shares the same constraints and cleanup helpers (`lib/camera.ts`). Only one communication tab is mounted at a time, so the page never holds two streams.

## Configuration flow

```
.env.local ──▶ npm run proxy   (reads SIGN_SPEAK_API_KEY etc.; never served)
           └─▶ npm run start   (serves /runtime-config.json with NEXT_PUBLIC_* values;
                                adds proxy / Hand Talk origins to CSP)
           └─▶ npm run dev/build (inlines NEXT_PUBLIC_* as fallback)
browser: loadPublicConfig() → /runtime-config.json → build env → safe defaults
```

## Offline

- Core pages and scripted scenarios are precached by the generated service worker, as before.
- `/runtime-config.json` is network-first with a cached fallback, so on-device model settings survive offline reloads. It contains no secrets.
- Lab assets keep their own hash-verified cache. Local models are cached only after the explicit **Save this model for offline use** action (`interpretai-model-*` caches, preserved across app updates).
- The service worker ignores POST and cross-origin requests, so proxy calls, video and API responses are never cached.
- Real browser connectivity (`navigator.onLine`) and the **Simulate outage** demo switch stay separate, and both disable cloud features.

## Build-time fix in 2.1

Next.js writes React segment payloads flattened (`__next.dashboard.__PAGE__.txt`) with Turbopack on macOS and Linux, and nested (`__next.dashboard/__PAGE__.txt`) with Webpack on Windows. The 2.0 server and service worker handled only the nested form, so offline precaching never finished on macOS. Both now try the literal path first and the mapped path second.

## 4.0: continuous sign recognition pipeline

```
camera (getUserMedia, video only)
  → use-sign-tracker.ts: ImageBitmap every ≥33 ms (adaptive, ≤200 ms), one frame in flight
  → workers/sign-tracker.worker.ts (module worker, compiled to public/sign-engine/ by scripts/prepare-signs.mjs)
      MediaPipe HolisticLandmarker (CPU) → assemble.ts: 543×3 frame (face, left hand, pose, right hand; NaN = missing)
      → Recognizer: frameStatus (nothing / no-hands / crowded / partial / ok)
                    Segmenter (motion start, 300 ms still/absent end, 4 s cap, dropout bridging)
                    features.ts (body-relative, dominant-hand canonicalised, velocity; 460-d; ≤64 frames @30 fps)
                    ONNX Runtime Web (WASM) → logits[250] → decision.ts (temperature, "Not sure" < 0.29)
      → movement.ts: live movement + per-sign summary
      → posts: frame status (no face points), signing, discarded, result
  → sign-recognition-panel.tsx: sequence.ts (history, merge, uncertain, undo) → phrases.ts (fixed table) → review
      standalone (/signs/): confirm on page, risk check
      workspace: asl-signs provider → RecognitionManager (consent, risk) → review queue → conversation
```

- Landmark format: `kaggle-asl-signs 543×3` (the training format), feature version 2; `parseMeta` refuses other versions and sizes. The 3.0 hand tracker and fingerspelling model are unchanged; Holistic hand points use the same 21-point image format and feed the letter model in sign mode.
- Assets: `lib/sign-assets.json` (generated) lists every optional file with size and SHA-256; `lib/sign-cache.ts` downloads and verifies; the service worker serves them from `interpretai-signs-v1`.
- Pure logic (`lib/asl/signs/*`) is shared by the worker, the page, Node tests and `ml/signs/evaluate.mjs`, so evaluation uses exactly the app's pipeline.
