# InterpretAI 4.0 — final requirements and acceptance audit

Audited on 24 October 2026 against the actual source, model assets and test runs in this repository. "PASS" means implemented **and** verified by the stated test or measurement. Where verification was only possible on the 6 bundled real clips, a synthetic camera or upstream (third-party) evaluation, the entry says so. Nothing below is based on a file or label merely existing.

Key: **P** = PASS · **PA** = PARTIAL · **B** = BLOCKED. Test names refer to `tests/` (unit: Vitest; e2e: Playwright). Environment limits: only GitHub and package registries were reachable; no Kaggle, Hugging Face, Google Cloud Storage, PyTorch wheels, GPU, real webcam or human signers.

## Summary

| | Count |
|---|---:|
| 1. Total requirements | **156** |
| 2. PASS | **138** |
| 3. PARTIAL | **14** |
| 4. BLOCKED | **4** |
| 5. Completion (verified PASS only) | **88.5%** (138 / 156) |

## A. Existing application preservation (10 P)

| # | Requirement | Status | Files | Evidence / verification | Remaining |
|---|---|---|---|---|---|
| A1 | Launches | P | `scripts/serve.mjs`, `build.mjs` | `npm run build` + `npm run start`; every e2e test runs against it | — |
| A2 | Navigation | P | `components/app-shell.tsx` | e2e `app.spec.ts` (mobile nav, focus, Escape), new sidebar entry | — |
| A3 | Dashboard | P | `app/dashboard` | e2e "patient overview…" | — |
| A4 | Healthcare scenarios | P | `lib/scenarios.ts` | 20 unit tests; e2e scenarios A–E | — |
| A5 | 24-letter fingerspelling | P | `lib/asl/fingerspelling.ts` | e2e fingerspelling + **real-photo pipeline** test pass; unit parity tests | — |
| A6 | Hand tracking | P | `workers/hand-tracker.worker.ts` (unchanged) | e2e lab and handshape tests with real MediaPipe | — |
| A7 | Confirm/correct | P | `lib/asl/recognition-state.ts` | unit + e2e review queue | — |
| A8 | Offline architecture | P | `scripts/build-sw.mjs` | e2e "full toolkit works after actual browser network loss"; new caches additive | — |
| A9 | Privacy/safety controls | P | `tests/privacy-guards.test.ts` | 8 guard tests pass (2 new) | — |
| A10 | No regression | P | — | all 29 pre-existing e2e and all pre-existing unit tests pass | — |

## B. Webcam and movement tracking (15 P)

| # | Requirement | Status | Files | Evidence / verification | Remaining |
|---|---|---|---|---|---|
| B1 | Permission explicitly requested | P | `sign-recognition-panel.tsx` | Consent checkbox + Start; `getUserMedia` only then (e2e live camera; consent withdrawal disables) | — |
| B2 | Live preview | P | `use-sign-tracker.ts` | e2e with Chrome's fake camera: stream attached, Holistic processes frames | Real webcam: manual procedure |
| B3 | Both hands tracked | P | `assemble.ts`, worker | Holistic left/right hands → 543-point frame; unit tests for two-hand assignment; overlay draws both | Live two-hand signing not tested with a person |
| B4 | Movement across frames | P | `segmenter.ts`, `movement.ts` | segments carry all frames; unit tests on real clips | — |
| B5 | Direction | P | `movement.ts` | `directionOf`, signer perspective; unit tests; shown in UI (e2e) | — |
| B6 | Trajectory | P | `movement.ts`, panel | 16-point trajectory, SVG sketch; unit test on real GIRAFFE clip | — |
| B7 | Timestamps | P | worker, `segmenter.ts` | monotonic timestamps; segment timestamps; fps estimated (unit) | — |
| B8 | Temporal smoothing | P | `movement.ts`, `segmenter.ts` | EMA trajectory + smoothed speed; unit test shows jitter reduced | — |
| B9 | Missing landmarks | P | `landmarks.ts`, `movement.ts` | NaN representation; gap bridging (unit) | — |
| B10 | Tracking loss | P | `segmenter.ts` (fixed) | real-clip stream with a dropped frame keeps HELLO GIRAFFE (unit); no-hands / nothing states | — |
| B11 | Dominant hand documented | P | `features.ts`, MODEL-CARD-SIGNS | rule documented (more frames, then wrist travel; mirrored canonicalisation) | — |
| B12 | Mirrored preview safe | P | CSS mirror only; `features.ts` | frames sent unmirrored; unit test "mirrored clip gives the same features"; real clips confirm anatomical labels | — |
| B13 | Sign segmentation | P | `segmenter.ts` | 13 unit tests; real-clip stream HELLO POLICE BLUE segmented correctly | Natural fast signing untested |
| B14 | No duplicate on a held sign | P | `segmenter.ts`, `sequence.ts` | unit "does not start on a hand held still", "waits for new motion"; merge test; e2e QUIET → one token | — |
| B15 | Camera released | P | `use-sign-tracker.ts` | e2e: no stream after Stop; unmount/hidden tab stop | — |

## C. Pose and facial landmarks (8 P)

| # | Requirement | Status | Evidence |
|---|---|---|---|
| C1 | Body landmarks | P | Holistic pose (33); upper-body features; crowd detection via pose count (e2e "No one in view") |
| C2 | Face landmarks | P | Holistic face mesh → 40 lip points as model input (`features.ts`) |
| C3 | Body-relative hand position | P | shoulder-anchored features; movement regions head/chest/lower (unit) |
| C4 | Versioned format | P | 543×3 Kaggle layout, feature version 2; `parseMeta` refuses other versions (unit) |
| C5 | Existing models compatible | P | hand tracker untouched; unit test feeds Holistic hand points to the 3.0 letter model |
| C6 | Graceful degradation | P | partial / no-hands / crowded / nothing states and "Not sure (partial)" (unit) |
| C7 | Face not used for identification | P | no identification code (inspection); only lip shape enters the classifier |
| C8 | Face not stored | P | guard test: worker posts only `facePresent`; no storage APIs (unit) |

## D. Vocabulary (8 P, 2 PA)

| # | Requirement | Status | Evidence / remaining |
|---|---|---|---|
| D1 | ≥ 100 classes | P | **250** (`vocabulary.json`, unit) |
| D2 | All have real training examples | **PA** | Every class has ≥ 33 real held-out clips (upstream metadata, counts sum to 14,396, unit test) and the model classifies real clips correctly; the **training** set itself could not be inspected here |
| D3 | Stable IDs | P | `asl-signs-v1:<label>`, unique (unit) |
| D4 | ASL gloss | P | all 250, unique (unit) |
| D5 | English meaning | P | all 250 (unit) |
| D6 | Duplicates removed | P | IDs, labels and glosses asserted unique. Near-synonyms (AWAKE/WAKE…) are distinct model classes, so they are flagged ambiguous, not merged |
| D7 | Variants documented | **PA** | Every entry has a note; specific notes for ~20 signs. Regional/Black ASL variants need Deaf linguistic review |
| D8 | Ambiguous signs identified | P | 26 flagged from confusion data + synonym groups (unit) |
| D9 | All classes evaluated | P | upstream per-class results for all 250 (unit checks coverage); `eval:signs` covers all classes |
| D10 | UI advertises only supported classes | P | browser list generated from validated vocabulary (e2e: 250 rows); vocabulary must match model 1:1 |

## E. Dataset (8 P, 1 PA, 1 B)

| # | Requirement | Status | Evidence / remaining |
|---|---|---|---|
| E1 | Legitimate dataset | P | Google asl-signs (DATASET-SIGNS.md, with alternatives considered) |
| E2 | Provenance | P | DATASET-SIGNS.md |
| E3 | Licence | P | CC BY 4.0; attribution in UI |
| E4 | Restrictions | P | Kaggle rules, attribution, what is redistributed |
| E5 | Download instructions work | **B** | Written, **not executable here** (Kaggle blocked). Fix: run DATASET-SIGNS.md steps 1–3 on your machine |
| E6 | Training examples validated | **PA** | Bundled real clips validated by the format decoder and the evaluator; full data not validated here. Fix: `npm run eval:signs -- --data-dir …` (fails on malformed files or unknown labels) |
| E7 | Labels match vocabulary | P | generator and parser assertions (unit) |
| E8 | Signer-independent evaluation | P | 3 held-out signers; validation signers separate |
| E9 | Leakage checks | P | participant disjointness + model-hash identity (unit) |
| E10 | Limitations | P | DATASET-SIGNS.md, KNOWN-LIMITATIONS.md |

## F. Recognition model (13 P, 1 PA, 2 B)

| # | Requirement | Status | Evidence / remaining |
|---|---|---|---|
| F1 | Real temporal architecture | P | temporal conv + transformer over ≤ 64 frames (ONNX inspected: input `[1,T,460]`) |
| F2 | Training scripts execute | **B** | Upstream pipeline not runnable here (no data, PyTorch or GPU). Fix: `ml/signs/README.md` retraining commands |
| F3 | Trained on real ASL | P | upstream training on asl-signs; corroborated by 5/6 correct on real held-out clips and the hash-matched version |
| F4 | Training config documented | P | MODEL-CARD-SIGNS.md, ml/signs/README.md |
| F5 | Validation performed | P | upstream validation (74.4%) + InterpretAI re-check on real clips |
| F6 | Checkpointing works | **B** | Not runnable here. Fix: upstream `uv run gesturesign train` |
| F7 | Export works | **PA** | The exported ONNX loads and runs in Node and the browser (verified); the export step itself was not executed |
| F8 | I/O dimensions validated | P | `parseMeta` (460-d, version), session input/output names, logits length checked in the worker (unit) |
| F9 | Loads in app | P | e2e "250 signs · on device" |
| F10 | Predictions from inference | P | e2e + unit with real model, no mocks |
| F11 | Confidence thresholds | P | temperature 0.883, "Not sure" < 0.29 (unit) |
| F12 | Unknown rejection | P | "Not sure", partial, crowded, NaN → nothing (unit; e2e). Out-of-vocabulary signs can still be misread (documented) |
| F13 | Version displayed | P | review queue and conversation show `asl-signs-v1 (default-2fc9038cc4)` (e2e) |
| F14 | Metrics recorded | P | `metrics.json`; MODEL-CARD-SIGNS.md |
| F15 | Per-class results for all classes | P | 250 per-class results (upstream); VOCABULARY-SIGNS.md |
| F16 | Real inference tested | P | 6 real held-out clips in Node, browser worker, evaluator |

## G. Continuous recognition (13 P)

G1 mode exists · G2 start · G3 pause (discards a half sign) · G4 resume · G5 stop · G6 boundaries · G7 repeats filtered · G8 sequence · G9 visible history · G10 undo · G11 unknown signs safe · G12 low confidence needs review · G13 interruptions don't corrupt — all **P**, verified by e2e (`signs.spec.ts`: live camera, replay, keyboard) and unit (real-clip stream, dropout, merge, uncertain tokens). Caveat: exercised with real recorded landmarks and a synthetic camera, not a live signer.

## H. Short phrases (8 P, 6 PA, 1 B)

| # | Requirement | Status | Evidence / remaining |
|---|---|---|---|
| H1 | Patterns documented | P | PHRASES.md, in-app coverage table |
| H2 | "Hi, how are you?" | **PA** | HELLO → "Hi." verified with a real clip (e2e); HOW and YOU are not in the vocabulary |
| H3 | "I am fine" | **PA** | FINE pattern (unit); no real FINE recording available to verify |
| H4 | "What is your name?" | **B** | WHAT, YOUR and NAME are not in any model available here. Fix: a model with those signs (e.g. trained on ASL Citizen) + new pattern |
| H5 | "Thank you" | **PA** | pattern (unit); not verified with a real recording |
| H6 | "I need help" | **PA** | only via fingerspelled #HELP (unit); HELP sign missing |
| H7 | "I want water" | **PA** | WATER / DRINK WATER / WATER PLEASE patterns (unit); not verified with a real recording |
| H8 | "Where is the bathroom?" | **PA** | POTTY WHERE (unit); child-directed label needs Deaf review |
| H9 | Glosses displayed | P | e2e "HELLO GIRAFFE" |
| H10 | English suggestions | P | e2e "Hi." |
| H11 | Unsupported handled | P | e2e + unit |
| H12 | No invented signs | P | tokens only from model output or user choice among its guesses (unit "cannot choose a label that was not among the guesses") |
| H13 | Editable | P | e2e edit → confirm |
| H14 | Confirm / reject | P | e2e |
| H15 | Limitations disclosed | P | UI note, PHRASES.md |

## I. Interface and usability (15 P, 1 PA)

I1 design preserved (existing tokens and components) · I2 modes switch · I3 active model · I4 camera status · I5 movement visible · I6 prediction status · I7 uncertainty (top-3 calibrated) · I8 history · I9 phrase suggestions · I10 correction controls · I11 clear/reset · I12 desktop · I13 mobile (360/320/768 px audits) · I14 keyboard (e2e) · I16 no fake functionality (replay is labelled real dataset landmarks; scripted areas remain labelled "Simulated") — **P**.
I15 screen-reader announcements — **PA**: polite live regions verified in the DOM (e2e) and axe passes; not tested with VoiceOver/NVDA.

## J. Privacy and safety (11 P)

Camera consent; frames local; cloud only with consent (sign mode has no cloud path); secrets server-side (guards); no automatic video storage (guard); confirmation required (review queue); escalation (unit + e2e); experimental status disclosed; no clinical claims; interpreter emphasised (persistent action); stop/reject at any time — all **P**.

## K. Testing (16 P, 2 PA)

K1 lint · K2 typecheck · K3 unit (236) · K4 integration (proxy, manager, real-model continuous pipeline, evaluator) · K5 e2e (37) · K6 build · K7 inference smoke · K8 movement · K9 unknown rejection · K10 repeated-sign filtering · K11 phrase assembly · K12 camera permission (grant, deny) · K13 offline · K14 accessibility (axe) · K17 latency measured · K18 webcam procedure documented — **P**.
K15 model accuracy reported — **PA**: upstream 72.1% / 88.1% on 14,396 clips; InterpretAI measured 5/6 only. K16 per-class evaluation reported — **PA**: upstream only.

## L. Final delivery (13 P, 1 PA)

ZIP; sources; model files included (ONNX bundled; MediaPipe models downloaded at build with pinned hashes, explained); dataset setup; training; evaluation; macOS launch; Windows launch (instructions, not run here); README; model card; limitations; this report; no secrets (guard tests + ZIP scan) — **P**. L14 reproducible — **PA**: the app rebuilds and passes from the clean ZIP (below); model training reproduction not verified here.

## 6. Failed or incomplete requirements and fixes

| Item | Status | What to do (exact files / commands) |
|---|---|---|
| E5 dataset download | B | Kaggle account → accept rules → `kaggle competitions download -c asl-signs -p ~/datasets/asl-signs` (DATASET-SIGNS.md) |
| E6 validate training examples | PA | `npm run eval:signs -- --data-dir ~/datasets/asl-signs` |
| F2 training / F6 checkpointing / F7 export | B / B / PA | `ml/signs/README.md` → GestureSign `uv run gesturesign prepare && train && evaluate && export`; then `python3 ml/signs/build_vocabulary.py && npm run prepare:signs && npm test` |
| K15 / K16 accuracy and per-class re-measurement | PA | `npm run eval:signs -- --data-dir ~/datasets/asl-signs` → `reports/sign-eval.md`; paste the numbers into MODEL-CARD-SIGNS.md |
| D2 inspect training examples | PA | as E6 with `--participants` set to training signers |
| D7 variants | PA | Deaf linguist review of `docs/VOCABULARY-SIGNS.md`; add notes in `ml/signs/build_vocabulary.py` (`NOTES`) |
| H2–H8 phrase verification | PA | Run `docs/WEBCAM-MANUAL-TEST.md` checks 3–9 with fluent signers; record results |
| H4 "What is your name?" | B | Needs WHAT/YOUR/NAME (and HOW, YOU, HELP, WANT, ME) in the vocabulary: train or obtain a licensed model on ASL Citizen or similar, drop it in via the same `public/models/` format, add patterns in `lib/asl/signs/phrases.ts` |
| I15 screen readers | PA | Test `/signs/` with VoiceOver (macOS) and NVDA (Windows) |
| L14 full reproducibility | PA | as F2 |

## 7. Measured accuracy and latency

- **Accuracy measured here:** 5 of 6 real held-out clips correct at top-1 (BLUE 75%, POLICE 92%, GIRAFFE 85%, SMILE 35%, HELLO 93%; QUIET → SHH 95%, a documented near-synonym). Identical in Node, the browser worker and the evaluator. Six clips are far too few to estimate accuracy.
- **Accuracy reported by the model's authors (not re-measured here):** 72.1% top-1, 88.1% top-5, 14,396 clips, 3 held-out signers; 77.1% precision when answering at the 0.29 threshold.
- **Latency measured here (Linux container, headless Chromium, CPU):** Holistic ≈ 20 ms per frame on an empty scene (first frame ≈ 420 ms); model 2.5–9 ms per sign in the browser after a ≈ 59 ms first run; model median 8.9 ms in Node. **Unmeasured:** latency with a person in view, on a Mac, on low-end devices.

## 8. Are all classes trained and evaluated?

All **250** classes (≥ 100 required) were trained and evaluated per class **by the upstream project** on real data from held-out signers. The bundled weights are byte-identical to the evaluated version (hash in the version name). InterpretAI independently confirmed correct real-data inference on 6 classes only. **Independent training and full per-class re-evaluation inside this project remain incomplete** (blocked by data access); the tooling to do it is included and tested.

## 9. Release verdict

**InterpretAI 4.0 is released as an experimental research prototype, not as a complete 4.0.** 138 of 156 requirements are verified (88.5%). Continuous on-device recognition of 250 real ASL signs, movement tracking, pose and face landmarks, segmentation, history, phrases, privacy and offline behaviour are implemented and tested with real recorded signing. It is **not complete** because training could not be reproduced, the full evaluation was not re-run here, "What is your name?" cannot be supported with the available vocabulary, five other required phrases are only partially verified, and no live signer, Deaf user or clinical testing has happened. The model's authors state it should not be used for accessibility-critical communication. It must not be used with real patients.

## Fresh-ZIP check

`InterpretAI-4.0-source.zip` (8.4 MB, 184 files; no `node_modules`, build output, `.env.local`, generated assets or keys; scanned for token patterns) was extracted into an empty folder and checked: `npm ci` (431 packages), `npm run lint` (clean), `npm run typecheck` (passed), `npm test` (**236 passed**, 20 files) and `npm run build` (passed, 12 routes, 122 assets precached). Google's model host is unreachable here, so the clean build warned that the hand and Holistic models were not downloaded; it kept the pinned SHA-256 manifest. On a computer with internet, the build downloads both and verifies them. Browser tests were run on the working tree (37 passed), where both models were present.
