# Dataset: Google – Isolated Sign Language Recognition (asl-signs)

## Selection

| Candidate | Why chosen / not chosen |
|---|---|
| **Kaggle asl-signs (PopSign / Google), CC BY 4.0** | **Chosen.** Real signers, 250 signs (≥ 100 required), ~94k clips, supplied as MediaPipe Holistic landmarks (same format as the browser pipeline), permissive licence, signer IDs for signer-independent splits, and a trained, evaluated, MIT-licensed model (GestureSign) exists for it. |
| WLASL (2,000 glosses) | Videos from YouTube links, many dead; C-UDA licence, academic use only; no landmarks supplied. |
| ASL Citizen (2,731 glosses) | Good fit, but hosted on Microsoft download servers, unreachable from the build environment; no trained landmark model available to verify. |
| How2Sign / YouTube-ASL | Continuous sentence-level data; far beyond what can be trained and validated here. |

## Provenance

- Published by Google with the PopSign project (Georgia Tech / Deaf Professional Arts Network collaboration) for the 2023 Kaggle competition "Google – Isolated Sign Language Recognition": https://www.kaggle.com/competitions/asl-signs/data
- Recorded by 21 signers on smartphones, signing single signs from the PopSign vocabulary (aimed at hearing parents of Deaf children learning first signs).
- Supplied as per-frame landmarks: 468 face, 21 left-hand, 33 pose, 21 right-hand points (x, y, z) from MediaPipe Holistic. No video or images.

## Licence and restrictions

- **CC BY 4.0.** Attribution: "Google – Isolated Sign Language Recognition (Kaggle, asl-signs), CC BY 4.0". Shown in the app next to the replay clips and in the model panel.
- Downloading requires a Kaggle account and accepting the competition rules.
- InterpretAI redistributes **only** the landmarks of six held-out clips (`public/models/asl-signs-v1/heldout-clips.json`, `tests/fixtures/signs/…`), which CC BY permits with attribution. No faces or video are included; face points are not even part of those clips.
- The trained model is MIT (GestureSign); ONNX Runtime Web is MIT; MediaPipe is Apache 2.0. Notices: `public/third-party/`.

## Download instructions (for full evaluation or retraining)

1. Create a Kaggle account, open https://www.kaggle.com/competitions/asl-signs/data and accept the rules.
2. `pip install kaggle`, put your API token in `~/.kaggle/kaggle.json` (never in this project).
3. `kaggle competitions download -c asl-signs -p ~/datasets/asl-signs && cd ~/datasets/asl-signs && unzip asl-signs.zip` (≈ 40 GB unzipped; the GestureSign pipeline can read the zip directly).
4. Evaluate InterpretAI's pipeline: `npm run eval:signs -- --data-dir ~/datasets/asl-signs` (see [ml/signs/README.md](../ml/signs/README.md)).

These instructions were **not executed here** (Kaggle is unreachable from the build environment). The evaluation script itself was executed on a 6-clip Kaggle-format sample made from the real held-out clips (`tests/fixtures/signs/mini-asl-signs`).

## Validation and leakage checks

- Labels: `labels.json` has 250 unique labels; `vocabulary.json` is generated from it, with index order and labels asserted to match, unique IDs and glosses asserted (`build_vocabulary.py`, `parseVocabulary`, unit tests).
- `metrics.json` has per-class results for exactly the 250 model labels, and its per-class clip counts add up to the 14,396 test clips (unit test).
- **Signer independence:** test signers (16069, 37055, 61333) and validation signers (26734, 49445) are disjoint and were never used in training (upstream split by participant; asserted in a unit test from the shipped metadata). The decision threshold was calibrated on validation signers.
- **Model identity:** the shipped ONNX file's SHA-256 begins with the version hash in `model-meta.json` (`2fc9038cc4`), so the bundled weights are exactly the evaluated ones (unit test checks the version; the manifest records the full hash).
- The six bundled clips come from the held-out signers.

## Limitations

- 21 signers; skin tone, age, region, handedness and signing style coverage is unknown and likely narrow. Black ASL and regional variants are not documented in the data.
- Vocabulary chosen for young children (e.g. POTTY, OWIE, KITTY, ZEBRA), not healthcare. Many healthcare-critical signs (PAIN, HELP, NEED, MEDICINE, DOCTOR, NAME, YOU, ME, WHAT, HOW) are absent.
- Isolated, deliberately produced signs recorded on phones; natural continuous signing differs (co-articulation, speed).
- Landmarks only: errors from MediaPipe in the original recordings are baked into the data.
