# Test results — InterpretAI 4.0.0

Run on 24 October 2026 in a Linux container (Node.js 22.22.0, npm 10.9.4, Chromium via Playwright 1.64.1, headless) against a fresh production build. A Mac uses the same commands. These results do not guarantee identical behaviour on every computer, camera or browser.

| Command | Result |
|---|---|
| `npm run lint` | Passed: 0 errors, 0 warnings |
| `npm run typecheck` | Passed |
| `npm test` | **236 passed** in 20 files (3.0: 144) |
| `npm run build` | Passed: 12 routes (new `/signs/`); 122 app-shell assets precached; optional downloads: lab 21.8 MB, sign recognition 47.7 MB |
| `npm run test:e2e` | **37 passed**, 0 failed, 0 skipped (3.0: 29). Used the preinstalled Chromium via `PLAYWRIGHT_CHROMIUM_EXECUTABLE` (the Playwright browser download is blocked here) |
| `npm run eval:signs` | Ran on the 6-clip Kaggle-format sample: 5/6 top-1, per-class report for 250 classes, median model latency 8.9 ms. **Not run on the full 14,396-clip test set** (Kaggle unreachable) |
| Fresh-ZIP check | See the end of this file |

## New unit and integration tests (Vitest)

| File | Tests | Covers |
|---|---|---|
| `signs/features.test.ts` (ported) | 22 | Feature parity with the Python training pipeline (shared fixture), mirror invariance, dominant hand, resampling |
| `signs/segmenter.test.ts` (ported) | 13 | Sign boundaries, short-dropout bridging, no repeat on a held sign, hands-leaving discard, max length, frame-status states |
| `signs/recognizer.test.ts`, `decision.test.ts`, `assemble.test.ts`, `meta.test.ts` (ported) | 27 | "Not sure" below threshold, partial framing, crowded scenes, NaN logits, hand-to-wrist assignment, Holistic face points, model/label validation |
| **`signs/interpretai-signs.test.ts`** | 27 | Vocabulary (250 classes, unique IDs and glosses, per-class evaluation for all, ambiguity, refuses mismatched vocabularies); signer-leakage check; model identity; **real ONNX inference on 6 real held-out clips** (≥5/6, I/O dims, latency logged); nonsense input → "Not sure"; **continuous recognition on a stream built from real clips** (HELLO POLICE BLUE in order; a paused sign → one token; a one-frame tracking dropout does not break the sequence; movement summaries); movement direction, smoothing, gap bridging, live indicator; sequence merge/keep rules, uncertain tokens, choose/undo/remove/clear, spelled words; phrase patterns, coverage against model labels, unsupported sequences, honest target coverage; provider: risk escalation, consent, offline, calibrated confidence; Holistic hands feed the 3.0 fingerspelling model |
| **`signs/evaluate-script.test.ts`** | 1 | `ml/signs/evaluate.mjs` end to end on Kaggle-format parquet built from the real clips |
| `privacy-guards.test.ts` | 8 (+2) | Face landmarks never posted by the sign worker; no browser storage of landmarks or video |
| `recognition-providers.test.ts` | updated | Registry now lists `asl-signs` first |

Real-clip inference log (Node, ONNX Runtime Web WASM, 1 thread): `blue→blue 75% 49.3 ms; police→police 92% 11.7 ms; quiet→shhh 95% 11.1 ms; giraffe→giraffe 85% 22.4 ms; smile→smile 35% 6.0 ms; hello→hello 93% 3.9 ms`. The same results come from the browser worker (first sign 58.6 ms including warm-up, then 2.5–9.3 ms).

## New browser tests (Playwright, real worker, real models, no mocks)

1. `/signs/`: disclosures, intended-use warning, 250-row vocabulary with search, phrase-coverage table, axe; camera disabled before download; download; **real held-out clip → HELLO** with top-3 and movement; HELLO GIRAFFE → explicit unsupported, Confirm disabled; Undo → "Hi." → edit → Confirm; paused QUIET clip → one SHH token; Reject; high-risk English → interpreter escalation and replay disabled; axe again.
2. Live fake camera: Holistic runs on device; "No one in view" (the synthetic camera has no person, and nothing is invented); pause/resume; fingerspelling sub-mode; Stop releases the stream; consent withdrawal disables the camera.
3. Workspace: "Download needed" → download → "Available"; replay → **Review this phrase** → review queue (calibrated label, model version) → not in the conversation until confirmed → confirmed; a rejected phrase never enters the conversation; axe.
4. Offline after download: network off, reload, recognition still works.
5. Offline before download: page and vocabulary load; camera stays disabled.
6. Camera denied: clear message; replay still works.
7. Mobile 360 px: no horizontal overflow; controls focusable. (`/signs/` was also added to the 320/768 px layout audit and the all-routes axe audit.)
8. Keyboard only: download, replay, undo with Enter/Space; the polite live region announces "Recognised HELLO…".

The existing 29 browser tests pass unchanged (patient flow, scenarios, offline, mobile, axe on all routes, sample lab, fingerspelling including the real-photo pipeline, mocked Sign-Speak and Hugging Face).

## Not tested

- **A real person signing to a real webcam.** Procedure ready: WEBCAM-MANUAL-TEST.md. Chrome's synthetic camera cannot sign.
- The full held-out evaluation (14,396 clips) with InterpretAI's pipeline; training, checkpointing and export (Kaggle, PyTorch and GPUs unavailable).
- Deaf users, signers outside the training data, Black ASL and regional variants, clinical settings.
- Holistic latency with a person in view and on a Mac; GPU delegate on real hardware.
- Safari and Firefox; Windows (instructions included, not run); real screen readers (live regions checked in the DOM only).
- Any live external API (unchanged from 3.0: all mocked).

## Fresh-ZIP check

`InterpretAI-4.0-source.zip` (8.4 MB, 184 files; no `node_modules`, build output, `.env.local`, generated assets or keys; scanned for token patterns) was extracted into an empty folder and checked: `npm ci` (431 packages), `npm run lint` (clean), `npm run typecheck` (passed), `npm test` (**236 passed**, 20 files) and `npm run build` (passed, 12 routes, 122 assets precached). Google's model host is unreachable here, so the clean build warned that the hand and Holistic models were not downloaded; it kept the pinned SHA-256 manifest. On a computer with internet, the build downloads both and verifies them. Browser tests were run on the working tree (37 passed), where both models were present.
