# Privacy and healthcare safety

InterpretAI is a research prototype. It is **not** HIPAA compliant, has not been assessed for HIPAA, and is not medically approved. Use fictional information only.

## Data inventory

| Data | Where it lives | Leaves the device? | Persisted? |
|---|---|---|---|
| Camera frames (lab, live tracking) | Worker memory, one frame at a time | No | No; each `ImageBitmap` is closed after processing |
| Hand landmarks | Page memory during a 3 s capture | No | No; discarded after classification |
| Fingerspelling letters (bundled model) | Page memory | No — the model runs on this device | No; cleared by Clear spelling, Review, or Stop |
| Still photo (Hugging Face mode, on request) | `Blob` in page memory | **Only** after per-photo consent, to the proxy and then your Hugging Face endpoint | No; cleared and revoked on send or discard; proxy zero-fills its copy |
| Recorded clip (Mode 3 only, on request) | `Blob` in page memory + object URL | **Only** after per-clip consent, to the proxy and then Sign-Speak | No; cleared and the URL revoked on send or discard. Never cached by the service worker. |
| Recognised and typed conversation | React state | No (typed text goes to an avatar provider only if one is connected and the text passes the safeguards) | No; cleared on reload or **Clear conversation** |
| Proxy | Request in memory | Forwarded to Sign-Speak | No disk writes. Logs only method, route, status, duration. Clip buffer zero-filled after forwarding. |
| Public config (`/runtime-config.json`) | Cache Storage | — | Yes; contains no secrets |
| Optional model files | Cache Storage | — | Yes, after explicit download; removable |
| Audio | — | — | Never requested (`audio: false`; `Permissions-Policy: microphone=()`) |

## Privacy notice (shown in plain words in the app)

- **On this device:** camera preview, hand tracking (MediaPipe), the L/Y rules, the bundled fingerspelling model, any local model you add, text-to-speech, and the conversation.
- **External services, only after you choose to send:** Sign-Speak (one video clip), Hugging Face (one photo), and Sign-Speak or Hand Talk signing avatars (provider text you choose to show). Each goes through InterpretAI's proxy, except Hand Talk, whose SDK runs in the page.
- **Never:** background uploads, audio capture, analytics, saving video, or saving conversations.

## Review-before-conversation workflow

Machine output (from any mode) first appears in **"Machine output awaiting your review"** on the patient side. Only output the patient **confirms** or **corrects** is added to the conversation; rejected output never is. Confirmation is the patient's choice, **not proof of comprehension**. Provider messages can be edited, and edits are labelled ("Edited from …"). Machine signing happens only when someone presses **Show in signing avatar**.

## Consent model

1. **Camera consent** (checkbox) before the live camera can start. Unchecking it stops the camera immediately.
2. **Per-clip third-party consent.** After recording, the patient reviews the clip itself, then ticks a checkbox naming Sign-Speak as a third-party cloud service. Consent covers that one clip and is cleared after submission. The proxy refuses requests without the consent header (`428`).
3. **Processing location** is shown on every mode (*On this device* / *Cloud · third party*), on the patient panel badge, and on every conversation entry.

## Credentials

- `SIGN_SPEAK_API_KEY` is read only by `server/proxy.mjs`. Tests verify that no browser source reads it, that the static build does not contain it, and that `/runtime-config.json` and `/health` do not expose it.
- `.env.local` is git-ignored and excluded from the delivery ZIPs. `.env.example` contains blanks only.
- The Hand Talk token is a browser token by the SDK's design. Restrict it with Hand Talk.

## Healthcare safety rules

- **High-risk escalation.** Medication, allergies, diagnosis, treatment, consent and emergency keywords in typed provider text, in recognised text, or in a patient correction set the conversation to *Human interpreter recommended*. This pauses recognition and machine signing and shows **Request Qualified Interpreter**. An explicit patient request ("I would like a qualified interpreter") does the same. Scripted scenarios keep their own stops.
- **No fabricated results.** Unknown results add nothing. Failures show an error state and never substitute scripted text or another provider. Confidence appears only if the provider or model produced it, and is labelled accordingly.
- **Patient review.** Every recognised message starts as *Awaiting patient review*. Confirm, Correct (the original text stays visible) and Reject are always available. A confirmation records the patient's choice. It is **not** evidence that anyone understood.
- **Machine signing** is labelled *Machine-generated · Unvalidated*, always shows the English text, and refuses high-risk text.
- **No bookings.** Interpreter requests remain a fictional simulation. The app contacts no one.
- **Keyword limits.** The safeguards are simple English patterns. They can miss paraphrases and other languages, and can produce false positives. They are not a clinical safety system.

## Offline

- Cloud recognition and avatars show *Offline* or *Demo outage* and cannot start. Nothing is queued for later upload.
- On-device modes work offline once their files are downloaded.
- The service worker handles same-origin GET requests only. It never caches video, POST bodies, proxy calls or provider responses.

## 4.0: sign recognition and face data

- MediaPipe Holistic computes face-mesh landmarks because the sign model uses 40 lip points. Face landmarks are processed **only inside the sign Web Worker**. They are never posted to the page (the worker sends only a `facePresent` flag), never drawn, stored, logged, cached or uploaded, and never used to identify a person. Nothing in InterpretAI performs face recognition.
- Camera frames (ImageBitmaps) are closed after one use. Landmark frames exist only in worker memory for the current sign (≤ 4 s) and are discarded after classification.
- Recognised signs, the sequence and phrases live in React memory; reloading clears them. Confirmed phrases on `/signs/` stay on that page; in the workspace they follow the existing review and conversation rules.
- The optional download (47.7 MB) is triggered only by the user, verified by size and SHA-256, and stored in Cache Storage (`interpretai-signs-v1`). Removing site data deletes it.
- Every recognised sign is shown for review; uncertain signs block phrase suggestions until resolved; phrases need explicit confirmation; typed or suggested English goes through the same high-risk detection, which stops recognition and recommends a qualified interpreter. A "I would like a qualified interpreter" action is always visible.
