# Local recognition (Mode 2): preparing a real model

**InterpretAI ships no trained ASL recognition model.** This release provides the pipeline, a model-loading interface, a small dependency-free runtime, and out-of-vocabulary rejection. A real model must come from appropriately consented data and documented evaluation. Until one is supplied, Mode 2 shows *Not configured* and never produces output.

## 1. Isolated signs vs. sentence translation

| | Isolated-sign recognition (supported interface) | Sentence-level translation (not supported) |
|---|---|---|
| Output | One gloss from a closed vocabulary, or *unknown* | Open English text |
| Grammar | Ignores ASL grammar, sequencing, classifiers, role shift | Must model them |
| Nonmanual signals | Not required for many lexical signs | Essential (questions, negation, topicalisation, adverbials) |
| Suitable here | Yes, as a research component under patient review | No; manifests declaring anything but `isolated-sign` are refused |

Mode 3 (Sign-Speak) returns provider English text and is labelled as such. Nothing in Mode 2 is presented as a translation.

## 2. Temporal landmark sequence format `interpretai.landmarks.v1`

```ts
type LandmarkSequence = {
  format: "interpretai.landmarks.v1";
  frames: {
    t: number;                       // ms, strictly increasing
    hands: {                         // 0, 1 or 2 entries
      handedness: "Left" | "Right";  // signer's anatomical hand (see below)
      handednessScore: number;       // MediaPipe's own score
      image: {x,y,z}[21];            // normalised to the UNMIRRORED frame
      world: {x,y,z}[21];            // metres, hand-centred
    }[];
  }[];
};
```

- **Handedness.** MediaPipe assumes a mirrored selfie image. InterpretAI sends unmirrored frames, so the worker swaps the label once (`signerHandedness`). The preview is mirrored only on screen. Left-dominant signers produce sequences with the dominant hand in the Left slot. A model must either be trained with both or mirror Left/Right consistently, and the manifest's evaluation should report it.
- **Absent landmarks.** An absent hand is an explicit zero-presence slot, never interpolated across. Sequences with fewer than two frames, non-increasing timestamps, more than two hands, wrong point counts or non-finite values are rejected (`validateSequence`).
- **Capture.** In the live workspace, Mode 2 records 3 s of frames in memory (`SequenceRecorder`, capped at 300 frames). Frames are discarded after classification.

## 3. Feature extraction (fixed, documented)

Per frame, two slots (`Right`, then `Left`), each with 67 features. The total is **134 features per frame** (`FEATURES_PER_FRAME`).

| Offset | Features | Normalisation |
|---|---|---|
| 0 | presence (1 or 0) | — |
| 1–63 | 21 world landmarks (x,y,z) | wrist at origin; divided by wrist→middle-MCP length. Size- and position-invariant, **not** rotation-invariant, because orientation is phonologically meaningful. |
| 64–65 | wrist x,y relative to frame centre | image space, −0.5…0.5. Camera-relative, not body-relative (no pose landmarks). |
| 66 | apparent palm size | image space; rough distance cue |

**Temporal smoothing.** Exponential smoothing of world landmarks per hand slot (`smoothingAlpha` from the manifest), reset whenever that hand disappears.

**Resampling.** The sequence is resampled to `input.frames` evenly spaced instants. Present-hand features are linearly interpolated only when both neighbouring frames contain the hand; otherwise the nearest frame is used.

## 4. Model package

Put files under `public/models/<id>/` and set `NEXT_PUBLIC_LOCAL_MODEL_MANIFEST=/models/<id>/manifest.json`. See `docs/examples/local-model-manifest.example.json`.

Required manifest fields (validated; missing documentation means the model is refused):

- `format: "interpretai.local-model.v1"`, `id`, `version` (**model versioning**: shown with every result and used in offline cache names)
- `granularity: "isolated-sign"`
- `vocabulary` (≥ 2 unique labels) and `rejectLabels` (e.g. `__none__`, trained on non-target signing and rest)
- `license.name`; `trainingData.description` and `trainingData.consent`
- `evaluation`: `dataset`, `signerIndependent` (boolean), numeric `metrics`, `knownGaps`
- `input`: sequence format, `frames`, `featuresPerFrame: 134`, `smoothingAlpha`, `minHandCoverage`
- `decision`: `minScore` (0–1) and `minMargin`
- `architecture: "dense-mlp"`, `weightsUrl`

`weights.json`: `{ "layers": [{ "weights": number[out][in], "bias": number[out], "activation": "relu" | "linear" }] }`, followed by a softmax. Shapes are checked against `frames × 134` inputs and the vocabulary size.

To use another architecture (for example a temporal CNN or transformer exported to ONNX or TF.js), add a runner next to `runDense` and a new `architecture` value. Keep the manifest validation and decision rules unchanged.

## 5. Out-of-vocabulary rejection

A result is **unknown** (and nothing is added to the conversation) when any of these hold:

1. hand coverage is below `minHandCoverage`;
2. the top label is a `rejectLabel`;
3. the top score is below `minScore`;
4. the top-two margin is below `minMargin`.

The score shown is labelled *Model score … (not calibrated)*. Calibrate thresholds on a held-out, signer-independent set, and report false-accept rates on out-of-vocabulary signing, not just accuracy on in-vocabulary signs.

## 6. Evaluation guidance

- **Signer-independent splits.** No signer may appear in both training and test sets. Report per-signer results, not only pooled accuracy.
- **Out-of-vocabulary tests.** Include fluent conversational signing, fingerspelling, gestures, and rest/transition segments. Measure how often each is wrongly accepted.
- **Conditions.** Lighting, camera angle and distance, backgrounds, skin tones, hand differences, left-dominant signers, glasses and sleeves, and low-end devices (which run at a lower frame rate here).
- **Regional variation and Black ASL.** Recruit and *compensate* Deaf signers from the target rural Southern communities, including Black ASL users, with Deaf-led governance (see the Research page lenses). Report results per variety. Do not deploy a model whose evaluation omits the communities it will serve.
- **Age groups.** Include older signers and youth; signing style and pace differ.
- **Human review.** Deaf ASL experts should review vocabulary choice and gloss labels. Patient review in the UI is not a substitute for evaluation.
- **Documentation.** Publish a model card (data, consent, metrics by subgroup, known gaps). The manifest's `evaluation.reportUrl` should point to it.

## 7. Nonmanual features (face and body)

See [NONMANUAL-FEATURES.md](NONMANUAL-FEATURES.md). The v1 sequence format is hands-only on purpose. A future `interpretai.landmarks.v2` would add optional pose/face blocks without breaking v1 models.
