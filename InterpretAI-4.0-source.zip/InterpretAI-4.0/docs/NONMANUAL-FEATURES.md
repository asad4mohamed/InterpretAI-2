# Evaluation: face and pose landmarks for future ASL recognition

**Decision for 2.1:** do not add face or pose inference yet. The worker stays hands-only. This is a deliberate decision, not an omission.

## Why nonmanual features matter

ASL grammar is carried partly by the face, head and torso. Raised or furrowed brows mark yes/no and wh-questions. Headshake marks negation. Mouth morphemes carry adverbial meaning. Eye gaze and body shift mark role shift and spatial reference. A recognizer that sees only hands cannot reliably separate *YOU HAVE PAIN* from *YOU HAVE PAIN?*. In healthcare that difference matters.

Sentence-level recognition will therefore need face and upper-body landmarks. For isolated lexical signs (the only thing Mode 2 accepts), hand shape, location, movement and orientation carry most of the information. Body-relative location is still better with pose landmarks than with today's camera-relative wrist position.

## Options in MediaPipe Tasks Vision 1.1.1

| Option | Adds | Approx. extra download | Notes |
|---|---|---|---|
| Pose Landmarker (lite) | 33 body points | ~5–6 MB | Gives body-relative hand location (shoulders, chest, face) |
| Face Landmarker | 478 face points + blendshapes | ~3–4 MB | Brows, mouth, gaze cues; most privacy-sensitive |
| Holistic Landmarker | Pose + face + hands in one task | larger | Simplest alignment; heavier on CPU |

Sizes are indicative. Pin and hash the exact files, as the hand model already is, before any adoption.

## Why not now

1. **No consumer.** No supplied model uses these features. Running face inference only to draw dots would add processing and privacy exposure with no linguistic benefit, which the requirements rule out.
2. **Privacy.** Face landmarks are biometric-adjacent. They would need separate consent wording, a stronger "never stored" guarantee, and Deaf community input on acceptability.
3. **Performance.** CPU inference for two or three models per frame would roughly halve the frame rate on low-end devices. Adaptive pacing would hide some of this, at the cost of temporal resolution.
4. **Validation.** Nonmanual annotation needs Deaf linguists. The data for this does not exist in the project yet.

## Prerequisites for adding them

- A model or provider that consumes them, documented in its manifest (`interpretai.landmarks.v2` with optional `pose` and `face` blocks; v1 models keep working).
- A separate opt-in ("also track face and upper body"), shown only for models that need it.
- Downloads that are optional, hash-pinned and cached, matching the lab's process.
- Per-subgroup evaluation as described in [LOCAL-RECOGNITION.md](LOCAL-RECOGNITION.md) §6.
- Measured frame rates on the target low-end devices.

Mode 3 (Sign-Speak) receives full video, so the provider sees nonmanual signals. Its handling of them is not documented in the material reviewed. Evaluate this before relying on question or negation recognition.
