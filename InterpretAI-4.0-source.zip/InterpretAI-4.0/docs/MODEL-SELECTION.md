# ASL model selection and deployment guide

Candidates were reviewed in October 2026 using public model cards and repositories. Hugging Face, Kaggle and Google storage were **not reachable** from the build environment. Hugging Face details therefore come from the public model pages, not from downloads.

## Candidates evaluated

| Candidate | Type / input | Vocabulary | Temporal? | Licence | Hosted inference | Evaluation | Decision |
|---|---|---|---|---|---|---|---|
| **InterpretAI fingerspelling v1** (trained here on [AkramOM606 keypoint.csv](https://github.com/AkramOM606/American-Sign-Language-Detection)) | MLP on 21 hand landmarks | 24 static letters | No (temporal speller in app) | MIT data; weights shipped with this project | Not needed; runs on device, offline | 94.5% hold-out; **21/24 on an unseen signer** | **Selected and bundled.** Only option whose data was obtainable, inspectable and verifiable here. |
| [nocontextdoruk/asl-landmark-mlp](https://huggingface.co/nocontextdoruk/asl-landmark-mlp) | ONNX MLP, 63 landmark values | 36 (0–9, A–Z) | No | **CC BY-NC 4.0** | "Not deployed by any Inference Provider" | 100% on a stratified sample split (likely inflated); split by sample, not signer | Strong alternative for on-device use, but non-commercial licence, unreachable for verification here, and it would need `onnxruntime-web`. Documented as an option. |
| [abdollahhh/asl-sign-language-efficientnet-b0](https://huggingface.co/abdollahhh/asl-sign-language-efficientnet-b0) | Image classifier, 224×224 RGB | 26 letters | No | Apache-2.0 | "Not deployed by any Inference Provider". Needs a **Dedicated Inference Endpoint**. | 99% on an evaluation split from the same dataset | **Suggested model for the Hugging Face adapter.** Works with one photo through your own endpoint. |
| Google Isolated Sign Language Recognition (Kaggle, 250 signs, holistic landmarks), e.g. [JosephZahar/GISLR](https://github.com/JosephZahar/Google-Isolated-Sign-Language-Recognition-Kaggle) | TFLite on 543 holistic landmarks × frames | 250 isolated signs (child-directed vocabulary) | Yes | Competition data CC BY 4.0; weights vary by repo | No | Kaggle leaderboard (signer-independent test) | **Blocked:** weights and data are on Kaggle (unreachable here), and it needs face and pose landmarks. This is the best path to real isolated-sign recognition. See "Next model" below. |
| WLASL datasets / I3D models | Video (RGB) | 100–2000 glosses | Yes | Research-only (C-UDA); videos are third-party | No | Published top-1 for WLASL100/2000 | Not integrated: research-only licence, large models, server GPU needed. |
| Sign-Speak API | Provider-hosted video | Open | Yes | Commercial | Yes (your key) | Not published per vocabulary | Integration-ready (see API-INTEGRATION.md). |

No model found here does **continuous ASL-to-English translation** with a licence and evaluation suitable for this project. Sentence-level translation therefore remains unimplemented except through a commercial provider.

## Using the Hugging Face adapter

The proxy sends **one JPEG photo** (raw bytes, `Authorization: Bearer $HF_TOKEN`) and expects the documented image-classification response `[{ "label": string, "score": number }]`.

**Option A (recommended): Dedicated Inference Endpoint**

1. On huggingface.co, open the model (e.g. `abdollahhh/asl-sign-language-efficientnet-b0`) and choose **Deploy → Inference Endpoints**.
2. Select the image-classification task and a small CPU instance. This is billed by Hugging Face per hour while running, so pause it when idle.
3. Copy the endpoint URL into `.env.local`:
   ```
   HF_TOKEN=hf_…            # fine-grained token with access to your endpoint
   HF_ASL_ENDPOINT_URL=https://xxxxxxxx.us-east-1.aws.endpoints.huggingface.cloud
   HF_ASL_MODEL_ID=abdollahhh/asl-sign-language-efficientnet-b0   # optional, shown as the model name
   NEXT_PUBLIC_RECOGNITION_PROXY_URL=http://127.0.0.1:8787
   ```

**Option B: HF Inference provider (serverless)**

Set only `HF_TOKEN` and `HF_ASL_MODEL_ID`. The proxy calls `https://router.huggingface.co/hf-inference/models/<HF_ASL_MODEL_ID>`. At the time of review, **no ASL model is served this way**, and community reports show HTTP 410 for many image-classification models. The app then shows *"This model is not served at the configured Hugging Face target"*, which is expected. Use Option A.

**Test it**

```bash
npm run proxy                      # prints whether the HF token and target are loaded
curl -s http://127.0.0.1:8787/health
# then: Communication → Experimental live recognition → Hugging Face → Take photo → consent → Send
```

## Next model: isolated signs (recommended research step)

1. Obtain the GISLR dataset or a trained TFLite model under its licence, using an environment with Kaggle access.
2. Add MediaPipe Pose and Face landmarkers, pinned and hash-checked like the hand model, behind a separate opt-in (see NONMANUAL-FEATURES.md).
3. Export to the `interpretai.local-model.v1` manifest (LOCAL-RECOGNITION.md), or add a TF.js or ONNX runner.
4. Evaluate signer-independently, including Deaf signers from rural Southern communities and Black ASL users, before showing results to patients.
