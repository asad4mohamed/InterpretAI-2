# InterpretAI 4.0 — changelog

## New: continuous on-device sign recognition

- **Model:** GestureSign temporal transformer (MIT), 250 isolated ASL signs, trained on Google's asl-signs data (CC BY 4.0), 72.1% top-1 / 88.1% top-5 on 3 held-out signers (authors' evaluation). Bundled unchanged as ONNX (`public/models/asl-signs-v1/`), verified by hash and on 6 real held-out clips (5/6). See MODEL-CARD-SIGNS.md.
- **Pose and face landmarks:** MediaPipe Holistic Landmarker (hands + 33-point pose + face mesh) in a Web Worker, CPU delegate, pinned SHA-256. Face points stay in the worker and are used only as lip-shape model input.
- **Movement over time:** body-relative, smoothed (EMA) wrist trajectories with short-gap bridging; live movement indicator; per-sign summary (dominant hand, two-handed, direction from the signer's point of view, path length in shoulder widths, start/end body region, trajectory sketch).
- **Sign segmentation and continuous mode:** motion-based segmenter (start on movement, end after 300 ms still or absent, 4 s cap); start, pause (discards a half-captured sign), resume, stop; crowded-scene and out-of-frame states.
- **Sequence history:** ordered tokens with top-3 calibrated probabilities, "Not sure" tokens that must be resolved, choose-another-guess, remove, Undo last sign, Clear all; repeated segments of one sign merged; fingerspelled words (#WORD) from the 3.0 letter model inside sign mode.
- **Short phrases:** fixed table of 22 gloss patterns, validated against the model labels; editable English; Confirm/Reject; explicit "No supported phrase pattern" for anything else. Coverage of the 7 required phrases documented honestly (PHRASES.md).
- **Interface:** new sidebar page **Sign recognition** (`/signs/`); new workspace mode **ASL signs, continuous** feeding the existing review queue, risk detection and escalation; status bar (recognition, camera, tracking, movement, model); vocabulary browser (search, category filter, per-class held-out accuracy, ambiguity notes); model panel; phrase-coverage table; replay of 6 real held-out clips for users without a camera.
- **Offline:** 47.7 MB optional download (Holistic, ONNX Runtime WASM, model), integrity-checked, stored in its own cache; small metadata precached so the page and vocabulary load offline even before the download.
- **Evaluation tooling:** `npm run eval:signs` evaluates InterpretAI's exact pipeline on Kaggle parquet files (per-class results, confusions, latency). `ml/signs/build_vocabulary.py` generates the vocabulary and docs/VOCABULARY-SIGNS.md.

## Changes to existing code

- `lib/asl/types.ts`: `sign-model` mode, `sign-sequence` granularity and request, `holistic-stream` input, `calibrated-probability` confidence kind.
- `lib/asl/provider-registry.ts`: `asl-signs` provider (first in the list); `createDefaultRegistry` takes an optional `signToolsReady`.
- `components/recognition-workspace.tsx`: renders the sign panel in sign mode; generic model panel hidden for that mode.
- `components/use-recognition-config.ts`: overlapping availability checks — only the newest updates the UI (fixes a stale "Download needed" badge after downloading).
- `scripts/build-sw.mjs`: sign cache; large optional files excluded from the app-shell precache.
- `scripts/prepare-signs.mjs` (new), run by `build` and `dev`.
- Sidebar: "Sign recognition" entry. Icons: undo, trash, waves.

## Defects found and fixed during 4.0 work

1. A one-frame hand-tracking dropout mid-sign reset the segmenter's hand speed and cut the sign (HELLO lost in a real-clip stream test). Fixed in `segmenter.ts` (≤150 ms dropouts bridged).
2. A real held-out QUIET clip with a pause inside produced two SHH tokens. Fixed with the merge rule in `sequence.ts`.
3. The Holistic GPU delegate took ~450 ms/frame (7.5 s for the first) where WebGL is software-only; camera frames never reached the model within seconds. Switched to the CPU delegate (~20 ms/frame).
4. Replay frames updated the live camera status ("1 hand, tracked" on an empty camera). Replay frames are now excluded from camera status.
5. Workspace confidence label said "(not calibrated)" for temperature-calibrated probabilities. New confidence kind.
6. Replay buttons' accessible names did not match their visible text (axe `label-content-name-mismatch`). Fixed.
7. Mode badge stayed "Download needed" after downloading (race between availability checks). Fixed.
8. Stopping only the camera would have silenced the engine's messages (shared request counter). Separate engine and camera IDs.
