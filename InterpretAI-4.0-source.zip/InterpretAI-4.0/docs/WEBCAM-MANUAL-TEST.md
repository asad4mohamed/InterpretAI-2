# Real-webcam manual test procedure (sign recognition)

Automated tests use real landmark clips and Chrome's synthetic camera. They cannot sign. Run this procedure on a real computer with a webcam, ideally with a Deaf or fluent ASL signer, and record the results in the table at the end. **Results from this procedure have not been collected yet.**

## Setup

1. `npm run build && npm run start` (internet needed once for the Holistic model).
2. Chrome or Edge, http://127.0.0.1:3000/signs/ (localhost is a secure context).
3. Good, even front lighting; plain background; camera at chest height, about 1–1.5 m away so **both shoulders and the head are in view**.
4. Select **Download sign recognition** once (≈ 47.7 MB). Wait for "Downloaded · not loaded".

## Checks

| # | Action | Expected |
|---|---|---|
| 1 | Tick consent, **Start camera**, allow the browser prompt | Preview mirrored; status "Watching for a sign"; tracking line shows "Hands and upper body tracked" when you raise your hands; tracking latency appears under the latest output after the first sign |
| 2 | Step half out of frame | "Shoulders out of frame · step back a little"; a sign made now becomes "Not sure (partial)" |
| 3 | Sign HELLO, then lower your hands | One HELLO token; top-3 bars; movement description; phrase suggestion "Hi." |
| 4 | Hold your hand still in view for 5 s after a sign | No extra tokens (held signs are not repeated) |
| 5 | Sign THANK-YOU, WATER, FINE, WHERE, POTTY (lower hands between signs) | One token each, in order; Undo removes the last |
| 6 | Sign WATER, then PLEASE | "Water, please." suggested; edit the text; **Confirm phrase** → appears under "Confirmed in this session" |
| 7 | Sign HELLO then any animal sign | "No supported phrase pattern" message; Confirm disabled until you write your own English |
| 8 | Sign something not in the vocabulary (e.g. PAIN) | Either "Not sure" (pick/remove) or a wrong supported sign: reject or remove it |
| 9 | Tick **Fingerspell a word instead**, spell H-E-L-P, **Add #HELP** | Token #HELP; suggestion "I need help." |
| 10 | Ask a second person to step into view | "More than one person · recognition paused" |
| 11 | **Pause recognition** / **Resume** | Nothing processed while paused; camera light stays on |
| 12 | **Stop camera now** | Camera light off immediately |
| 13 | In Communication → Experimental live recognition → ASL signs, recognise HELLO, **Review this phrase**, confirm in the review queue | Message appears in the care-team conversation with source and model version |
| 14 | Type "medication dose" as the phrase and review it | Interpreter escalation; automation pauses |

## Record

| Date | Signer (Deaf / hearing, fluency, handedness) | Device, browser, camera | Lighting | Signs attempted | Correct | Not sure | Wrong | Median tracking ms | Notes |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |
