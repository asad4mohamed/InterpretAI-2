# InterpretAI 3.0.0 — changes and bugs fixed

## New

- **Working on-device ASL fingerspelling recognition.** Trained in this project on a public MIT-licensed MediaPipe landmark dataset, evaluated on held-out data (94.5%) and on 24 real photos of an unseen signer (87.5%). Live per-frame classification with rejection (score, margin, out-of-distribution distance), a temporal speller (hold-to-commit, no duplicate letters, release for double letters, word gaps), latency readout, and pause/resume. Works offline.
- **Hugging Face integration** through the secure proxy: server-side `HF_TOKEN`, a Dedicated Inference Endpoint or HF Inference model, per-photo consent, MIME and size validation, one retry while loading, 401/404/410/429/503/timeout handling, response-schema validation, and no payload logging.
- **Model information panel** for every mode: provider, model and version, vocabulary, input, local vs cloud, status, offline availability, known limitations, plus a capability matrix (hand tracking / handshape / fingerspelling / isolated signs / sentence translation).
- **Review-before-conversation.** Machine output goes to a review queue first, and only confirmed or corrected output enters the conversation.
- Provider messages can be **edited**, with the edit recorded. Machine signing is **only on explicit request** ("Show in signing avatar").
- Measured latency is shown for local tracking and model inference, and as round-trip time for cloud results.
- Reproducible training scripts in `ml/` and a model card in `docs/`.

## Bugs fixed (2.1 → 3.0)

| # | Bug | Fix |
|---|---|---|
| 1 | Offline toolkit never finished installing on macOS/Linux builds: Next.js writes flattened `__next.*.txt` files there, but the server and service worker only looked for the nested Windows layout | `serve.mjs` and the service worker try both layouts (2.1) |
| 2 | L/Y handshape rules were too strict for real hands, so they almost never matched | Looser thresholds, one-frame jitter tolerance, and on-screen hints explaining what to change (2.1.1) |
| 3 | The live status bar still said "selected — start the camera" after the camera had started | Announces "Camera on…" on successful start |
| 4 | Machine signing was requested automatically for every provider message, so text was sent to a third party without an explicit request | Signing now requires the **Show in signing avatar** button |
| 5 | Unconfirmed machine output appeared directly in the conversation log | Separate review queue; the conversation shows only confirmed or corrected patient output |
| 6 | The status label read "Experimental handshape detected" for fingerspelled letters | New "Fingerspelled letter detected" state |
| 7 | The build failed with no internet because the optional hand model download was fatal | Build continues with a clear warning (2.1) |
| 8 | Server security headers were missing on error responses | Headers apply to every response (2.1) |

## Unchanged

All 10 routes, the five scripted scenarios, safety stops, interpreter simulation, preventive care, research dashboard, competition demo, sample lab, Three.js mannequin, Sign-Speak and Hand Talk adapters, and the offline toolkit.
