@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is needed to open this demo.
  echo Install Node.js, then open this file again.
  pause
  exit /b 1
)
echo InterpretAI - local prototype
echo After the server is ready, open http://127.0.0.1:3000 in your browser.
echo Keep this window open. Press Ctrl+C to stop.
echo.
node scripts\serve.mjs
pause
