"use client";
import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { useApp } from "@/components/app-provider";
import { Badge, Icon, PageHeading } from "@/components/ui";
export default function SafetyPage() {
  const { requestInterpreter } = useApp();
  return (
    <AppShell>
      <PageHeading
        eyebrow="KNOW THE LIMITS"
        title="Safety & patient rights"
        description="Understand the prototype’s limitations and your choices before using it."
      />
      <section className="safety-hero">
        <span className="feature-icon">
          <Icon name="shield" size={34} />
        </span>
        <div>
          <Badge tone="white">RESEARCH PROTOTYPE</Badge>
          <h2>
            Support for access.
            <br />
            Respect for human understanding.
          </h2>
          <p>
            InterpretAI is experimental. ASL translation accuracy has not been
            clinically validated. This prototype does not interpret arbitrary
            ASL, diagnose conditions, or guide treatment.
          </p>
        </div>
      </section>
      <div className="safety-principles">
        {[
          {
            icon: "hand",
            title: "You can always say no.",
            text: "You can decline this tool or stop using it at any point. You do not need to give a reason. Your communication preferences should guide your care.",
          },
          {
            icon: "users",
            title: "Qualified interpreters are essential.",
            text: "Human interpretation remains available through your clinic’s actual process. This prototype does not book, connect to, or replace qualified interpreters.",
          },
          {
            icon: "info",
            title: "AI can make errors.",
            text: "ASL has linguistic and cultural nuance that automated systems can miss. Clinical conversations use fixed English scripts. The separate lab's handshape matches can be wrong and are not ASL translations. Any confidence shown in the experimental workspace is labelled as provider-reported or an uncalibrated model score; InterpretAI never invents one.",
          },
          {
            icon: "lock",
            title: "Privacy is part of access.",
            text: "No account, database, analytics, or tracking. Typed notes stay in page memory. The camera is optional. A video clip is recorded only when you press Record. It stays in page memory and goes to a named third party only after you consent to that one clip. No microphone is requested.",
          },
        ].map((p) => (
          <article className="card" key={p.title}>
            <span className="stat-icon teal">
              <Icon name={p.icon as "hand" | "users" | "info" | "lock"} />
            </span>
            <h2>{p.title}</h2>
            <p>{p.text}</p>
          </article>
        ))}
      </div>
      <section className="card high-risk-card">
        <div>
          <Badge tone="amber">WHEN THE PROTOTYPE MUST PAUSE</Badge>
          <h2>Some conversations need more than a tool.</h2>
          <p>
            Explicit high-risk scenarios stop automatically and direct the
            patient to qualified interpretation.
          </p>
        </div>
        <div className="risk-topics">
          {[
            "Medication dosing",
            "Allergies",
            "Diagnoses",
            "Medical consent",
            "Treatment decisions",
            "Emergency symptoms",
          ].map((t) => (
            <span key={t}>
              <Icon name="shield" size={17} />
              {t}
            </span>
          ))}
        </div>
        <div className="notice">
          <Icon name="info" />
          <p>
            The keyword safeguard is a demonstration only. It can miss topics,
            languages, wording, and context. It does not evaluate emergencies or
            guarantee safety in unrestricted text. There is no ASL detection.
            For real urgent concerns, use your local emergency service’s
            accessible process; this prototype contacts no one.
          </p>
        </div>
        <Link href="/communication/" className="subtle-link">
          Explore the safety stop in Scenario D
          <Icon name="arrow-right" size={17} />
        </Link>
      </section>
      <section className="card privacy-details">
        <h2>What stays on your device?</h2>
        <div>
          <p>
            <strong>Cached for offline use</strong>The public app shell,
            fictional examples, icons, styles, and static scripts. Browser
            storage can be cleared in your browser’s site settings.
          </p>
          <p>
            <strong>Kept only while the page is open</strong>Demo notes, camera
            preview, preferences, checklist choices, and fictional interpreter
            requests. Reloading clears them. Do not enter real health
            information.
          </p>
          <p>
            <strong>Sent only with your explicit choice</strong>In the
            experimental workspace, a clip you record and approve is sent once
            to Sign-Speak, or a photo you take and approve is sent once to your
            configured Hugging Face model, through InterpretAI’s secure proxy.
            Fingerspelling recognition runs entirely on this device. Typed text
            you choose to show in a signing avatar goes to that avatar provider.
            Cloud features are labelled and are off when offline. Nothing is
            uploaded in the background, and nothing is cached afterward.
          </p>
          <p>
            <strong>Standard hosting requests</strong>Loading the site requires
            ordinary network requests. Hosting infrastructure may retain
            standard access logs. The prototype adds no third-party analytics
            and makes no claim of clinical privacy certification.
          </p>
        </div>
      </section>
      <section className="card research-safety-note">
        <span className="eyebrow">BEFORE ANY FUTURE CLINICAL PILOT</span>
        <h2>Research goals require evidence and oversight.</h2>
        <p>
          The proposed Texas study would require a Deaf-led board, accessible
          consent, independent ethics and safety review, and evaluation across
          regional ASL, Black ASL, and age groups before expansion. No board,
          enrolled clinic network, or subgroup validation is represented as
          established by this prototype.
        </p>
        <p>
          Local processing is a proposed privacy safeguard. HIPAA compliance has
          not been assessed or certified. Continuous ASL recognition, speech
          processing, and a validated ASL-interpreting avatar are not
          implemented. The experimental workspace can connect to third-party
          recognition and signing providers once credentials are supplied. Their
          output is unvalidated for clinical use and pauses for high-risk
          topics.
        </p>
        <Link href="/research/" className="subtle-link">
          Read the proposed research safeguards{" "}
          <Icon name="arrow-right" size={17} />
        </Link>
      </section>
      <section className="card research-safety-note">
        <span className="eyebrow">SEPARATE TECHNICAL SAMPLE</span>
        <h2>The handshape lab has a much narrower purpose.</h2>
        <p>
          The optional lab uses a local MediaPipe hand-landmark model and
          original geometry rules to look for L-like and Y-like manual-alphabet
          handshapes. It is not an ASL translation model. Other shapes remain
          unknown, matches can be wrong, and no clinical or linguistic accuracy
          is established.
        </p>
        <p>
          The avatar is an original, scripted 3D pose illustration with no
          Deaf-led review yet. It does not sign clinical messages or translate
          text. The lab is kept separate from clinical scenarios. Camera frames
          and landmarks are transient and are never recorded or uploaded.
        </p>
        <Link href="/sample-lab/" className="subtle-link">
          Explore the bounded sample <Icon name="arrow-right" size={17} />
        </Link>
      </section>
      <div className="ethical-commitment">
        <Icon name="hand" size={31} />
        <h2>“AI should expand access, not replace human choice.”</h2>
        <p>
          InterpretAI does not replace your right to effective communication or
          appropriate qualified interpretation.
        </p>
        <button className="btn btn-primary" onClick={requestInterpreter}>
          Request Qualified Interpreter
          <Icon name="users" size={18} />
        </button>
      </div>
    </AppShell>
  );
}
