"use client";

import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { Badge, Icon, PageHeading } from "@/components/ui";
import { useApp } from "@/components/app-provider";

const reminders = [
  {
    title: "Blood pressure screening",
    text: "Ask your clinic what to expect.",
    category: "Screening",
  },
  {
    title: "Vaccination appointment",
    text: "Prepare the questions you want to ask.",
    category: "Vaccination",
  },
  {
    title: "Routine preventive screening",
    text: "Review the appointment checklist.",
    category: "Preparation",
  },
];

export default function DashboardPage() {
  const { requestInterpreter, offlineReady, openInfo } = useApp();
  return (
    <AppShell>
      <PageHeading
        eyebrow="PATIENT OVERVIEW"
        title="Your next visit, in focus."
        description="Jordan Morgan · Pine Grove Community Clinic · Rural Texas"
        action={<Badge tone="gray">Fictional patient & Texas FQHC</Badge>}
      />
      <div className="overview-layout">
        <section
          className="visit-overview"
          id="appointments"
          aria-labelledby="visits-title"
        >
          <div className="section-heading">
            <h2 id="visits-title">Upcoming appointments</h2>
            <span>02 visits</span>
          </div>
          <div className="next-visit">
            <div className="next-visit-date">
              <span>NOVEMBER</span>
              <strong>04</strong>
              <span>WEDNESDAY</span>
            </div>
            <div className="next-visit-info">
              <span className="eyebrow">NEXT APPOINTMENT</span>
              <h3>Annual wellness visit</h3>
              <p>Dr. Avery Brooks</p>
              <span className="visit-time">
                <Icon name="clock" size={15} />
                9:30 AM – 10:15 AM <span>·</span> In person
              </span>
            </div>
            <button
              className="icon-button"
              aria-label="View annual wellness visit details"
              onClick={() =>
                openInfo(
                  "Annual wellness visit · November 4",
                  "Fictional appointment: Wednesday, November 4, 2026, 9:30–10:15 AM at Pine Grove Community Clinic. Bring your questions, confirm arrangements with your clinic, and request communication support. No appointment is actually booked.",
                )
              }
            >
              <Icon name="arrow-right" />
            </button>
          </div>
          <div className="visit-preparation">
            <span>
              <Icon name="users" size={16} />
              In-person ASL interpreter preferred
            </span>
            <Link href="/preventive-care/">
              Prepare for visit <Icon name="arrow-right" size={16} />
            </Link>
          </div>
          <div className="following-visit">
            <div className="following-date">
              <span>NOV</span>
              <strong>18</strong>
            </div>
            <div>
              <h3>Care follow-up</h3>
              <p>11:00 AM – 11:30 AM · Video visit</p>
            </div>
            <button
              className="icon-button"
              aria-label="View care follow-up details"
              onClick={() =>
                openInfo(
                  "Care follow-up · November 18",
                  "Fictional appointment: Wednesday, November 18, 2026, 11:00–11:30 AM. Video visits require an internet connection. Ask the clinic to confirm accessible video and qualified interpreter arrangements.",
                )
              }
            >
              <Icon name="arrow-right" size={19} />
            </button>
          </div>
        </section>
        <section className="workspace-invitation">
          <div className="workspace-invitation-label">
            <Icon name="message" size={20} />
            <span>COMMUNICATION WORKSPACE</span>
          </div>
          <h2>
            Start with
            <br />
            <em>your words.</em>
          </h2>
          <p>
            Choose a scripted conversation. Confirm your message, correct it, or
            ask for qualified interpretation.
          </p>
          <Link href="/communication/" className="btn btn-white">
            Open communication workspace <Icon name="arrow-right" size={18} />
          </Link>
          <span className="invitation-note">
            Simulated — Not Clinically Validated
          </span>
        </section>
      </div>
      <div className="patient-context">
        <div>
          <span>PRIMARY LANGUAGE</span>
          <strong>American Sign Language</strong>
        </div>
        <div>
          <span>PREFERRED SUPPORT</span>
          <strong>Qualified ASL interpreter</strong>
        </div>
        <div>
          <span>OFFLINE TOOLKIT</span>
          <strong>
            <Icon name={offlineReady ? "check" : "download"} size={15} />
            {offlineReady
              ? "Downloaded to this device"
              : "Preparing for this device"}
          </strong>
        </div>
        <Link href="/preferences/" aria-label="Edit communication preferences">
          <Icon name="settings" size={18} />
        </Link>
      </div>
      <div className="dashboard-details">
        <section className="preparation-overview">
          <div className="section-heading">
            <div>
              <h2>Before your visit</h2>
              <p>Plain-language preparation for common appointments.</p>
            </div>
            <Link href="/preventive-care/" className="subtle-link">
              All care examples <Icon name="arrow-right" size={16} />
            </Link>
          </div>
          <div className="preparation-rows">
            {reminders.map((r, i) => (
              <Link
                href="/preventive-care/"
                className="preparation-row"
                key={r.title}
              >
                <span className="row-number">0{i + 1}</span>
                <div>
                  <h3>{r.title}</h3>
                  <p>{r.text}</p>
                </div>
                <span className="preparation-category">{r.category}</span>
                <Icon name="arrow-right" size={18} />
              </Link>
            ))}
          </div>
          <p className="plain-note preparation-footnote">
            Fictional reminders. Your clinician determines your care schedule
            with you.
          </p>
        </section>
        <aside className="dashboard-resources">
          <span className="eyebrow">RESOURCE LIBRARY</span>
          <h2>
            Prepare in
            <br />
            <em>your language.</em>
          </h2>
          <p>
            Read the companion guides for a visit, an interpreter request, or a
            lost video connection.
          </p>
          <Link href="/resources/" className="subtle-link">
            Explore ASL resources <Icon name="arrow-right" size={17} />
          </Link>
          <span className="resource-availability">
            <Icon name="video" size={16} />
            ASL videos planned. Human review pending.
          </span>
        </aside>
      </div>
      <section className="patient-rights-strip">
        <Icon name="users" size={23} />
        <div>
          <h3>You can ask for a person.</h3>
          <p>
            Pause the prototype or choose a qualified interpreter at any time.
          </p>
        </div>
        <button className="subtle-link" onClick={requestInterpreter}>
          Request Qualified Interpreter <Icon name="arrow-right" size={17} />
        </button>
      </section>
    </AppShell>
  );
}
