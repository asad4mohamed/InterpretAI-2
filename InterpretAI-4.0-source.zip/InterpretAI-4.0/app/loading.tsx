export default function Loading() {
  return (
    <main
      className="loading-state"
      aria-busy="true"
      aria-label="Loading patient experience"
    >
      <div className="loading-block" />
      <div className="loading-block tall" />
      <p role="status">Preparing your space…</p>
    </main>
  );
}
