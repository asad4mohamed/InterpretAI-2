"use client";
import Link from "next/link";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Badge, Icon, PageHeading } from "@/components/ui";
import {
  evaluationLenses,
  researchBudget,
  researchMeasures,
  researchPlan,
  researchReading,
  researchTimeline,
  technologyPaths,
} from "@/lib/research";

const measureFilters = [
  "All measures",
  "Access & care",
  "Patient experience",
  "Safety & reliability",
] as const;
type MeasureFilter = (typeof measureFilters)[number];

export default function ResearchPage() {
  const [chart, setChart] = useState<"annual" | "cumulative">("annual");
  const [measureFilter, setMeasureFilter] =
    useState<MeasureFilter>("All measures");
  const [direction, setDirection] =
    useState<keyof typeof technologyPaths>("patient");
  const [lens, setLens] =
    useState<(typeof evaluationLenses)[number]["id"]>("regional");
  const path = technologyPaths[direction];
  const evaluation = evaluationLenses.find((item) => item.id === lens)!;
  const measures = researchMeasures.filter(
    (item) => measureFilter === "All measures" || item.group === measureFilter,
  );
  const budgetTotal = researchBudget.reduce(
    (sum, item) => sum + item.amount,
    0,
  );
  return (
    <AppShell>
      <PageHeading
        eyebrow="TEAM 22 · BRIDGING THE GAP"
        title="Research & impact"
        description="A proposed Deaf-led research program for primary and preventive care in rural Texas federally qualified health centers (FQHCs)."
        action={<Badge tone="amber">PROPOSAL · NOT A LIVE PILOT</Badge>}
      />
      <div className="research-disclaimer">
        <Icon name="info" />
        <div>
          <strong>A research plan, with no measured clinical outcomes.</strong>
          <p>
            No clinics have been enrolled through this prototype. Sites,
            funding, timelines, and evaluation methods below are proposed; no
            clinical validation or funding award is claimed.
          </p>
        </div>
      </div>
      <section className="study-overview" aria-label="Proposed research scope">
        <div className="study-intro">
          <span className="eyebrow">THE TEXAS PROPOSAL</span>
          <h2>
            Start local.
            <br />
            <em>Earn the right to expand.</em>
          </h2>
          <p>
            Work toward reliable communication access in rural clinics, with
            Deaf patients governing what gets built, tested, and considered for
            use.
          </p>
        </div>
        <dl className="study-facts">
          <div>
            <dt>Proposed clinic network</dt>
            <dd>{researchPlan.sites}</dd>
            <dd className="fact-note">
              Rural Texas FQHCs · partners not yet recruited
            </dd>
          </div>
          <div>
            <dt>Proposed research period</dt>
            <dd>{researchPlan.years} years</dd>
            <dd className="fact-note">
              Progression subject to safety and ethics approvals
            </dd>
          </div>
          <div>
            <dt>Planning envelope</dt>
            <dd>${researchPlan.budgetMillions}M</dd>
            <dd className="fact-note">
              Proposed budget · no actual expenditures
            </dd>
          </div>
        </dl>
      </section>
      <section className="research-section" aria-labelledby="outcomes-title">
        <div className="research-section-heading">
          <div>
            <span className="eyebrow">THE QUESTIONS THAT MATTER</span>
            <h2 id="outcomes-title">Measure access. Listen to patients.</h2>
          </div>
          <Badge tone="gray">BASELINES & TARGETS NOT YET SET</Badge>
        </div>
        <p className="section-description">
          Define baselines, denominators, comparison groups, and meaningful
          targets with the community before collecting study data. No
          illustrative percentages are presented as results.
        </p>
        <div
          className="research-switcher"
          role="group"
          aria-label="Research measure category"
        >
          {measureFilters.map((filter) => (
            <button
              key={filter}
              aria-pressed={measureFilter === filter}
              onClick={() => setMeasureFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <p className="measure-count" role="status">
          {measures.length} proposed measures · {measureFilter}
        </p>
        <div className="measure-grid">
          {measures.map((measure) => (
            <article className="measure-item" key={measure.name}>
              <span className="eyebrow">{measure.group}</span>
              <h3>{measure.name}</h3>
              <p>{measure.question}</p>
              <span className="measure-unit">{measure.unit}</span>
              <details>
                <summary>Proposed evaluation method</summary>
                <p>{measure.method}</p>
              </details>
            </article>
          ))}
        </div>
        <Link
          href="/communication/"
          className="subtle-link research-inline-link"
        >
          Try the scripted teach-back in Scenario B{" "}
          <Icon name="arrow-right" size={17} />
        </Link>
      </section>
      <section
        className="research-section technology-research"
        aria-labelledby="technology-title"
      >
        <div className="research-section-heading">
          <div>
            <span className="eyebrow">THE TECHNICAL RESEARCH VISION</span>
            <h2 id="technology-title">
              On-device is the goal. Validation comes first.
            </h2>
          </div>
          <Badge tone="amber">PROPOSED · NOT IMPLEMENTED</Badge>
        </div>
        <p className="section-description">
          The executive summary proposes two-way ASL and English support on a
          local device. Continuous ASL recognition, speech recognition, speech
          output, and an ASL-interpreting avatar all require separate research
          and evaluation.
        </p>
        <div
          className="research-switcher"
          role="group"
          aria-label="Proposed communication direction"
        >
          <button
            aria-pressed={direction === "patient"}
            onClick={() => setDirection("patient")}
          >
            ASL → English
          </button>
          <button
            aria-pressed={direction === "provider"}
            onClick={() => setDirection("provider")}
          >
            English → ASL
          </button>
        </div>
        <div className="technology-path" aria-live="polite" aria-atomic="true">
          <h3>{path.title}</h3>
          <p>{path.description}</p>
          <ol className="pipeline-stages">
            {path.stages.map((stage, index) => (
              <li key={stage.title}>
                <span className="pipeline-number">0{index + 1}</span>
                <h4>{stage.title}</h4>
                <p>{stage.detail}</p>
              </li>
            ))}
          </ol>
        </div>
        <div className="capability-boundary">
          <div>
            <Icon name="check" size={20} />
            <p>
              <strong>Working in this prototype</strong>Cached scripted
              scenarios, patient confirmation and correction, a local camera
              preview, and simulated interpreter requests.
            </p>
          </div>
          <div>
            <Icon name="shield" size={20} />
            <p>
              <strong>A requirement for future research</strong>Unclear output,
              high-risk topics, and patient requests must pause for qualified
              interpretation. No model confidence score or comprehensive risk
              detector exists here.
            </p>
          </div>
        </div>
      </section>
      <Link href="/sample-lab/" className="subtle-link research-inline-link">
        Try two experimental handshape matches & a scripted avatar pose{" "}
        <Icon name="arrow-right" size={17} />
      </Link>
      <section
        className="research-section governance-section"
        aria-labelledby="governance-title"
      >
        <div className="governance-intro">
          <span className="eyebrow">GOVERNED BY THE COMMUNITY</span>
          <h2 id="governance-title">
            Deaf leadership.
            <br />
            <em>Evidence for every group.</em>
          </h2>
          <p>
            A proposed Deaf-led board would guide recruitment, consent, data
            use, stopping rules, and expansion. Community members should be paid
            for their expertise.
          </p>
          <p>
            Before expansion, review language variation, age, error severity,
            and comprehension separately. No subgroup has been evaluated in this
            prototype.
          </p>
        </div>
        <div className="equity-panel">
          <span className="eyebrow">PROPOSED EVALUATION LENSES</span>
          <div
            className="research-switcher"
            role="group"
            aria-label="Subgroup evaluation lens"
          >
            {evaluationLenses.map((item) => (
              <button
                key={item.id}
                aria-pressed={lens === item.id}
                onClick={() => setLens(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="equity-detail" aria-live="polite" aria-atomic="true">
            <h3>{evaluation.title}</h3>
            <p>{evaluation.detail}</p>
          </div>
          <Badge tone="gray">RESEARCH QUESTIONS · NO SUBGROUP RESULTS</Badge>
        </div>
      </section>
      <section className="card timeline-card">
        <div className="card-heading">
          <div>
            <span className="eyebrow">FIVE YEARS · EACH PHASE HAS A GATE</span>
            <h2>A proposed path from baseline to regional research</h2>
          </div>
          <Badge tone="gray">SUBJECT TO APPROVALS</Badge>
        </div>
        <ol className="research-timeline">
          {researchTimeline.map((phase, index) => (
            <li key={phase.title}>
              <span className="timeline-node">0{index + 1}</span>
              <small>YEAR {index + 1}</small>
              <h3>{phase.title}</h3>
              <p>{phase.detail}</p>
              <p className="timeline-gate">{phase.gate}</p>
            </li>
          ))}
        </ol>
      </section>
      <div className="research-columns research-financing">
        <section className="card budget-card" aria-labelledby="budget-title">
          <div className="card-heading">
            <div>
              <h2 id="budget-title">Proposed five-year budget</h2>
              <p>Illustrative annual allocation of the $5M proposal</p>
            </div>
            <Icon name="activity" />
          </div>
          <div className="budget-summary">
            <strong>
              ${budgetTotal.toFixed(2)}
              <span>M</span>
            </strong>
            <div>
              proposed total
              <small>No funds awarded or spent through this prototype</small>
            </div>
          </div>
          <div
            className="filter-tabs chart-tabs"
            role="group"
            aria-label="Budget chart view"
          >
            <button
              className={chart === "annual" ? "selected" : ""}
              onClick={() => setChart("annual")}
              aria-pressed={chart === "annual"}
            >
              Annual budget
            </button>
            <button
              className={chart === "cumulative" ? "selected" : ""}
              onClick={() => setChart("cumulative")}
              aria-pressed={chart === "cumulative"}
            >
              Cumulative
            </button>
          </div>
          <div
            className="budget-chart"
            role="img"
            aria-label={`${chart === "annual" ? "Annual" : "Cumulative"} proposed budget in millions: ${researchBudget.map((item, index) => `year ${item.year}, $${(chart === "annual" ? item.amount : researchBudget.slice(0, index + 1).reduce((sum, entry) => sum + entry.amount, 0)).toFixed(2)} million`).join("; ")}`}
          >
            <div className="chart-grid-lines">
              <span />
              <span />
              <span />
              <span />
            </div>
            {researchBudget.map((item, index) => {
              const amount =
                chart === "annual"
                  ? item.amount
                  : researchBudget
                      .slice(0, index + 1)
                      .reduce((sum, entry) => sum + entry.amount, 0);
              return (
                <div className="budget-column" key={item.year}>
                  <span className="bar-amount">${amount.toFixed(2)}M</span>
                  <div
                    className="budget-bar"
                    style={{
                      height: `${(amount / (chart === "annual" ? 1.5 : 5)) * 180}px`,
                    }}
                  />
                  <span>Year {item.year}</span>
                </div>
              );
            })}
          </div>
          <details className="budget-table">
            <summary>View budget as a table</summary>
            <table>
              <caption>
                Planning illustration, not actual expenditure or awarded funding
              </caption>
              <thead>
                <tr>
                  <th scope="col">Year</th>
                  <th scope="col">Research phase</th>
                  <th scope="col">Proposed budget</th>
                </tr>
              </thead>
              <tbody>
                {researchBudget.map((item) => (
                  <tr key={item.year}>
                    <th scope="row">{item.year}</th>
                    <td>{item.label}</td>
                    <td>${item.amount.toFixed(2)}M</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <th scope="row" colSpan={2}>
                    Total
                  </th>
                  <td>${budgetTotal.toFixed(2)}M</td>
                </tr>
              </tfoot>
            </table>
          </details>
        </section>
        <section
          className="evaluation-card funding-model"
          aria-labelledby="funding-title"
        >
          <span className="eyebrow">A SUSTAINABILITY HYPOTHESIS</span>
          <h2 id="funding-title">
            A device subscription.
            <br />A protected place for people.
          </h2>
          <p>
            The summary proposes clinic device subscriptions, grant support, and
            value-based care arrangements. Pricing, savings, reimbursement, and
            partnerships remain untested.
          </p>
          <dl>
            <div>
              <dt>Device subscriptions</dt>
              <dd>
                Explore predictable access to an evaluated toolkit. No
                subscription product or price is offered here.
              </dd>
            </div>
            <div>
              <dt>Grants & care partnerships</dt>
              <dd>
                Study funding feasibility with prospective partners; no grants
                or reimbursement agreements are secured.
              </dd>
            </div>
            <div>
              <dt>FQHC networks</dt>
              <dd>
                Consider a regional research pathway only after evidence,
                community review, and clinic readiness.
              </dd>
            </div>
          </dl>
          <div className="funding-commitment">
            <Icon name="users" size={20} />
            <p>
              Budget for qualified interpreters remains essential. A device
              subscription must not remove patient choice or appropriate human
              interpretation.
            </p>
          </div>
        </section>
      </div>
      <section
        className="research-section reading-section"
        aria-labelledby="reading-title"
      >
        <div className="research-section-heading">
          <div>
            <span className="eyebrow">CONTEXT FOR THE PROPOSAL</span>
            <h2 id="reading-title">
              Selected research from the executive summary
            </h2>
          </div>
        </div>
        <p className="section-description">
          These publications provide background, not evidence that InterpretAI
          is effective. External articles require an internet connection; the
          research plan above is available after offline caching.
        </p>
        <ol className="research-reading">
          {researchReading.map((item) => (
            <li key={item.href}>
              <a href={item.href} target="_blank" rel="noreferrer">
                {item.title}
                <Icon name="external" size={16} />
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
              <span>{item.citation}</span>
            </li>
          ))}
        </ol>
        <p className="research-team">
          Team 22 · Mohamed Asad · Xander Lawson · Durga Mandadapu · Aryan Ghosh
        </p>
      </section>
    </AppShell>
  );
}
