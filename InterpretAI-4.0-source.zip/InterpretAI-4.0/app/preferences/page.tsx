"use client";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { useApp } from "@/components/app-provider";
import { Badge, Icon, PageHeading } from "@/components/ui";
export default function PreferencesPage() {
  const [language, setLanguage] = useState("asl");
  const [support, setSupport] = useState("in-person");
  const [captions, setCaptions] = useState(true);
  const [saved, setSaved] = useState(false);
  const { requestInterpreter } = useApp();
  return (
    <AppShell>
      <PageHeading
        eyebrow="YOUR PREFERENCES"
        title="Communication preferences"
        description="Try communication preferences for Jordan, our fictional patient. No account or real personal information needed."
      />
      <div className="preferences-layout">
        <section className="card preference-form">
          <div className="profile-summary">
            <span className="profile-avatar large">JM</span>
            <div>
              <h2>Jordan Morgan</h2>
              <p>Fictional patient · Pine Grove Community Clinic</p>
            </div>
            <Badge tone="gray">DEMO PROFILE</Badge>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSaved(true);
            }}
            onChange={() => setSaved(false)}
          >
            <label className="field-label" htmlFor="language">
              My primary communication language
            </label>
            <select
              id="language"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
            >
              <option value="asl">American Sign Language (ASL)</option>
              <option value="written">Written English</option>
              <option value="discuss">
                I would like to discuss my preferences
              </option>
            </select>
            <label className="field-label" htmlFor="support">
              My preferred interpretation support
            </label>
            <select
              id="support"
              value={support}
              onChange={(e) => setSupport(e.target.value)}
            >
              <option value="in-person">
                Qualified in-person ASL interpreter
              </option>
              <option value="video">Qualified video remote interpreter</option>
              <option value="clinic">Discuss options with my clinic</option>
            </select>
            <label className="checkbox-setting">
              <input
                type="checkbox"
                checked={captions}
                onChange={(e) => setCaptions(e.target.checked)}
              />
              <span>
                <strong>I prefer written companion text</strong>
                <small>
                  A demo preference for a future care profile. Workspace text
                  stays available for all users.
                </small>
              </span>
            </label>
            <div className="notice">
              <Icon name="lock" />
              <p>
                These selections stay in this page’s memory and reset when you
                leave. Saving here does not change clinic records or book an
                interpreter.
              </p>
            </div>
            <button className="btn btn-primary" type="submit">
              <Icon name="check" size={17} />
              Save demo preferences
            </button>
            <p className="completion-note" role="status">
              {saved
                ? `Demo preferences saved in this page: ${language === "asl" ? "ASL" : language === "written" ? "Written English" : "Discuss language"}, ${support === "in-person" ? "in-person interpreter" : support === "video" ? "video remote interpreter" : "discuss support"}.`
                : "Your choices can be changed at any time."}
            </p>
          </form>
        </section>
        <aside className="card rights-card">
          <span className="feature-icon">
            <Icon name="shield" size={30} />
          </span>
          <h2>You decide what works for you.</h2>
          <p>
            You can decline the prototype, pause a conversation, or ask for
            qualified human interpretation at any time.
          </p>
          <p className="rights-statement">
            InterpretAI does not replace your right to effective communication
            or appropriate qualified interpretation.
          </p>
          <button
            className="btn btn-primary w-full"
            onClick={requestInterpreter}
          >
            Request Qualified Interpreter
            <Icon name="users" size={17} />
          </button>
        </aside>
      </div>
    </AppShell>
  );
}
