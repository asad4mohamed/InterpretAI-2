import Link from "next/link";
import { Brand, Icon } from "@/components/ui";
export default function NotFound() {
  return (
    <main className="standalone-state">
      <Brand />
      <span className="feature-icon">
        <Icon name="message" size={34} />
      </span>
      <h1>Let’s get you back to your care.</h1>
      <p>
        This page isn’t part of the prototype. Your patient workspace is one
        step away.
      </p>
      <Link href="/dashboard/" className="btn btn-primary">
        Go to my overview
        <Icon name="arrow-right" />
      </Link>
    </main>
  );
}
