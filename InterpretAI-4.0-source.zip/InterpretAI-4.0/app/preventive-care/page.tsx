import { AppShell } from "@/components/app-shell";
import { CareLibrary } from "@/components/care-library";
import { Icon, PageHeading } from "@/components/ui";
export default function CarePage() {
  return (
    <AppShell>
      <PageHeading
        eyebrow="PREVENTIVE CARE"
        title="Prepare for a visit"
        description="Explore plain-language care examples and plan the communication support you want."
      />
      <div className="notice care-notice">
        <Icon name="info" />
        <p>
          These fictional examples help you navigate a visit. Your clinician
          determines appropriate screening, vaccination, and follow-up schedules
          with you. No personalized medical recommendations are provided.
        </p>
      </div>
      <CareLibrary />
    </AppShell>
  );
}
