import type { Metadata, Viewport } from "next";
import { AppProvider } from "@/components/app-provider";
import "./globals.css";
export const metadata: Metadata = {
  title: {
    default: "InterpretAI — Your language. Your care. Your choice.",
    template: "%s | InterpretAI",
  },
  description:
    "A Deaf-centered research prototype for accessible healthcare communication. Offline communication cards, patient choice, and qualified interpreter access.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icon.svg", apple: "/icon-192.png" },
  appleWebApp: {
    capable: true,
    title: "InterpretAI",
    statusBarStyle: "default",
  },
};
export const viewport: Viewport = {
  themeColor: "#087F8C",
  width: "device-width",
  initialScale: 1,
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
