"use client";
import { Icon } from "@/components/ui";
export default function ErrorPage({
  reset,
}: {
  error: Error;
  reset: () => void;
}) {
  return (
    <main className="standalone-state">
      <Icon name="info" size={36} />
      <h1>Something interrupted this page.</h1>
      <p>
        Your typed demo information is temporary. Try loading the page again.
      </p>
      <button className="btn btn-primary" onClick={reset}>
        Try again
        <Icon name="refresh" />
      </button>
    </main>
  );
}
