import { AppShell } from "@/components/app-shell";
import { SignRecognitionPanel } from "@/components/sign-recognition-panel";
import { Badge, Icon, PageHeading } from "@/components/ui";

export default function SignsPage() {
  return (
    <AppShell>
      <PageHeading
        eyebrow="EXPERIMENTAL · NOT CLINICALLY VALIDATED"
        title="Sign recognition"
        description="Continuous, on-device recognition of 250 isolated ASL signs with movement tracking, a reviewable sign history, and a small set of short phrases. It is not ASL translation and does not replace a qualified interpreter."
      />
      <div className="simulation-disclaimer">
        <Icon name="shield" size={19} />
        <div>
          <strong>Experimental — Not Clinically Validated</strong>
          <span>
            Results can be wrong, especially for signers, lighting and cameras
            unlike the training data. Every sign and phrase is shown for your
            review; nothing is used until you confirm it. For clinical
            discussion, request a qualified interpreter.
          </span>
        </div>
        <Badge tone="amber">RESEARCH PROTOTYPE</Badge>
      </div>
      <SignRecognitionPanel variant="standalone" />
    </AppShell>
  );
}
