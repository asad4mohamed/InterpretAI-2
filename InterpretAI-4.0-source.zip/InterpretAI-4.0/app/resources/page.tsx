"use client";
import { useState } from "react";
import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { Badge, Icon, PageHeading } from "@/components/ui";
export default function ResourcesPage() {
  const [active, setActive] = useState<string | null>(null);
  const resources = [
    {
      title: "Getting ready for your visit",
      category: "Visit preparation",
      text: "Write down your questions. Ask the clinic for appointment details in an accessible format. Share your communication preferences before the visit.",
    },
    {
      title: "Asking for an ASL interpreter",
      category: "Your communication",
      text: "Tell the clinic that you use ASL and want a qualified interpreter. Ask the clinic to confirm the arrangements. You can ask to pause when communication is not effective.",
    },
    {
      title: "When video loses connection",
      category: "Offline toolkit",
      text: "Use a predefined card to ask to pause. Tell the clinic that video is not working for you. Ask staff to use their actual process to arrange appropriate qualified interpretation.",
    },
    {
      title: "Making room for questions",
      category: "Your communication",
      text: "You can ask for more time, a clearer explanation, or a qualified interpreter. Confirm only messages you understand and agree with.",
    },
  ];
  return (
    <AppShell>
      <PageHeading
        eyebrow="RESOURCE LIBRARY"
        title="ASL resources"
        description="Plain-language preparation and a home for future Deaf-led, human-reviewed ASL content."
      />
      <div className="notice">
        <Icon name="info" />
        <p>
          ASL videos are placeholders. No videos have been filmed or reviewed.
          The scripted English demo cards use the label “Simulation /
          Prevalidated Example”; that label does not establish clinical or
          linguistic validation.
        </p>
      </div>
      <div className="resource-grid">
        {resources.map((r, i) => (
          <article className="card resource-card" key={r.title}>
            <div className={`resource-visual visual-${i}`}>
              <span>
                <Icon name={i === 2 ? "offline" : "hand"} size={45} />
              </span>
              <Badge tone="white">ASL VIDEO PLACEHOLDER</Badge>
            </div>
            <div className="resource-card-copy">
              <Badge tone="gray">{r.category}</Badge>
              <h2>{r.title}</h2>
              <p>
                Human-reviewed ASL video planned.
                <br />
                Plain-language companion available now.
              </p>
              <button
                className="btn btn-outline w-full"
                onClick={() => setActive(active === r.title ? null : r.title)}
                aria-expanded={active === r.title}
              >
                {active === r.title
                  ? "Close companion text"
                  : "Read companion text"}
                <Icon name={active === r.title ? "x" : "book"} size={17} />
              </button>
              {active === r.title && (
                <div className="resource-transcript">
                  <h3>Plain-language companion</h3>
                  <p>{r.text}</p>
                  <small>Preparation support only. No clinical advice.</small>
                </div>
              )}
            </div>
          </article>
        ))}
      </div>
      <section className="patient-rights-strip">
        <Icon name="message" size={25} />
        <div>
          <h3>Prefer to try an example?</h3>
          <p>Walk through predefined cards in the communication workspace.</p>
        </div>
        <Link className="subtle-link" href="/communication/">
          Explore communication
          <Icon name="arrow-right" size={17} />
        </Link>
      </section>
    </AppShell>
  );
}
