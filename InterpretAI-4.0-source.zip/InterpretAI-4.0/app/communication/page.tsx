import { AppShell } from "@/components/app-shell";
import { CommunicationModes } from "@/components/communication-modes";
import { PageHeading } from "@/components/ui";
export default function CommunicationPage() {
  return (
    <AppShell>
      <PageHeading
        eyebrow="PATIENT & CARE TEAM"
        title="Communication workspace"
        description="Choose a scripted example, or try the clearly separated experimental recognition workspace. Confirm or correct each patient message before continuing."
      />
      <CommunicationModes />
    </AppShell>
  );
}
