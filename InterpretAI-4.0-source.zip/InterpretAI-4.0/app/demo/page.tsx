"use client";
import Link from "next/link";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { CommunicationWorkspace } from "@/components/communication-workspace";
import { useApp } from "@/components/app-provider";
import { Badge, Icon, PageHeading } from "@/components/ui";
import { researchPlan } from "@/lib/research";
const steps = [
  "The access problem",
  "Meet the patient",
  "Start a conversation",
  "When the network fails",
  "Confirm & teach back",
  "Choose a human",
  "The research vision",
  "Our commitment",
];
const content = [
  {
    title: "Access starts with being understood.",
    time: "30 seconds",
    text: "Deaf ASL users in rural Texas may face barriers to primary and preventive care when qualified interpreters are unavailable or VRI becomes unreliable. InterpretAI proposes research with 10–12 rural Texas FQHCs, beginning with Deaf-led design and evaluation.",
    tip: "Introduce the research prototype. Be explicit: no live ASL interpretation or clinical validation is claimed.",
  },
  {
    title: "Meet Jordan. Fictional patient, real design priorities.",
    time: "30 seconds",
    text: "Jordan uses ASL and visits a fictional rural Texas FQHC. The patient overview brings appointments, preventive care preparation, communication preferences, and qualified interpreter access into one calm space.",
    tip: "Open the patient dashboard, explore one appointment, then return here using Competition demo in the sidebar.",
  },
  {
    title: "Begin with a routine check-in.",
    time: "45 seconds",
    text: "Choose Next to reveal Jordan’s scripted message. Confirm the card before the conversation can continue. Every example is explicitly labeled.",
    tip: "Click Next → “Yes, that’s my message” → Next. No camera input is translated.",
  },
  {
    title: "A connection can fail. Access still matters.",
    time: "30 seconds",
    text: "Choose “Simulate outage” below. The fixed scenario remains usable while the interface explains that remote interpreting needs a connection. The browser’s actual online/offline status remains separate.",
    tip: "For a real offline test, build the app, wait for “Offline toolkit ready”, then set your browser network to Offline and reload.",
  },
  {
    title: "Understanding deserves a second conversation.",
    time: "30 seconds",
    text: "Use Scenario B to prepare for a preventive visit. At the teach-back card, the patient repeats how they will confirm visit logistics and interpreter support. They can correct the example or ask for a person. A click is not a comprehension score.",
    tip: "Advance and confirm the scripted patient cards. At “Teach-back practice”, try Correct, then repeat and confirm if the message fits. Clinical teach-back requires qualified human support.",
  },
  {
    title: "High-risk questions need a human.",
    time: "40 seconds",
    text: "Advance this medication question. The scenario stops before any clinical interpretation is provided. Explore a fictional request for qualified in-person or video interpretation.",
    tip: "Click Next to trigger the safety stop, then “Request Qualified Interpreter”. No actual booking or connection is made.",
  },
  {
    title: "A research vision, with honest evidence.",
    time: "30 seconds",
    text: "Explore the five-year, $5 million proposal for 10–12 rural Texas FQHCs. Measures include time to communication access, screening and vaccination completion, teach-back comprehension, and interpreter escalation. Telehealth and on-device ASL systems are future research goals.",
    tip: "Open Research & impact. Switch technology directions, inspect evaluation lenses, and compare annual/cumulative budget. No clinical results, clinic enrollment, or funding awards are claimed.",
  },
  {
    title: "AI should expand access, not replace human choice.",
    time: "20 seconds",
    text: "The goal is healthcare that respects language, autonomy, and human understanding. The next step is Deaf-led co-design, independent safety evaluation, and ethical research—not clinical deployment.",
    tip: "Close with patient choice. InterpretAI does not replace the right to effective communication or appropriate qualified interpretation.",
  },
];
export default function DemoPage() {
  const [index, setIndex] = useState(0);
  const { setSimulatedOffline, requestInterpreter } = useApp();
  const c = content[index];
  const scenario =
    index === 3
      ? "outage"
      : index === 5
        ? "medication"
        : index === 4
          ? "screening"
          : "check-in";
  function restart() {
    setIndex(0);
    setSimulatedOffline(false);
  }
  return (
    <AppShell>
      <PageHeading
        eyebrow="GUIDED WALKTHROUGH"
        title="Competition demo"
        description="A repeatable, 3–5-minute guided demonstration of access, safety, and patient choice."
        action={
          <Badge tone="teal">
            <Icon name="clock" size={14} />
            3–5 MINUTE DEMO
          </Badge>
        }
      />
      <div className="demo-layout">
        <aside className="card demo-step-list" aria-label="Demonstration steps">
          <span className="eyebrow">YOUR DEMO GUIDE</span>
          <ol>
            {steps.map((s, i) => (
              <li key={s}>
                <button
                  onClick={() => {
                    setIndex(i);
                    setSimulatedOffline(false);
                  }}
                  className={i === index ? "active" : ""}
                  aria-current={i === index ? "step" : undefined}
                >
                  <span>
                    {i < index ? (
                      <Icon name="check" size={14} />
                    ) : (
                      String(i + 1).padStart(2, "0")
                    )}
                  </span>
                  {s}
                </button>
              </li>
            ))}
          </ol>
          <button className="text-button" onClick={restart}>
            <Icon name="refresh" size={16} />
            Restart demonstration
          </button>
        </aside>
        <section className="card demo-content">
          <div className="demo-stage-meta">
            <Badge tone="gray">STEP {index + 1} OF 8</Badge>
            <span>
              <Icon name="clock" size={14} />
              {c.time}
            </span>
          </div>
          <h2>{c.title}</h2>
          <p>{c.text}</p>
          <div className="presenter-tip">
            <Icon name="monitor" size={20} />
            <div>
              <strong>Presenter’s cue</strong>
              <p>{c.tip}</p>
            </div>
          </div>
          {index === 0 && (
            <div className="demo-problem-grid">
              <div>
                <Icon name="hand" size={29} />
                <h3>Language access</h3>
                <p>
                  ASL is a language, with its own grammar and cultural context.
                </p>
              </div>
              <div>
                <Icon name="offline" size={29} />
                <h3>Rural connectivity</h3>
                <p>Unreliable video can interrupt effective communication.</p>
              </div>
              <div>
                <Icon name="users" size={29} />
                <h3>Human choice</h3>
                <p>Qualified interpretation remains central to care.</p>
              </div>
            </div>
          )}
          {index === 1 && (
            <div className="demo-patient-preview">
              <span className="profile-avatar large">JM</span>
              <div>
                <h3>Jordan Morgan</h3>
                <p>ASL first · Qualified in-person interpretation preferred</p>
                <Badge tone="gray">FICTIONAL PATIENT</Badge>
              </div>
              <Link href="/dashboard/" className="btn btn-primary">
                Explore patient dashboard
                <Icon name="arrow-right" size={17} />
              </Link>
            </div>
          )}
          {index >= 2 && index <= 5 && (
            <CommunicationWorkspace
              key={`${index}-${scenario}`}
              initialScenario={scenario}
              compact
            />
          )}
          {index === 6 && (
            <div className="demo-research-preview">
              <div>
                <strong>${researchPlan.budgetMillions}M</strong>
                <span>Proposed five-year budget</span>
              </div>
              <div>
                <strong>{researchPlan.sites} FQHCs</strong>
                <span>Proposed rural Texas research network</span>
              </div>
              <Badge tone="amber">PLANNING ILLUSTRATION</Badge>
              <Link href="/research/" className="btn btn-primary">
                Explore research & impact
                <Icon name="arrow-right" size={17} />
              </Link>
              <Link href="/sample-lab/" className="subtle-link">
                Optional: try the handshape & avatar lab{" "}
                <Icon name="arrow-right" size={17} />
              </Link>
            </div>
          )}
          {index === 7 && (
            <div className="demo-ethics">
              <Icon name="hand" size={48} />
              <h3>
                Your language.
                <br />
                Your care.
                <br />
                <span>Your choice.</span>
              </h3>
              <button className="btn btn-primary" onClick={requestInterpreter}>
                Request Qualified Interpreter
                <Icon name="users" size={18} />
              </button>
              <Link href="/safety/" className="subtle-link">
                Read our ethical commitment
                <Icon name="arrow-right" size={17} />
              </Link>
            </div>
          )}
          <div className="demo-stage-controls">
            <button
              className="btn btn-outline"
              disabled={index === 0}
              onClick={() => {
                setIndex((v) => v - 1);
                setSimulatedOffline(false);
              }}
            >
              <Icon name="arrow-left" size={17} />
              Previous
            </button>
            <span>{index + 1} / 8</span>
            <button
              className="btn btn-primary"
              onClick={() => {
                if (index === 7) restart();
                else {
                  setIndex((v) => v + 1);
                  setSimulatedOffline(false);
                }
              }}
            >
              {index === 7 ? "Run demo again" : "Next demo step"}
              <Icon name={index === 7 ? "refresh" : "arrow-right"} size={17} />
            </button>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
