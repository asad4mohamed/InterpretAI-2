"use client";

import Link from "next/link";
import { Brand, Icon } from "@/components/ui";
import { useApp } from "@/components/app-provider";
import { researchPlan } from "@/lib/research";

const principles = [
  {
    number: "01",
    title: "A toolkit that stays with you.",
    text: "Download the predefined communication examples once. Open them again when a clinic’s connection drops.",
    note: "Offline accessibility",
  },
  {
    number: "02",
    title: "ASL belongs in the room.",
    text: "A visual-first workspace with explicit patient confirmation and a place for future human-reviewed ASL resources.",
    note: "ASL-first design",
  },
  {
    number: "03",
    title: "A person is always your choice.",
    text: "Ask for qualified interpretation, pause a conversation, or decline the prototype. The decision stays with you.",
    note: "Human interpreter access",
  },
  {
    number: "04",
    title: "Less information collected.",
    text: "No account or analytics. Camera preview stays on your device. Demo notes disappear when you reload.",
    note: "Privacy by design",
  },
];

export default function LandingPage() {
  const { requestInterpreter, online } = useApp();
  return (
    <div className="landing">
      <a className="skip-link" href="#main">
        Skip to main content
      </a>
      <header className="landing-nav">
        <Link href="/" aria-label="InterpretAI home">
          <Brand />
        </Link>
        <nav aria-label="Landing navigation">
          <a href="#how-it-works">The approach</a>
          <Link href="/safety/">Patient rights</Link>
          <Link href="/research/">Research</Link>
        </nav>
        <Link href="/dashboard/" className="nav-entry">
          Open prototype <Icon name="arrow-right" size={17} />
        </Link>
      </header>
      <main id="main">
        <section className="landing-hero">
          <div className="hero-copy">
            <p className="hero-kicker">
              <span />
              Bridging the gap in rural Texas.
            </p>
            <h1>
              Your language.
              <br />
              Your care.
              <br />
              <em>Your choice.</em>
            </h1>
            <p className="hero-description">
              When a connection drops, the conversation shouldn’t end.
              Offline-capable communication tools for Deaf ASL users in rural
              primary and preventive care, with qualified human interpretation
              at the center.
            </p>
            <div className="hero-actions">
              <Link href="/dashboard/" className="btn btn-primary">
                Explore Patient Experience <Icon name="arrow-right" size={18} />
              </Link>
              <a href="#how-it-works" className="text-button">
                See How It Works <Icon name="arrow-right" size={17} />
              </a>
            </div>
            <p className="hero-footnote">
              No account required. Fictional patients only.
            </p>
          </div>
          <div className="communication-preview">
            <div className="preview-label">
              <span>Inside the workspace</span>
              <span>01 / Check-in</span>
            </div>
            <div className="preview-window">
              <div className="preview-header">
                <span className="preview-window-title">
                  <Icon name="message" size={18} />
                  Patient communication
                </span>
                <span className="preview-network">
                  <span className="status-dot" />
                  {online ? "Online" : "Offline"}
                </span>
              </div>
              <div className="preview-conversation">
                <div className="preview-provider">
                  <span className="preview-speaker">CARE TEAM</span>
                  <p>How would you prefer to communicate today?</p>
                </div>
                <div className="preview-patient">
                  <span className="preview-speaker">PATIENT MESSAGE</span>
                  <p>
                    “I use ASL. Please arrange a qualified interpreter for my
                    visit.”
                  </p>
                  <span className="preview-script-label">
                    Simulation / Prevalidated Example
                  </span>
                </div>
                <div className="preview-confirmation">
                  <Icon name="check" size={16} />
                  <span>You confirm the message before continuing.</span>
                </div>
              </div>
              <Link href="/communication/" className="preview-workspace-link">
                Try this conversation <Icon name="arrow-right" size={18} />
              </Link>
            </div>
            <div className="preview-caption">
              <span className="caption-rule" />
              <p>
                A scripted example. No live ASL translation.
                <br />
                You choose when to pause and who helps you communicate.
              </p>
            </div>
          </div>
        </section>
        <div className="landing-disclaimer">
          <Icon name="info" size={19} />
          <p>
            <strong>Simulated — Not Clinically Validated.</strong> This research
            prototype does not translate arbitrary ASL or replace a qualified
            interpreter.
          </p>
          <Link href="/safety/">
            Read the limitations <Icon name="arrow-right" size={16} />
          </Link>
        </div>
        <section className="landing-approach" id="how-it-works">
          <div className="approach-intro">
            <span className="eyebrow">THE APPROACH</span>
            <h2>
              A connection can fail.
              <br />
              <em>Access shouldn’t.</em>
            </h2>
            <p>
              In rural Texas community health centers, unreliable video and a
              shortage of available interpreters can interrupt a visit.
              InterpretAI explores practical support for primary and preventive
              care between those moments.
            </p>
          </div>
          <div className="principles-grid">
            {principles.map((p) => (
              <article className="principle" key={p.number}>
                <div className="principle-index">
                  <span>{p.number}</span>
                  <span>{p.note}</span>
                </div>
                <h3>{p.title}</h3>
                <p>{p.text}</p>
              </article>
            ))}
          </div>
        </section>
        <section className="landing-proposal" aria-labelledby="proposal-title">
          <div>
            <span className="eyebrow">TEAM 22 · THE RESEARCH PROPOSAL</span>
            <h2 id="proposal-title">
              Bridging the gap.
              <br />
              <em>Beginning in rural Texas.</em>
            </h2>
            <p>
              A proposed Deaf-led program in federally qualified health centers
              (FQHCs), studying communication access, preventive care,
              teach-back comprehension, and the availability of human support.
            </p>
            <Link href="/research/" className="subtle-link">
              Explore the research plan <Icon name="arrow-right" size={18} />
            </Link>
          </div>
          <div className="proposal-outline">
            <dl>
              <div>
                <dt>Proposed Texas FQHCs</dt>
                <dd>{researchPlan.sites}</dd>
              </div>
              <div>
                <dt>Proposed research period</dt>
                <dd>{researchPlan.years} years</dd>
              </div>
              <div>
                <dt>Planning envelope</dt>
                <dd>${researchPlan.budgetMillions}M</dd>
              </div>
            </dl>
            <p>
              No live pilot, enrolled clinic network, funding award, or measured
              clinical outcomes. Continuous ASL recognition and an
              ASL-interpreting avatar remain research goals.
            </p>
          </div>
        </section>
        <section className="human-section">
          <div className="human-heading">
            <span className="eyebrow">A NON-NEGOTIABLE PART OF CARE</span>
            <h2>
              Qualified interpretation
              <br />
              <em>remains essential.</em>
            </h2>
            <p>
              ASL is a language with its own grammar and cultural context. A
              scripted tool cannot provide the judgment, nuance, or
              understanding of a qualified interpreter.
            </p>
            <button className="btn btn-white" onClick={requestInterpreter}>
              Request Qualified Interpreter{" "}
              <Icon name="arrow-right" size={18} />
            </button>
          </div>
          <div className="human-statement">
            <span className="statement-mark" aria-hidden="true">
              “
            </span>
            <blockquote>
              AI should expand access,
              <br />
              not replace human choice.
            </blockquote>
            <p>
              InterpretAI does not replace your right to effective communication
              or appropriate qualified interpretation.
            </p>
            <Link href="/safety/">
              Safety & patient rights <Icon name="arrow-right" size={17} />
            </Link>
          </div>
        </section>
        <section className="landing-demo-entry">
          <div>
            <span className="eyebrow">FOR JUDGES · 3–5 MINUTES</span>
            <h2>Walk through one visit.</h2>
            <p>
              Meet a fictional patient. Test an outage. See where the tool
              stops.
            </p>
          </div>
          <Link href="/demo/" className="btn btn-outline">
            Start the Competition Demo <Icon name="arrow-right" size={18} />
          </Link>
        </section>
      </main>
      <footer className="landing-footer">
        <Brand />
        <span>Your language. Your care. Your choice.</span>
        <Link href="/safety/">
          Research prototype · No clinical validation{" "}
          <Icon name="arrow-right" size={15} />
        </Link>
      </footer>
      <button className="landing-interpreter" onClick={requestInterpreter}>
        <Icon name="users" size={18} />
        Request Qualified Interpreter
      </button>
    </div>
  );
}
