import { AppShell } from "@/components/app-shell";
import { HandshapeLab } from "@/components/handshape-lab";
import { PageHeading } from "@/components/ui";
export default function SampleLabPage() {
  return (
    <AppShell>
      <PageHeading
        eyebrow="A BOUNDED TECHNICAL EXPERIMENT"
        title="ASL sample lab"
        description="Try two experimental manual-alphabet handshape matches and an original, scripted avatar pose study. This is separate from healthcare interpretation."
      />
      <HandshapeLab />
    </AppShell>
  );
}
