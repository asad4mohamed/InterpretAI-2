# InterpretAI

**Your language. Your care. Your choice.**

InterpretAI is a Deaf-centered, offline-capable healthcare communication **research and competition prototype**. It explores communication support for Deaf American Sign Language (ASL) users when qualified in-person interpreters are unavailable or video remote interpreting (VRI) becomes unreliable, particularly in rural communities in the American South.

**Simulated — Not Clinically Validated.** This application does not translate arbitrary ASL, diagnose conditions, interpret clinical decisions, contact clinics, book interpreters, or replace qualified human interpretation. Clinical conversations use scripts. A separate optional sample lab uses a local hand-landmark model and experimental geometry rules for two handshapes. It is not an ASL translation model.

**New in 4.0 — continuous on-device sign recognition (250 isolated signs):** the new **Sign recognition** page (`/signs/`) and the workspace mode **ASL signs, continuous** track hands, upper body and lip shape with MediaPipe Holistic, cut the live stream into individual signs, and classify each with a trained temporal transformer (GestureSign, MIT; trained on Google's asl-signs data, CC BY 4.0; **72.1% top-1 on 3 signers never used in training**, measured by its authors). Each sign shows its top-3 calibrated probabilities and movement (direction, path, body region). Low-confidence signs become "Not sure" and must be resolved. Signs form a reviewable, undoable history, and a fixed table of 22 patterns suggests short English phrases, which the patient edits and confirms. Everything runs in the browser and works offline after a 47.7 MB download. It is **not** sentence translation, the model's authors state it is not meant for accessibility-critical communication, and only one required phrase ("Hi" from HELLO) could be verified with a real recording here. See [docs/CHANGELOG-4.0.md](docs/CHANGELOG-4.0.md), [docs/MODEL-CARD-SIGNS.md](docs/MODEL-CARD-SIGNS.md), [docs/PHRASES.md](docs/PHRASES.md), and the requirement audit [docs/AUDIT-4.0.md](docs/AUDIT-4.0.md).

**From 3.0:** an on-device ASL fingerspelling model (24 static letters, [model card](docs/MODEL-CARD-FINGERSPELLING.md)); a Hugging Face adapter; a review queue so that **only patient-confirmed output enters the conversation**; provider message editing; machine signing only on explicit request ([docs/CHANGELOG-3.0.md](docs/CHANGELOG-3.0.md)).

Modes in the experimental workspace: **ASL signs, continuous (working, on device)** · **ASL fingerspelling (working, on device)** · experimental L/Y handshape rules · supplied local isolated-sign model (no model bundled) · Sign-Speak (awaiting credentials) · Hugging Face (awaiting token and endpoint) · Off.

## Install and run

Use Node.js 22 or later and npm, on macOS, Windows or Linux. No API keys, database, or account are required.

```bash
npm install
npm run dev
```

The first `dev` or `build` downloads the official MediaPipe hand model (7.8 MB) and Holistic model (13.7 MB) once and verifies their SHA-256. Windows (PowerShell) uses the same commands; see [START-HERE.md](START-HERE.md). If you are offline at that point, the build still succeeds and only the optional on-device hand tracking is unavailable. Run `npm run prepare:lab` later, or copy the prebuilt ZIP’s `out/lab-assets/` folder to `public/lab-assets/`.

Open **http://127.0.0.1:3000**. Development mode deliberately does not register the service worker. If you previously ran the production prototype on the same origin, unregister its service worker or clear that origin’s site data before development so cached production files do not hide your changes.

For the complete competition experience, including offline caching (the prebuilt production workflow):

```bash
npm run build
npm run start
```

On macOS you can also double-click `Start-InterpretAI.command` (Windows: `Start-InterpretAI.cmd`) to serve an existing `out/` build without installing dependencies.

Optional integrations (see [docs/API-INTEGRATION.md](docs/API-INTEGRATION.md)):

```bash
cp .env.example .env.local   # fill in only what you have
npm run proxy                # secure proxy on http://127.0.0.1:8787 (keeps SIGN_SPEAK_API_KEY and HF_TOKEN server-side)
```

The production server serves the static Next.js export on **http://127.0.0.1:3000**. Set `PORT` to use a different port. Service workers need a secure context: HTTPS or localhost/127.0.0.1. Any production static host must serve directory index files and the generated `out/sw.js` with revalidation rather than immutable caching. All assets, including the font, are local.

## Implemented experience

- Landing page with the access problem, prototype limits, and ethical commitment.
- Fictional patient dashboard: appointments, preventive reminders, communication preferences, resources, interpreter access, and actual network status.
- Two-panel communication workspace with five selectable scenarios, Back/Next/Restart, English captions, confirmation and correction, and optional local camera preview.
- **Experimental live recognition** (second tab on `/communication/`; deep link `/communication/#live`): mode selector with live provider status; camera consent; two-hand on-device tracking with *no hands*, *tracking lost* and model-loading states; 3-second landmark capture (Modes 1–2); reviewed clip recording with per-clip third-party consent (Mode 3); results labelled with source, processing location and provider-reported or model confidence; patient Confirm, Correct and Reject; Clear conversation; care-team plain-language text; optional browser text-to-speech; optional machine-signing panel; high-risk escalation that pauses automation; persistent qualified-interpreter requests.
- A persistent **Request Qualified Interpreter** action, accessible native modal, in-person/video preference, and a repeatable fictional request workflow.
- Preventive care examples for wellness, blood pressure screening, vaccination, routine screening, and follow-up. Includes checklists, support preferences, and accessible preparation completion states.
- Resource library with working plain-language companion panels and clearly labeled ASL video placeholders.
- Editable fictional communication preferences, kept only in page memory.
- Safety & Patient Rights center with experimental limitations, privacy details, patient autonomy, and interpreter escalation.
- Research dashboard aligned to Team 22’s executive summary: **10–12 proposed rural Texas FQHCs**, a **five-year, $5M planning envelope**, eight proposed evaluation measures, an accessible annual/cumulative budget chart, approval gates, Deaf-led governance, and an untested sustainability model. No sites, funding awards, or measured outcomes are claimed.
- Interactive research-only ASL → English / English → ASL architecture paths and regional ASL / Black ASL / age-group evaluation lenses. These explain proposed research, without simulating recognition, speech, or an avatar.
- Scenario B includes a confirmable/correctable **scripted teach-back of visit logistics**. A confirmation click is not a comprehension score.
- A separate **ASL sample lab** at `/sample-lab/`: optional local MediaPipe hand tracking with original L/Y geometry rules, unknown-state rejection, patient confirmation/correction, and an original scripted 3D avatar pose illustration with replay, slow playback, and viewing-angle controls. Neither the rules nor poses have undergone Deaf-led linguistic or clinical validation.
- An eight-step Competition Demo, designed for a 3–5-minute walkthrough and repeatable without resetting the app.
- Responsive sidebar/mobile navigation, keyboard focus indicators, skip links, semantic forms, modal focus management, reduced-motion support, and live status messages.

## Demonstrate the application in 3–5 minutes

1. Open `/demo/`. Introduce communication barriers and the prototype’s limits.
2. Open **My overview** to meet fictional patient Jordan Morgan. Show the appointment and language preference.
3. Open **Communication**, Scenario A. Select **Next**, then confirm the patient card before proceeding.
4. Choose Scenario C and **Simulate outage**. The scenario remains functional. The interface explicitly identifies the simulation, and actual browser status remains separate.
5. Choose Scenario B and advance through the preparation cards, confirming the scripted patient messages. At **Teach-back practice**, choose **Correct**, repeat the example, then confirm only if it matches the message. No comprehension score is generated; clinical understanding needs appropriate qualified human review.
6. Choose Scenario D, then **Next**. The medication question automatically stops. Open **Request Qualified Interpreter**, choose a modality, and try the simulated request. No real request is sent. Scenario E separately stops at a patient’s explicit interpreter request.
7. Open **Research & impact**. Show the proposed Texas FQHC scope, filter the eight evaluation measures, switch the future technology pathway, and explore subgroup evaluation lenses. Toggle annual/cumulative budget and expand the table. Baselines and targets are not yet set; no clinical outcomes are presented.
8. Finish with: **“AI should expand access, not replace human choice.”** Use **Run demo again** to reset the guide and simulated connection state.

## Real offline workflow

1. Run `npm run build` and `npm run start`.
2. Open `/dashboard/` while online and wait for **Offline toolkit ready** in the footer. Installation precaches core application assets; merely opening a page is not proof that caching completed. Optional lab model/runtime assets are excluded from automatic downloads.
3. In browser developer tools, choose **Network → Offline** (keep service workers enabled), or disconnect the device network. The **Simulate outage** button is a separate UI demonstration and does not disconnect the browser.
4. Reload `/communication/`, select any scenario, advance, confirm/correct, or open the simulated interpreter dialog. Visit preventive care, resources, research, and the demo guide, including pages not previously visited individually.
5. Restore connectivity. Browser `online`/`offline` events update the network indicator. This is the browser’s connectivity signal, not a guaranteed test that a clinic or remote interpreter is reachable.

The service-worker generator enumerates and versions the core static export, including route HTML, React navigation payloads, scripts, styles, fonts, and icons. All-or-nothing initial precaching avoids claiming a complete toolkit when essential assets were not downloaded. A new worker removes only old application caches after successful installation and preserves the versioned optional recognition cache. `/lab-assets/` files are cached only by the lab's explicit download action, with a fixed allowlist and SHA-256 integrity checks. Camera frames and landmarks are never cached.

**Actually available offline after successful caching:** all static pages, all five predefined scenarios, English companion cards, confirmation/correction, page-local notes, safety keyword checks, fictional interpreter request selection, visit preparation checklists, research charts, and the competition walkthrough. Camera preview may be available in a supported secure browser, but is not needed for any scenario.

**Experimental live recognition offline:** on-device modes work after their files are downloaded (lab tools, or a local model saved with **Save this model for offline use**). Cloud recognition and signing avatars show *Offline* or *Demo outage* and cannot start. Nothing is queued for later.

**Unavailable or not implemented:** validated ASL interpretation, real VRI, real interpreter requests, clinical services, and ASL video playback. ASL video blocks are explicitly labeled placeholders. Browser storage eviction or clearing site data removes the offline toolkit. A first-ever offline visit cannot download the application.

## Safety and patient autonomy

Every scripted communication example displays **Simulation / Prevalidated Example**, as required for the competition. “Prevalidated” is a demonstration label, **not evidence that these authored English scripts or any ASL content have undergone human, linguistic, or clinical validation**. There is no ASL interpretation pipeline and no actual prevalidated ASL video corpus.

The scenario engine requires confirmation at specified patient turns. Correction revokes confirmation. Explicit medication and interpreter-request scenarios stop and cannot advance or go back until the user restarts or selects another scenario. Provider notes use straightforward English keyword safeguards for medication dosing, allergies, diagnoses, consent, treatment, and emergency symptoms. These safeguards can miss wording/context/languages and can produce false positives. They do not detect every high-risk topic, evaluate emergencies, understand ASL, or provide clinical safety assurance.

Qualified interpreters remain essential for linguistic/cultural nuance, consent, treatment discussions, and other high-risk communication. Patients can decline or pause the prototype and seek qualified interpretation through their clinic’s actual process. **InterpretAI does not replace your right to effective communication or appropriate qualified interpretation.**

No individualized screening schedules, diagnoses, dosing instructions, clinical recommendations, or verified medical outcomes are provided.

## Privacy and data

- Fictional patients only. Do not enter real protected health information.
- No login, database, third-party analytics, or trackers. With no optional integration configured, no external requests are made.
- Optional cloud features send data only on explicit action: a reviewed clip after per-clip consent (Sign-Speak, via the proxy), or safe typed text to a connected signing-avatar provider. API keys stay in the proxy process. See [docs/PRIVACY-AND-SAFETY.md](docs/PRIVACY-AND-SAFETY.md).
- Typed notes, choices, checklists, requests, and preferences live only in React memory. They are not persisted or uploaded. Reloading clears them; route changes clear page-specific state.
- Camera permission is requested only after an explicit action (and, in the live workspace, a consent checkbox). Microphone capture is never requested. The only recording is a short clip the patient chooses to record in Mode 3. It stays in page memory, is shown for review, and is cleared on send or discard. Tracks stop on Stop, unmount, tab hide, or withdrawn consent. Cancelled or late permission results are stopped.
- **Sign recognition (4.0):** camera frames, landmarks and recognised signs stay in the browser. Face landmarks are computed by MediaPipe Holistic only because the model uses 40 lip points; they stay inside the Web Worker, are never shown, posted to the page, stored or used to identify anyone. The 47.7 MB model download happens only when you press the button, and is integrity-checked.
- Public app files and fictional resources are cached in browser Cache Storage. Clear site data in browser settings to remove them.
- The static host receives standard asset requests and may keep infrastructure access logs. No clinical privacy certification is claimed.

## Checks and tests

```bash
npm run lint
npm run typecheck
npm test
npm run build
npm run test:setup
npm run test:e2e
```

Latest results (4.0): [docs/TEST-RESULTS.md](docs/TEST-RESULTS.md). Model evaluation: `npm run eval:signs -- --data-dir <Kaggle asl-signs folder>` ([ml/signs/README.md](ml/signs/README.md)). All external APIs are mocked in tests. To reuse an installed Chromium instead of downloading one, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE=/path/to/chrome`.

Earlier unit tests cover confirmation/correction gates, bounded navigation, scenario completion, high-risk stops, patient choice, reset behavior, each keyword category, and known detection limits. Playwright covers the patient flow, modal focus/keyboard behavior, scenario controls, preventive preparation, resource panels, preferences, repeatable demo, mobile layout, true offline navigation/reload, and automated WCAG A/AA checks with axe. E2E tests use the production static build and start a local server automatically. Automated accessibility results do not establish complete WCAG conformance; Deaf-led evaluation and manual assistive-technology testing remain necessary.

## Architecture

Next.js App Router, React, strict TypeScript, Tailwind CSS, locally bundled DM Sans, and Lucide icons. `app/` owns routes, `components/` contains reusable UI and interactive flows, `lib/scenarios.ts` is the pure scenario/safety engine, and `lib/data.ts` contains fictional care and illustrative research data. `lib/asl/` is the provider-independent recognition layer. `components/use-hand-tracker.ts` is the camera and worker lifecycle for hand tracking; `components/use-sign-tracker.ts` + `workers/sign-tracker.worker.ts` + `lib/asl/signs/` are the 4.0 sign pipeline (Holistic → segmenter → features → ONNX → decision → sequence → phrases). `scripts/build-sw.mjs` creates a content-versioned service worker after static export. `scripts/serve.mjs` serves `out/` with privacy/security headers and `/runtime-config.json`. `server/proxy.mjs` is the **optional** secure backend for Sign-Speak; the static export cannot host server routes. Details: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Documentation

| Document | Contents |
|---|---|
| [START-HERE.md](START-HERE.md) | Quick start for the prebuilt demo and for editing |
| [docs/AUDIT-4.0.md](docs/AUDIT-4.0.md) | **4.0 requirement-by-requirement audit, measured results, blockers and release verdict** |
| [docs/CHANGELOG-4.0.md](docs/CHANGELOG-4.0.md) | What 4.0 adds and changes |
| [docs/MODEL-CARD-SIGNS.md](docs/MODEL-CARD-SIGNS.md) | The 250-sign model: origin, data, evaluation, rejection rules, intended use |
| [docs/DATASET-SIGNS.md](docs/DATASET-SIGNS.md) | Dataset selection, provenance, licence, download, leakage checks |
| [docs/VOCABULARY-SIGNS.md](docs/VOCABULARY-SIGNS.md) | All 250 classes: ID, gloss, English, accuracy, ambiguity (generated) |
| [docs/PHRASES.md](docs/PHRASES.md) | Supported phrase patterns and the status of each required phrase |
| [docs/WEBCAM-MANUAL-TEST.md](docs/WEBCAM-MANUAL-TEST.md) | Real-webcam test procedure |
| [ml/signs/README.md](ml/signs/README.md) | Evaluation and retraining instructions |
| [docs/IMPLEMENTATION-STATUS.md](docs/IMPLEMENTATION-STATUS.md) | 3.0 completion report and the 12-phase checklist |
| [docs/MODEL-CARD-FINGERSPELLING.md](docs/MODEL-CARD-FINGERSPELLING.md) | The bundled model: data, evaluation, limits, reproduction |
| [docs/MODEL-SELECTION.md](docs/MODEL-SELECTION.md) | ASL models evaluated, the choice made, and Hugging Face deployment |
| [docs/CHANGELOG-3.0.md](docs/CHANGELOG-3.0.md) | New features and every bug fixed |
| [docs/API-INTEGRATION.md](docs/API-INTEGRATION.md) | Sign-Speak proxy and Hand Talk setup, with sources for every endpoint |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Modules, modes, guarantees, camera pipeline, offline |
| [docs/LOCAL-RECOGNITION.md](docs/LOCAL-RECOGNITION.md) | Landmark format, normalisation, model manifest, OOV rejection, evaluation guidance |
| [docs/NONMANUAL-FEATURES.md](docs/NONMANUAL-FEATURES.md) | Face/pose landmark evaluation |
| [docs/PRIVACY-AND-SAFETY.md](docs/PRIVACY-AND-SAFETY.md) | Data inventory, consent model, escalation rules |
| [docs/KNOWN-LIMITATIONS.md](docs/KNOWN-LIMITATIONS.md) | What does not work, or is unverified |
| [docs/COMPETITION-DEMO.md](docs/COMPETITION-DEMO.md) | Presenter checklist, including the live-recognition add-on |
| [docs/TEST-RESULTS.md](docs/TEST-RESULTS.md) | Test commands and results |

## Responsible next steps

1. Establish paid Deaf-led governance with ASL users in rural Southern communities, interpreters, clinicians, and accessibility researchers.
2. Conduct accessible co-design and usability sessions before proposing clinical use.
3. Commission and independently review ASL resources with qualified Deaf and interpreter experts; establish provenance and review/version policies.
4. Evaluate comprehension, signing variation, intersectional access, screen-reader/keyboard usability, offline reliability, storage eviction, and device limitations.
5. Define a formal clinical risk model and escalation protocol with healthcare partners, with independent ethics and safety review before any pilot.
6. Research any future ASL model separately using appropriately consented data and rigorous linguistic/safety evaluation. Do not infer readiness from this scripted demo.
7. Consider real scheduling, secure clinical integration, consent, data governance, and accessibility arrangements only under appropriate approvals.

## Executive-summary alignment

The prototype reflects Team 22’s October 2026 executive summary while preserving the original research-prototype boundary. The proposed scope is five years, a $5M envelope, and 10–12 prospective rural Texas FQHCs. The annual allocation is a new planning illustration, not an allocation supplied in the summary or actual spending. Year 1 focuses on co-design, validation, and baselines; Years 2–3 on a conditional preventive-care pilot; Years 4–5 on telehealth feasibility and sustainability/scale-up assessment. Every clinical phase requires appropriate approvals and evidence.

Validated continuous ASL recognition, speech recognition, and a validated ASL-interpreting avatar remain research goals. Version 2.1 adds integration-ready adapters for third-party recognition and machine signing, plus optional browser text-to-speech. None is clinically validated. The sample lab implements only hand landmarks, two original geometry rules, and two unreviewed mannequin poses. Offline functionality does not include an ASL translation model. HIPAA compliance is not assessed or claimed. A proposed device subscription must preserve appropriate qualified interpretation and patient choice; pricing, savings, partnerships, and reimbursement are untested.

See [the alignment review](docs/executive-summary-alignment.md) for the changes and research questions raised by the summary.

This prototype demonstrates an ethical product direction, not clinical deployment readiness.

## Optional handshape and avatar sample lab

1. Open `/sample-lab/`. Choose **Handshape L** or **Handshape Y** and try **Play pose transition**, slow playback, and the angled view. This original scripted mannequin is an unreviewed pose illustration, not a signing interpreter. Reduced-motion settings show the final pose immediately.
2. Select **Download recognition tools** for the separate **21.8 MB** optional download. The app verifies SHA-256 hashes and stores the four public files in a dedicated browser cache. No third-party server is contacted at runtime.
3. Select **Enable camera & handshape matching**. After the local worker initializes, the browser requests explicit camera permission. Only video is requested. Up to two hands are tracked and drawn (teal = right, amber = left), but the L/Y rules read one hand only. Show one L-like or Y-like handshape and hold it still; unsupported or absent hands remain **Unknown**. These geometry rules are not a trained ASL classifier, do not assess palm orientation, and may produce false matches or misses.
4. Review a stable candidate, confirm it to select its scripted avatar pose, or reject it. Manually selecting an avatar pose never creates a camera recognition result. No accuracy or translation-confidence score is displayed.
5. For offline recognition, use the production build, wait for both **Offline toolkit ready** and **Recognition tools downloaded**, disable the browser network, and reload the lab. The worker and local assets can initialize again in a supported secure browser. The avatar only requires the core application download. Camera hardware, browser support, and permission are still required.
6. **Stop camera & tracking**, leaving the lab, hiding the browser tab, or canceling startup terminates tracking and releases camera tracks. Frames and landmarks are transient; there is no recording, upload, microphone, or persistent camera-derived history. **Remove downloaded tools** removes only the optional public model/runtime cache.

The model is MediaPipe Tasks Vision 1.1.1 with Google's float16 Hand Landmarker bundle, model version 1. It runs with the CPU delegate in a dedicated worker and uses a local ES-module WebAssembly runtime. The 3D illustration uses Three.js 0.186.1 and original procedural geometry, with no external avatar model or texture. Model sources, hashes, licenses, limitations, and evaluation boundaries are documented in [sample-lab provenance](docs/sample-lab-provenance.md). Chrome/Edge are the primary technical test targets; no ASL or clinical accuracy is established.

The **source ZIP** omits the generated `public/lab-assets/` files to stay small. `npm run dev` and `npm run build` run `npm run prepare:lab`, which copies the pinned npm runtime, downloads the official model once if it is absent (internet required), and verifies its SHA-256. The **prebuilt ZIP** already contains these files. `npm run build` runs this preparation. Core service-worker precaching excludes `/lab-assets/` so low-connectivity users are not forced to download the model. Static hosts must serve `.wasm` as `application/wasm` and allow same-origin WebAssembly execution. The included server supplies a scoped `wasm-unsafe-eval` script policy without allowing arbitrary JavaScript evaluation.
