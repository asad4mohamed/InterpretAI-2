export const careItems = [
  {
    id: "wellness",
    title: "Annual wellness visit",
    category: "Wellness",
    detail:
      "A visit to discuss your health, questions, and care goals with your clinic.",
    date: "Discuss with your clinic",
    icon: "heart",
    color: "teal",
    checklist: [
      "Write down the questions you want to ask",
      "Bring your appointment information",
      "Share your communication preferences",
    ],
  },
  {
    id: "blood-pressure",
    title: "Blood pressure screening",
    category: "Screening",
    detail:
      "Ask your clinic what a blood pressure check involves and whether it fits your care plan.",
    date: "Example reminder",
    icon: "activity",
    color: "purple",
    checklist: [
      "Confirm the appointment location",
      "Ask for an accessible explanation",
      "Arrange your preferred communication support",
    ],
  },
  {
    id: "vaccination",
    title: "Vaccination appointment",
    category: "Vaccination",
    detail:
      "An opportunity to ask a clinician questions about vaccinations with qualified interpretation.",
    date: "Example reminder",
    icon: "shield",
    color: "blue",
    checklist: [
      "Bring records you choose to share with the clinic",
      "Prepare your questions for the clinician",
      "Request a qualified interpreter for clinical discussion",
    ],
  },
  {
    id: "screening",
    title: "Routine preventive screening",
    category: "Screening",
    detail:
      "Ask your clinician about preventive care and get accessible information before making decisions.",
    date: "Discuss with your clinic",
    icon: "clipboard",
    color: "orange",
    checklist: [
      "Confirm instructions directly with the clinic",
      "Ask for accessible preparation materials",
      "Request an interpreter for decisions and consent",
    ],
  },
  {
    id: "follow-up",
    title: "Follow-up scheduling",
    category: "Follow-up",
    detail:
      "Connect with your clinic to confirm the next visit in your existing care plan.",
    date: "Your clinic sets the schedule",
    icon: "calendar",
    color: "teal",
    checklist: [
      "Confirm a date with your clinic",
      "Ask how to reach the clinic accessibly",
      "Confirm interpreter arrangements",
    ],
  },
] as const;
