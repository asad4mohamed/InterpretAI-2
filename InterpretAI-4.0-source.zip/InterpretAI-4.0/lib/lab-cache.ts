import assets from "./lab-assets.json";
export { assets as labAssets };
export async function recognitionToolsCached() {
  if (!("caches" in globalThis)) return false;
  const cache = await caches.open(assets.cacheName);
  const matches = await Promise.all(
    assets.files.map((file) => cache.match(file.url)),
  );
  return matches.every(Boolean);
}
export async function downloadRecognitionTools(
  signal: AbortSignal,
  progress: (completed: number) => void,
) {
  if (!("caches" in globalThis) || !globalThis.crypto?.subtle)
    throw new Error(
      "This browser cannot securely cache the optional recognition tools. Use a supported browser on HTTPS or localhost.",
    );
  const cache = await caches.open(assets.cacheName);
  for (let index = 0; index < assets.files.length; index++) {
    const file = assets.files[index];
    signal.throwIfAborted();
    let response: Response;
    try {
      response = await fetch(file.url, { signal, cache: "no-cache" });
    } catch (failure) {
      if (signal.aborted) throw failure;
      throw new Error(
        "Recognition files could not be downloaded. Reconnect and retry; the scripted avatar still works.",
      );
    }
    if (!response.ok)
      throw new Error(
        "The optional recognition files could not be downloaded. Reconnect and retry; the scripted avatar still works.",
      );
    const buffer = await response.arrayBuffer();
    const digest = Array.from(
      new Uint8Array(await crypto.subtle.digest("SHA-256", buffer)),
      (byte) => byte.toString(16).padStart(2, "0"),
    ).join("");
    signal.throwIfAborted();
    if (buffer.byteLength !== file.bytes || digest !== file.sha256)
      throw new Error(
        "A recognition file failed its integrity check. Download the tools again.",
      );
    await cache.put(
      file.url,
      new Response(buffer, {
        headers: {
          "Content-Type": file.url.endsWith(".wasm")
            ? "application/wasm"
            : file.url.endsWith(".js") || file.url.endsWith(".mjs")
              ? "text/javascript"
              : "application/octet-stream",
        },
      }),
    );
    progress(index + 1);
  }
  signal.throwIfAborted();
  if (!(await recognitionToolsCached()))
    throw new Error(
      "The download could not be retained by this browser. Check available storage and retry.",
    );
}
