export type RiskTopic =
  | "Medication dosing"
  | "Allergies"
  | "Diagnoses"
  | "Medical consent"
  | "Treatment decisions"
  | "Emergency symptoms"
  | "Patient choice";
export type ScenarioStep = {
  speaker: "patient" | "provider" | "system";
  text: string;
  hint?: string;
  risk?: RiskTopic;
  confirm?: boolean;
  purpose?: "teach-back";
};
export type Scenario = {
  id: string;
  letter: string;
  title: string;
  description: string;
  duration: string;
  steps: ScenarioStep[];
};
export const scenarios: Scenario[] = [
  {
    id: "check-in",
    letter: "A",
    title: "Routine appointment check-in",
    description:
      "Introduce your communication preferences and check in for a visit.",
    duration: "2 min",
    steps: [
      {
        speaker: "provider",
        text: "Welcome to Pine Grove Community Clinic. Are you here for your appointment?",
      },
      {
        speaker: "patient",
        text: "Yes. I am Deaf and use American Sign Language. Please face me when communicating.",
        confirm: true,
        hint: "A scripted communication card, not a translation of camera input.",
      },
      {
        speaker: "provider",
        text: "Thank you for sharing. Would you like a qualified interpreter for your visit?",
      },
      {
        speaker: "patient",
        text: "Yes, please request a qualified ASL interpreter. I can use these cards while I wait.",
        confirm: true,
      },
      {
        speaker: "system",
        text: "Check-in example complete. A clinic staff member would follow the clinic’s actual interpreter request process.",
      },
    ],
  },
  {
    id: "screening",
    letter: "B",
    title: "Preventive screening preparation",
    description:
      "Prepare for a preventive visit and practice confirming your understanding.",
    duration: "2 min",
    steps: [
      {
        speaker: "provider",
        text: "Let’s prepare for your upcoming preventive care appointment.",
      },
      {
        speaker: "patient",
        text: "Please give me an accessible checklist and arrange a qualified interpreter.",
        confirm: true,
      },
      {
        speaker: "provider",
        text: "We can discuss the appointment checklist together with an interpreter. What would help you prepare?",
      },
      {
        speaker: "patient",
        text: "Please write down the location, arrival time, and how to contact the clinic.",
        confirm: true,
      },
      {
        speaker: "provider",
        text: "Before we finish, please explain how you will confirm your appointment details and communication support. We can review them together with a qualified interpreter.",
      },
      {
        speaker: "patient",
        text: "I will ask the clinic to confirm where to go, when to arrive, and who will provide qualified interpretation. I will ask again if anything is unclear.",
        confirm: true,
        purpose: "teach-back",
        hint: "A scripted practice of explaining visit logistics back. Confirmation does not measure clinical comprehension.",
      },
      {
        speaker: "system",
        text: "Preparation and teach-back example complete. No comprehension score was calculated. Ask the clinic and a qualified interpreter about any clinical instructions.",
      },
    ],
  },
  {
    id: "outage",
    letter: "C",
    title: "VRI connection interruption",
    description:
      "Explore available communication cards when a video connection fails.",
    duration: "2 min",
    steps: [
      {
        speaker: "provider",
        text: "The video remote interpreting connection has been interrupted.",
      },
      {
        speaker: "system",
        text: "Predefined cards remain available offline after download. Remote interpreters require connectivity; these cards do not replace interpretation.",
      },
      {
        speaker: "patient",
        text: "The video is freezing. Please pause the visit and arrange another qualified interpreter.",
        confirm: true,
      },
      {
        speaker: "provider",
        text: "We will pause and use the clinic’s actual process to explore an in-person interpreter or restore the video connection.",
      },
      {
        speaker: "system",
        text: "Outage example complete. Use “Simulate outage” to demonstrate the interface; actual browser connectivity is shown separately.",
      },
    ],
  },
  {
    id: "medication",
    letter: "D",
    title: "A medication-related question",
    description:
      "See how the prototype pauses a high-risk clinical conversation.",
    duration: "1 min",
    steps: [
      {
        speaker: "provider",
        text: "Do you have any questions you would like to discuss during your visit?",
      },
      {
        speaker: "patient",
        text: "I have a question about medication dosing.",
        risk: "Medication dosing",
      },
    ],
  },
  {
    id: "interpreter",
    letter: "E",
    title: "Request a qualified interpreter",
    description: "Exercise your choice to use qualified human interpretation.",
    duration: "1 min",
    steps: [
      {
        speaker: "provider",
        text: "How would you prefer to communicate today?",
      },
      {
        speaker: "patient",
        text: "I want a qualified ASL interpreter before we continue.",
        risk: "Patient choice",
      },
    ],
  },
];
export type ScenarioState = {
  scenarioId: string;
  index: number;
  confirmed: number[];
  stopped: boolean;
  risk?: RiskTopic;
};
export type ScenarioAction =
  | { type: "select"; id: string }
  | { type: "next" }
  | { type: "back" }
  | { type: "restart" }
  | { type: "confirm" }
  | { type: "correct" }
  | { type: "stop"; risk: RiskTopic };
export const initialState: ScenarioState = {
  scenarioId: "check-in",
  index: 0,
  confirmed: [],
  stopped: false,
};
export function scenarioFor(id: string) {
  return scenarios.find((s) => s.id === id) ?? scenarios[0];
}
export function scenarioReducer(
  state: ScenarioState,
  action: ScenarioAction,
): ScenarioState {
  const scenario = scenarioFor(state.scenarioId);
  if (action.type === "select")
    return { ...initialState, scenarioId: scenarioFor(action.id).id };
  if (action.type === "restart")
    return { ...initialState, scenarioId: state.scenarioId };
  if (action.type === "stop")
    return { ...state, stopped: true, risk: action.risk };
  if (state.stopped) return state;
  if (action.type === "confirm")
    return {
      ...state,
      confirmed: Array.from(new Set([...state.confirmed, state.index])),
    };
  if (action.type === "correct")
    return {
      ...state,
      confirmed: state.confirmed.filter((i) => i !== state.index),
    };
  if (action.type === "back")
    return { ...state, index: Math.max(0, state.index - 1) };
  if (
    scenario.steps[state.index].confirm &&
    !state.confirmed.includes(state.index)
  )
    return state;
  const index = Math.min(state.index + 1, scenario.steps.length - 1);
  const risk = scenario.steps[index].risk;
  return { ...state, index, stopped: !!risk, risk };
}
const safeguards: [RiskTopic, RegExp][] = [
  [
    "Medication dosing",
    /\b(medication|medicine|dose|dosing|dosage|pill|tablet|insulin|mg|milligram)\b/i,
  ],
  ["Allergies", /\b(allerg\w*|anaphyl\w*)\b/i],
  ["Diagnoses", /\b(diagnos\w*|cancer|diabetes)\b/i],
  ["Medical consent", /\b(consent|permission for|sign the form)\b/i],
  [
    "Treatment decisions",
    /\b(treatment|surgery|operation|procedure|therapy)\b/i,
  ],
  [
    "Emergency symptoms",
    /\b(emergency|chest pain|cannot breathe|can’t breathe|can't breathe|trouble breathing|stroke|bleeding|unconscious)\b/i,
  ],
];
export function detectRisk(text: string): RiskTopic | undefined {
  return safeguards.find(([, pattern]) => pattern.test(text))?.[0];
}
