export const researchPlan = {
  sites: "10–12",
  location: "Rural Texas FQHCs",
  years: 5,
  budgetMillions: 5,
  team: "Team 22",
} as const;

// These allocations are an illustration. The executive summary specifies
// a five-year $5M envelope, not annual awards or actual expenditure.
export const researchBudget = [
  { year: 1, amount: 0.75, label: "Co-design, validation & baselines" },
  { year: 2, amount: 1.2, label: "Conditional preventive-care pilot" },
  { year: 3, amount: 1.3, label: "Pilot evaluation & refinement" },
  { year: 4, amount: 1.05, label: "Telehealth feasibility research" },
  { year: 5, amount: 0.7, label: "Sustainability & scale-up assessment" },
] as const;

export const researchTimeline = [
  {
    title: "Listen. Validate. Establish baselines.",
    detail:
      "Deaf-led co-design, simulated safety evaluation, and a baseline protocol with prospective clinic partners.",
    gate: "Gate: community governance and ethics review",
  },
  {
    title: "Begin a limited preventive-care pilot.",
    detail:
      "Explore routine visit support only after ethics, safety, accessibility, and clinic-readiness approvals.",
    gate: "Gate: approval before any patient pilot",
  },
  {
    title: "Evaluate before broadening use.",
    detail:
      "Assess screening and vaccination completion, teach-back comprehension, escalation, and subgroup performance.",
    gate: "Gate: independent review of harms and disparities",
  },
  {
    title: "Study accessible telehealth.",
    detail:
      "Research connected visit support and interpreter handoffs. Remote interpreting still requires connectivity.",
    gate: "Gate: additional safety and access review",
  },
  {
    title: "Assess a sustainable regional model.",
    detail:
      "Evaluate cost, community priorities, and FQHC-network partnerships before considering regional scale-up.",
    gate: "Gate: evidence and Deaf-led approval to expand",
  },
] as const;

export const researchMeasures = [
  {
    name: "Time to communication access",
    question: "How long until the patient has effective communication support?",
    method:
      "Define the start and end of the access interval with patients and clinics; report time and unmet access needs.",
    unit: "Minutes · baseline pending",
    group: "Access & care",
  },
  {
    name: "Screening & vaccination completion",
    question: "Does access to agreed preventive care improve?",
    method:
      "Compare eligible, clinician-agreed care completion with baseline and a context-matched hearing-patient cohort, subject to an approved study design.",
    unit: "Completion rate · baseline pending",
    group: "Access & care",
  },
  {
    name: "Appointment completion",
    question: "Can patients complete the visits they choose to attend?",
    method:
      "Track completed visits and communication-related interruptions using predefined, consented measures.",
    unit: "Visit completion rate · baseline pending",
    group: "Access & care",
  },
  {
    name: "Teach-back comprehension",
    question:
      "Can the patient explain their understanding in their own language?",
    method:
      "Co-design an accessible teach-back rubric and use qualified human review. A message-confirmation click is not a comprehension score.",
    unit: "Human-reviewed rubric · not yet defined",
    group: "Patient experience",
  },
  {
    name: "Patient-reported satisfaction",
    question: "Do patients feel understood and in control?",
    method:
      "Develop an accessible, voluntary survey with Deaf participants; report experience alongside concerns and refusals.",
    unit: "Accessible survey · not yet collected",
    group: "Patient experience",
  },
  {
    name: "Qualified interpreter escalation",
    question: "When is human help requested, and is it actually available?",
    method:
      "Report requests, reasons, completion, and time to qualified support. A lower escalation rate is not a success goal.",
    unit: "Escalation & fulfillment rates · baseline pending",
    group: "Safety & reliability",
  },
  {
    name: "Critical communication errors",
    question: "What errors, near misses, and harms must stop the study?",
    method:
      "Predefine severity, independent review, and stopping criteria before a pilot. No error-free clinical performance is claimed.",
    unit: "Reviewed events · no clinical data",
    group: "Safety & reliability",
  },
  {
    name: "Offline feature reliability",
    question: "Do downloaded communication tools remain available?",
    method:
      "Test cached scenarios across devices, network loss, reloads, and storage eviction. This does not measure offline AI interpretation.",
    unit: "Task completion rate · research baseline pending",
    group: "Safety & reliability",
  },
] as const;

export const technologyPaths = {
  patient: {
    title: "Patient ASL → clinician English",
    description:
      "A proposed on-device language pipeline. The separate sample lab connects hand landmarks to two geometry rules; no ASL language interpretation is implemented.",
    stages: [
      {
        title: "Consented local video",
        detail:
          "A future research study would require explicit consent, data governance, and an accessible way to decline.",
      },
      {
        title: "Visual language features",
        detail:
          "Research hand, body, and facial features while respecting the linguistic information that keypoints may miss.",
      },
      {
        title: "ASL-to-English model",
        detail:
          "Develop and independently evaluate continuous-signing models across language varieties and participant groups.",
      },
      {
        title: "Patient review & English output",
        detail:
          "Study patient confirmation, accessible corrections, and optional speech output with qualified human escalation.",
      },
    ],
  },
  provider: {
    title: "Clinician English → patient ASL",
    description:
      "A proposed reverse pathway. The current app displays written English; it does not capture speech or translate English into ASL.",
    stages: [
      {
        title: "Clinician speech or text",
        detail:
          "Future speech capture would need its own consent and controls. This prototype never requests a microphone.",
      },
      {
        title: "English text review",
        detail:
          "Research accessible ways to review the original message and surface ambiguity before any interpretation.",
      },
      {
        title: "ASL rendering research",
        detail:
          "Evaluate human-reviewed signing resources and any proposed avatar with Deaf language experts. The sample lab contains two unreviewed poses; an ASL-interpreting avatar is not implemented.",
      },
      {
        title: "Patient teach-back & choice",
        detail:
          "Evaluate understanding with appropriate qualified interpretation; pause when the message is unclear or the patient requests a person.",
      },
    ],
  },
} as const;

export const evaluationLenses = [
  {
    id: "regional",
    label: "Regional ASL",
    title: "Evaluate regional language variation.",
    detail:
      "Recruit with rural Texas Deaf communities and document the varieties represented. Report gaps and error patterns before any geographic expansion.",
  },
  {
    id: "black-asl",
    label: "Black ASL",
    title: "Include Black ASL users in research leadership.",
    detail:
      "Co-design recruitment and evaluation with Black Deaf participants and language experts. Do not treat aggregate performance as evidence of equitable access.",
  },
  {
    id: "age",
    label: "Age groups",
    title: "Study usability and understanding across ages.",
    detail:
      "Set appropriate recruitment, consent, and accessibility protocols. Review device use, signing variation, comprehension, and sample-size limitations by age group.",
  },
] as const;

export const researchReading = [
  {
    title: "VRI in health care: Deaf patients’ experiences",
    citation: "Kushalnagar et al. · JMIR, 2019",
    href: "https://rehab.jmir.org/2019/1/e13233/",
  },
  {
    title: "Communication and preventive services among Deaf ASL users",
    citation: "McKee et al. · American Journal of Preventive Medicine, 2011",
    href: "https://pmc.ncbi.nlm.nih.gov/articles/PMC3117257/",
  },
  {
    title: "Biases in sign language understanding models",
    citation: "Atwell, Bragg & Alikhani · EMNLP, 2024",
    href: "https://aclanthology.org/2024.emnlp-main.17/",
  },
] as const;
