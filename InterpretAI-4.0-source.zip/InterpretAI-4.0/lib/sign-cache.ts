import assets from "./sign-assets.json";

/**
 * Optional sign-recognition download (Holistic landmarker, ONNX Runtime and
 * the sign model). Stored in its own Cache Storage bucket after a size and
 * SHA-256 check, so it works offline afterwards. Nothing downloads until the
 * user presses the download button.
 */
export { assets as signAssets };

export const signDownloadBytes = assets.files.reduce(
  (sum, file) => sum + file.bytes,
  0,
);

export async function signToolsCached() {
  if (!("caches" in globalThis)) return false;
  const cache = await caches.open(assets.cacheName);
  const matches = await Promise.all(
    assets.files.map((file) => cache.match(file.url)),
  );
  return matches.every(Boolean);
}

const contentType = (url: string) =>
  url.endsWith(".wasm")
    ? "application/wasm"
    : url.endsWith(".mjs") || url.endsWith(".js")
      ? "text/javascript"
      : url.endsWith(".json")
        ? "application/json"
        : "application/octet-stream";

export async function downloadSignTools(
  signal: AbortSignal,
  progress: (completed: number, total: number) => void,
) {
  if (!("caches" in globalThis) || !globalThis.crypto?.subtle)
    throw new Error(
      "This browser cannot securely cache the sign recognition files. Use a current browser on HTTPS or localhost.",
    );
  const cache = await caches.open(assets.cacheName);
  for (let index = 0; index < assets.files.length; index++) {
    const file = assets.files[index]!;
    signal.throwIfAborted();
    let response: Response;
    try {
      response = await fetch(file.url, { signal, cache: "no-cache" });
    } catch (failure) {
      if (signal.aborted) throw failure;
      throw new Error(
        "Sign recognition files could not be downloaded. Reconnect and retry.",
      );
    }
    if (!response.ok)
      throw new Error(
        file.url.endsWith(".task")
          ? 'The Holistic landmarker is missing on this server. Run "npm run prepare:signs" with internet access, then rebuild.'
          : `A sign recognition file is missing (${file.url}).`,
      );
    const buffer = await response.arrayBuffer();
    const digest = Array.from(
      new Uint8Array(await crypto.subtle.digest("SHA-256", buffer)),
      (byte) => byte.toString(16).padStart(2, "0"),
    ).join("");
    signal.throwIfAborted();
    if (buffer.byteLength !== file.bytes || digest !== file.sha256)
      throw new Error(
        `A sign recognition file failed its integrity check (${file.url.split("/").pop()}). Download again.`,
      );
    await cache.put(
      file.url,
      new Response(buffer, {
        headers: { "Content-Type": contentType(file.url) },
      }),
    );
    progress(index + 1, assets.files.length);
  }
  if (!(await signToolsCached()))
    throw new Error(
      "The download could not be retained by this browser. Check available storage and retry.",
    );
}

export async function removeSignTools() {
  if ("caches" in globalThis) await caches.delete(assets.cacheName);
}
