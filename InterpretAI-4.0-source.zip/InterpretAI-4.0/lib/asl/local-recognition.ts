import {
  FEATURES_PER_FRAME,
  handCoverage,
  sequenceToFeatures,
  smoothSequence,
} from "./landmark-sequence";
import {
  RecognitionError,
  type LandmarkSequence,
  type RecognitionHypothesis,
} from "./types";
import { validateSequence } from "./validation";

/**
 * Mode 2 — local trained isolated-sign model.
 *
 * InterpretAI ships NO trained ASL model. This module defines the manifest a
 * supplied model must provide (vocabulary, licence, training-data and
 * evaluation documentation), a small dependency-free runtime for the
 * documented `dense-mlp` architecture, and out-of-vocabulary rejection.
 * A model without documentation is refused rather than run.
 */

export type LocalModelManifest = {
  format: "interpretai.local-model.v1";
  id: string;
  version: string;
  granularity: "isolated-sign";
  description: string;
  vocabulary: string[];
  /** Labels the model was trained to emit for "none of the above". */
  rejectLabels: string[];
  license: { name: string; url?: string };
  trainingData: { description: string; consent: string; signers?: number };
  evaluation: {
    dataset: string;
    signerIndependent: boolean;
    metrics: Record<string, number>;
    reportUrl?: string;
    knownGaps: string;
  };
  input: {
    sequence: "interpretai.landmarks.v1";
    frames: number;
    featuresPerFrame: number;
    smoothingAlpha: number;
    minHandCoverage: number;
  };
  decision: { minScore: number; minMargin: number };
  architecture: "dense-mlp";
  weightsUrl: string;
};

export type DenseLayer = {
  weights: number[][]; // [outputs][inputs]
  bias: number[];
  activation: "relu" | "linear";
};
export type DenseWeights = { layers: DenseLayer[] };

const isRecord = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
const nonEmpty = (v: unknown) => typeof v === "string" && v.trim().length > 0;

export function validateManifest(raw: unknown): LocalModelManifest {
  const fail = (why: string): never => {
    throw new RecognitionError(
      "model-load-failed",
      `Local model refused: ${why}`,
    );
  };
  if (!isRecord(raw)) return fail("manifest is not an object.");
  if (raw.format !== "interpretai.local-model.v1")
    fail("unsupported manifest format.");
  if (!nonEmpty(raw.id) || !nonEmpty(raw.version))
    fail("id and version are required.");
  if (raw.granularity !== "isolated-sign")
    fail(
      "only isolated-sign models are supported; sentence translation is out of scope.",
    );
  if (
    !Array.isArray(raw.vocabulary) ||
    raw.vocabulary.length < 2 ||
    !raw.vocabulary.every(nonEmpty) ||
    new Set(raw.vocabulary).size !== raw.vocabulary.length
  )
    fail("a documented vocabulary of at least two unique labels is required.");
  if (
    !Array.isArray(raw.rejectLabels) ||
    !raw.rejectLabels.every((l) =>
      (raw.vocabulary as string[]).includes(l as string),
    )
  )
    fail("rejectLabels must be listed in the vocabulary.");
  const license = raw.license;
  if (!isRecord(license) || !nonEmpty(license.name))
    fail("a licence is required.");
  const training = raw.trainingData;
  if (
    !isRecord(training) ||
    !nonEmpty(training.description) ||
    !nonEmpty(training.consent)
  )
    fail("training-data description and consent basis are required.");
  const evaluation = raw.evaluation;
  if (
    !isRecord(evaluation) ||
    !nonEmpty(evaluation.dataset) ||
    typeof evaluation.signerIndependent !== "boolean" ||
    !isRecord(evaluation.metrics) ||
    !Object.values(evaluation.metrics).every(
      (m) => typeof m === "number" && Number.isFinite(m),
    ) ||
    !nonEmpty(evaluation.knownGaps)
  )
    fail(
      "evaluation dataset, signer-independence, numeric metrics and known gaps are required.",
    );
  const input = raw.input;
  if (
    !isRecord(input) ||
    input.sequence !== "interpretai.landmarks.v1" ||
    !Number.isInteger(input.frames) ||
    (input.frames as number) < 2 ||
    (input.frames as number) > 120 ||
    input.featuresPerFrame !== FEATURES_PER_FRAME ||
    typeof input.smoothingAlpha !== "number" ||
    typeof input.minHandCoverage !== "number"
  )
    fail(
      `input must use interpretai.landmarks.v1 with ${FEATURES_PER_FRAME} features per frame.`,
    );
  const decision = raw.decision;
  if (
    !isRecord(decision) ||
    typeof decision.minScore !== "number" ||
    typeof decision.minMargin !== "number" ||
    decision.minScore <= 0 ||
    decision.minScore >= 1
  )
    fail("decision thresholds (minScore in (0,1), minMargin) are required.");
  if (raw.architecture !== "dense-mlp") fail("unsupported architecture.");
  if (!nonEmpty(raw.weightsUrl)) fail("weightsUrl is required.");
  return raw as unknown as LocalModelManifest;
}

export function validateWeights(
  raw: unknown,
  manifest: LocalModelManifest,
): DenseWeights {
  const fail = (why: string): never => {
    throw new RecognitionError(
      "model-load-failed",
      `Local model weights refused: ${why}`,
    );
  };
  if (!isRecord(raw) || !Array.isArray(raw.layers) || !raw.layers.length)
    return fail("no layers.");
  let inputs = manifest.input.frames * manifest.input.featuresPerFrame;
  for (const layer of raw.layers as DenseLayer[]) {
    if (!Array.isArray(layer.weights) || !Array.isArray(layer.bias))
      fail("malformed layer.");
    if (layer.weights.length !== layer.bias.length)
      fail("bias/weights size mismatch.");
    if (!["relu", "linear"].includes(layer.activation))
      fail("unsupported activation.");
    for (const row of layer.weights)
      if (
        !Array.isArray(row) ||
        row.length !== inputs ||
        !row.every(Number.isFinite)
      )
        fail("weight matrix does not match the expected input size.");
    if (!layer.bias.every(Number.isFinite)) fail("non-finite bias.");
    inputs = layer.weights.length;
  }
  if (inputs !== manifest.vocabulary.length)
    fail("output size does not match the vocabulary.");
  return raw as DenseWeights;
}

export function runDense(weights: DenseWeights, input: Float32Array) {
  let current: ArrayLike<number> = input;
  for (const layer of weights.layers) {
    const next = new Float64Array(layer.bias.length);
    for (let o = 0; o < layer.bias.length; o++) {
      let sum = layer.bias[o];
      const row = layer.weights[o];
      for (let i = 0; i < row.length; i++) sum += row[i] * current[i];
      next[o] = layer.activation === "relu" ? Math.max(0, sum) : sum;
    }
    current = next;
  }
  const max = Math.max(...Array.from(current));
  const exps = Array.from(current, (v) => Math.exp(v - max));
  const total = exps.reduce((a, b) => a + b, 0);
  return exps.map((v) => v / total);
}

export type LocalDecision = {
  outcome: "recognized" | "unknown";
  reason: string;
  hypotheses: RecognitionHypothesis[];
};

/** Runs the model and applies out-of-vocabulary rejection. */
export function classifySequence(
  manifest: LocalModelManifest,
  weights: DenseWeights,
  sequence: LandmarkSequence,
): LocalDecision {
  validateSequence(sequence);
  if (handCoverage(sequence) < manifest.input.minHandCoverage)
    return {
      outcome: "unknown",
      reason: "Hands were not visible for enough of the capture.",
      hypotheses: [],
    };
  const features = sequenceToFeatures(
    smoothSequence(sequence, manifest.input.smoothingAlpha),
    manifest.input.frames,
  );
  const scores = runDense(weights, features);
  const ranked = scores
    .map((score, index) => ({ label: manifest.vocabulary[index], score }))
    .sort((a, b) => b.score - a.score);
  const [top, second] = ranked;
  const note =
    "Softmax output of the supplied model. It is not a calibrated probability of being correct.";
  if (manifest.rejectLabels.includes(top.label))
    return {
      outcome: "unknown",
      reason: "The model's rejection class scored highest.",
      hypotheses: [],
    };
  if (top.score < manifest.decision.minScore)
    return {
      outcome: "unknown",
      reason:
        "No vocabulary item passed the model's documented score threshold.",
      hypotheses: [],
    };
  if (second && top.score - second.score < manifest.decision.minMargin)
    return {
      outcome: "unknown",
      reason: "The top two vocabulary items were too close to separate.",
      hypotheses: [],
    };
  return {
    outcome: "recognized",
    reason: "Passed the model's documented thresholds.",
    hypotheses: [
      {
        text: top.label,
        confidence: { kind: "model-score", value: top.score, note },
        startSec: null,
        endSec: null,
      },
    ],
  };
}

export const localModelCachePrefix = "interpretai-model-";

/** Loads manifest + weights. Uses an explicit offline cache when present. */
export async function loadLocalModel(
  manifestUrl: string,
  options: { fetcher?: typeof fetch; signal?: AbortSignal } = {},
) {
  const fetcher = options.fetcher ?? fetch;
  const get = async (url: string) => {
    if ("caches" in globalThis) {
      for (const key of await caches.keys())
        if (key.startsWith(localModelCachePrefix)) {
          const hit = await (await caches.open(key)).match(url);
          if (hit) return hit.json();
        }
    }
    let response: Response;
    try {
      response = await fetcher(url, { signal: options.signal });
    } catch {
      throw new RecognitionError(
        "model-load-failed",
        "The local model files could not be loaded. If you are offline, download the model while online first.",
      );
    }
    if (!response.ok)
      throw new RecognitionError(
        "model-load-failed",
        `The local model file returned HTTP ${response.status}.`,
      );
    try {
      return await response.json();
    } catch {
      throw new RecognitionError(
        "model-load-failed",
        "The local model file is not valid JSON.",
      );
    }
  };
  const manifest = validateManifest(await get(manifestUrl));
  const weightsUrl = new URL(
    manifest.weightsUrl,
    new URL(manifestUrl, "http://local.invalid"),
  ).pathname;
  const weights = validateWeights(await get(weightsUrl), manifest);
  return { manifest, weights, weightsUrl };
}

/** Explicit, user-initiated offline download of the documented model files. */
export async function cacheLocalModel(
  manifestUrl: string,
  weightsUrl: string,
  id: string,
  version: string,
) {
  if (!("caches" in globalThis))
    throw new RecognitionError(
      "model-load-failed",
      "This browser cannot cache files for offline use.",
    );
  const cache = await caches.open(`${localModelCachePrefix}${id}-${version}`);
  await cache.addAll([manifestUrl, weightsUrl]);
}
