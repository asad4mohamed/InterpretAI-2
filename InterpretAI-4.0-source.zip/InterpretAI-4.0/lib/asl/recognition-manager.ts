import { detectRisk, type RiskTopic } from "../scenarios";
import type { ProviderRegistry } from "./provider-registry";
import {
  RecognitionError,
  type AvailabilityContext,
  type ConsentState,
  type ProcessingStatus,
  type RecognitionRequest,
  type RecognitionResult,
} from "./types";

export type ManagedOutcome = {
  result: RecognitionResult;
  /** First high-risk topic found in any returned hypothesis. */
  risk?: RiskTopic;
};

/**
 * Orchestrates one recognition request at a time.
 *
 * Guarantees (covered by tests/recognition-manager.test.ts):
 *  - nothing is sent anywhere until `run` is called with a request;
 *  - camera consent is required for every mode, and a matching per-clip
 *    third-party consent is required for every cloud provider;
 *  - cloud providers are refused while offline or in the demo outage;
 *  - a failed request is reported as a failure — there is no fallback to
 *    another provider or to scripted text;
 *  - starting a new request cancels the previous one.
 */
export class RecognitionManager {
  private active: AbortController | null = null;
  constructor(private readonly registry: ProviderRegistry) {}

  cancel() {
    this.active?.abort(
      new RecognitionError("cancelled", "Recognition was cancelled."),
    );
    this.active = null;
  }

  get busy() {
    return this.active !== null;
  }

  async run(
    providerId: string,
    request: RecognitionRequest,
    context: AvailabilityContext,
    onStatus?: (status: ProcessingStatus) => void,
  ): Promise<ManagedOutcome> {
    const provider = this.registry.get(providerId);
    const { descriptor } = provider;
    if (descriptor.mode === "unavailable")
      throw new RecognitionError(
        "not-configured",
        "Recognition is not configured.",
      );
    checkConsent(request.consent, descriptor.thirdParty ? descriptor.id : null);
    if (descriptor.capabilities.location === "cloud") {
      if (!context.online)
        throw new RecognitionError(
          "offline",
          "Cloud recognition is unavailable offline. Nothing was sent.",
        );
      if (context.simulatedOffline)
        throw new RecognitionError(
          "simulated-outage",
          "The demo outage is on. Nothing was sent.",
        );
    }
    this.cancel();
    const controller = new AbortController();
    this.active = controller;
    const forward = () => controller.abort(request.signal?.reason);
    request.signal?.addEventListener("abort", forward, { once: true });
    try {
      const result = await provider.recognize(
        { ...request, signal: controller.signal },
        onStatus,
      );
      if (controller.signal.aborted)
        throw new RecognitionError("cancelled", "Recognition was cancelled.");
      const risk = result.hypotheses
        .map((h) => detectRisk(h.text))
        .find((topic): topic is RiskTopic => !!topic);
      return { result, risk };
    } catch (failure) {
      if (failure instanceof RecognitionError) throw failure;
      if (controller.signal.aborted)
        throw new RecognitionError("cancelled", "Recognition was cancelled.");
      throw new RecognitionError(
        "provider-error",
        failure instanceof Error ? failure.message : "Recognition failed.",
      );
    } finally {
      request.signal?.removeEventListener("abort", forward);
      if (this.active === controller) this.active = null;
    }
  }
}

export function checkConsent(
  consent: ConsentState,
  thirdPartyId: string | null,
) {
  if (!consent.camera)
    throw new RecognitionError(
      "consent-required",
      "Camera consent is required.",
    );
  if (thirdPartyId && consent.thirdPartyUpload?.provider !== thirdPartyId)
    throw new RecognitionError(
      "consent-required",
      "Explicit consent is required before a clip is sent to a third party.",
    );
}
