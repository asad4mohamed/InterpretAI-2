import {
  RecognitionError,
  type LandmarkSequence,
  type PublicRecognitionConfig,
  type RecognitionHypothesis,
  type VideoClip,
} from "./types";

/** Containers the browser's MediaRecorder can produce and the proxy accepts. */
export const acceptedVideoTypes = ["video/webm", "video/mp4"] as const;

export function baseMimeType(mime: string) {
  return mime.split(";")[0].trim().toLowerCase();
}

/**
 * Validates a clip before anything leaves the device. These are application
 * limits chosen to keep requests short; Sign-Speak's own limits are not
 * published in the material reviewed (see docs/API-INTEGRATION.md).
 */
export function validateClip(
  clip: VideoClip,
  config: Pick<PublicRecognitionConfig, "maxClipBytes" | "maxClipSeconds">,
) {
  const type = baseMimeType(clip.mimeType || clip.blob.type);
  if (!acceptedVideoTypes.includes(type as (typeof acceptedVideoTypes)[number]))
    throw new RecognitionError(
      "invalid-input",
      `Unsupported clip format (${type || "unknown"}). Only WebM or MP4 video is accepted.`,
    );
  if (clip.blob.size === 0)
    throw new RecognitionError("invalid-input", "The recorded clip is empty.");
  if (clip.blob.size > config.maxClipBytes)
    throw new RecognitionError(
      "invalid-input",
      `The clip is ${(clip.blob.size / 1e6).toFixed(1)} MB; the limit is ${(config.maxClipBytes / 1e6).toFixed(1)} MB.`,
    );
  if (!Number.isFinite(clip.durationMs) || clip.durationMs < 500)
    throw new RecognitionError(
      "invalid-input",
      "The clip is shorter than half a second. Record a longer clip.",
    );
  if (clip.durationMs > config.maxClipSeconds * 1000 + 750)
    throw new RecognitionError(
      "invalid-input",
      `The clip is longer than ${config.maxClipSeconds} seconds.`,
    );
  return type;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);

const finiteOrNull = (value: unknown) =>
  typeof value === "number" && Number.isFinite(value) ? value : null;

/**
 * Parses Sign-Speak's documented recognition shape, as published in the
 * official @sign-speak/react-sdk 0.7.3 type definitions:
 *
 *   { feedback_id: string,
 *     prediction: [{ feedback_id, timestamp_start_sec, timestamp_end_sec,
 *                    finished, prediction: string, confidence: number }] }
 *
 * Anything else is rejected as an invalid response. Empty predictions are
 * dropped, never replaced with placeholder text.
 */
export function parseSignSpeakRecognition(data: unknown): {
  reference: string | null;
  hypotheses: RecognitionHypothesis[];
} {
  if (!isRecord(data) || !Array.isArray(data.prediction))
    throw new RecognitionError(
      "invalid-response",
      "The recognition service returned a response in an unexpected format. Nothing was displayed.",
    );
  const hypotheses: RecognitionHypothesis[] = [];
  for (const item of data.prediction) {
    if (!isRecord(item) || typeof item.prediction !== "string")
      throw new RecognitionError(
        "invalid-response",
        "A recognition entry was malformed. Nothing was displayed.",
      );
    const text = item.prediction.trim();
    if (!text) continue;
    const confidence = finiteOrNull(item.confidence);
    hypotheses.push({
      text,
      confidence:
        confidence === null
          ? {
              kind: "none",
              note: "The provider did not return a confidence value.",
            }
          : {
              kind: "provider-reported",
              value: confidence,
              note: "Reported by Sign-Speak. Its scale and calibration have not been independently verified by InterpretAI.",
            },
      startSec: finiteOrNull(item.timestamp_start_sec),
      endSec: finiteOrNull(item.timestamp_end_sec),
    });
  }
  return {
    reference: typeof data.feedback_id === "string" ? data.feedback_id : null,
    hypotheses,
  };
}

/** Validates a landmark sequence before it reaches any local model. */
export function validateSequence(sequence: LandmarkSequence) {
  if (sequence?.format !== "interpretai.landmarks.v1")
    throw new RecognitionError(
      "invalid-input",
      "Unknown landmark sequence format.",
    );
  if (!Array.isArray(sequence.frames) || sequence.frames.length < 2)
    throw new RecognitionError(
      "invalid-input",
      "Too few frames were captured. Keep your hands in view and try again.",
    );
  let last = -Infinity;
  for (const frame of sequence.frames) {
    if (!Number.isFinite(frame.t) || frame.t <= last)
      throw new RecognitionError(
        "invalid-input",
        "Frame timestamps must be finite and strictly increasing.",
      );
    last = frame.t;
    if (frame.hands.length > 2)
      throw new RecognitionError(
        "invalid-input",
        "More than two hands in a frame.",
      );
    for (const hand of frame.hands)
      for (const set of [hand.image, hand.world])
        if (
          set.length !== 21 ||
          set.some((p) => ![p.x, p.y, p.z].every(Number.isFinite))
        )
          throw new RecognitionError(
            "invalid-input",
            "A hand observation did not contain 21 finite landmarks.",
          );
  }
  if (!sequence.frames.some((frame) => frame.hands.length))
    throw new RecognitionError(
      "invalid-input",
      "No hands were detected during capture.",
    );
}
