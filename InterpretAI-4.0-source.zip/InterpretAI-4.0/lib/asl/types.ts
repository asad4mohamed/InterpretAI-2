/**
 * Provider-independent types for ASL recognition and signing output.
 *
 * Nothing in this module performs recognition. It defines the contracts that
 * every provider (experimental handshape rules, a supplied local model, or an
 * external API reached through a secure proxy) must satisfy, so the UI can
 * report honestly where a result came from and how certain the provider said
 * it was.
 */

/** The four clearly differentiated recognition modes. */
export type RecognitionMode =
  | "experimental-handshape" // Mode 1: existing L/Y geometry rules
  | "fingerspelling" // bundled trained model: 24 static ASL letters, on device
  | "sign-model" // bundled trained temporal model: 250 isolated signs, on device
  | "local-model" // Mode 2: a supplied, documented, trained local model
  | "external-api" // Mode 3: approved commercial API via secure proxy
  | "unavailable"; // Mode 4: nothing configured

export type ProcessingLocation = "on-device" | "cloud";

/** What kind of linguistic unit a provider claims to return. */
export type RecognitionGranularity =
  | "handshape" // a static manual-alphabet-like handshape, not a sign
  | "fingerspelling" // spelled letters from static handshapes, not signs
  | "isolated-sign" // one gloss from a closed vocabulary
  | "sign-sequence" // a reviewed sequence of isolated signs + a fixed-table phrase
  | "continuous-english"; // provider returns English text for a clip

export type InputKind =
  | "landmark-stream"
  | "landmark-sequence"
  | "holistic-stream"
  | "video-clip"
  | "still-image";

export type ProviderCapabilities = {
  granularity: RecognitionGranularity;
  input: InputKind;
  location: ProcessingLocation;
  /** True only if the provider itself returns a confidence-like number. */
  reportsConfidence: boolean;
  /** Whether a submitted request can be cancelled. */
  cancellable: "local-abort" | "provider-delete" | "none";
  /** Works with no network once its assets are present. */
  worksOffline: boolean;
  /** Supported vocabulary when it is a closed set; null for open output. */
  vocabulary: readonly string[] | null;
};

export type ProviderAvailability =
  | { state: "available" }
  | { state: "needs-download"; detail: string }
  | { state: "not-configured"; detail: string }
  | { state: "offline"; detail: string }
  | { state: "simulated-outage"; detail: string }
  | { state: "unsupported-browser"; detail: string }
  | { state: "error"; detail: string };

export type ProviderDescriptor = {
  id: string;
  mode: RecognitionMode;
  label: string;
  /** One-line plain-language description shown in the mode selector. */
  summary: string;
  capabilities: ProviderCapabilities;
  /** Shown before any third-party processing. */
  thirdParty: null | { name: string; documentationUrl: string };
};

/** Configuration that the browser is allowed to know. Never contains secrets. */
export type PublicRecognitionConfig = {
  /** Base URL of the optional secure proxy, e.g. http://127.0.0.1:8787 */
  proxyUrl: string | null;
  /** URL of a local model manifest (same origin), e.g. /models/x/manifest.json */
  localModelManifestUrl: string | null;
  avatarProvider: "none" | "sign-speak" | "handtalk";
  /** Hand Talk SDK tokens are browser tokens by design (see API guide). */
  handTalkToken: string | null;
  /** Hard ceiling for a recorded clip, enforced before upload. */
  maxClipSeconds: number;
  maxClipBytes: number;
  requestTimeoutMs: number;
  source: "runtime-config" | "build-env" | "defaults";
};

/* ---------- Inputs ---------- */

export type Handedness = "Left" | "Right";

export type LandmarkPoint = { x: number; y: number; z: number };

/** One detected hand in one frame. */
export type HandObservation = {
  /** Signer's anatomical hand, corrected for the unmirrored camera frame. */
  handedness: Handedness;
  /** MediaPipe's own handedness score (0–1). Provider-reported, not ours. */
  handednessScore: number;
  /** 21 image-normalized points (x,y in 0..1 of the frame). */
  image: LandmarkPoint[];
  /** 21 metric world points, centred near the hand. */
  world: LandmarkPoint[];
};

export type LandmarkFrame = {
  /** Milliseconds, strictly increasing within a sequence. */
  t: number;
  hands: HandObservation[];
};

/** Versioned temporal landmark sequence, see docs/LOCAL-RECOGNITION.md. */
export type LandmarkSequence = {
  format: "interpretai.landmarks.v1";
  frames: LandmarkFrame[];
};

export type VideoClip = {
  blob: Blob;
  mimeType: string;
  durationMs: number;
};

/* ---------- Consent ---------- */

export type ConsentState = {
  /** The patient agreed to camera use for this session. */
  camera: boolean;
  /**
   * The patient agreed to send THIS clip to a named third party. Consent is
   * per-clip and is cleared after each submission.
   */
  thirdPartyUpload: { provider: string; grantedAt: number } | null;
};

/* ---------- Results ---------- */

export type ConfidenceReport =
  | { kind: "provider-reported"; value: number; note: string }
  | { kind: "model-score"; value: number; note: string }
  /** Temperature-scaled on held-out signers (asl-signs-v1). Still not proof of correctness. */
  | { kind: "calibrated-probability"; value: number; note: string }
  | { kind: "none"; note: string };

export type RecognitionHypothesis = {
  text: string;
  confidence: ConfidenceReport;
  startSec: number | null;
  endSec: number | null;
};

export type RecognitionResult = {
  providerId: string;
  mode: RecognitionMode;
  granularity: RecognitionGranularity;
  location: ProcessingLocation;
  /** Empty when the provider recognised nothing. Never synthesised. */
  hypotheses: RecognitionHypothesis[];
  /** "unknown" when nothing passed the provider/vocabulary rules. */
  outcome: "recognized" | "unknown";
  /** Provider reference that may be used for feedback, never shown as data. */
  providerReference: string | null;
  modelVersion: string | null;
  receivedAt: number;
};

export type RecognitionErrorCode =
  | "not-configured"
  | "consent-required"
  | "offline"
  | "simulated-outage"
  | "invalid-input"
  | "auth-failed"
  | "rate-limited"
  | "network"
  | "timeout"
  | "invalid-response"
  | "provider-error"
  | "cancelled"
  | "model-load-failed"
  | "model-unavailable";

export class RecognitionError extends Error {
  readonly code: RecognitionErrorCode;
  constructor(code: RecognitionErrorCode, message: string) {
    super(message);
    this.name = "RecognitionError";
    this.code = code;
  }
}

export type RecognitionRequest =
  | {
      kind: "video-clip";
      clip: VideoClip;
      consent: ConsentState;
      signal?: AbortSignal;
    }
  | {
      kind: "landmark-sequence";
      sequence: LandmarkSequence;
      consent: ConsentState;
      signal?: AbortSignal;
    }
  | {
      kind: "still-image";
      image: Blob;
      consent: ConsentState;
      signal?: AbortSignal;
    }
  | {
      kind: "sign-sequence";
      /** English the user confirmed or wrote (from the phrase table or their own words). */
      english: string;
      glosses: string[];
      minProbability: number | null;
      userWritten: boolean;
      modelVersion: string;
      consent: ConsentState;
      signal?: AbortSignal;
    }
  | {
      kind: "fingerspelling";
      text: string;
      letters: { letter: string; score: number }[];
      consent: ConsentState;
      signal?: AbortSignal;
    };

export type ProcessingStatus =
  | { phase: "idle" }
  | { phase: "validating" }
  | { phase: "uploading" }
  | { phase: "waiting"; detail: string }
  | { phase: "polling"; attempt: number }
  | { phase: "complete" }
  | { phase: "failed"; code: RecognitionErrorCode };

export interface RecognitionProvider {
  readonly descriptor: ProviderDescriptor;
  availability(context: AvailabilityContext): Promise<ProviderAvailability>;
  recognize(
    request: RecognitionRequest,
    onStatus?: (status: ProcessingStatus) => void,
  ): Promise<RecognitionResult>;
}

export type AvailabilityContext = {
  online: boolean;
  simulatedOffline: boolean;
};
