import type { PublicRecognitionConfig } from "./types";

/**
 * Public (non-secret) integration configuration.
 *
 * Resolution order:
 *  1. /runtime-config.json — written by `scripts/serve.mjs` from the server's
 *     environment at request time, so a prebuilt export can be pointed at a
 *     proxy without rebuilding.
 *  2. NEXT_PUBLIC_* variables inlined at build time (development server).
 *  3. Safe defaults: everything external is unconfigured.
 *
 * Secrets (e.g. SIGN_SPEAK_API_KEY) are never read here. They live only in
 * the optional proxy process.
 */
export const defaultConfig: PublicRecognitionConfig = {
  proxyUrl: null,
  localModelManifestUrl: null,
  avatarProvider: "none",
  handTalkToken: null,
  maxClipSeconds: 10,
  maxClipBytes: 8_000_000,
  requestTimeoutMs: 45_000,
  source: "defaults",
};

const clean = (value: unknown) =>
  typeof value === "string" && value.trim() ? value.trim() : null;

function safeUrl(value: unknown, { sameOriginPath = false } = {}) {
  const text = clean(value);
  if (!text) return null;
  if (sameOriginPath)
    return text.startsWith("/") && !text.startsWith("//") ? text : null;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    // Plain HTTP is allowed only for loopback development proxies.
    if (
      url.protocol === "http:" &&
      !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname)
    )
      return null;
    return url.origin + url.pathname.replace(/\/$/, "");
  } catch {
    return null;
  }
}

function bounded(value: unknown, min: number, max: number, fallback: number) {
  const n = typeof value === "string" ? Number(value) : value;
  return typeof n === "number" && Number.isFinite(n)
    ? Math.min(max, Math.max(min, n))
    : fallback;
}

/** Normalises untrusted configuration input. Unknown keys are ignored. */
export function normalizeConfig(
  raw: Record<string, unknown>,
  source: PublicRecognitionConfig["source"],
): PublicRecognitionConfig {
  const avatar = clean(raw.avatarProvider);
  return {
    proxyUrl: safeUrl(raw.proxyUrl),
    localModelManifestUrl: safeUrl(raw.localModelManifestUrl, {
      sameOriginPath: true,
    }),
    avatarProvider:
      avatar === "sign-speak" || avatar === "handtalk" ? avatar : "none",
    handTalkToken: clean(raw.handTalkToken),
    maxClipSeconds: bounded(
      raw.maxClipSeconds,
      2,
      30,
      defaultConfig.maxClipSeconds,
    ),
    maxClipBytes: bounded(
      raw.maxClipBytes,
      250_000,
      25_000_000,
      defaultConfig.maxClipBytes,
    ),
    requestTimeoutMs: bounded(
      raw.requestTimeoutMs,
      5_000,
      120_000,
      defaultConfig.requestTimeoutMs,
    ),
    source,
  };
}

export function buildEnvConfig(): PublicRecognitionConfig | null {
  const raw = {
    proxyUrl: process.env.NEXT_PUBLIC_RECOGNITION_PROXY_URL,
    localModelManifestUrl: process.env.NEXT_PUBLIC_LOCAL_MODEL_MANIFEST,
    avatarProvider: process.env.NEXT_PUBLIC_AVATAR_PROVIDER,
    handTalkToken: process.env.NEXT_PUBLIC_HANDTALK_TOKEN,
    maxClipSeconds: process.env.NEXT_PUBLIC_MAX_CLIP_SECONDS,
  };
  return Object.values(raw).some((value) => clean(value))
    ? normalizeConfig(raw, "build-env")
    : null;
}

export async function loadPublicConfig(
  fetcher: typeof fetch = fetch,
): Promise<PublicRecognitionConfig> {
  try {
    const response = await fetcher("/runtime-config.json", {
      cache: "no-store",
    });
    if (response.ok) {
      const data: unknown = await response.json();
      if (data && typeof data === "object" && !Array.isArray(data))
        return normalizeConfig(
          data as Record<string, unknown>,
          "runtime-config",
        );
    }
  } catch {
    // Development server or offline without a cached copy.
  }
  return buildEnvConfig() ?? defaultConfig;
}
