import { detectRisk, type RiskTopic } from "../scenarios";
import { withTimeout } from "./sign-speak";
import {
  RecognitionError,
  type AvailabilityContext,
  type ProviderAvailability,
  type PublicRecognitionConfig,
} from "./types";

/**
 * English → ASL signing-avatar providers.
 *
 * These are OPTIONAL, machine-generated, and unvalidated by InterpretAI.
 * The existing Three.js mannequin in the sample lab is a separate scripted
 * pose illustration and is deliberately not one of these providers.
 */

export type AvatarProviderId = "sign-speak" | "handtalk";

export type AvatarDescriptor = {
  id: AvatarProviderId;
  label: string;
  output: "video" | "embedded-sdk";
  /** Documented provider limit, or an application limit where none is published. */
  maxChars: number;
  maxCharsSource: "provider-documented" | "application-limit";
  controls: readonly (
    "play" | "pause" | "resume" | "stop" | "replay" | "speed"
  )[];
  documentationUrl: string;
};

export const avatarDescriptors: Record<AvatarProviderId, AvatarDescriptor> = {
  "sign-speak": {
    id: "sign-speak",
    label: "Sign-Speak ASL production (video)",
    output: "video",
    maxChars: 500,
    maxCharsSource: "application-limit",
    controls: ["play", "pause", "replay"],
    documentationUrl:
      "https://app.theneo.io/sign-speak/sign-speak-api/api-specifications",
  },
  handtalk: {
    id: "handtalk",
    label: "Hand Talk for Devs (embedded 3D avatar)",
    output: "embedded-sdk",
    maxChars: 1000,
    maxCharsSource: "provider-documented",
    controls: ["play", "pause", "resume", "stop", "replay", "speed"],
    documentationUrl:
      "https://api-docs.handtalk.me/v1/en/javascript/getting-start",
  },
};

export type AvatarTextCheck =
  { ok: true; text: string } | { ok: false; reason: string; risk?: RiskTopic };

/**
 * Gate applied before ANY text is sent to a signing provider. High-risk
 * clinical content is never machine-signed; it is routed to a qualified
 * interpreter instead.
 */
export function checkAvatarText(
  text: string,
  descriptor: AvatarDescriptor,
): AvatarTextCheck {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return { ok: false, reason: "Type a message first." };
  if (clean.length > descriptor.maxChars)
    return {
      ok: false,
      reason: `Machine signing is limited to ${descriptor.maxChars} characters for ${descriptor.label}.`,
    };
  const risk = detectRisk(clean);
  if (risk)
    return {
      ok: false,
      risk,
      reason: `${risk} is high-risk content. It will not be machine-signed. Use a qualified interpreter.`,
    };
  return { ok: true, text: clean };
}

export function avatarAvailability(
  config: PublicRecognitionConfig,
  context: AvailabilityContext,
  proxyProduction: boolean | null,
): ProviderAvailability {
  if (config.avatarProvider === "none")
    return {
      state: "not-configured",
      detail:
        "No signing-avatar provider is connected. English text is shown instead.",
    };
  if (!context.online)
    return {
      state: "offline",
      detail: "Signing-avatar providers need a network connection.",
    };
  if (context.simulatedOffline)
    return {
      state: "simulated-outage",
      detail: "The demo outage is on. The signing avatar is disabled.",
    };
  if (config.avatarProvider === "handtalk") {
    if (!config.handTalkToken)
      return {
        state: "not-configured",
        detail: "Hand Talk is selected but no token is configured.",
      };
    if (!webglSupported())
      return {
        state: "unsupported-browser",
        detail: "Hand Talk requires a browser with WebGL support.",
      };
    return { state: "available" };
  }
  if (!config.proxyUrl)
    return {
      state: "not-configured",
      detail: "Sign-Speak production needs the secure proxy URL.",
    };
  if (proxyProduction === null)
    return { state: "error", detail: "The secure proxy could not be reached." };
  if (!proxyProduction)
    return {
      state: "not-configured",
      detail: "The proxy has no Sign-Speak key configured.",
    };
  return { state: "available" };
}

export function webglSupported() {
  if (typeof document === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    return !!(canvas.getContext("webgl2") || canvas.getContext("webgl"));
  } catch {
    return false;
  }
}

/** Sign-Speak /produce-sign via the proxy. Returns a video Blob. */
export async function produceSignSpeakVideo(
  config: PublicRecognitionConfig,
  text: string,
  signal?: AbortSignal,
  fetcher: typeof fetch = (...args) => fetch(...args),
  pollIntervalMs = 1500,
): Promise<Blob> {
  if (!config.proxyUrl)
    throw new RecognitionError(
      "not-configured",
      "Sign-Speak production is not configured.",
    );
  const timer = withTimeout(signal, config.requestTimeoutMs);
  try {
    let response = await fetcher(`${config.proxyUrl}/v1/sign-speak/produce`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ english: text }),
      signal: timer.signal,
      cache: "no-store",
    });
    while (response.status === 202) {
      const { requestId } = (await response.json()) as { requestId?: string };
      if (!requestId || !/^[\w-]{1,128}$/.test(requestId))
        throw new RecognitionError(
          "invalid-response",
          "The proxy did not return a valid request ID.",
        );
      await new Promise((r) => setTimeout(r, pollIntervalMs));
      timer.signal.throwIfAborted();
      response = await fetcher(
        `${config.proxyUrl}/v1/sign-speak/produce/${encodeURIComponent(requestId)}`,
        {
          signal: timer.signal,
          cache: "no-store",
        },
      );
    }
    if (response.status === 401 || response.status === 403)
      throw new RecognitionError(
        "auth-failed",
        "Sign-Speak rejected the configured credentials.",
      );
    if (response.status === 503)
      throw new RecognitionError(
        "not-configured",
        "Sign-Speak production is not configured on the proxy.",
      );
    if (!response.ok)
      throw new RecognitionError(
        "provider-error",
        `Signing video request failed (HTTP ${response.status}).`,
      );
    const blob = await response.blob();
    if (!blob.size || !/^video\//.test(blob.type))
      throw new RecognitionError(
        "invalid-response",
        "The provider did not return a playable video.",
      );
    return blob;
  } catch (failure) {
    if (failure instanceof RecognitionError) throw failure;
    if (timer.signal.aborted && timer.signal.reason instanceof RecognitionError)
      throw timer.signal.reason;
    throw new RecognitionError(
      "network",
      "The signing provider could not be reached.",
    );
  } finally {
    timer.dispose();
  }
}

/* ---------- Hand Talk for Devs (documented browser SDK) ---------- */

/** Documented in the Hand Talk API reference (Methods and Props). */
export type HandTalkApi = {
  active: () => void;
  disable: () => Promise<void>;
  translate: (sentence: string) => Promise<void>;
  pause: () => void;
  resume: () => void;
  stop: () => Promise<void>;
  repeat: () => Promise<void>;
  changeAnimationSpeed: (speed: "normal" | "slow" | "fast") => void;
  onApplicationStateChange?: (cb: (state: unknown) => void) => () => void;
  isLoaded: boolean;
};

declare global {
  interface Window {
    HTApi?: new (config: Record<string, unknown>) => HandTalkApi;
  }
}

export const HANDTALK_SDK_URL =
  "https://api-cdn.handtalk.me/sdk/latest/ht-api-sdk.min.js";

let sdkLoading: Promise<void> | null = null;
export function loadHandTalkSdk(timeoutMs = 20000) {
  if (typeof window === "undefined")
    return Promise.reject(new Error("No browser."));
  if (window.HTApi) return Promise.resolve();
  sdkLoading ??= new Promise<void>((resolve, reject) => {
    const script = document.createElement("script");
    script.src = HANDTALK_SDK_URL;
    script.async = true;
    const timer = window.setTimeout(
      () => fail("The Hand Talk SDK took too long to load."),
      timeoutMs,
    );
    function fail(message: string) {
      clearTimeout(timer);
      script.remove();
      sdkLoading = null;
      reject(new RecognitionError("model-load-failed", message));
    }
    script.onload = () => {
      clearTimeout(timer);
      if (window.HTApi) resolve();
      else fail("The Hand Talk SDK loaded but did not expose HTApi.");
    };
    script.onerror = () => fail("The Hand Talk SDK could not be downloaded.");
    document.head.appendChild(script);
  });
  return sdkLoading;
}

export async function createHandTalk(token: string, parentSelector: string) {
  await loadHandTalkSdk();
  const Api = window.HTApi;
  if (!Api)
    throw new RecognitionError(
      "model-load-failed",
      "Hand Talk SDK unavailable.",
    );
  // signLanguage "en-ase": the documented English option; "ase" is the
  // ISO 639-3 code for American Sign Language.
  const api = new Api({
    token,
    signLanguage: "en-ase",
    language: "enUS",
    parentElementSelector: parentSelector,
  });
  api.active();
  return api;
}
