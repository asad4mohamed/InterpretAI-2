import {
  errorForStatus,
  fetchProxyHealth,
  proxyMessage,
  readJson,
  withTimeout,
} from "./sign-speak";
import {
  RecognitionError,
  type AvailabilityContext,
  type ProcessingStatus,
  type ProviderAvailability,
  type ProviderDescriptor,
  type PublicRecognitionConfig,
  type RecognitionHypothesis,
  type RecognitionProvider,
  type RecognitionRequest,
  type RecognitionResult,
} from "./types";

/**
 * Hugging Face image classification through InterpretAI's secure proxy.
 *
 * The browser sends ONE still photo, only after per-image consent. The proxy
 * holds HF_TOKEN and calls either a Dedicated Inference Endpoint
 * (HF_ASL_ENDPOINT_URL) or the HF Inference provider route for
 * HF_ASL_MODEL_ID. The documented response is an array of {label, score}.
 *
 * A single photo can only show a static handshape (e.g. a fingerspelled
 * letter). This adapter never claims sign or sentence recognition.
 */
export const huggingFaceDescriptor: ProviderDescriptor = {
  id: "huggingface",
  mode: "external-api",
  label: "Hugging Face model (cloud, one photo)",
  summary:
    "Sends one reviewed still photo to your configured Hugging Face model through the secure proxy. Returns that model's labels.",
  capabilities: {
    granularity: "handshape",
    input: "still-image",
    location: "cloud",
    reportsConfidence: true,
    cancellable: "local-abort",
    worksOffline: false,
    vocabulary: null,
  },
  thirdParty: {
    name: "Hugging Face",
    documentationUrl:
      "https://huggingface.co/docs/api-inference/tasks/image-classification",
  },
};

export const acceptedImageTypes = ["image/jpeg", "image/png", "image/webp"];
export const MAX_IMAGE_BYTES = 2_000_000;
/** Below this provider score a label is shown as "unknown". */
export const HF_MIN_SCORE = 0.5;

export function validateImage(image: Blob) {
  const type = image.type.split(";")[0].trim().toLowerCase();
  if (!acceptedImageTypes.includes(type))
    throw new RecognitionError(
      "invalid-input",
      `Unsupported image format (${type || "unknown"}). Use JPEG, PNG or WebP.`,
    );
  if (!image.size)
    throw new RecognitionError("invalid-input", "The photo is empty.");
  if (image.size > MAX_IMAGE_BYTES)
    throw new RecognitionError(
      "invalid-input",
      "The photo is larger than 2 MB.",
    );
  return type;
}

export function parseHfClassification(data: unknown): RecognitionHypothesis[] {
  const items = Array.isArray(data) ? data : null;
  if (
    !items ||
    !items.every(
      (item) =>
        item &&
        typeof item === "object" &&
        typeof (item as { label?: unknown }).label === "string" &&
        typeof (item as { score?: unknown }).score === "number" &&
        Number.isFinite((item as { score: number }).score),
    )
  )
    throw new RecognitionError(
      "invalid-response",
      "The Hugging Face model returned an unexpected response. Nothing was displayed.",
    );
  return (items as { label: string; score: number }[])
    .filter((item) => item.label.trim())
    .sort((a, b) => b.score - a.score)
    .map((item) => ({
      text: item.label.trim(),
      confidence: {
        kind: "provider-reported" as const,
        value: item.score,
        note: "Score returned by the Hugging Face model. Not calibrated or verified by InterpretAI.",
      },
      startSec: null,
      endSec: null,
    }));
}

export function createHuggingFaceProvider(
  config: PublicRecognitionConfig,
  fetcher: typeof fetch = (...args) => fetch(...args),
): RecognitionProvider {
  let modelId: string | null = null;
  return {
    descriptor: huggingFaceDescriptor,
    async availability(
      context: AvailabilityContext,
    ): Promise<ProviderAvailability> {
      if (!config.proxyUrl)
        return {
          state: "not-configured",
          detail:
            "No secure proxy is configured. Hugging Face tokens must stay on the proxy.",
        };
      if (!context.online)
        return {
          state: "offline",
          detail: "Cloud inference needs a network connection.",
        };
      if (context.simulatedOffline)
        return { state: "simulated-outage", detail: "The demo outage is on." };
      const health = await fetchProxyHealth(config.proxyUrl, fetcher);
      if (!health)
        return {
          state: "error",
          detail: "The secure proxy could not be reached.",
        };
      modelId = health.huggingFace.modelId;
      if (!health.huggingFace.tokenSet)
        return {
          state: "not-configured",
          detail: "HF_TOKEN is not set on the proxy.",
        };
      if (!health.huggingFace.configured)
        return {
          state: "not-configured",
          detail: "Set HF_ASL_ENDPOINT_URL or HF_ASL_MODEL_ID on the proxy.",
        };
      return { state: "available" };
    },
    async recognize(
      request: RecognitionRequest,
      onStatus?: (status: ProcessingStatus) => void,
    ): Promise<RecognitionResult> {
      if (!config.proxyUrl)
        throw new RecognitionError(
          "not-configured",
          "Hugging Face is not configured.",
        );
      if (request.kind !== "still-image")
        throw new RecognitionError(
          "invalid-input",
          "This model accepts one still photo.",
        );
      if (
        request.consent.thirdPartyUpload?.provider !== huggingFaceDescriptor.id
      )
        throw new RecognitionError(
          "consent-required",
          "Explicit consent is required before a photo is sent to Hugging Face.",
        );
      onStatus?.({ phase: "validating" });
      const type = validateImage(request.image);
      const timer = withTimeout(request.signal, config.requestTimeoutMs);
      try {
        onStatus?.({ phase: "uploading" });
        let response: Response;
        try {
          response = await fetcher(`${config.proxyUrl}/v1/hf/classify-image`, {
            method: "POST",
            headers: {
              "Content-Type": type,
              "X-InterpretAI-Consent": "huggingface",
            },
            body: request.image,
            signal: timer.signal,
            cache: "no-store",
          });
        } catch {
          if (
            timer.signal.aborted &&
            timer.signal.reason instanceof RecognitionError
          )
            throw timer.signal.reason;
          throw new RecognitionError(
            "network",
            "The secure proxy could not be reached. Nothing was displayed.",
          );
        }
        const data = await readJson(response);
        if (!response.ok) {
          const code =
            data && typeof data === "object" && "error" in data
              ? String(
                  (data as { error?: { code?: unknown } }).error?.code ?? "",
                )
              : "";
          if (code === "model-unavailable" || code === "model-loading")
            throw new RecognitionError(
              "model-unavailable",
              proxyMessage(data) || "The model is unavailable.",
            );
          throw errorForStatus(response.status, proxyMessage(data));
        }
        const payload = data as {
          status?: unknown;
          model?: unknown;
          result?: unknown;
        };
        if (payload.status !== "completed")
          throw new RecognitionError(
            "invalid-response",
            "The proxy did not return a completed result.",
          );
        const hypotheses = parseHfClassification(payload.result);
        onStatus?.({ phase: "complete" });
        const top = hypotheses[0];
        const confident =
          !!top &&
          top.confidence.kind !== "none" &&
          top.confidence.value >= HF_MIN_SCORE;
        return {
          providerId: huggingFaceDescriptor.id,
          mode: "external-api",
          granularity: "handshape",
          location: "cloud",
          outcome: confident ? "recognized" : "unknown",
          hypotheses: confident ? hypotheses.slice(0, 3) : [],
          providerReference: null,
          modelVersion:
            typeof payload.model === "string" ? payload.model : modelId,
          receivedAt: Date.now(),
        };
      } catch (failure) {
        if (failure instanceof RecognitionError) {
          onStatus?.({ phase: "failed", code: failure.code });
          throw failure;
        }
        throw new RecognitionError(
          "provider-error",
          "Hugging Face recognition failed.",
        );
      } finally {
        timer.dispose();
      }
    },
  };
}
