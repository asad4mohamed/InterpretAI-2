import { matchHandshape, steadyHandshape, emptyHandshape } from "../handshapes";
import {
  classifySequence,
  loadLocalModel,
  type DenseWeights,
  type LocalModelManifest,
} from "./local-recognition";
import { createSignSpeakProvider } from "./sign-speak";
import { createHuggingFaceProvider } from "./huggingface";
import {
  classifyHand,
  emptySpeller,
  handFeatures,
  loadFingerspellingModel,
  spelledText,
  stepSpeller,
  type StaticHandModel,
} from "./fingerspelling";
import {
  RecognitionError,
  type AvailabilityContext,
  type ProviderAvailability,
  type ProviderDescriptor,
  type PublicRecognitionConfig,
  type RecognitionMode,
  type RecognitionProvider,
  type RecognitionRequest,
  type RecognitionResult,
} from "./types";
import { validateSequence } from "./validation";

/* ---------- Mode 1: existing experimental L/Y geometry rules ---------- */

export const handshapeDescriptor: ProviderDescriptor = {
  id: "experimental-handshape",
  mode: "experimental-handshape",
  label: "Experimental handshape lab (L / Y only)",
  summary:
    "On-device geometry rules for two manual-alphabet-like handshapes. Not ASL recognition.",
  capabilities: {
    granularity: "handshape",
    input: "landmark-stream",
    location: "on-device",
    reportsConfidence: false,
    cancellable: "local-abort",
    worksOffline: true,
    vocabulary: ["L-like handshape", "Y-like handshape"],
  },
  thirdParty: null,
};

export function createHandshapeProvider(
  toolsReady: () => Promise<boolean>,
): RecognitionProvider {
  return {
    descriptor: handshapeDescriptor,
    async availability(): Promise<ProviderAvailability> {
      return (await toolsReady().catch(() => false))
        ? { state: "available" }
        : {
            state: "needs-download",
            detail:
              "Download the optional on-device hand-tracking tools (about 21.8 MB) first.",
          };
    },
    async recognize(request: RecognitionRequest): Promise<RecognitionResult> {
      if (request.kind !== "landmark-sequence")
        throw new RecognitionError(
          "invalid-input",
          "The handshape lab reads live landmarks.",
        );
      validateSequence(request.sequence);
      let state = { ...emptyHandshape };
      let candidate: "L" | "Y" | null = null;
      for (const frame of request.sequence.frames) {
        const observed =
          frame.hands.length === 1
            ? matchHandshape(frame.hands[0].world)
            : null;
        const step = steadyHandshape(state, observed, frame.t);
        state = step.state;
        candidate =
          step.candidate ?? (observed === candidate ? candidate : null);
      }
      return {
        providerId: handshapeDescriptor.id,
        mode: "experimental-handshape",
        granularity: "handshape",
        location: "on-device",
        outcome: candidate ? "recognized" : "unknown",
        hypotheses: candidate
          ? [
              {
                text: `${candidate}-like handshape`,
                confidence: {
                  kind: "none",
                  note: "Geometry rules produce no confidence value.",
                },
                startSec: null,
                endSec: null,
              },
            ]
          : [],
        providerReference: null,
        modelVersion: "geometry-rules-v1",
        receivedAt: Date.now(),
      };
    },
  };
}

/* ---------- Bundled on-device fingerspelling model ---------- */

export const signModelDescriptor: ProviderDescriptor = {
  id: "asl-signs",
  mode: "sign-model",
  label: "ASL signs, continuous (on device, 250 signs)",
  summary:
    "A trained temporal model reads isolated ASL signs from hand, body and lip movement, one sign at a time, and suggests short phrases from a fixed table. Not sentence translation.",
  capabilities: {
    granularity: "sign-sequence",
    input: "holistic-stream",
    location: "on-device",
    reportsConfidence: true,
    cancellable: "local-abort",
    worksOffline: true,
    vocabulary: null,
  },
  thirdParty: null,
};

/**
 * The live pipeline runs in the sign worker (SignRecognitionPanel). This
 * provider receives the sequence the patient reviewed and the English they
 * confirmed or wrote, so it enters the same review queue, risk detection and
 * escalation as every other mode. It never creates text itself.
 */
export function createSignModelProvider(
  signToolsReady: () => Promise<boolean>,
): RecognitionProvider {
  return {
    descriptor: signModelDescriptor,
    async availability(): Promise<ProviderAvailability> {
      if (!(await signToolsReady().catch(() => false)))
        return {
          state: "needs-download",
          detail:
            "Download the on-device sign recognition files (about 47.7 MB) in this mode first.",
        };
      return { state: "available" };
    },
    async recognize(request: RecognitionRequest): Promise<RecognitionResult> {
      if (request.kind !== "sign-sequence")
        throw new RecognitionError(
          "invalid-input",
          "This mode accepts reviewed sign sequences only.",
        );
      const english = request.english.trim();
      if (!english || english.length > 200 || request.glosses.length === 0)
        throw new RecognitionError("invalid-input", "Nothing to review.");
      return {
        providerId: signModelDescriptor.id,
        mode: "sign-model",
        granularity: "sign-sequence",
        location: "on-device",
        outcome: "recognized",
        hypotheses: [
          {
            text: english,
            confidence:
              request.minProbability === null
                ? {
                    kind: "none",
                    note: `Glosses: ${request.glosses.join(" ")}. Fingerspelled or user-chosen only.`,
                  }
                : {
                    kind: "calibrated-probability",
                    value: request.minProbability,
                    note: `Glosses: ${request.glosses.join(" ")}. Lowest calibrated sign probability.${request.userWritten ? " English written or edited by the patient." : " English from the fixed phrase table."}`,
                  },
            startSec: null,
            endSec: null,
          },
        ],
        providerReference: null,
        modelVersion: request.modelVersion,
        receivedAt: Date.now(),
      };
    },
  };
}

export const fingerspellingDescriptor: ProviderDescriptor = {
  id: "fingerspelling",
  mode: "fingerspelling",
  label: "ASL fingerspelling (on device, 24 letters)",
  summary:
    "A trained model reads static manual-alphabet letters live and spells them after each is held steady. Letters only — not signs or sentences.",
  capabilities: {
    granularity: "fingerspelling",
    input: "landmark-stream",
    location: "on-device",
    reportsConfidence: true,
    cancellable: "local-abort",
    worksOffline: true,
    vocabulary: null,
  },
  thirdParty: null,
};

export function createFingerspellingProvider(
  toolsReady: () => Promise<boolean>,
  fetcher?: typeof fetch,
): RecognitionProvider & { model: () => Promise<StaticHandModel> } {
  let loaded: Promise<StaticHandModel> | null = null;
  const model = () => {
    loaded ??= loadFingerspellingModel(fetcher).catch((failure) => {
      loaded = null;
      throw failure;
    });
    return loaded;
  };
  const resultFor = (
    text: string,
    scores: number[],
    version: string,
  ): RecognitionResult => ({
    providerId: fingerspellingDescriptor.id,
    mode: "fingerspelling",
    granularity: "fingerspelling",
    location: "on-device",
    outcome: text.trim() ? "recognized" : "unknown",
    hypotheses: text.trim()
      ? [
          {
            text: text.trim(),
            confidence: scores.length
              ? {
                  kind: "model-score",
                  value: Math.min(...scores),
                  note: "Lowest per-letter softmax score. Not a calibrated probability.",
                }
              : { kind: "none", note: "No letter scores were recorded." },
            startSec: null,
            endSec: null,
          },
        ]
      : [],
    providerReference: null,
    modelVersion: version,
    receivedAt: Date.now(),
  });
  return {
    descriptor: fingerspellingDescriptor,
    model,
    async availability(): Promise<ProviderAvailability> {
      if (!(await toolsReady().catch(() => false)))
        return {
          state: "needs-download",
          detail:
            "Download the optional on-device hand-tracking tools (about 21.8 MB) first.",
        };
      try {
        await model();
        return { state: "available" };
      } catch (failure) {
        return {
          state: "error",
          detail:
            failure instanceof Error
              ? failure.message
              : "The fingerspelling model could not be loaded.",
        };
      }
    },
    async recognize(request: RecognitionRequest): Promise<RecognitionResult> {
      const loadedModel = await model();
      const version = `${loadedModel.id}@${loadedModel.version}`;
      if (request.kind === "fingerspelling")
        return resultFor(
          request.text,
          request.letters.map((l) => l.score),
          version,
        );
      if (request.kind !== "landmark-sequence")
        throw new RecognitionError(
          "invalid-input",
          "Fingerspelling reads hand landmarks.",
        );
      validateSequence(request.sequence);
      let state = { ...emptySpeller };
      const scores: number[] = [];
      for (const frame of request.sequence.frames) {
        request.signal?.throwIfAborted();
        const hand = frame.hands.length === 1 ? frame.hands[0] : null;
        // Sequences carry normalised coordinates; assume a 4:3 frame.
        const features = hand ? handFeatures(hand.image, 640, 480) : null;
        const decision = features ? classifyHand(loadedModel, features) : null;
        const step = stepSpeller(state, {
          letter: decision?.letter ?? null,
          handPresent: frame.hands.length > 0,
          t: frame.t,
        });
        state = step.state;
        if (step.committed && decision) scores.push(decision.score);
      }
      return resultFor(spelledText(state), scores, version);
    },
  };
}

/* ---------- Mode 2: supplied local trained model ---------- */

export const localModelDescriptor: ProviderDescriptor = {
  id: "local-model",
  mode: "local-model",
  label: "Local trained model (isolated signs)",
  summary:
    "Runs a supplied, documented isolated-sign model on this device. No model is bundled.",
  capabilities: {
    granularity: "isolated-sign",
    input: "landmark-sequence",
    location: "on-device",
    reportsConfidence: true,
    cancellable: "local-abort",
    worksOffline: true,
    vocabulary: null,
  },
  thirdParty: null,
};

export function createLocalModelProvider(
  config: PublicRecognitionConfig,
  fetcher: typeof fetch = (...args) => fetch(...args),
): RecognitionProvider & {
  model: () => Promise<{
    manifest: LocalModelManifest;
    weights: DenseWeights;
    weightsUrl: string;
  }>;
} {
  let loaded: Promise<{
    manifest: LocalModelManifest;
    weights: DenseWeights;
    weightsUrl: string;
  }> | null = null;
  const model = () => {
    if (!config.localModelManifestUrl)
      return Promise.reject(
        new RecognitionError("not-configured", "No local model is configured."),
      );
    loaded ??= loadLocalModel(config.localModelManifestUrl, { fetcher }).catch(
      (failure) => {
        loaded = null;
        throw failure;
      },
    );
    return loaded;
  };
  return {
    descriptor: localModelDescriptor,
    model,
    async availability(): Promise<ProviderAvailability> {
      if (!config.localModelManifestUrl)
        return {
          state: "not-configured",
          detail:
            "No trained local model is configured. InterpretAI does not include one; see the local recognition guide.",
        };
      try {
        await model();
        return { state: "available" };
      } catch (failure) {
        return {
          state: "error",
          detail:
            failure instanceof Error
              ? failure.message
              : "The local model could not be loaded.",
        };
      }
    },
    async recognize(request: RecognitionRequest): Promise<RecognitionResult> {
      if (request.kind !== "landmark-sequence")
        throw new RecognitionError(
          "invalid-input",
          "The local model reads a landmark sequence.",
        );
      request.signal?.throwIfAborted();
      const { manifest, weights } = await model();
      request.signal?.throwIfAborted();
      const decision = classifySequence(manifest, weights, request.sequence);
      return {
        providerId: localModelDescriptor.id,
        mode: "local-model",
        granularity: "isolated-sign",
        location: "on-device",
        outcome: decision.outcome,
        hypotheses: decision.hypotheses,
        providerReference: null,
        modelVersion: `${manifest.id}@${manifest.version}`,
        receivedAt: Date.now(),
      };
    },
  };
}

/* ---------- Mode 4: nothing configured ---------- */

export const unavailableDescriptor: ProviderDescriptor = {
  id: "unavailable",
  mode: "unavailable",
  label: "Recognition off",
  summary:
    "No recognition. Use scripted cards, typing, or a qualified interpreter.",
  capabilities: {
    granularity: "handshape",
    input: "landmark-stream",
    location: "on-device",
    reportsConfidence: false,
    cancellable: "none",
    worksOffline: true,
    vocabulary: [],
  },
  thirdParty: null,
};

export const unavailableProvider: RecognitionProvider = {
  descriptor: unavailableDescriptor,
  async availability() {
    return {
      state: "not-configured",
      detail: "Recognition is not configured. Nothing will be interpreted.",
    };
  },
  async recognize() {
    throw new RecognitionError(
      "not-configured",
      "Recognition is not configured.",
    );
  },
};

/* ---------- Registry ---------- */

export type ProviderRegistry = {
  list: () => RecognitionProvider[];
  get: (id: string) => RecognitionProvider;
  byMode: (mode: RecognitionMode) => RecognitionProvider;
};

export function createRegistry(
  providers: RecognitionProvider[],
): ProviderRegistry {
  const all = [
    ...providers.filter((p) => p.descriptor.id !== "unavailable"),
    unavailableProvider,
  ];
  return {
    list: () => all,
    get: (id) => all.find((p) => p.descriptor.id === id) ?? unavailableProvider,
    byMode: (mode) =>
      all.find((p) => p.descriptor.mode === mode) ?? unavailableProvider,
  };
}

export function createDefaultRegistry(
  config: PublicRecognitionConfig,
  toolsReady: () => Promise<boolean>,
  fetcher?: typeof fetch,
  signToolsReady: () => Promise<boolean> = async () => false,
) {
  return createRegistry([
    createSignModelProvider(signToolsReady),
    createFingerspellingProvider(toolsReady, fetcher),
    createHandshapeProvider(toolsReady),
    createLocalModelProvider(config, fetcher),
    createSignSpeakProvider(config, fetcher),
    createHuggingFaceProvider(config, fetcher),
  ]);
}

/** Resolves availability for every provider, never throwing. */
export async function describeAvailability(
  registry: ProviderRegistry,
  context: AvailabilityContext,
) {
  const entries = await Promise.all(
    registry.list().map(async (provider) => {
      let availability: ProviderAvailability;
      try {
        availability = await provider.availability(context);
      } catch (failure) {
        availability = {
          state: "error",
          detail:
            failure instanceof Error ? failure.message : "Status unavailable.",
        };
      }
      // Cloud providers are never "available" while offline or in the demo outage.
      if (
        provider.descriptor.capabilities.location === "cloud" &&
        availability.state === "available"
      ) {
        if (!context.online)
          availability = { state: "offline", detail: "Offline." };
        else if (context.simulatedOffline)
          availability = { state: "simulated-outage", detail: "Demo outage." };
      }
      return [provider.descriptor.id, availability] as const;
    }),
  );
  return Object.fromEntries(entries) as Record<string, ProviderAvailability>;
}
