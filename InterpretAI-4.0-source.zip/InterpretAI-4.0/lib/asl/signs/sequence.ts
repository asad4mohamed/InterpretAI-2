/**
 * Continuous recognition history: the ordered list of signs recognised in a
 * session, with the rules that keep it honest.
 *
 *  - One segment (one sign boundary from the segmenter) gives at most one
 *    token, so a held sign is never repeated (the segmenter itself waits for
 *    new motion after a still hold).
 *  - A second token with the same sign is merged into the previous one when
 *    the previous segment ended on a short still pause (gap below
 *    MERGE_GAP_MS) or was cut by the 4-second limit: that is one sign with a
 *    pause in it (seen in real held-out clips), not two. If the hands left
 *    the frame in between, a repeat is treated as deliberate and kept.
 *  - Results below the calibrated threshold, or signed with the body partly
 *    out of frame, become "uncertain" tokens. They show the model's top
 *    guesses but block phrase suggestions until the user picks one or
 *    removes the token. Nothing is ever chosen for the user.
 *  - Fingerspelled words from the existing letter model can be inserted as
 *    "spelled" tokens (shown as #WORD, the usual gloss convention).
 */
import type { Decision } from "./decision";
import type { MovementSummary } from "./movement";
import type { Vocabulary, VocabularyEntry } from "./vocabulary";

export type Guess = {
  label: string;
  gloss: string;
  english: string;
  probability: number;
};

export type SignToken =
  | {
      id: string;
      kind: "sign";
      label: string;
      gloss: string;
      english: string;
      probability: number;
      /** True when the user picked this label from the alternatives. */
      userChosen: boolean;
      top: Guess[];
      startT: number;
      endT: number;
      endReason: string;
      movement: MovementSummary | null;
      reliability: VocabularyEntry["reliability"];
    }
  | {
      id: string;
      kind: "uncertain";
      reason: "low-confidence" | "partial";
      top: Guess[];
      startT: number;
      endT: number;
      endReason: string;
      movement: MovementSummary | null;
    }
  | {
      id: string;
      kind: "spelled";
      text: string;
      gloss: string;
      startT: number;
      endT: number;
    };

export type SequenceState = {
  tokens: SignToken[];
  /** Counts for the status line and tests. */
  merged: number;
  discarded: number;
};

export const emptySequence: SequenceState = {
  tokens: [],
  merged: 0,
  discarded: 0,
};

export type SegmentResult = {
  decision: Decision;
  startT: number;
  endT: number;
  endReason: string;
  movement: MovementSummary | null;
};

export type SequenceAction =
  | { type: "result"; id: string; result: SegmentResult }
  | { type: "discarded" }
  | { type: "choose"; id: string; label: string }
  | { type: "remove"; id: string }
  | { type: "undo" }
  | { type: "clear" }
  | { type: "spelled"; id: string; text: string; t: number };

export const MERGE_GAP_MS = 700;

export function guessesFor(
  decision: Decision,
  vocabulary: Vocabulary,
): Guess[] {
  return decision.top.flatMap((g) => {
    const entry = vocabulary.signs[g.index];
    return entry
      ? [
          {
            label: entry.modelLabel,
            gloss: entry.gloss,
            english: entry.english,
            probability: g.probability,
          },
        ]
      : [];
  });
}

export function sequenceReducer(vocabulary: Vocabulary) {
  const entryFor = (label: string) =>
    vocabulary.signs.find((s) => s.modelLabel === label);
  return function reduce(
    state: SequenceState,
    action: SequenceAction,
  ): SequenceState {
    switch (action.type) {
      case "discarded":
        return { ...state, discarded: state.discarded + 1 };
      case "result": {
        const { decision, startT, endT, endReason, movement } = action.result;
        if (decision.kind === "nothing")
          return { ...state, discarded: state.discarded + 1 };
        const top = guessesFor(decision, vocabulary);
        if (decision.kind === "not-sure") {
          return {
            ...state,
            tokens: [
              ...state.tokens,
              {
                id: action.id,
                kind: "uncertain",
                reason: decision.reason ?? "low-confidence",
                top,
                startT,
                endT,
                endReason,
                movement,
              },
            ],
          };
        }
        const best = top[0];
        const entry = best && entryFor(best.label);
        if (!best || !entry) return state;
        const previous = state.tokens[state.tokens.length - 1];
        if (
          previous?.kind === "sign" &&
          previous.label === best.label &&
          (previous.endReason === "max" ||
            (previous.endReason === "still" &&
              startT - previous.endT < MERGE_GAP_MS))
        ) {
          // Same sign continuing across a segment boundary: one token.
          const mergedToken: SignToken = {
            ...previous,
            endT,
            endReason,
            probability: Math.max(previous.probability, best.probability),
          };
          return {
            ...state,
            tokens: [...state.tokens.slice(0, -1), mergedToken],
            merged: state.merged + 1,
          };
        }
        return {
          ...state,
          tokens: [
            ...state.tokens,
            {
              id: action.id,
              kind: "sign",
              label: best.label,
              gloss: best.gloss,
              english: best.english,
              probability: best.probability,
              userChosen: false,
              top,
              startT,
              endT,
              endReason,
              movement,
              reliability: entry.reliability,
            },
          ],
        };
      }
      case "choose":
        return {
          ...state,
          tokens: state.tokens.map((token) => {
            if (token.id !== action.id || token.kind === "spelled")
              return token;
            const guess = token.top.find((g) => g.label === action.label);
            const entry = entryFor(action.label);
            if (!guess || !entry) return token;
            return {
              id: token.id,
              kind: "sign",
              label: guess.label,
              gloss: guess.gloss,
              english: guess.english,
              probability: guess.probability,
              userChosen: true,
              top: token.top,
              startT: token.startT,
              endT: token.endT,
              endReason: token.endReason,
              movement: token.movement,
              reliability: entry.reliability,
            };
          }),
        };
      case "remove":
        return {
          ...state,
          tokens: state.tokens.filter((t) => t.id !== action.id),
        };
      case "undo":
        return { ...state, tokens: state.tokens.slice(0, -1) };
      case "clear":
        return emptySequence;
      case "spelled": {
        const text = action.text
          .trim()
          .toUpperCase()
          .replace(/[^A-Z ]/g, "");
        if (!text) return state;
        return {
          ...state,
          tokens: [
            ...state.tokens,
            {
              id: action.id,
              kind: "spelled",
              text,
              gloss: `#${text.replace(/ +/g, "-")}`,
              startT: action.t,
              endT: action.t,
            },
          ],
        };
      }
    }
  };
}

/** True when every token is resolved (no uncertain tokens remain). */
export function sequenceResolved(state: SequenceState) {
  return state.tokens.every((t) => t.kind !== "uncertain");
}

export function glossLine(tokens: readonly SignToken[]) {
  return tokens.map((t) => (t.kind === "uncertain" ? "?" : t.gloss)).join(" ");
}
