/**
 * Movement over time, in the signer's own frame of reference.
 *
 * Positions are made body-relative (shoulder midpoint as origin, shoulder
 * width as unit, via computeAnchor), smoothed with an exponential moving
 * average, and short landmark dropouts are bridged. Directions are reported
 * from the SIGNER's point of view: the camera frame is unmirrored, so image
 * x increasing is the signer's left.
 *
 * Nothing here feeds the model. The model receives the raw frames exactly as
 * in training; this module only describes the motion to the user.
 */
import { computeAnchor, leftIsDominant } from "./features";
import {
  HAND_WRIST,
  LEFT_HAND_START,
  N_HAND,
  POSE_START,
  RIGHT_HAND_START,
  type Frame,
} from "./landmarks";

export type Direction =
  | "up"
  | "down"
  | "signer-left"
  | "signer-right"
  | "up-signer-left"
  | "up-signer-right"
  | "down-signer-left"
  | "down-signer-right"
  | "still";

export type Region = "head" | "chest" | "lower" | "unknown";

export type Point2 = { x: number; y: number };

export const directionText: Record<Direction, string> = {
  up: "up",
  down: "down",
  "signer-left": "to the signer’s left",
  "signer-right": "to the signer’s right",
  "up-signer-left": "up and to the signer’s left",
  "up-signer-right": "up and to the signer’s right",
  "down-signer-left": "down and to the signer’s left",
  "down-signer-right": "down and to the signer’s right",
  still: "held in place",
};

/** Body-relative displacement → signer-perspective direction. */
export function directionOf(
  dx: number,
  dy: number,
  minDistance = 0.15,
): Direction {
  // Body-relative x grows toward the signer's left (unmirrored camera).
  const right = -dx;
  const up = -dy;
  if (!(Math.hypot(right, up) >= minDistance)) return "still";
  const angle = (Math.atan2(up, right) * 180) / Math.PI; // 0 = signer-right
  const sector = Math.round(angle / 45);
  switch (((sector % 8) + 8) % 8) {
    case 0:
      return "signer-right";
    case 1:
      return "up-signer-right";
    case 2:
      return "up";
    case 3:
      return "up-signer-left";
    case 4:
      return "signer-left";
    case 5:
      return "down-signer-left";
    case 6:
      return "down";
    default:
      return "down-signer-right";
  }
}

const wrist = (f: Frame, start: number): Point2 | null => {
  const x = f[(start + HAND_WRIST) * 3];
  const y = f[(start + HAND_WRIST) * 3 + 1];
  return Number.isFinite(x) && Number.isFinite(y) ? { x: x!, y: y! } : null;
};

const handSeen = (f: Frame, start: number) => {
  for (let i = 0; i < N_HAND; i++)
    if (Number.isFinite(f[(start + i) * 3])) return true;
  return false;
};

/** Where a hand is relative to the body: head (above the shoulders), chest, lower. */
export function regionOf(f: Frame, point: Point2): Region {
  const anchor = computeAnchor([f]);
  const noseY = f[(POSE_START + 0) * 3 + 1];
  const hasPose = Number.isFinite(f[(POSE_START + 11) * 3]);
  if (!hasPose) return "unknown";
  const rel = (point.y - anchor.cy) / anchor.scale;
  const headLine = Number.isFinite(noseY)
    ? (noseY! - anchor.cy) / anchor.scale / 2
    : -0.35;
  if (rel < headLine) return "head";
  if (rel < 0.9) return "chest";
  return "lower";
}

export type MovementSummary = {
  dominant: "left" | "right";
  twoHanded: boolean;
  direction: Direction;
  /** Path length of the dominant wrist, in shoulder widths. */
  pathLength: number;
  startRegion: Region;
  endRegion: Region;
  durationMs: number;
  /** Up to 16 smoothed body-relative points (signer-perspective x). */
  trajectory: Point2[];
  /** Frames where the dominant hand was missing and bridged or skipped. */
  missingFrames: number;
};

/**
 * Smoothed, gap-bridged trajectory of one wrist in body-relative units.
 * Gaps of up to `maxGap` frames hold the last position; longer gaps restart
 * the smoother so a re-entering hand does not draw a jump.
 */
export function smoothTrajectory(
  frames: readonly Frame[],
  start: number,
  alpha = 0.5,
  maxGap = 3,
): { points: (Point2 | null)[]; missing: number } {
  const anchor = computeAnchor(frames);
  let state: Point2 | null = null;
  let gap = 0;
  let missing = 0;
  const points = frames.map((f) => {
    const raw = wrist(f, start);
    if (!raw) {
      missing++;
      gap++;
      if (gap > maxGap) state = null;
      return state;
    }
    gap = 0;
    const p = {
      x: (raw.x - anchor.cx) / anchor.scale,
      y: (raw.y - anchor.cy) / anchor.scale,
    };
    state = state
      ? {
          x: state.x + alpha * (p.x - state.x),
          y: state.y + alpha * (p.y - state.y),
        }
      : p;
    return state;
  });
  return { points, missing };
}

export function summarizeMovement(
  frames: readonly Frame[],
  timestamps: readonly number[],
): MovementSummary | null {
  if (frames.length === 0) return null;
  const leftDominant = leftIsDominant(frames);
  const start = leftDominant ? LEFT_HAND_START : RIGHT_HAND_START;
  const other = leftDominant ? RIGHT_HAND_START : LEFT_HAND_START;
  const { points, missing } = smoothTrajectory(frames, start);
  const seen = points.filter((p): p is Point2 => p !== null);
  if (seen.length === 0) return null;
  let path = 0;
  for (let i = 1; i < seen.length; i++)
    path += Math.hypot(
      seen[i]!.x - seen[i - 1]!.x,
      seen[i]!.y - seen[i - 1]!.y,
    );
  const first = seen[0]!;
  const last = seen[seen.length - 1]!;
  const firstIndex = points.findIndex((p) => p !== null);
  let lastIndex = points.length - 1;
  while (lastIndex > 0 && points[lastIndex] === null) lastIndex--;
  const rawStart = wrist(frames[firstIndex]!, start);
  const rawEnd = wrist(frames[lastIndex]!, start);
  const otherFrames = frames.filter((f) => handSeen(f, other)).length;
  const step = Math.max(1, Math.ceil(seen.length / 16));
  return {
    dominant: leftDominant ? "left" : "right",
    twoHanded: otherFrames >= Math.max(2, frames.length * 0.3),
    direction: directionOf(last.x - first.x, last.y - first.y),
    pathLength: Math.round(path * 100) / 100,
    startRegion: rawStart ? regionOf(frames[firstIndex]!, rawStart) : "unknown",
    endRegion: rawEnd ? regionOf(frames[lastIndex]!, rawEnd) : "unknown",
    durationMs: Math.max(
      0,
      (timestamps[timestamps.length - 1] ?? 0) - (timestamps[0] ?? 0),
    ),
    trajectory: seen
      .filter((_, i) => i % step === 0)
      .map((p) => ({ x: -p.x, y: p.y })),
    missingFrames: missing,
  };
}

export type LiveMovement = {
  /** Smoothed dominant-hand speed, shoulder widths per second. */
  speed: number;
  direction: Direction;
  moving: boolean;
};

/**
 * Per-frame movement indicator for the UI. Uses the hand closest to moving
 * (fastest), smoothed, and reports the direction over the last ~300 ms.
 */
export class LiveMovementTracker {
  private history: { t: number; left: Point2 | null; right: Point2 | null }[] =
    [];
  private speed = 0;
  constructor(
    private readonly windowMs = 300,
    private readonly moveSpeed = 0.6,
  ) {}

  reset() {
    this.history = [];
    this.speed = 0;
  }

  push(frame: Frame, t: number): LiveMovement {
    const anchor = computeAnchor([frame]);
    const rel = (p: Point2 | null) =>
      p
        ? {
            x: (p.x - anchor.cx) / anchor.scale,
            y: (p.y - anchor.cy) / anchor.scale,
          }
        : null;
    const sample = {
      t,
      left: rel(wrist(frame, LEFT_HAND_START)),
      right: rel(wrist(frame, RIGHT_HAND_START)),
    };
    this.history = [...this.history, sample].filter(
      (s) => t - s.t <= this.windowMs,
    );
    const oldest = this.history[0]!;
    const dt = (t - oldest.t) / 1000;
    let best = { d: 0, dx: 0, dy: 0 };
    for (const side of ["left", "right"] as const) {
      const a = oldest[side];
      const b = sample[side];
      if (!a || !b) continue;
      const d = Math.hypot(b.x - a.x, b.y - a.y);
      if (d > best.d) best = { d, dx: b.x - a.x, dy: b.y - a.y };
    }
    const instant = dt > 0 ? best.d / dt : 0;
    const present = sample.left || sample.right;
    this.speed = present ? 0.5 * this.speed + 0.5 * instant : 0;
    const moving = this.speed >= this.moveSpeed;
    return {
      speed: Math.round(this.speed * 100) / 100,
      moving,
      direction: moving ? directionOf(best.dx, best.dy, 0.05) : "still",
    };
  }
}
