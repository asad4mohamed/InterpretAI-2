/**
 * Short conversational phrases assembled from recognised signs.
 *
 * This is a small, closed table of gloss patterns, not translation. A
 * sequence gets an English suggestion only when it matches a documented
 * pattern exactly, using only signs the model really outputs (or words the
 * user fingerspelled). Anything else is reported as unsupported, with the
 * glosses shown as recognised, and the user may write their own English.
 * Suggestions are always editable and must be confirmed by the user.
 *
 * Every pattern is checked against the model vocabulary at load time
 * (phraseCoverage), so a pattern can never reference a sign the model lacks.
 */
import type { SignToken } from "./sequence";

/** A step in a pattern: a model sign label, or a fingerspelled word. */
export type PatternStep = { sign: string } | { spelled: string };

export type PhrasePattern = {
  id: string;
  steps: PatternStep[];
  /** English suggestions, best first. */
  english: string[];
  /** The documented target phrase this pattern serves, if any. */
  target?: TargetPhrase;
  note?: string;
};

export const TARGET_PHRASES = [
  "Hi, how are you?",
  "I am fine",
  "What is your name?",
  "Thank you",
  "I need help",
  "I want water",
  "Where is the bathroom?",
] as const;
export type TargetPhrase = (typeof TARGET_PHRASES)[number];

export const PHRASE_PATTERNS: readonly PhrasePattern[] = [
  {
    id: "greeting",
    steps: [{ sign: "hello" }],
    english: ["Hi.", "Hello."],
    target: "Hi, how are you?",
    note: "Only the greeting is supported: HOW and YOU are not in the model vocabulary.",
  },
  {
    id: "fine",
    steps: [{ sign: "fine" }],
    english: ["I'm fine.", "Fine."],
    target: "I am fine",
    note: "FINE on its own is a common reply. The first-person point (ME) is not in the vocabulary, so “I” is implied.",
  },
  {
    id: "hello-fine",
    steps: [{ sign: "hello" }, { sign: "fine" }],
    english: ["Hi, I'm fine."],
  },
  {
    id: "thank-you",
    steps: [{ sign: "thankyou" }],
    english: ["Thank you."],
    target: "Thank you",
  },
  {
    id: "help-spelled",
    steps: [{ spelled: "HELP" }],
    english: ["I need help."],
    target: "I need help",
    note: "HELP is not in the sign vocabulary. This works only by fingerspelling H-E-L-P with the letter model.",
  },
  {
    id: "water",
    steps: [{ sign: "water" }],
    english: ["I want water.", "Water, please."],
    target: "I want water",
    note: "WANT is not in the vocabulary; “want” is a suggestion you must confirm.",
  },
  {
    id: "water-please",
    steps: [{ sign: "water" }, { sign: "please" }],
    english: ["Water, please.", "I want water, please."],
    target: "I want water",
  },
  {
    id: "drink-water",
    steps: [{ sign: "drink" }, { sign: "water" }],
    english: ["I want to drink water."],
    target: "I want water",
  },
  {
    id: "thirsty",
    steps: [{ sign: "thirsty" }],
    english: ["I'm thirsty."],
  },
  {
    id: "thirsty-water",
    steps: [{ sign: "thirsty" }, { sign: "water" }],
    english: ["I'm thirsty. I want water."],
    target: "I want water",
  },
  {
    id: "bathroom-where",
    steps: [{ sign: "potty" }, { sign: "where" }],
    english: ["Where is the bathroom?"],
    target: "Where is the bathroom?",
    note: "Uses the model's POTTY class (a child-directed label); confirm with a Deaf reviewer that it matches the adult TOILET sign.",
  },
  {
    id: "where-bathroom",
    steps: [{ sign: "where" }, { sign: "potty" }],
    english: ["Where is the bathroom?"],
    target: "Where is the bathroom?",
  },
  {
    id: "bathroom",
    steps: [{ sign: "potty" }],
    english: ["I need the bathroom."],
  },
  {
    id: "sick",
    steps: [{ sign: "sick" }],
    english: ["I feel sick."],
  },
  {
    id: "hurt",
    steps: [{ sign: "owie" }],
    english: ["It hurts."],
    note: "OWIE is a child-directed label; confirm it matches the adult HURT sign.",
  },
  { id: "hungry", steps: [{ sign: "hungry" }], english: ["I'm hungry."] },
  { id: "sleepy", steps: [{ sign: "sleepy" }], english: ["I'm sleepy."] },
  { id: "hot", steps: [{ sign: "hot" }], english: ["I'm hot.", "It's hot."] },
  { id: "yes", steps: [{ sign: "yes" }], english: ["Yes."] },
  { id: "no", steps: [{ sign: "no" }], english: ["No."] },
  { id: "wait", steps: [{ sign: "wait" }], english: ["Please wait."] },
  { id: "bye", steps: [{ sign: "bye" }], english: ["Goodbye."] },
];

/** How each documented target phrase is (or is not) covered. */
export const TARGET_COVERAGE: Record<
  TargetPhrase,
  { status: "supported" | "partial" | "unsupported"; detail: string }
> = {
  "Hi, how are you?": {
    status: "partial",
    detail:
      "HELLO is recognised. HOW and YOU are not in the vocabulary, so “how are you” cannot be recognised.",
  },
  "I am fine": {
    status: "supported",
    detail: "FINE → “I'm fine.” (ME is not in the vocabulary; it is implied).",
  },
  "What is your name?": {
    status: "unsupported",
    detail:
      "WHAT, YOUR and NAME are not in the vocabulary. No pattern exists; the app says so instead of guessing.",
  },
  "Thank you": { status: "supported", detail: "THANK-YOU → “Thank you.”" },
  "I need help": {
    status: "partial",
    detail:
      "HELP is not a vocabulary sign. Fingerspelling #HELP (letter model) → “I need help.”",
  },
  "I want water": {
    status: "supported",
    detail:
      "WATER, DRINK WATER, WATER PLEASE, THIRSTY WATER → “I want water.” (WANT is implied and must be confirmed).",
  },
  "Where is the bathroom?": {
    status: "partial",
    detail:
      "POTTY WHERE / WHERE POTTY → “Where is the bathroom?”. POTTY is a child-directed class that needs Deaf review.",
  },
};

export type PhraseMatch =
  | { kind: "empty" }
  | { kind: "uncertain"; count: number }
  | { kind: "matched"; patterns: PhrasePattern[]; suggestions: string[] }
  | { kind: "unsupported"; glosses: string };

const stepMatches = (step: PatternStep, token: SignToken) =>
  "sign" in step
    ? token.kind === "sign" && token.label === step.sign
    : token.kind === "spelled" && token.text === step.spelled;

export function matchPhrase(
  tokens: readonly SignToken[],
  patterns: readonly PhrasePattern[] = PHRASE_PATTERNS,
): PhraseMatch {
  if (tokens.length === 0) return { kind: "empty" };
  const uncertain = tokens.filter((t) => t.kind === "uncertain").length;
  if (uncertain) return { kind: "uncertain", count: uncertain };
  const matched = patterns.filter(
    (p) =>
      p.steps.length === tokens.length &&
      p.steps.every((step, i) => stepMatches(step, tokens[i]!)),
  );
  if (matched.length === 0)
    return {
      kind: "unsupported",
      glosses: tokens
        .map((t) => (t.kind === "uncertain" ? "?" : t.gloss))
        .join(" "),
    };
  return {
    kind: "matched",
    patterns: matched,
    suggestions: [...new Set(matched.flatMap((p) => p.english))],
  };
}

/** Patterns referencing signs the model does not output (must be empty). */
export function phraseCoverage(
  modelLabels: readonly string[],
  patterns: readonly PhrasePattern[] = PHRASE_PATTERNS,
) {
  const known = new Set(modelLabels);
  return patterns.flatMap((p) =>
    p.steps.flatMap((s) =>
      "sign" in s && !known.has(s.sign) ? [`${p.id}:${s.sign}`] : [],
    ),
  );
}
