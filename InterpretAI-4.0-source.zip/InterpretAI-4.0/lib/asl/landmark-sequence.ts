import type {
  Handedness,
  HandObservation,
  LandmarkFrame,
  LandmarkPoint,
  LandmarkSequence,
} from "./types";

/**
 * Temporal landmark sequences for future isolated-sign models.
 *
 * Coordinate conventions (documented in docs/LOCAL-RECOGNITION.md):
 *  - MediaPipe image landmarks: x,y normalised to the UNMIRRORED camera frame
 *    (0..1), z relative depth with the wrist as origin.
 *  - MediaPipe world landmarks: metres, origin near the hand's centre.
 *  - Handedness: MediaPipe assumes a mirrored selfie image. InterpretAI sends
 *    unmirrored frames, so the label is swapped once in `signerHandedness`
 *    to describe the signer's anatomical hand.
 */

export const LANDMARKS_PER_HAND = 21;
export const SLOT_ORDER: readonly Handedness[] = ["Right", "Left"];
/** presence + 21×3 hand shape + wrist location (x, y) + palm scale */
export const FEATURES_PER_SLOT = 1 + LANDMARKS_PER_HAND * 3 + 3;
export const FEATURES_PER_FRAME = FEATURES_PER_SLOT * SLOT_ORDER.length;

export function signerHandedness(mediaPipeLabel: string): Handedness | null {
  if (mediaPipeLabel === "Left") return "Right";
  if (mediaPipeLabel === "Right") return "Left";
  return null;
}

const sub = (a: LandmarkPoint, b: LandmarkPoint) => ({
  x: a.x - b.x,
  y: a.y - b.y,
  z: a.z - b.z,
});
const length = (p: LandmarkPoint) => Math.hypot(p.x, p.y, p.z);

/**
 * Hand-shape normalisation: translate world landmarks so the wrist is the
 * origin and divide by wrist→middle-finger-MCP length. The result is
 * invariant to hand size and position, but NOT to rotation (orientation is
 * linguistically meaningful in ASL and is kept).
 */
export function normalizeHandShape(world: readonly LandmarkPoint[]) {
  const wrist = world[0];
  const scale = length(sub(world[9], wrist));
  if (!(scale > 1e-6)) return null;
  return world.map((p) => {
    const d = sub(p, wrist);
    return { x: d.x / scale, y: d.y / scale, z: d.z / scale };
  });
}

/**
 * Hand location in the frame: wrist position relative to frame centre in
 * [-0.5, 0.5] plus the apparent palm size (a rough distance-to-camera cue).
 * Without pose landmarks this is camera-relative, not body-relative.
 */
export function handLocation(image: readonly LandmarkPoint[]) {
  const wrist = image[0];
  const palm = Math.hypot(image[9].x - wrist.x, image[9].y - wrist.y);
  return { x: wrist.x - 0.5, y: wrist.y - 0.5, scale: palm };
}

/** Exponential smoothing of world landmarks per hand slot. Resets on absence. */
export function smoothSequence(
  sequence: LandmarkSequence,
  alpha = 0.5,
): LandmarkSequence {
  const a = Math.min(1, Math.max(0.05, alpha));
  const previous = new Map<Handedness, HandObservation>();
  const frames: LandmarkFrame[] = sequence.frames.map((frame) => {
    const seen = new Set<Handedness>();
    const hands = frame.hands.map((hand) => {
      seen.add(hand.handedness);
      const before = previous.get(hand.handedness);
      const blend = (cur: LandmarkPoint[], old?: LandmarkPoint[]) =>
        old
          ? cur.map((p, i) => ({
              x: a * p.x + (1 - a) * old[i].x,
              y: a * p.y + (1 - a) * old[i].y,
              z: a * p.z + (1 - a) * old[i].z,
            }))
          : cur;
      const smoothed: HandObservation = {
        ...hand,
        image: blend(hand.image, before?.image),
        world: blend(hand.world, before?.world),
      };
      previous.set(hand.handedness, smoothed);
      return smoothed;
    });
    for (const key of [...previous.keys()])
      if (!seen.has(key)) previous.delete(key);
    return { t: frame.t, hands };
  });
  return { format: sequence.format, frames };
}

function frameFeatures(frame: LandmarkFrame) {
  const out = new Float32Array(FEATURES_PER_FRAME);
  SLOT_ORDER.forEach((side, slot) => {
    const hand = frame.hands.find((h) => h.handedness === side);
    if (!hand) return; // absent hand: presence 0, all zeros
    const shape = normalizeHandShape(hand.world);
    if (!shape) return;
    const base = slot * FEATURES_PER_SLOT;
    out[base] = 1;
    shape.forEach((p, i) => {
      out[base + 1 + i * 3] = p.x;
      out[base + 2 + i * 3] = p.y;
      out[base + 3 + i * 3] = p.z;
    });
    const loc = handLocation(hand.image);
    out[base + 1 + LANDMARKS_PER_HAND * 3] = loc.x;
    out[base + 2 + LANDMARKS_PER_HAND * 3] = loc.y;
    out[base + 3 + LANDMARKS_PER_HAND * 3] = loc.scale;
  });
  return out;
}

/**
 * Resamples a sequence to `count` evenly spaced instants. Present-hand
 * features are linearly interpolated only when both neighbours have the hand;
 * otherwise the nearest frame is used so absence is never invented away.
 */
export function sequenceToFeatures(sequence: LandmarkSequence, count: number) {
  const frames = sequence.frames;
  const per = frames.map(frameFeatures);
  const start = frames[0].t;
  const end = frames[frames.length - 1].t;
  const out = new Float32Array(count * FEATURES_PER_FRAME);
  for (let k = 0; k < count; k++) {
    const t = count === 1 ? start : start + ((end - start) * k) / (count - 1);
    let j = 0;
    while (j < frames.length - 2 && frames[j + 1].t < t) j++;
    const t0 = frames[j].t;
    const t1 = frames[j + 1].t;
    const w = t1 > t0 ? Math.min(1, Math.max(0, (t - t0) / (t1 - t0))) : 0;
    const a = per[j];
    const b = per[j + 1];
    for (let slot = 0; slot < SLOT_ORDER.length; slot++) {
      const base = slot * FEATURES_PER_SLOT;
      const both = a[base] === 1 && b[base] === 1;
      for (let f = 0; f < FEATURES_PER_SLOT; f++) {
        const value = both
          ? a[base + f] * (1 - w) + b[base + f] * w
          : (w < 0.5 ? a : b)[base + f];
        out[k * FEATURES_PER_FRAME + base + f] = value;
      }
    }
  }
  return out;
}

/** Share of frames in which at least one hand was observed. */
export function handCoverage(sequence: LandmarkSequence) {
  if (!sequence.frames.length) return 0;
  return (
    sequence.frames.filter((frame) => frame.hands.length > 0).length /
    sequence.frames.length
  );
}

/** Bounded in-memory recorder used during an explicit capture window only. */
export class SequenceRecorder {
  private frames: LandmarkFrame[] = [];
  constructor(private readonly maxFrames = 300) {}
  push(frame: LandmarkFrame) {
    const last = this.frames[this.frames.length - 1];
    if (last && frame.t <= last.t) return false;
    if (this.frames.length >= this.maxFrames) return false;
    this.frames.push(frame);
    return true;
  }
  get size() {
    return this.frames.length;
  }
  finish(): LandmarkSequence {
    const frames = this.frames;
    this.frames = [];
    return { format: "interpretai.landmarks.v1", frames };
  }
  clear() {
    this.frames = [];
  }
}
