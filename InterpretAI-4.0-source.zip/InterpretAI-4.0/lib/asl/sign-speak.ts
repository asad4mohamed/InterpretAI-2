import {
  RecognitionError,
  type AvailabilityContext,
  type ProcessingStatus,
  type ProviderAvailability,
  type ProviderDescriptor,
  type PublicRecognitionConfig,
  type RecognitionProvider,
  type RecognitionRequest,
  type RecognitionResult,
} from "./types";
import { parseSignSpeakRecognition, validateClip } from "./validation";

/**
 * Mode 3 — Sign-Speak ASL recognition through InterpretAI's optional proxy.
 *
 * The browser never sees the Sign-Speak key. It talks only to
 * `server/proxy.mjs`, which adds the provider key header server-side, calls
 * https://api.sign-speak.com/recognize-sign and relays Sign-Speak's
 * documented 202 + batch_id polling. See docs/API-INTEGRATION.md for the
 * provenance of every endpoint and field used.
 */

export const signSpeakDescriptor: ProviderDescriptor = {
  id: "sign-speak",
  mode: "external-api",
  label: "Sign-Speak (cloud API)",
  summary:
    "Sends one reviewed video clip to Sign-Speak through the secure proxy. Returns the provider's English text.",
  capabilities: {
    granularity: "continuous-english",
    input: "video-clip",
    location: "cloud",
    reportsConfidence: true,
    cancellable: "local-abort",
    worksOffline: false,
    vocabulary: null,
  },
  thirdParty: {
    name: "Sign-Speak",
    documentationUrl:
      "https://app.theneo.io/sign-speak/sign-speak-api/api-specifications",
  },
};

export type ProxyHealth = {
  ok: boolean;
  signSpeak: { recognition: boolean; production: boolean };
  huggingFace: {
    configured: boolean;
    tokenSet: boolean;
    target: "dedicated-endpoint" | "hf-inference" | null;
    modelId: string | null;
  };
};

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason);
    const id = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(id);
        reject(signal.reason);
      },
      { once: true },
    );
  });

/** Combines a caller signal with a timeout, without relying on AbortSignal.any. */
export function withTimeout(signal: AbortSignal | undefined, ms: number) {
  const controller = new AbortController();
  const timer = setTimeout(
    () =>
      controller.abort(
        new RecognitionError(
          "timeout",
          "The recognition service did not answer in time. Nothing was displayed.",
        ),
      ),
    ms,
  );
  const forward = () =>
    controller.abort(
      new RecognitionError("cancelled", "Recognition was cancelled."),
    );
  if (signal?.aborted) forward();
  signal?.addEventListener("abort", forward, { once: true });
  return {
    signal: controller.signal,
    dispose: () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", forward);
    },
  };
}

export function errorForStatus(
  status: number,
  message?: string,
): RecognitionError {
  if (status === 401 || status === 403)
    return new RecognitionError(
      "auth-failed",
      "The recognition service rejected the configured credentials. An administrator must update the proxy key.",
    );
  if (status === 429)
    return new RecognitionError(
      "rate-limited",
      "The recognition service rate limit or quota was reached. Try again later.",
    );
  if (status === 413 || status === 400 || status === 415)
    return new RecognitionError(
      "invalid-input",
      message || "The recognition service could not accept this clip.",
    );
  if (status === 503)
    return new RecognitionError(
      "not-configured",
      message || "The proxy is running but Sign-Speak is not configured.",
    );
  if (status === 504)
    return new RecognitionError(
      "timeout",
      "The recognition service did not answer in time. Nothing was displayed.",
    );
  return new RecognitionError(
    "provider-error",
    `The recognition service returned an error (HTTP ${status}). Nothing was displayed.`,
  );
}

export async function readJson(response: Response) {
  try {
    return (await response.json()) as unknown;
  } catch {
    throw new RecognitionError(
      "invalid-response",
      "The recognition proxy returned an unreadable response. Nothing was displayed.",
    );
  }
}

export const proxyMessage = (data: unknown) =>
  data && typeof data === "object" && "error" in data
    ? String((data as { error?: { message?: unknown } }).error?.message ?? "")
    : undefined;

export async function fetchProxyHealth(
  proxyUrl: string,
  fetcher: typeof fetch = fetch,
  timeoutMs = 4000,
): Promise<ProxyHealth | null> {
  const { signal, dispose } = withTimeout(undefined, timeoutMs);
  try {
    const response = await fetcher(`${proxyUrl}/health`, {
      signal,
      cache: "no-store",
    });
    if (!response.ok) return null;
    const data = (await response.json()) as Partial<ProxyHealth>;
    return {
      ok: data.ok === true,
      signSpeak: {
        recognition: data.signSpeak?.recognition === true,
        production: data.signSpeak?.production === true,
      },
      huggingFace: {
        configured: data.huggingFace?.configured === true,
        tokenSet: data.huggingFace?.tokenSet === true,
        target:
          data.huggingFace?.target === "dedicated-endpoint" ||
          data.huggingFace?.target === "hf-inference"
            ? data.huggingFace.target
            : null,
        modelId:
          typeof data.huggingFace?.modelId === "string"
            ? data.huggingFace.modelId
            : null,
      },
    };
  } catch {
    return null;
  } finally {
    dispose();
  }
}

export function createSignSpeakProvider(
  config: PublicRecognitionConfig,
  fetcher: typeof fetch = (...args) => fetch(...args),
  pollIntervalMs = 1500,
): RecognitionProvider {
  return {
    descriptor: signSpeakDescriptor,
    async availability(
      context: AvailabilityContext,
    ): Promise<ProviderAvailability> {
      if (!config.proxyUrl)
        return {
          state: "not-configured",
          detail:
            "No secure recognition proxy is configured. See the API integration guide.",
        };
      if (!context.online)
        return {
          state: "offline",
          detail:
            "Cloud recognition needs a network connection. On-device tools remain available.",
        };
      if (context.simulatedOffline)
        return {
          state: "simulated-outage",
          detail:
            "The demo outage is on. Cloud recognition is disabled until you restore the demo connection.",
        };
      const health = await fetchProxyHealth(config.proxyUrl, fetcher);
      if (!health)
        return {
          state: "error",
          detail: "The recognition proxy could not be reached.",
        };
      if (!health.signSpeak.recognition)
        return {
          state: "not-configured",
          detail:
            "The proxy is running, but no Sign-Speak key is set on the server.",
        };
      return { state: "available" };
    },
    async recognize(
      request: RecognitionRequest,
      onStatus?: (s: ProcessingStatus) => void,
    ): Promise<RecognitionResult> {
      if (!config.proxyUrl)
        throw new RecognitionError(
          "not-configured",
          "Sign-Speak recognition is not configured.",
        );
      if (request.kind !== "video-clip")
        throw new RecognitionError(
          "invalid-input",
          "Sign-Speak accepts a recorded video clip.",
        );
      if (request.consent.thirdPartyUpload?.provider !== signSpeakDescriptor.id)
        throw new RecognitionError(
          "consent-required",
          "Explicit consent is required before this clip is sent to Sign-Speak.",
        );
      onStatus?.({ phase: "validating" });
      const mime = validateClip(request.clip, config);
      const { signal, dispose } = withTimeout(
        request.signal,
        config.requestTimeoutMs,
      );
      const fail = (failure: unknown): never => {
        if (failure instanceof RecognitionError) throw failure;
        if (signal.aborted && signal.reason instanceof RecognitionError)
          throw signal.reason;
        throw new RecognitionError(
          "network",
          "The recognition proxy could not be reached. Nothing was sent or displayed.",
        );
      };
      try {
        onStatus?.({ phase: "uploading" });
        let response: Response;
        try {
          response = await fetcher(
            `${config.proxyUrl}/v1/sign-speak/recognize`,
            {
              method: "POST",
              headers: {
                "Content-Type": mime,
                "X-InterpretAI-Consent": "sign-speak",
              },
              body: request.clip.blob,
              signal,
              cache: "no-store",
            },
          );
        } catch (failure) {
          return fail(failure);
        }
        let data = await readJson(response);
        if (!response.ok)
          throw errorForStatus(response.status, proxyMessage(data));
        let attempt = 0;
        while (response.status === 202) {
          const id = (data as { requestId?: unknown }).requestId;
          if (typeof id !== "string" || !/^[\w-]{1,128}$/.test(id))
            throw new RecognitionError(
              "invalid-response",
              "The proxy did not return a valid request ID.",
            );
          attempt++;
          onStatus?.({ phase: "polling", attempt });
          try {
            await sleep(pollIntervalMs, signal);
            response = await fetcher(
              `${config.proxyUrl}/v1/sign-speak/recognize/${encodeURIComponent(id)}`,
              { signal, cache: "no-store" },
            );
          } catch (failure) {
            return fail(failure);
          }
          data = await readJson(response);
          if (!response.ok)
            throw errorForStatus(response.status, proxyMessage(data));
        }
        const payload = data as { status?: unknown; result?: unknown };
        if (payload.status !== "completed")
          throw new RecognitionError(
            "invalid-response",
            "The proxy response did not contain a completed result.",
          );
        const parsed = parseSignSpeakRecognition(payload.result);
        onStatus?.({ phase: "complete" });
        return {
          providerId: signSpeakDescriptor.id,
          mode: "external-api",
          granularity: "continuous-english",
          location: "cloud",
          hypotheses: parsed.hypotheses,
          outcome: parsed.hypotheses.length ? "recognized" : "unknown",
          providerReference: parsed.reference,
          modelVersion: null,
          receivedAt: Date.now(),
        };
      } catch (failure) {
        if (failure instanceof RecognitionError) {
          onStatus?.({ phase: "failed", code: failure.code });
          throw failure;
        }
        return fail(failure);
      } finally {
        dispose();
      }
    },
  };
}
