import type { RiskTopic } from "../scenarios";
import type {
  ConfidenceReport,
  ProcessingLocation,
  RecognitionErrorCode,
  RecognitionResult,
} from "./types";

/** Every user-visible state of the experimental recognition workspace. */
export type WorkspacePhase =
  | "camera-off"
  | "permission-required"
  | "model-loading"
  | "camera-ready"
  | "tracking"
  | "no-hands"
  | "tracking-lost"
  | "handshape-detected"
  | "letter-detected"
  | "capturing"
  | "awaiting-consent"
  | "processing"
  | "completed"
  | "unknown"
  | "unavailable"
  | "auth-failed"
  | "offline"
  | "error"
  | "interpreter-recommended";

export const phaseLabels: Record<WorkspacePhase, string> = {
  "camera-off": "Camera off",
  "permission-required": "Camera permission required",
  "model-loading": "Loading on-device model",
  "camera-ready": "Camera ready",
  tracking: "Tracking active",
  "no-hands": "No hands detected",
  "tracking-lost": "Tracking lost",
  "handshape-detected": "Experimental handshape detected",
  "letter-detected": "Fingerspelled letter detected",
  capturing: "Capturing",
  "awaiting-consent": "Review clip before sending",
  processing: "Recognition processing",
  completed: "Recognition completed — review required",
  unknown: "Unknown or unrecognised sign",
  unavailable: "Recognition unavailable",
  "auth-failed": "API authentication failed",
  offline: "Offline mode",
  error: "Something went wrong",
  "interpreter-recommended": "Qualified interpreter recommended",
};

export function phaseForError(code: RecognitionErrorCode): WorkspacePhase {
  switch (code) {
    case "auth-failed":
      return "auth-failed";
    case "offline":
    case "simulated-outage":
      return "offline";
    case "not-configured":
      return "unavailable";
    case "cancelled":
      return "camera-ready";
    default:
      return "error";
  }
}

export type EntrySource =
  | "asl-signs"
  | "experimental-handshape"
  | "fingerspelling"
  | "local-model"
  | "sign-speak"
  | "huggingface"
  | "typed"
  | "system";

export type EntryStatus =
  | "pending-review"
  | "confirmed"
  | "rejected"
  | "corrected"
  | "sent"
  | "escalated";

export type ConversationEntry = {
  id: string;
  author: "patient" | "provider" | "system";
  text: string;
  source: EntrySource;
  location: ProcessingLocation | "none";
  status: EntryStatus;
  confidence?: ConfidenceReport;
  modelVersion?: string | null;
  risk?: RiskTopic;
  correctedFrom?: string;
};

export type ConversationState = {
  entries: ConversationEntry[];
  escalation: RiskTopic | null;
};

export type ConversationAction =
  | {
      type: "recognized";
      id: string;
      result: RecognitionResult;
      risk?: RiskTopic;
    }
  | { type: "provider-text"; id: string; text: string; risk?: RiskTopic }
  | { type: "confirm"; id: string }
  | { type: "reject"; id: string }
  | { type: "correct"; id: string; text: string; risk?: RiskTopic }
  | { type: "edit-provider"; id: string; text: string; risk?: RiskTopic }
  | { type: "escalate"; risk: RiskTopic }
  | { type: "clear" };

export const emptyConversation: ConversationState = {
  entries: [],
  escalation: null,
};

const knownSources: EntrySource[] = [
  "asl-signs",
  "experimental-handshape",
  "fingerspelling",
  "local-model",
  "sign-speak",
  "huggingface",
];
const sourceFor = (providerId: string): EntrySource =>
  knownSources.find((source) => source === providerId) ??
  "experimental-handshape";

/** Only patient-confirmed (or patient-corrected) output enters the conversation. */
export function inConversation(entry: ConversationEntry) {
  return (
    entry.author === "provider" ||
    entry.status === "confirmed" ||
    entry.status === "corrected"
  );
}

/**
 * Pure conversation reducer. Recognised text always starts as
 * "pending-review"; only the patient can confirm, reject, or correct it.
 * Any high-risk topic marks the conversation as escalated, which persists
 * until the conversation is cleared.
 */
export function conversationReducer(
  state: ConversationState,
  action: ConversationAction,
): ConversationState {
  const update = (id: string, patch: Partial<ConversationEntry>) =>
    state.entries.map((e) => (e.id === id ? { ...e, ...patch } : e));
  switch (action.type) {
    case "recognized": {
      const top = action.result.hypotheses[0];
      if (!top) return state; // unknown results never become conversation text
      return {
        entries: [
          ...state.entries,
          {
            id: action.id,
            author: "patient",
            text: top.text,
            source: sourceFor(action.result.providerId),
            location: action.result.location,
            status: action.risk ? "escalated" : "pending-review",
            confidence: top.confidence,
            modelVersion: action.result.modelVersion,
            risk: action.risk,
          },
        ],
        escalation: action.risk ?? state.escalation,
      };
    }
    case "provider-text":
      return {
        entries: [
          ...state.entries,
          {
            id: action.id,
            author: "provider",
            text: action.text,
            source: "typed",
            location: "none",
            status: action.risk ? "escalated" : "sent",
            risk: action.risk,
          },
        ],
        escalation: action.risk ?? state.escalation,
      };
    case "confirm": {
      const entry = state.entries.find((e) => e.id === action.id);
      if (
        !entry ||
        entry.author !== "patient" ||
        entry.status !== "pending-review"
      )
        return state;
      return { ...state, entries: update(action.id, { status: "confirmed" }) };
    }
    case "reject": {
      const entry = state.entries.find((e) => e.id === action.id);
      if (!entry || entry.author !== "patient" || entry.status === "rejected")
        return state;
      return { ...state, entries: update(action.id, { status: "rejected" }) };
    }
    case "correct": {
      const entry = state.entries.find((e) => e.id === action.id);
      const text = action.text.trim();
      if (!entry || entry.author !== "patient" || !text) return state;
      return {
        entries: update(action.id, {
          text,
          correctedFrom: entry.correctedFrom ?? entry.text,
          source: "typed",
          status: action.risk ? "escalated" : "corrected",
          confidence: undefined,
          risk: action.risk,
        }),
        escalation: action.risk ?? state.escalation,
      };
    }
    case "edit-provider": {
      const entry = state.entries.find((e) => e.id === action.id);
      const text = action.text.trim();
      if (!entry || entry.author !== "provider" || !text) return state;
      return {
        entries: update(action.id, {
          text,
          correctedFrom: entry.correctedFrom ?? entry.text,
          status: action.risk ? "escalated" : "sent",
          risk: action.risk,
        }),
        escalation: action.risk ?? state.escalation,
      };
    }
    case "escalate":
      return { ...state, escalation: action.risk };
    case "clear":
      return emptyConversation;
  }
}
