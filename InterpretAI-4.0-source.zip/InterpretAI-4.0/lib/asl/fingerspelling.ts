import { RecognitionError, type LandmarkPoint } from "./types";

/**
 * On-device ASL fingerspelling (static manual-alphabet letters).
 *
 * The bundled model (public/models/asl-fingerspelling-v1/model.json) was
 * trained by InterpretAI on a public MIT-licensed MediaPipe landmark dataset.
 * See docs/MODEL-CARD-FINGERSPELLING.md for data, evaluation and gaps.
 *
 * This is NOT sign recognition and NOT translation: it reads one static
 * handshape at a time and spells letters only after they are held steady.
 */

export type StaticHandModel = {
  format: "interpretai.static-hand-model.v1";
  id: string;
  version: string;
  granularity: "fingerspelling-static-letter";
  description: string;
  vocabulary: string[];
  license: { name: string; url?: string };
  trainingData: { description: string; consent: string };
  evaluation: {
    dataset: string;
    signerIndependent: boolean;
    metrics: Record<string, number>;
    knownGaps: string;
  };
  input: { features: "mediapipe-image-landmarks-2d"; featuresPerFrame: 42 };
  decision: {
    minScore: number;
    minMargin: number;
    maxCentroidDistance: number;
  };
  architecture: "dense-mlp";
  layers: {
    weights: number[][];
    bias: number[];
    activation: "relu" | "linear";
  }[];
  centroids: number[][];
};

export const FINGERSPELLING_MODEL_URL =
  "/models/asl-fingerspelling-v1/model.json";

const isRecord = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);

export function validateStaticModel(raw: unknown): StaticHandModel {
  const fail = (why: string): never => {
    throw new RecognitionError(
      "model-load-failed",
      `Fingerspelling model refused: ${why}`,
    );
  };
  if (!isRecord(raw) || raw.format !== "interpretai.static-hand-model.v1")
    return fail("unsupported format.");
  const m = raw as unknown as StaticHandModel;
  if (!Array.isArray(m.vocabulary) || m.vocabulary.length < 2)
    fail("no vocabulary.");
  if (
    !m.license?.name ||
    !m.trainingData?.description ||
    !m.evaluation?.knownGaps
  )
    fail("licence, training data and evaluation documentation are required.");
  if (m.input?.featuresPerFrame !== 42) fail("expected 42 input features.");
  if (!Array.isArray(m.layers) || !m.layers.length) fail("no layers.");
  let inputs = 42;
  for (const layer of m.layers) {
    if (layer.weights.length !== layer.bias.length)
      fail("layer size mismatch.");
    if (layer.weights.some((row) => row.length !== inputs))
      fail("weight shape mismatch.");
    inputs = layer.weights.length;
  }
  if (inputs !== m.vocabulary.length)
    fail("output size does not match vocabulary.");
  const hidden = m.layers[m.layers.length - 2]?.weights.length;
  if (
    m.centroids.length !== m.vocabulary.length ||
    m.centroids.some((c) => c.length !== hidden)
  )
    fail("centroids do not match the model.");
  return m;
}

/**
 * Feature extraction identical to the training pipeline: pixel coordinates,
 * wrist-relative, flattened (x0,y0,…,x20,y20), divided by max |value|.
 * Mirroring was part of training augmentation, so left and right hands are
 * both accepted without flipping.
 */
export function handFeatures(
  image: readonly LandmarkPoint[],
  width: number,
  height: number,
): Float32Array | null {
  if (image.length !== 21 || !(width > 0) || !(height > 0)) return null;
  const out = new Float32Array(42);
  const wx = image[0].x * width;
  const wy = image[0].y * height;
  let max = 0;
  for (let i = 0; i < 21; i++) {
    const x = image[i].x * width - wx;
    const y = image[i].y * height - wy;
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    out[i * 2] = x;
    out[i * 2 + 1] = y;
    max = Math.max(max, Math.abs(x), Math.abs(y));
  }
  if (max < 1e-6) return null;
  for (let i = 0; i < 42; i++) out[i] /= max;
  return out;
}

export type LetterDecision = {
  letter: string | null;
  /** Softmax score of the top letter (model output, not calibrated). */
  score: number;
  margin: number;
  distance: number;
  reason:
    "accepted" | "low-score" | "ambiguous" | "unfamiliar-shape" | "no-hand";
  top: string;
  inferenceMs: number;
};

export function classifyHand(
  model: StaticHandModel,
  features: Float32Array,
  now: () => number = () => performance.now(),
): LetterDecision {
  const started = now();
  let current: ArrayLike<number> = features;
  let hidden: ArrayLike<number> = features;
  model.layers.forEach((layer, index) => {
    const next = new Float64Array(layer.bias.length);
    for (let o = 0; o < layer.bias.length; o++) {
      let sum = layer.bias[o];
      const row = layer.weights[o];
      for (let i = 0; i < row.length; i++) sum += row[i] * current[i];
      next[o] = layer.activation === "relu" ? Math.max(0, sum) : sum;
    }
    if (index === model.layers.length - 2) hidden = next;
    current = next;
  });
  const logits = Array.from(current);
  const max = Math.max(...logits);
  const exps = logits.map((v) => Math.exp(v - max));
  const total = exps.reduce((a, b) => a + b, 0);
  const probs = exps.map((v) => v / total);
  const order = probs
    .map((p, i) => [p, i] as const)
    .sort((a, b) => b[0] - a[0]);
  const [best, second] = order;
  const centroid = model.centroids[best[1]];
  let d = 0;
  for (let i = 0; i < centroid.length; i++) d += (hidden[i] - centroid[i]) ** 2;
  const distance = Math.sqrt(d);
  const margin = best[0] - (second?.[0] ?? 0);
  const top = model.vocabulary[best[1]];
  const reason =
    distance > model.decision.maxCentroidDistance
      ? "unfamiliar-shape"
      : best[0] < model.decision.minScore
        ? "low-score"
        : margin < model.decision.minMargin
          ? "ambiguous"
          : "accepted";
  return {
    letter: reason === "accepted" ? top : null,
    score: best[0],
    margin,
    distance,
    reason,
    top,
    inferenceMs: now() - started,
  };
}

/* ---------- Temporal speller ---------- */

export type SpellerOptions = {
  /** A letter must be held this long before it is committed. */
  holdMs: number;
  /** …and seen in at least this many frames. */
  minFrames: number;
  /** The same letter can repeat only after a release this long (no/other letter). */
  releaseMs: number;
  /** No hand for this long ends the current word. */
  wordGapMs: number;
};

export const defaultSpellerOptions: SpellerOptions = {
  holdMs: 700,
  minFrames: 4,
  releaseMs: 300,
  wordGapMs: 1500,
};

export type SpellerState = {
  words: string[];
  current: string;
  candidate: string | null;
  candidateSince: number;
  candidateFrames: number;
  /** The current hold has already produced a letter. */
  committedThisHold: boolean;
  lastCommitted: string | null;
  /** When the hand left the last committed letter (null while still on it). */
  releaseStart: number | null;
  /** The last release lasted long enough to allow repeating the same letter. */
  releaseOk: boolean;
  lastHandAt: number | null;
  /** Fraction 0..1 of the hold timer, for the on-screen progress bar. */
  progress: number;
};

export const emptySpeller: SpellerState = {
  words: [],
  current: "",
  candidate: null,
  candidateSince: 0,
  candidateFrames: 0,
  committedThisHold: false,
  lastCommitted: null,
  releaseStart: null,
  releaseOk: false,
  lastHandAt: null,
  progress: 0,
};

/**
 * Pure state machine. Prevents duplicate predictions: one hold commits one
 * letter, and a double letter (e.g. "LL") requires a visible release first.
 * A long absence of hands ends the current word.
 */
export function stepSpeller(
  state: SpellerState,
  observation: { letter: string | null; handPresent: boolean; t: number },
  options: SpellerOptions = defaultSpellerOptions,
): { state: SpellerState; committed: string | null } {
  const { letter, handPresent, t } = observation;
  const next: SpellerState = { ...state };
  if (handPresent) next.lastHandAt = t;
  else if (
    state.current &&
    state.lastHandAt !== null &&
    t - state.lastHandAt >= options.wordGapMs
  ) {
    next.words = [...state.words, state.current];
    next.current = "";
    next.lastCommitted = null;
    next.releaseStart = null;
    next.releaseOk = false;
  }
  // Track releases away from the last committed letter.
  if (next.lastCommitted !== null) {
    if (letter !== next.lastCommitted) next.releaseStart ??= t;
    else if (next.releaseStart !== null) {
      next.releaseOk = t - next.releaseStart >= options.releaseMs;
      next.releaseStart = null;
    }
  }
  if (letter !== state.candidate) {
    next.candidate = letter;
    next.candidateSince = t;
    next.candidateFrames = letter ? 1 : 0;
    next.committedThisHold = false;
    next.progress = 0;
    return { state: next, committed: null };
  }
  if (!letter) return { state: { ...next, progress: 0 }, committed: null };
  next.candidateFrames = state.candidateFrames + 1;
  const held = t - state.candidateSince;
  next.progress = state.committedThisHold
    ? 1
    : Math.min(1, held / options.holdMs);
  const repeatBlocked = letter === next.lastCommitted && !next.releaseOk;
  if (
    !state.committedThisHold &&
    !repeatBlocked &&
    held >= options.holdMs &&
    next.candidateFrames >= options.minFrames
  ) {
    return {
      state: {
        ...next,
        current: next.current + letter,
        lastCommitted: letter,
        committedThisHold: true,
        releaseStart: null,
        releaseOk: false,
        progress: 1,
      },
      committed: letter,
    };
  }
  return { state: next, committed: null };
}

export function spelledText(state: SpellerState) {
  return [...state.words, state.current].filter(Boolean).join(" ");
}

export async function loadFingerspellingModel(
  fetcher: typeof fetch = (...args) => fetch(...args),
  url = FINGERSPELLING_MODEL_URL,
) {
  let response: Response;
  try {
    response = await fetcher(url);
  } catch {
    throw new RecognitionError(
      "model-load-failed",
      "The fingerspelling model could not be loaded. If you are offline, open the app online once so it can be cached.",
    );
  }
  if (!response.ok)
    throw new RecognitionError(
      "model-load-failed",
      `The fingerspelling model returned HTTP ${response.status}.`,
    );
  return validateStaticModel(await response.json());
}
