/**
 * Shared, framework-free camera helpers used by every camera surface
 * (scripted preview, sample lab, experimental recognition workspace) so
 * permission errors, cleanup and frame pacing behave identically.
 */

export type CameraFailure =
  | "permission-denied"
  | "not-found"
  | "in-use"
  | "unsupported"
  | "insecure"
  | "unknown";

export function classifyCameraError(failure: unknown): CameraFailure {
  const name =
    failure && typeof failure === "object" && "name" in failure
      ? String((failure as { name: unknown }).name)
      : "";
  if (
    name === "NotAllowedError" ||
    name === "PermissionDeniedError" ||
    name === "SecurityError"
  )
    return "permission-denied";
  if (
    name === "NotFoundError" ||
    name === "OverconstrainedError" ||
    name === "DevicesNotFoundError"
  )
    return "not-found";
  if (
    name === "NotReadableError" ||
    name === "TrackStartError" ||
    name === "AbortError"
  )
    return "in-use";
  if (name === "NotSupportedError" || name === "TypeError")
    return "unsupported";
  return "unknown";
}

export const cameraMessages: Record<CameraFailure, string> = {
  "permission-denied":
    "Camera permission was declined. Allow camera access in your browser’s site settings to try recognition. Scripted cards, typing, and interpreter requests still work.",
  "not-found":
    "No camera was found. Connect a camera, or continue with scripted cards and typing.",
  "in-use":
    "The camera is busy or could not start. Close other apps using the camera and retry.",
  unsupported:
    "This browser could not start camera capture. Open the app in a current Chrome or Edge browser and retry.",
  insecure:
    "Camera access needs a secure page (HTTPS, localhost, or 127.0.0.1).",
  unknown: "The camera could not be started.",
};

export function cameraSupport(): CameraFailure | null {
  if (typeof window === "undefined") return "unsupported";
  if (!window.isSecureContext) return "insecure";
  if (!navigator.mediaDevices?.getUserMedia) return "unsupported";
  return null;
}

/** Video only. Microphone capture is never requested. */
export const cameraConstraints: MediaStreamConstraints = {
  video: {
    facingMode: "user",
    width: { ideal: 640 },
    height: { ideal: 480 },
    frameRate: { ideal: 30, max: 30 },
  },
  audio: false,
};

export function stopStream(stream: MediaStream | null | undefined) {
  stream?.getTracks().forEach((track) => {
    track.stop();
    stream.removeTrack?.(track);
  });
}

/**
 * Adaptive frame pacing. Fast devices sample about 8–10 frames per second;
 * slow devices back off up to 2 frames per second so the UI stays responsive.
 */
export function nextFrameInterval(averageProcessingMs: number) {
  if (!Number.isFinite(averageProcessingMs) || averageProcessingMs <= 0)
    return 110;
  return Math.round(Math.min(500, Math.max(100, averageProcessingMs * 1.6)));
}

export function isLowPerformance(averageProcessingMs: number) {
  return averageProcessingMs > 150;
}

/** Exponential moving average used for processing-time estimates. */
export function updateAverage(previous: number, sample: number, weight = 0.2) {
  if (!Number.isFinite(sample) || sample < 0) return previous;
  return previous <= 0 ? sample : previous * (1 - weight) + sample * weight;
}

export type TrackingState = "no-hands" | "tracking" | "tracking-lost";

/** Distinguishes "never saw a hand" from "lost hands that were being tracked". */
export function trackingState(
  handCount: number,
  lastSeenAt: number | null,
  now: number,
  graceMs = 1200,
): TrackingState {
  if (handCount > 0) return "tracking";
  if (lastSeenAt !== null && now - lastSeenAt <= graceMs)
    return "tracking-lost";
  return "no-hands";
}

/** MediaPipe requires strictly increasing timestamps in VIDEO mode. */
export function monotonicTimestamp(previous: number, proposed: number) {
  const rounded = Math.round(proposed);
  return rounded > previous ? rounded : previous + 1;
}
