export type SampleLetter = "L" | "Y";
export type HandPoint = { x: number; y: number; z: number };
export type StableHandshape = {
  letter: SampleLetter | null;
  since: number;
  samples: number;
  /** Consecutive frames without a match; one miss is tolerated. */
  misses: number;
};
export const emptyHandshape: StableHandshape = {
  letter: null,
  since: 0,
  samples: 0,
  misses: 0,
};
export const sampleLetters: Record<
  SampleLetter,
  { instruction: string; extended: readonly number[] }
> = {
  L: {
    instruction:
      "Extend your thumb and index finger. Curl the other three fingers. Face your palm toward the camera.",
    extended: [0, 1],
  },
  Y: {
    instruction:
      "Extend your thumb and little finger. Curl the other three fingers. Face your palm toward the camera.",
    extended: [0, 4],
  },
};
const distance = (a: HandPoint, b: HandPoint) =>
  Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
function angle(a: HandPoint, b: HandPoint, c: HandPoint) {
  const first = [a.x - b.x, a.y - b.y, a.z - b.z];
  const second = [c.x - b.x, c.y - b.y, c.z - b.z];
  const length = Math.hypot(...first) * Math.hypot(...second);
  if (length < 1e-10) return 0;
  return (
    (Math.acos(
      Math.max(
        -1,
        Math.min(
          1,
          first.reduce((sum, value, i) => sum + value * second[i], 0) / length,
        ),
      ),
    ) *
      180) /
    Math.PI
  );
}

export type HandshapeCheck = {
  letter: SampleLetter | null;
  /** Plain-language reason when no letter matched (for on-screen coaching). */
  hint: string;
};

// A deliberately narrow geometry rule, not a trained ASL classifier.
// It does not validate palm orientation, language, meaning, or comprehension.
// Thresholds were loosened in 2.1.1 after real-hand testing: natural fingers
// are rarely perfectly straight and webcam depth (z) is noisy.
export function explainHandshape(points: readonly HandPoint[]): HandshapeCheck {
  if (
    points.length !== 21 ||
    points.some((point) => ![point.x, point.y, point.z].every(Number.isFinite))
  )
    return { letter: null, hint: "Hand landmarks were incomplete." };
  const palm = distance(points[0], points[9]);
  if (palm < 1e-5 || distance(points[5], points[17]) < palm * 0.2)
    return {
      letter: null,
      hint: "Turn your palm toward the camera so the whole hand is visible.",
    };
  const fingers = [5, 9, 13, 17].map((base) => {
    const pipAngle = angle(points[base], points[base + 1], points[base + 2]);
    const dipAngle = angle(
      points[base + 1],
      points[base + 2],
      points[base + 3],
    );
    const tipReach = distance(points[base + 3], points[0]);
    const pipReach = distance(points[base + 1], points[0]);
    const extended =
      pipAngle > 140 && dipAngle > 130 && tipReach > pipReach * 1.08;
    const folded =
      tipReach < pipReach * 1.02 ||
      (pipAngle < 130 && distance(points[base + 3], points[base]) < palm * 0.8);
    return { extended, folded };
  });
  const thumbStraightness =
    angle(points[1], points[2], points[3]) +
    angle(points[2], points[3], points[4]);
  const thumbOpen =
    thumbStraightness > 255 && distance(points[4], points[5]) > palm * 0.5;
  const [index, middle, ring, pinky] = fingers;
  if (!middle.folded || !ring.folded)
    return {
      letter: null,
      hint: "Curl your middle and ring fingers into your palm.",
    };
  if (!thumbOpen)
    return { letter: null, hint: "Stick your thumb straight out to the side." };
  if (index.extended && pinky.folded) {
    const spread = angle(points[4], points[2], points[8]);
    return spread > 35 && spread < 160
      ? { letter: "L", hint: "" }
      : {
          letter: null,
          hint: "Open the gap between your thumb and index finger.",
        };
  }
  if (index.folded && pinky.extended) return { letter: "Y", hint: "" };
  if (index.extended && pinky.extended)
    return {
      letter: null,
      hint: "For L curl your pinky; for Y curl your index finger.",
    };
  return {
    letter: null,
    hint: "Straighten your index finger (L) or your pinky (Y).",
  };
}

export function matchHandshape(
  points: readonly HandPoint[],
): SampleLetter | null {
  return explainHandshape(points).letter;
}

export function steadyHandshape(
  previous: StableHandshape,
  observed: SampleLetter | null,
  now: number,
): { state: StableHandshape; candidate: SampleLetter | null } {
  if (!observed) {
    // Tolerate a single dropped frame so webcam jitter does not restart the
    // hold timer, but never show a candidate on a frame without a match.
    const misses = previous.misses + 1;
    return {
      state:
        previous.letter && misses < 2
          ? { ...previous, misses }
          : { ...emptyHandshape },
      candidate: null,
    };
  }
  const state =
    previous.letter === observed && now >= previous.since
      ? { ...previous, samples: previous.samples + 1, misses: 0 }
      : { letter: observed, since: now, samples: 1, misses: 0 };
  return {
    state,
    candidate: state.samples >= 4 && now - state.since >= 650 ? observed : null,
  };
}

export const handConnections: readonly (readonly [number, number])[] = [
  [0, 1],
  [1, 2],
  [2, 3],
  [3, 4],
  [0, 5],
  [5, 6],
  [6, 7],
  [7, 8],
  [5, 9],
  [9, 10],
  [10, 11],
  [11, 12],
  [9, 13],
  [13, 14],
  [14, 15],
  [15, 16],
  [13, 17],
  [0, 17],
  [17, 18],
  [18, 19],
  [19, 20],
];
