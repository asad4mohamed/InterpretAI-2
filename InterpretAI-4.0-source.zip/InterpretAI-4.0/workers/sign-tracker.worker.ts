import {
  FilesetResolver,
  HolisticLandmarker,
  type NormalizedLandmark,
} from "@mediapipe/tasks-vision";
import * as ort from "onnxruntime-web/wasm";
import assets from "../lib/sign-assets.json";
import { assembleFrame, type DetectedHand } from "../lib/asl/signs/assemble";
import type { Decision } from "../lib/asl/signs/decision";
import { parseLabels, parseMeta } from "../lib/asl/signs/meta";
import {
  LiveMovementTracker,
  summarizeMovement,
  type LiveMovement,
  type MovementSummary,
} from "../lib/asl/signs/movement";
import { Recognizer } from "../lib/asl/signs/recognizer";
import { frameStatus, type FrameStatus } from "../lib/asl/signs/segmenter";
import {
  LEFT_HAND_START,
  POSE_START,
  RIGHT_HAND_START,
  type Frame,
} from "../lib/asl/signs/landmarks";

/**
 * On-device continuous sign recognition, entirely inside this worker:
 * MediaPipe Holistic (hands, pose, face mesh) → 543-point frames → sign
 * segmentation → features → ONNX temporal model → calibrated decision.
 *
 * Privacy: camera frames arrive as ImageBitmaps and are closed after one
 * use. Face landmarks are used only as model input (lip shape) inside this
 * worker; they are never posted to the page, stored, or used to identify
 * anyone. Nothing is uploaded.
 */

export type SignWorkerRequest =
  | { type: "init"; origin: string }
  | { type: "frame"; image: ImageBitmap; t: number }
  /** Real landmark frames (e.g. held-out dataset clips), same pipeline. */
  | { type: "replay"; frames: Float32Array[]; fps: number; t0: number }
  | { type: "reset" };

export type OverlayHand = {
  side: "left" | "right";
  image: { x: number; y: number }[];
};

export type SignWorkerResponse =
  | { type: "progress"; stage: "runtime" | "landmarker" | "model" }
  | { type: "ready"; modelVersion: string; classes: number; delegate: string }
  | { type: "init-error"; message: string }
  | {
      type: "frame";
      t: number;
      ms: number;
      status: FrameStatus;
      segmenter: "idle" | "signing" | "resting";
      poses: number;
      hands: OverlayHand[];
      /** Nose, shoulders, elbows, wrists (pose indices 0, 11–16) for the overlay. */
      upperBody: ({ x: number; y: number } | null)[];
      facePresent: boolean;
      movement: LiveMovement;
      frameWidth: number;
      frameHeight: number;
    }
  | { type: "signing" }
  | { type: "discarded" }
  | {
      type: "result";
      decision: Decision;
      startT: number;
      endT: number;
      endReason: string;
      frames: number;
      fps: number;
      inferenceMs: number;
      movement: MovementSummary | null;
    }
  | { type: "replay-done" }
  | { type: "error"; message: string };

let holistic: HolisticLandmarker | null = null;
let delegate = "CPU";
let recognizer: Recognizer | null = null;
let session: ort.InferenceSession | null = null;
let lastTimestamp = -1;
const live = new LiveMovementTracker();
const send = (message: SignWorkerResponse) => self.postMessage(message);

const UPPER = [0, 11, 12, 13, 14, 15, 16];
const points = (list: NormalizedLandmark[] | undefined) =>
  (list ?? []).map((p) => ({ x: p.x, y: p.y, z: p.z }));

async function bytes(url: string) {
  const response = await fetch(url);
  if (!response.ok)
    throw new Error(`${url.split("/").pop()}: HTTP ${response.status}`);
  return new Uint8Array(await response.arrayBuffer());
}

function handsOf(frame: Frame): OverlayHand[] {
  const out: OverlayHand[] = [];
  for (const [side, start] of [
    ["left", LEFT_HAND_START],
    ["right", RIGHT_HAND_START],
  ] as const) {
    if (!Number.isFinite(frame[start * 3])) continue;
    const image = [];
    for (let i = 0; i < 21; i++)
      image.push({
        x: frame[(start + i) * 3]!,
        y: frame[(start + i) * 3 + 1]!,
      });
    out.push({ side, image });
  }
  return out;
}

function upperBodyOf(frame: Frame) {
  return UPPER.map((i) => {
    const x = frame[(POSE_START + i) * 3];
    const y = frame[(POSE_START + i) * 3 + 1];
    return Number.isFinite(x) && Number.isFinite(y) ? { x: x!, y: y! } : null;
  });
}

async function initialize(origin: string) {
  send({ type: "progress", stage: "runtime" });
  const fileset = await FilesetResolver.forVisionTasks(
    `${origin}${assets.mediapipeWasm}`,
    true,
  );
  send({ type: "progress", stage: "landmarker" });
  const task = await bytes(`${origin}${assets.holistic}`);
  const create = (d: "GPU" | "CPU") =>
    HolisticLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetBuffer: task, delegate: d },
      runningMode: "VIDEO",
    });
  // CPU delegate, like the 3.0 hand tracker: measured at about 20 ms per
  // frame in headless Chromium, while the GPU delegate in a worker took about
  // 450 ms per frame (and 7.5 s for the first) where WebGL is software-only.
  holistic = await create("CPU");
  delegate = "CPU";
  send({ type: "progress", stage: "model" });
  const [metaRaw, labelsRaw, model, wasm] = await Promise.all([
    fetch(`${origin}${assets.modelMeta}`).then((r) => r.json()),
    fetch(`${origin}${assets.labels}`).then((r) => r.json()),
    bytes(`${origin}${assets.model}`),
    bytes(`${origin}${assets.ortRoot}ort-wasm-simd-threaded.wasm`),
  ]);
  const meta = parseMeta(metaRaw);
  const labels = parseLabels(labelsRaw, meta.classes);
  ort.env.wasm.wasmPaths = `${origin}${assets.ortRoot}`;
  ort.env.wasm.wasmBinary = wasm;
  ort.env.wasm.numThreads = 1;
  ort.env.logLevel = "error";
  session = await ort.InferenceSession.create(model, {
    executionProviders: ["wasm"],
    graphOptimizationLevel: "all",
    logSeverityLevel: 3,
  });
  const run = session;
  recognizer = new Recognizer(
    meta,
    labels,
    async (input) => {
      const outputs = await run.run({
        frames: new ort.Tensor("float32", input.data, [
          1,
          input.frames,
          input.dim,
        ]),
      });
      const logits = outputs.logits?.data;
      const embedding = outputs.embedding?.data;
      if (
        !(logits instanceof Float32Array) ||
        !(embedding instanceof Float32Array)
      )
        throw new Error("The sign model returned unexpected outputs.");
      if (logits.length !== meta.classes)
        throw new Error("The sign model returned the wrong number of classes.");
      return { logits, embedding };
    },
    (event) => {
      if (event.type === "signing") send({ type: "signing" });
      else if (event.type === "discarded") send({ type: "discarded" });
      else if (event.type === "error")
        send({ type: "error", message: event.message });
      else if (event.type === "result") {
        const { segment } = event.result;
        send({
          type: "result",
          decision: event.result.decision,
          startT: segment.timestamps[0] ?? 0,
          endT: segment.timestamps[segment.timestamps.length - 1] ?? 0,
          endReason: event.result.endReason,
          frames: segment.frames.length,
          fps: Math.round(segment.fps * 10) / 10,
          inferenceMs: Math.round(event.result.inferenceMs * 10) / 10,
          movement: summarizeMovement(segment.frames, segment.timestamps),
        });
      }
    },
  );
  lastTimestamp = -1;
  send({
    type: "ready",
    modelVersion: `asl-signs-v1 (${meta.version})`,
    classes: meta.classes,
    delegate,
  });
}

function pushFrame(
  frame: Frame,
  t: number,
  poses: number,
  started: number,
  w: number,
  h: number,
) {
  if (!recognizer) throw new Error("The sign recognizer is not ready.");
  recognizer.push({ frame, t, poses });
  send({
    type: "frame",
    t,
    ms: performance.now() - started,
    status: frameStatus(frame, poses),
    segmenter: recognizer.segmenterState,
    poses,
    hands: handsOf(frame),
    upperBody: upperBodyOf(frame),
    facePresent: Number.isFinite(frame[0]),
    movement: live.push(frame, t),
    frameWidth: w,
    frameHeight: h,
  });
}

self.onmessage = async (event: MessageEvent<SignWorkerRequest>) => {
  const message = event.data;
  if (message.type === "init") {
    try {
      await initialize(message.origin);
    } catch (failure) {
      holistic?.close();
      holistic = null;
      send({
        type: "init-error",
        message:
          failure instanceof Error
            ? `Sign recognition could not start: ${failure.message}`
            : "Sign recognition could not start.",
      });
    }
    return;
  }
  if (message.type === "reset") {
    recognizer?.reset();
    live.reset();
    return;
  }
  if (message.type === "replay") {
    try {
      recognizer?.reset();
      live.reset();
      const step = 1000 / message.fps;
      message.frames.forEach((frame, i) => {
        const poses = Number.isFinite(frame[(POSE_START + 11) * 3]) ? 1 : 0;
        pushFrame(frame, message.t0 + i * step, poses, performance.now(), 0, 0);
      });
      recognizer?.flush();
      send({ type: "replay-done" });
    } catch (failure) {
      send({
        type: "error",
        message: failure instanceof Error ? failure.message : "Replay failed.",
      });
    }
    return;
  }
  const started = performance.now();
  try {
    if (!holistic) throw new Error("The landmarker is not ready.");
    const proposed = Math.round(message.t);
    const t = proposed > lastTimestamp ? proposed : lastTimestamp + 1;
    lastTimestamp = t;
    const r = holistic.detectForVideo(message.image, t);
    const hands: DetectedHand[] = [];
    const left = r.leftHandLandmarks[0];
    const right = r.rightHandLandmarks[0];
    if (left) hands.push({ points: points(left), side: "left" });
    if (right) hands.push({ points: points(right), side: "right" });
    const pose = r.poseLandmarks[0];
    const face = r.faceLandmarks[0];
    const frame = assembleFrame({
      hands,
      pose: pose ? points(pose) : null,
      face: face ? points(face) : null,
    });
    pushFrame(
      frame,
      t,
      r.poseLandmarks.length,
      started,
      message.image.width,
      message.image.height,
    );
  } catch (failure) {
    send({
      type: "error",
      message:
        failure instanceof Error
          ? `A frame could not be processed: ${failure.message}`
          : "A frame could not be processed.",
    });
  } finally {
    message.image.close();
  }
};
