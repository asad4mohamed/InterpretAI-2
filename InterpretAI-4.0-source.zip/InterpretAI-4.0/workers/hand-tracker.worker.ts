import { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";
import { explainHandshape } from "../lib/handshapes";
import assets from "../lib/lab-assets.json";
import type { HandPoint, SampleLetter } from "../lib/handshapes";

/**
 * Single shared MediaPipe Hand Landmarker worker for every camera surface.
 * Frames arrive as transferable ImageBitmaps, are processed once, and are
 * closed immediately. Nothing is stored, recorded, or uploaded.
 */

export type TrackedHand = {
  /** Signer's anatomical hand. MediaPipe assumes mirrored input; frames here
   * are unmirrored, so its label is swapped once. */
  handedness: "Left" | "Right";
  /** MediaPipe's own handedness score, reported as-is. */
  handednessScore: number;
  image: HandPoint[];
  world: HandPoint[];
};

export type TrackerRequest =
  | { type: "initialize"; origin: string }
  | { type: "frame"; image: ImageBitmap; timestamp: number };
export type TrackerResponse =
  | { type: "progress"; stage: "runtime" | "model" }
  | { type: "ready" }
  | { type: "error"; message: string }
  | {
      type: "result";
      /** Experimental L/Y match; only evaluated when exactly one hand is visible. */
      letter: SampleLetter | null;
      /** Coaching hint when one hand is visible but no letter matched. */
      hint: string;
      handCount: number;
      /** Image landmarks of the single visible hand (kept for the lab overlay). */
      landmarks: HandPoint[];
      hands: TrackedHand[];
      timestamp: number;
      processingMs: number;
      /** Frame size, needed to convert normalised landmarks to pixel units. */
      frameWidth: number;
      frameHeight: number;
    };
let tracker: HandLandmarker | null = null;
let lastTimestamp = -1;
const send = (message: TrackerResponse) => self.postMessage(message);
self.onmessage = async (event: MessageEvent<TrackerRequest>) => {
  const message = event.data;
  if (message.type === "initialize") {
    try {
      send({ type: "progress", stage: "runtime" });
      const fileset = await FilesetResolver.forVisionTasks(
        `${message.origin}${assets.root}/wasm`,
        true,
      );
      send({ type: "progress", stage: "model" });
      tracker = await HandLandmarker.createFromOptions(fileset, {
        baseOptions: {
          modelAssetPath: `${message.origin}${assets.root}/hand_landmarker.task`,
          delegate: "CPU",
        },
        runningMode: "VIDEO",
        numHands: 2,
        minHandDetectionConfidence: 0.65,
        minHandPresenceConfidence: 0.65,
        minTrackingConfidence: 0.65,
      });
      lastTimestamp = -1;
      send({ type: "ready" });
    } catch (failure) {
      console.warn(
        "Local hand tracker initialization failed:",
        failure instanceof Error ? failure.message : "Unknown runtime error",
      );
      tracker?.close();
      tracker = null;
      send({
        type: "error",
        message:
          "The local hand tracker could not start. Try a current Chrome or Edge browser, or retry the optional download. The avatar sample remains available.",
      });
    }
    return;
  }
  const started = performance.now();
  try {
    if (!tracker) throw new Error("Hand tracker is not ready.");
    // VIDEO mode requires strictly increasing timestamps.
    const proposed = Math.round(message.timestamp);
    const timestamp = proposed > lastTimestamp ? proposed : lastTimestamp + 1;
    lastTimestamp = timestamp;
    const result = tracker.detectForVideo(message.image, timestamp);
    const handCount = result.landmarks.length;
    const hands: TrackedHand[] = result.landmarks.map((image, index) => {
      const label = result.handedness[index]?.[0];
      return {
        handedness: label?.categoryName === "Left" ? "Right" : "Left",
        handednessScore: label?.score ?? 0,
        image,
        world: result.worldLandmarks[index] ?? [],
      };
    });
    send({
      type: "result",
      handCount,
      hands,
      landmarks: handCount === 1 ? result.landmarks[0] : [],
      ...(handCount === 1
        ? explainHandshape(result.worldLandmarks[0])
        : { letter: null, hint: "" }),
      timestamp,
      processingMs: performance.now() - started,
      frameWidth: message.image.width,
      frameHeight: message.image.height,
    });
  } catch {
    send({
      type: "error",
      message:
        "Tracking stopped because this browser could not process a frame. No recording was saved. You can restart or use the avatar sample.",
    });
  } finally {
    message.image.close();
  }
};
