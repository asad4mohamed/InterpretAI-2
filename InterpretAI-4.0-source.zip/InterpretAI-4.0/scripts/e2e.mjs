import { spawnSync } from "node:child_process";
import path from "node:path";
const args = process.argv.slice(2);
const install = args.includes("--install");
const result = spawnSync(
  process.execPath,
  [
    path.resolve("node_modules/@playwright/test/cli.js"),
    ...(install ? ["install", "chromium"] : ["test", ...args]),
  ],
  {
    stdio: "inherit",
    env: {
      ...process.env,
      PLAYWRIGHT_BROWSERS_PATH: path.resolve("work/browsers"),
    },
  },
);
process.exit(result.status ?? 1);
