import { copyFile, mkdir, readFile, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import ts from "typescript";

const root = "/lab-assets/mp1.1.1-model1";
const directory = path.resolve(`public${root}`);
await mkdir(directory, { recursive: true });
await copyFile(
  "node_modules/@mediapipe/tasks-vision/vision_bundle.mjs",
  path.join(directory, "vision_bundle.mjs"),
);
await mkdir(path.join(directory, "wasm"), { recursive: true });
const runtimeFiles = [
  "vision_wasm_module_internal.js",
  "vision_wasm_module_internal.wasm",
];
for (const name of runtimeFiles) {
  await copyFile(
    path.resolve("node_modules/@mediapipe/tasks-vision/wasm", name),
    path.join(directory, "wasm", name),
  );
}
const modelSource =
  "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";
const modelPath = path.join(directory, "hand_landmarker.task");
let modelAvailable = true;
try {
  await stat(modelPath);
} catch {
  try {
    const response = await fetch(modelSource);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    await writeFile(modelPath, new Uint8Array(await response.arrayBuffer()));
  } catch (failure) {
    // Do not fail the whole build: every other feature works without the
    // optional lab model. The lab's download button reports the missing file.
    modelAvailable = false;
    console.warn(
      `\n⚠ Optional hand model not downloaded (${failure instanceof Error ? failure.message : "network error"}).\n` +
        `  The app builds and runs; only the optional on-device hand tracking is unavailable.\n` +
        `  Fix: connect to the internet and run "npm run prepare:lab", or copy\n` +
        `  the prebuilt ZIP's out/lab-assets/ folder to public/lab-assets/.\n`,
    );
  }
}
if (!modelAvailable) {
  // Keep the pinned manifest so hashes stay authoritative; still compile the worker.
  const pinned = JSON.parse(await readFile("lib/lab-assets.json", "utf8"));
  await mkdir("public/lab-engine", { recursive: true });
  const compileWorker = async (file) =>
    ts.transpileModule(await readFile(file, "utf8"), {
      compilerOptions: {
        target: ts.ScriptTarget.ES2020,
        module: ts.ModuleKind.ESNext,
      },
    }).outputText;
  await writeFile(
    "public/lab-engine/hand-tracker.mjs",
    (await compileWorker("workers/hand-tracker.worker.ts"))
      .replace(
        'from "@mediapipe/tasks-vision"',
        `from "${root}/vision_bundle.mjs"`,
      )
      .replace('from "../lib/handshapes"', 'from "./handshapes.mjs"')
      .replace(
        /^import assets from .*;$/m,
        `const assets = ${JSON.stringify(pinned)};`,
      ),
  );
  await writeFile(
    "public/lab-engine/handshapes.mjs",
    await compileWorker("lib/handshapes.ts"),
  );
  process.exit(0);
}
const modelHash = createHash("sha256")
  .update(await readFile(modelPath))
  .digest("hex");
if (
  modelHash !==
  "fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1"
)
  throw new Error(
    "The pinned Hand Landmarker bundle failed its SHA-256 check.",
  );
const files = [];
for (const relative of [
  "hand_landmarker.task",
  "vision_bundle.mjs",
  ...runtimeFiles.map((name) => `wasm/${name}`),
]) {
  const bytes = await readFile(path.join(directory, relative));
  files.push({
    url: `${root}/${relative}`,
    bytes: bytes.length,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  });
}
const manifest = {
  cacheName: "interpretai-lab-mp1.1.1-model1",
  root,
  modelSource,
  files,
};
await writeFile(
  "lib/lab-assets.json",
  JSON.stringify(manifest, null, 2) + "\n",
);
// Keep MediaPipe's native dynamic import intact rather than compiling its
// runtime URL into an unresolved bundler module context.
await mkdir("public/lab-engine", { recursive: true });
const compile = async (file) =>
  ts.transpileModule(await readFile(file, "utf8"), {
    compilerOptions: {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
    },
  }).outputText;
const worker = (await compile("workers/hand-tracker.worker.ts"))
  .replace('from "@mediapipe/tasks-vision"', `from "${root}/vision_bundle.mjs"`)
  .replace('from "../lib/handshapes"', 'from "./handshapes.mjs"')
  .replace(
    /^import assets from .*;$/m,
    `const assets = ${JSON.stringify(manifest)};`,
  );
await writeFile("public/lab-engine/hand-tracker.mjs", worker);
await writeFile(
  "public/lab-engine/handshapes.mjs",
  await compile("lib/handshapes.ts"),
);
await mkdir("public/third-party", { recursive: true });
const licensePath = "public/third-party/mediapipe-Apache-2.0.txt";
try {
  await stat(licensePath);
} catch {
  const response = await fetch(
    "https://raw.githubusercontent.com/google-ai-edge/mediapipe/master/LICENSE",
  );
  if (!response.ok) throw new Error("Could not obtain the MediaPipe license.");
  await writeFile(licensePath, await response.text());
}
await copyFile(
  "node_modules/three/LICENSE",
  "public/third-party/three-MIT.txt",
);
console.log(
  `Optional handshape lab: ${(files.reduce((sum, file) => sum + file.bytes, 0) / 1_000_000).toFixed(1)} MB; excluded from automatic app-shell downloads.`,
);
