import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { staticExportPath } from "../lib/static-export-path.mjs";
const root = path.resolve("out");
const lab = JSON.parse(await readFile("lib/lab-assets.json", "utf8"));
const signs = JSON.parse(await readFile("lib/sign-assets.json", "utf8"));
// Large optional files live only in their explicit-download caches.
const optionalUrls = new Set(
  signs.files.filter((file) => file.bytes > 1_000_000).map((file) => file.url),
);
async function walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  const files = await Promise.all(
    entries.map((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)],
    ),
  );
  return files.flat();
}
const files = (await walk(root))
  .filter(
    (file) =>
      !file.endsWith("sw.js") &&
      !file.endsWith(".map") &&
      !path
        .relative(root, file)
        .split(path.sep)
        .join("/")
        .startsWith("lab-assets/") &&
      !path
        .relative(root, file)
        .split(path.sep)
        .join("/")
        .startsWith("sign-assets/") &&
      !optionalUrls.has(
        "/" + path.relative(root, file).split(path.sep).join("/"),
      ),
  )
  .sort();
const hash = createHash("sha256");
for (const file of files) hash.update(await readFile(file));
const version = hash.digest("hex").slice(0, 12);
const urls = files.map(
  (file) => "/" + path.relative(root, file).split(path.sep).join("/"),
);
const worker = `/* Generated from the actual static export. Public, fictional demo assets only.
   Never caches camera frames, video clips, cross-origin API calls, or POST responses. */
const CACHE = 'interpretai-${version}';
const LAB_CACHE = ${JSON.stringify(lab.cacheName)};
const LAB_ASSETS = ${JSON.stringify(lab.files.map((file) => file.url))};
const SIGN_CACHE = ${JSON.stringify(signs.cacheName)};
const SIGN_ASSETS = ${JSON.stringify(signs.files.map((file) => file.url))};
const exportPath = ${staticExportPath.toString()};
const ASSETS = ${JSON.stringify(urls)};
self.addEventListener('install', event => {
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await cache.addAll(ASSETS);
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async()=>{
    // Keep the current app cache, the optional lab and sign caches, and explicitly downloaded local models.
    for(const key of await caches.keys()) if(key.startsWith('interpretai-')&&key!==CACHE&&key!==LAB_CACHE&&key!==SIGN_CACHE&&!key.startsWith('interpretai-model-')) await caches.delete(key);
    await self.clients.claim();
    for(const client of await self.clients.matchAll()) client.postMessage({type:'OFFLINE_READY'});
  })());
});
self.addEventListener('message', event => {
  if(event.data?.type==='CHECK_READY') event.source?.postMessage({type:'OFFLINE_READY'});
});
self.addEventListener('fetch', event => {
  const url=new URL(event.request.url);
  if(event.request.method!=='GET'||url.origin!==self.location.origin) return;
  // Public, non-secret integration settings: network first, last copy offline.
  if(url.pathname==='/runtime-config.json') {
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      try {
        const fresh=await fetch(event.request,{cache:'no-store'});
        if(fresh.ok) await cache.put('/runtime-config.json',fresh.clone());
        return fresh;
      } catch { return (await cache.match('/runtime-config.json'))||Response.error(); }
    })());
    return;
  }
  event.respondWith((async()=>{
    if(LAB_ASSETS.includes(url.pathname)||SIGN_ASSETS.includes(url.pathname)) {
      if(event.request.cache==='no-cache'||event.request.cache==='reload') return fetch(event.request);
      // Either optional download may hold a shared runtime file; small metadata is also precached.
      for(const name of [LAB_CACHE,SIGN_CACHE,CACHE]) {
        const downloaded=await (await caches.open(name)).match(url.pathname);
        if(downloaded) return downloaded;
      }
      return fetch(event.request);
    }
    const cache=await caches.open(CACHE);
    // Precache keys use the exported file names; also accept the alternate
    // flattened/nested segment layout so either Next.js compiler works.
    const literal=await cache.match(url.pathname,{ignoreSearch:true});
    if(literal) return literal;
    let pathname=exportPath(url.pathname);
    if(event.request.mode==='navigate') {
      if(pathname.endsWith('/')) pathname+='index.html';
      else if(!pathname.split('/').pop().includes('.')) pathname+='/index.html';
    }
    const cached=await cache.match(pathname,{ignoreSearch:true});
    if(cached) return cached;
    try { return await fetch(event.request); }
    catch {
      if(event.request.mode==='navigate') return (await cache.match('/404.html'))||Response.error();
      return Response.error();
    }
  })());
});
`;
await writeFile(path.join(root, "sw.js"), worker);
await writeFile("public/sw.js", worker);
console.log(
  `Offline toolkit: ${urls.length} static assets precached, version ${version}.`,
);
