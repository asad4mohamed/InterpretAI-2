import { spawnSync } from "node:child_process";
import path from "node:path";
// Serialize libuv filesystem work on Windows to avoid transient concurrent
// recursive-mkdir EPERM failures in constrained desktop environments.
const env = {
  ...process.env,
  ...(process.platform === "win32" ? { UV_THREADPOOL_SIZE: "1" } : {}),
};
for (const args of [
  ["scripts/prepare-lab.mjs"],
  ["scripts/prepare-signs.mjs"],
  ["scripts/icons.mjs"],
  [
    path.resolve("node_modules/next/dist/bin/next"),
    "build",
    ...(process.platform === "win32" ? ["--webpack"] : []),
  ],
  ["scripts/build-sw.mjs"],
]) {
  const result = spawnSync(process.execPath, args, { stdio: "inherit", env });
  if (result.status !== 0) process.exit(result.status ?? 1);
}
