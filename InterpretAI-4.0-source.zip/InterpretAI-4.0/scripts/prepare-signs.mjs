// Prepares the optional on-device sign recognition engine:
//  - copies the pinned ONNX Runtime Web (WASM) files from node_modules;
//  - downloads Google's MediaPipe Holistic Landmarker once (pinned SHA-256);
//  - compiles workers/sign-tracker.worker.ts and lib/asl/signs/* into plain
//    ES modules under public/sign-engine/ (MediaPipe and ONNX Runtime load
//    their own WASM with dynamic imports, which bundlers would rewrite);
//  - writes lib/sign-assets.json, the integrity manifest the download button,
//    the worker and the service worker share.
// The app builds without the Holistic file (offline machines); only live
// camera sign recognition then reports the missing file.
import { copyFile, mkdir, readFile, readdir, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import ts from "typescript";

const ROOT = "/sign-assets/v1";
const LAB = "/lab-assets/mp1.1.1-model1";
const dir = path.resolve(`public${ROOT}`);
await mkdir(path.join(dir, "ort"), { recursive: true });
for (const name of [
  "ort.wasm.min.mjs",
  "ort-wasm-simd-threaded.mjs",
  "ort-wasm-simd-threaded.wasm",
])
  await copyFile(
    path.resolve("node_modules/onnxruntime-web/dist", name),
    path.join(dir, "ort", name),
  );
await copyFile(
  "node_modules/onnxruntime-web/LICENSE",
  "public/third-party/onnxruntime-web-MIT.txt",
).catch(() => undefined);
await copyFile(
  "lib/asl/signs/LICENSE-GestureSign.txt",
  "public/third-party/gesturesign-MIT.txt",
);

const HOLISTIC = {
  url: "https://storage.googleapis.com/mediapipe-models/holistic_landmarker/holistic_landmarker/float16/1/holistic_landmarker.task",
  sha256: "e2dab61191e2dcd0a15f943d8e3ed1dce13c82dfa597b9dd39f562975a50c3f8",
  bytes: 13683609,
};
const holisticPath = path.join(dir, "holistic_landmarker.task");
const sha = async (file) =>
  createHash("sha256").update(await readFile(file)).digest("hex");
let holisticReady = false;
try {
  await stat(holisticPath);
  holisticReady = (await sha(holisticPath)) === HOLISTIC.sha256;
} catch {
  /* not present yet */
}
if (!holisticReady) {
  try {
    const response = await fetch(HOLISTIC.url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = new Uint8Array(await response.arrayBuffer());
    const digest = createHash("sha256").update(data).digest("hex");
    if (data.length !== HOLISTIC.bytes || digest !== HOLISTIC.sha256)
      throw new Error("the Holistic Landmarker failed its SHA-256 check");
    await writeFile(holisticPath, data);
    holisticReady = true;
  } catch (failure) {
    console.warn(
      `\n⚠ Optional Holistic model not downloaded (${failure instanceof Error ? failure.message : "network error"}).\n` +
        "  The app builds and runs; only live camera sign recognition is unavailable.\n" +
        '  Fix: connect to the internet and run "npm run prepare:signs".\n',
    );
  }
}

// ---- integrity manifest ----------------------------------------------------
const files = [
  { url: `${ROOT}/holistic_landmarker.task`, pinned: HOLISTIC },
  { url: `${LAB}/vision_bundle.mjs` },
  { url: `${LAB}/wasm/vision_wasm_module_internal.js` },
  { url: `${LAB}/wasm/vision_wasm_module_internal.wasm` },
  { url: `${ROOT}/ort/ort.wasm.min.mjs` },
  { url: `${ROOT}/ort/ort-wasm-simd-threaded.mjs` },
  { url: `${ROOT}/ort/ort-wasm-simd-threaded.wasm` },
  { url: "/models/asl-signs-v1/model.onnx" },
  { url: "/models/asl-signs-v1/model-meta.json" },
  { url: "/models/asl-signs-v1/labels.json" },
];
let previous = null;
try {
  previous = JSON.parse(await readFile("lib/sign-assets.json", "utf8"));
} catch {
  /* first run */
}
const manifestFiles = [];
for (const file of files) {
  const local = path.resolve(`public${file.url}`);
  try {
    const data = await readFile(local);
    manifestFiles.push({
      url: file.url,
      bytes: data.length,
      sha256: createHash("sha256").update(data).digest("hex"),
    });
  } catch {
    const known =
      file.pinned ?? previous?.files.find((entry) => entry.url === file.url);
    if (!known) throw new Error(`Missing sign asset ${file.url}`);
    manifestFiles.push({ url: file.url, bytes: known.bytes, sha256: known.sha256 });
  }
}
const manifest = {
  cacheName: "interpretai-signs-v1",
  root: ROOT,
  holistic: `${ROOT}/holistic_landmarker.task`,
  holisticSource: HOLISTIC.url,
  mediapipeWasm: `${LAB}/wasm`,
  visionBundle: `${LAB}/vision_bundle.mjs`,
  ortRoot: `${ROOT}/ort/`,
  model: "/models/asl-signs-v1/model.onnx",
  modelMeta: "/models/asl-signs-v1/model-meta.json",
  labels: "/models/asl-signs-v1/labels.json",
  vocabulary: "/models/asl-signs-v1/vocabulary.json",
  files: manifestFiles,
};
await writeFile("lib/sign-assets.json", JSON.stringify(manifest, null, 2) + "\n");

// ---- compile the worker and its modules ------------------------------------
const out = path.resolve("public/sign-engine");
await mkdir(out, { recursive: true });
const compile = async (file) =>
  ts.transpileModule(await readFile(file, "utf8"), {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      verbatimModuleSyntax: false,
    },
  }).outputText;
const signModules = (await readdir("lib/asl/signs")).filter((f) =>
  f.endsWith(".ts"),
);
for (const name of signModules) {
  const js = (await compile(`lib/asl/signs/${name}`)).replace(
    /from (['"])\.\/([a-z-]+)\1/g,
    'from "./$2.mjs"',
  );
  await writeFile(path.join(out, name.replace(/\.ts$/, ".mjs")), js);
}
const worker = (await compile("workers/sign-tracker.worker.ts"))
  .replace(/from ["']@mediapipe\/tasks-vision["']/, `from "${LAB}/vision_bundle.mjs"`)
  .replace(/from ["']onnxruntime-web\/wasm["']/, `from "${ROOT}/ort/ort.wasm.min.mjs"`)
  .replace(/from ["']\.\.\/lib\/asl\/signs\/([a-z-]+)["']/g, 'from "./$1.mjs"')
  .replace(/^import assets from .*;$/m, `const assets = ${JSON.stringify(manifest)};`);
if (/from ["'](?!\.\/|\/)/.test(worker))
  throw new Error("sign-tracker worker still has a bare import after compilation");
await writeFile(path.join(out, "sign-tracker.mjs"), worker);
const total = manifestFiles.reduce((sum, f) => sum + f.bytes, 0);
console.log(
  `Optional sign recognition: ${(total / 1e6).toFixed(1)} MB (${holisticReady ? "Holistic model present" : "Holistic model MISSING"}); excluded from automatic app-shell downloads.`,
);
