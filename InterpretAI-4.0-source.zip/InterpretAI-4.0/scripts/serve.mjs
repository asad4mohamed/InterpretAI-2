import http from "node:http";
import { existsSync } from "node:fs";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { staticExportPath } from "../lib/static-export-path.mjs";
for (const file of [".env.local", ".env"])
  if (existsSync(file)) process.loadEnvFile(file);
const root = path.resolve("out");
const port = Number(process.env.PORT || 3000);
const env = (name) => process.env[name]?.trim() || null;
/** Public, non-secret settings only. Secrets stay in server/proxy.mjs. */
const runtimeConfig = {
  proxyUrl: env("NEXT_PUBLIC_RECOGNITION_PROXY_URL"),
  localModelManifestUrl: env("NEXT_PUBLIC_LOCAL_MODEL_MANIFEST"),
  avatarProvider: env("NEXT_PUBLIC_AVATAR_PROVIDER") || "none",
  handTalkToken: env("NEXT_PUBLIC_HANDTALK_TOKEN"),
  maxClipSeconds: env("NEXT_PUBLIC_MAX_CLIP_SECONDS"),
};
const origin = (value) => {
  try {
    return value ? new URL(value).origin : null;
  } catch {
    return null;
  }
};
const proxyOrigin = origin(runtimeConfig.proxyUrl);
const handTalk = runtimeConfig.avatarProvider === "handtalk";
const handTalkHosts = handTalk ? " https://*.handtalk.me" : "";
const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval'${handTalkHosts}`,
  `style-src 'self' 'unsafe-inline'${handTalkHosts}`,
  `img-src 'self' data: blob:${handTalkHosts}`,
  `font-src 'self'${handTalkHosts}`,
  `media-src 'self' blob:${handTalkHosts}`,
  `connect-src 'self'${proxyOrigin ? " " + proxyOrigin : ""}${handTalkHosts}`,
  "worker-src 'self' blob:",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".json": "application/json",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
  ".wasm": "application/wasm",
};
const server = http.createServer(async (req, res) => {
  // Security headers apply to every response, including errors.
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader(
    "Permissions-Policy",
    "camera=(self), microphone=(), geolocation=()",
  );
  res.setHeader("Content-Security-Policy", csp);
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname === "/runtime-config.json") {
      res.writeHead(200, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      res.end(JSON.stringify(runtimeConfig));
      return;
    }
    // Next.js writes React segment payloads either flattened
    // (__next.route.__PAGE__.txt, Turbopack on macOS/Linux) or nested
    // (__next.route/__PAGE__.txt, Webpack). Serve whichever exists.
    const pathname = decodeURIComponent(url.pathname);
    let file = null;
    for (const candidate of new Set([pathname, staticExportPath(pathname)])) {
      const resolved = path.resolve(root, "." + candidate);
      if (resolved !== root && !resolved.startsWith(root + path.sep)) {
        res.writeHead(403);
        res.end();
        return;
      }
      try {
        const info = await stat(resolved);
        file = info.isDirectory()
          ? path.join(resolved, "index.html")
          : resolved;
        if (info.isDirectory()) await stat(file);
        break;
      } catch {
        // try the next layout
      }
    }
    if (!file) {
      file = path.join(root, "404.html");
      res.statusCode = 404;
    }
    const data = await readFile(file);
    res.setHeader(
      "Content-Type",
      types[path.extname(file)] || "application/octet-stream",
    );
    res.setHeader(
      "Cache-Control",
      path.basename(file) === "sw.js"
        ? "no-cache"
        : "public, max-age=0, must-revalidate",
    );
    res.end(data);
  } catch {
    res.writeHead(500);
    res.end("Build the prototype first with npm run build.");
  }
});
server.listen(port, "127.0.0.1", () => {
  console.log(`InterpretAI production preview: http://127.0.0.1:${port}`);
  console.log(
    `Recognition proxy: ${proxyOrigin ?? "not configured"} · Signing avatar: ${runtimeConfig.avatarProvider}${runtimeConfig.localModelManifestUrl ? " · Local model: " + runtimeConfig.localModelManifestUrl : ""}`,
  );
});
