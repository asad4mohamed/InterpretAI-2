#!/bin/bash
# macOS launcher for the prebuilt InterpretAI demo. Double-click in Finder.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22 or later is needed to open this demo. Install it from https://nodejs.org and try again."
  read -r -p "Press Return to close."
  exit 1
fi
if [ ! -f out/index.html ]; then
  echo "The prebuilt site (out/) is missing. Run: npm install && npm run build"
  read -r -p "Press Return to close."
  exit 1
fi
echo "InterpretAI - local prototype"
echo "Open http://127.0.0.1:3000 in your browser. Keep this window open; press Ctrl+C to stop."
node scripts/serve.mjs
