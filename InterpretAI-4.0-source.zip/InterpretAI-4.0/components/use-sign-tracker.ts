"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { handConnections } from "@/lib/handshapes";
import {
  cameraConstraints,
  cameraMessages,
  cameraSupport,
  classifyCameraError,
  isLowPerformance,
  stopStream,
  updateAverage,
} from "@/lib/camera";
import type {
  SignWorkerRequest,
  SignWorkerResponse,
} from "@/workers/sign-tracker.worker";

export type SignFrame = Extract<SignWorkerResponse, { type: "frame" }>;
export type SignResult = Extract<SignWorkerResponse, { type: "result" }>;
export type SignEngineStatus =
  | "idle"
  | "loading"
  | "ready" // engine loaded, camera off (replay possible)
  | "permission"
  | "running";
export type SignLoadStage =
  "worker" | "runtime" | "landmarker" | "model" | null;

/**
 * Signs need more frames than static letters: the model was trained at 30
 * fps and needs at least 8 frames per sign. Pace at up to ~30 fps and back
 * off on slow devices (at most 200 ms between frames).
 */
export function signFrameInterval(averageMs: number) {
  if (!Number.isFinite(averageMs) || averageMs <= 0) return 33;
  return Math.round(Math.min(200, Math.max(33, averageMs * 1.2)));
}

const POSE_LINES: [number, number][] = [
  [1, 2], // shoulders
  [1, 3],
  [3, 5], // left arm
  [2, 4],
  [4, 6], // right arm
];

/**
 * One camera + one sign worker. Same lifecycle rules as the hand tracker:
 * nothing starts without an explicit action; stop, unmount, and hiding the
 * tab terminate the worker and release every camera track.
 */
export function useSignTracker({
  onEvent,
}: {
  onEvent?: (message: SignWorkerResponse) => void;
} = {}) {
  const [status, setStatus] = useState<SignEngineStatus>("idle");
  const [loadStage, setLoadStage] = useState<SignLoadStage>(null);
  const [error, setError] = useState("");
  const [paused, setPaused] = useState(false);
  const [averageMs, setAverageMs] = useState(0);
  const [lowPerformance, setLowPerformance] = useState(false);
  const [engine, setEngine] = useState<{
    modelVersion: string;
    classes: number;
    delegate: string;
  } | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workerRef = useRef<Worker | null>(null);
  const readyRef = useRef<Promise<void> | null>(null);
  const requestRef = useRef(0); // camera starts
  const engineIdRef = useRef(0); // worker instances
  const frameRef = useRef(0);
  const inFlightRef = useRef(false);
  const pausedRef = useRef(false);
  const mountedRef = useRef(true);
  const averageRef = useRef(0);
  const lastStatsRef = useRef(0);
  const replayRef = useRef<(() => void) | null>(null);
  const onEventRef = useRef(onEvent);
  useEffect(() => {
    onEventRef.current = onEvent;
  }, [onEvent]);

  const clearOverlay = () => {
    const c = overlayRef.current;
    c?.getContext("2d")?.clearRect(0, 0, c.width, c.height);
  };

  const stopCamera = useCallback(() => {
    cancelAnimationFrame(frameRef.current);
    stopStream(streamRef.current);
    streamRef.current = null;
    inFlightRef.current = false;
    if (videoRef.current) videoRef.current.srcObject = null;
    clearOverlay();
  }, []);

  /** Stops the camera and terminates the engine. */
  const stop = useCallback(() => {
    requestRef.current++;
    engineIdRef.current++;
    stopCamera();
    workerRef.current?.terminate();
    workerRef.current = null;
    readyRef.current = null;
    replayRef.current?.();
    replayRef.current = null;
    averageRef.current = 0;
    pausedRef.current = false;
    if (mountedRef.current) {
      setStatus("idle");
      setLoadStage(null);
      setPaused(false);
      setAverageMs(0);
      setLowPerformance(false);
      setEngine(null);
    }
  }, [stopCamera]);

  useEffect(() => {
    mountedRef.current = true;
    const visibility = () => {
      if (document.hidden && streamRef.current) stop();
    };
    document.addEventListener("visibilitychange", visibility);
    return () => {
      mountedRef.current = false;
      stop();
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [stop]);

  const draw = (frame: SignFrame) => {
    const canvas = overlayRef.current;
    const video = videoRef.current;
    if (!canvas || !video || !video.videoWidth) return;
    if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth;
    if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const W = canvas.width;
    const H = canvas.height;
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(255,255,255,0.7)";
    for (const [a, b] of POSE_LINES) {
      const p = frame.upperBody[a];
      const q = frame.upperBody[b];
      if (!p || !q) continue;
      ctx.beginPath();
      ctx.moveTo(p.x * W, p.y * H);
      ctx.lineTo(q.x * W, q.y * H);
      ctx.stroke();
    }
    for (const hand of frame.hands) {
      ctx.strokeStyle = hand.side === "right" ? "#85e3ce" : "#f2c46d";
      for (const [from, to] of handConnections) {
        const a = hand.image[from];
        const b = hand.image[to];
        if (!a || !b) continue;
        ctx.beginPath();
        ctx.moveTo(a.x * W, a.y * H);
        ctx.lineTo(b.x * W, b.y * H);
        ctx.stroke();
      }
    }
  };

  const handle = useCallback((message: SignWorkerResponse) => {
    if (!mountedRef.current) return;
    if (message.type === "progress") setLoadStage(message.stage);
    if (message.type === "frame") {
      inFlightRef.current = false;
      if (message.frameWidth > 0) {
        averageRef.current = updateAverage(averageRef.current, message.ms);
        const now = performance.now();
        if (now - lastStatsRef.current > 500) {
          lastStatsRef.current = now;
          setAverageMs(Math.round(averageRef.current));
          setLowPerformance(isLowPerformance(averageRef.current));
        }
        draw(message);
      }
    }
    if (message.type === "error") inFlightRef.current = false;
    if (message.type === "replay-done") {
      replayRef.current?.();
      replayRef.current = null;
    }
    onEventRef.current?.(message);
  }, []);

  /** Loads the worker, landmarker and model (no camera). */
  const load = useCallback(async () => {
    if (readyRef.current) return readyRef.current;
    if (!window.Worker || !window.createImageBitmap || !window.WebAssembly) {
      const message =
        "On-device sign recognition is not supported in this browser. Use a current Chrome or Edge browser.";
      setError(message);
      throw new Error(message);
    }
    const engineId = ++engineIdRef.current;
    setError("");
    setStatus("loading");
    setLoadStage("worker");
    const worker = new Worker("/sign-engine/sign-tracker.mjs", {
      type: "module",
    });
    workerRef.current = worker;
    readyRef.current = new Promise<void>((resolve, reject) => {
      const timeout = window.setTimeout(
        () =>
          reject(new Error("Sign recognition took too long to load. Retry.")),
        90000,
      );
      worker.onerror = () => {
        clearTimeout(timeout);
        reject(
          new Error(
            "The sign recognition engine could not run in this browser.",
          ),
        );
      };
      worker.onmessage = (event: MessageEvent<SignWorkerResponse>) => {
        if (engineId !== engineIdRef.current) return;
        const message = event.data;
        if (message.type === "ready") {
          clearTimeout(timeout);
          setEngine({
            modelVersion: message.modelVersion,
            classes: message.classes,
            delegate: message.delegate,
          });
          resolve();
        } else if (message.type === "init-error") {
          clearTimeout(timeout);
          reject(new Error(message.message));
        }
        handle(message);
      };
      worker.postMessage({
        type: "init",
        origin: window.location.origin,
      } satisfies SignWorkerRequest);
    });
    try {
      await readyRef.current;
      if (engineId === engineIdRef.current && mountedRef.current) {
        setStatus("ready");
        setLoadStage(null);
      }
    } catch (failure) {
      if (engineId === engineIdRef.current) {
        stop();
        if (mountedRef.current)
          setError(
            failure instanceof Error
              ? failure.message
              : "Sign recognition failed to load.",
          );
      }
      throw failure;
    }
  }, [handle, stop]);

  const start = useCallback(async () => {
    setError("");
    const unsupported = cameraSupport();
    if (unsupported) {
      setError(
        unsupported === "insecure"
          ? cameraMessages.insecure
          : cameraMessages.unsupported,
      );
      return false;
    }
    try {
      await load();
    } catch {
      return false;
    }
    const request = ++requestRef.current;
    try {
      setStatus("permission");
      const stream =
        await navigator.mediaDevices.getUserMedia(cameraConstraints);
      if (request !== requestRef.current || !mountedRef.current) {
        stopStream(stream);
        return false;
      }
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) throw new Error("The local preview could not be opened.");
      video.srcObject = stream;
      await video.play();
      if (request !== requestRef.current || !mountedRef.current) return false;
      workerRef.current?.postMessage({
        type: "reset",
      } satisfies SignWorkerRequest);
      setStatus("running");
      let lastFrame = 0;
      let lastVideoTime = -1;
      const loop = (now: number) => {
        if (request !== requestRef.current || !streamRef.current) return;
        if (
          video.readyState >= 2 &&
          !document.hidden &&
          !pausedRef.current &&
          !inFlightRef.current &&
          now - lastFrame >= signFrameInterval(averageRef.current) &&
          video.currentTime !== lastVideoTime
        ) {
          lastFrame = now;
          lastVideoTime = video.currentTime;
          inFlightRef.current = true;
          createImageBitmap(video)
            .then((image) => {
              if (request !== requestRef.current || !workerRef.current) {
                image.close();
                return;
              }
              workerRef.current.postMessage(
                {
                  type: "frame",
                  image,
                  t: performance.now(),
                } satisfies SignWorkerRequest,
                [image],
              );
            })
            .catch(() => {
              inFlightRef.current = false;
            });
        }
        frameRef.current = requestAnimationFrame(loop);
      };
      frameRef.current = requestAnimationFrame(loop);
      return true;
    } catch (failure) {
      if (request !== requestRef.current || !mountedRef.current) return false;
      stopCamera();
      setStatus("ready");
      const kind = classifyCameraError(failure);
      setError(
        kind !== "unknown" && failure instanceof DOMException
          ? cameraMessages[kind]
          : failure instanceof Error
            ? failure.message
            : cameraMessages.unknown,
      );
      return false;
    }
  }, [load, stopCamera]);

  /** Releases the camera but keeps the engine loaded (replay stays possible). */
  const stopCameraOnly = useCallback(() => {
    requestRef.current++;
    stopCamera();
    workerRef.current?.postMessage({
      type: "reset",
    } satisfies SignWorkerRequest);
    pausedRef.current = false;
    if (mountedRef.current) {
      setPaused(false);
      setStatus(workerRef.current ? "ready" : "idle");
    }
  }, [stopCamera]);

  const pause = useCallback(() => {
    pausedRef.current = true;
    setPaused(true);
    // Discard any half-captured sign so resuming starts cleanly.
    workerRef.current?.postMessage({
      type: "reset",
    } satisfies SignWorkerRequest);
  }, []);
  const resume = useCallback(() => {
    pausedRef.current = false;
    setPaused(false);
  }, []);

  /** Plays real landmark frames through the same worker pipeline. */
  const replay = useCallback(
    async (frames: Float32Array[], fps: number) => {
      await load();
      await new Promise<void>((resolve) => {
        replayRef.current = resolve;
        workerRef.current?.postMessage(
          {
            type: "replay",
            frames,
            fps,
            t0: performance.now(),
          } satisfies SignWorkerRequest,
          frames.map((f) => f.buffer),
        );
      });
    },
    [load],
  );

  return {
    status,
    loadStage,
    error,
    setError,
    paused,
    pause,
    resume,
    averageMs,
    lowPerformance,
    engine,
    videoRef,
    overlayRef,
    load,
    start,
    stop,
    stopCamera: stopCameraOnly,
    replay,
  };
}
