import {
  Activity,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  Bell,
  BookOpen,
  CalendarDays,
  Camera,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  Clock3,
  ExternalLink,
  FileText,
  Hand,
  Heart,
  HeartPulse,
  Home,
  Info,
  LayoutDashboard,
  LifeBuoy,
  LockKeyhole,
  MapPin,
  Menu,
  MessageSquare,
  MonitorPlay,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Settings2,
  ShieldCheck,
  ShieldPlus,
  Sparkles,
  Trash2,
  Undo2,
  Waves,
  Users,
  Video,
  Wifi,
  WifiOff,
  X,
  type LucideIcon,
} from "lucide-react";
export type IconName =
  | "activity"
  | "download"
  | "arrow-left"
  | "arrow-right"
  | "bell"
  | "book"
  | "calendar"
  | "camera"
  | "check"
  | "checks"
  | "down"
  | "chevron"
  | "help"
  | "clipboard"
  | "clock"
  | "external"
  | "file"
  | "hand"
  | "heart"
  | "pulse"
  | "home"
  | "info"
  | "dashboard"
  | "support"
  | "lock"
  | "pin"
  | "menu"
  | "message"
  | "monitor"
  | "pause"
  | "play"
  | "plus"
  | "refresh"
  | "settings"
  | "shield"
  | "shield-plus"
  | "sparkles"
  | "trash"
  | "undo"
  | "waves"
  | "users"
  | "video"
  | "wifi"
  | "offline"
  | "x";
const icons: Record<IconName, LucideIcon> = {
  activity: Activity,
  download: ArrowDownToLine,
  "arrow-left": ArrowLeft,
  "arrow-right": ArrowRight,
  bell: Bell,
  book: BookOpen,
  calendar: CalendarDays,
  camera: Camera,
  check: Check,
  checks: CheckCheck,
  down: ChevronDown,
  chevron: ChevronRight,
  help: CircleHelp,
  clipboard: ClipboardCheck,
  clock: Clock3,
  external: ExternalLink,
  file: FileText,
  hand: Hand,
  heart: Heart,
  pulse: HeartPulse,
  home: Home,
  info: Info,
  dashboard: LayoutDashboard,
  support: LifeBuoy,
  lock: LockKeyhole,
  pin: MapPin,
  menu: Menu,
  message: MessageSquare,
  monitor: MonitorPlay,
  pause: Pause,
  play: Play,
  plus: Plus,
  refresh: RefreshCw,
  settings: Settings2,
  shield: ShieldCheck,
  "shield-plus": ShieldPlus,
  sparkles: Sparkles,
  trash: Trash2,
  undo: Undo2,
  waves: Waves,
  users: Users,
  video: Video,
  wifi: Wifi,
  offline: WifiOff,
  x: X,
};
export function Icon({
  name,
  size = 20,
  ...props
}: {
  name: IconName;
  size?: number;
  className?: string;
}) {
  const Component = icons[name];
  return (
    <Component size={size} strokeWidth={1.75} aria-hidden="true" {...props} />
  );
}
export function Brand({ light = false }: { light?: boolean }) {
  return (
    <span className={`brand ${light ? "brand-light" : ""}`}>
      <span>
        Interpret<span className="brand-ai">AI</span>
      </span>
      <span className="brand-punctuation" aria-hidden="true">
        .
      </span>
    </span>
  );
}
export function Badge({
  children,
  tone = "teal",
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}
export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}
export function PrototypeNote() {
  return (
    <div className="prototype-note">
      <Icon name="shield" size={17} />
      <span>
        <strong>Research prototype.</strong> Fictional data. Simulated — Not
        Clinically Validated. No clinical advice or live ASL translation.
      </span>
    </div>
  );
}
