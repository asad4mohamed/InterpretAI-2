"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AvatarSample } from "./avatar-sample";
import { Badge, Icon } from "./ui";
import { useApp } from "./app-provider";
import {
  downloadRecognitionTools,
  labAssets,
  recognitionToolsCached,
} from "@/lib/lab-cache";
import {
  emptyHandshape,
  sampleLetters,
  steadyHandshape,
  type SampleLetter,
} from "@/lib/handshapes";
import { useHandTracker, type TrackerResult } from "./use-hand-tracker";

export function HandshapeLab() {
  const { online, offlineReady } = useApp();
  const [download, setDownload] = useState<
    "checking" | "missing" | "loading" | "ready"
  >("checking");
  const [progress, setProgress] = useState(0);
  const [frameCandidate, setCandidate] = useState<SampleLetter | null>(null);
  const [letter, setLetter] = useState<SampleLetter>("L");
  const [downloadError, setDownloadError] = useState("");
  const [frameMessage, setTrackingMessage] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const downloadRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);
  const stableRef = useRef({ ...emptyHandshape });
  const rejectedUntilRef = useRef(0);
  const onFrame = useCallback((message: TrackerResult) => {
    const now = performance.now();
    const result = steadyHandshape(
      stableRef.current,
      now < rejectedUntilRef.current ? null : message.letter,
      now,
    );
    stableRef.current = result.state;
    setCandidate(result.candidate);
    setTrackingMessage(
      message.handCount > 1
        ? "Two hands are visible and both are tracked. The L/Y sample reads one hand only; lower one hand to try it."
        : message.handCount === 0
          ? "No hand detected. Move one hand into the frame."
          : result.candidate
            ? "A stable geometry match is available for your review."
            : message.letter
              ? `${message.letter}-like shape seen. Hold still for a moment…`
              : `One hand detected. ${message.hint || "Hold an L or Y handshape still; other shapes remain unknown."}`,
    );
  }, []);
  const {
    status: trackerStatus,
    loadStage,
    error: trackerError,
    setError: setTrackerError,
    handCount,
    lowPerformance,
    videoRef,
    overlayRef,
    start: startTracker,
    stop: stopTracker,
  } = useHandTracker({ onFrame });
  const candidate = trackerStatus === "running" ? frameCandidate : null;
  const trackingMessage =
    trackerStatus === "idle"
      ? "Camera is off. No handshape has been observed."
      : trackerStatus === "loading"
        ? loadStage === "model"
          ? "Loading the on-device hand model…"
          : "Loading the on-device runtime…"
        : trackerStatus === "permission"
          ? "Tracker ready. Waiting for your camera permission…"
          : frameMessage || "Camera running. Looking for a hand…";
  const camera =
    trackerStatus === "running"
      ? "running"
      : trackerStatus === "idle"
        ? "idle"
        : "starting";
  const error = downloadError || trackerError;
  const setError = (message: string) => {
    setDownloadError(message);
    if (!message) setTrackerError("");
  };
  const stop = useCallback(() => {
    stopTracker();
    stableRef.current = { ...emptyHandshape };
    if (mountedRef.current) {
      setCandidate(null);
      setTrackingMessage("");
    }
  }, [stopTracker]);
  useEffect(() => {
    mountedRef.current = true;
    recognitionToolsCached()
      .then((ready) => {
        if (mountedRef.current) setDownload(ready ? "ready" : "missing");
      })
      .catch(() => {
        if (mountedRef.current) setDownload("missing");
      });
    return () => {
      mountedRef.current = false;
      downloadRef.current?.abort();
    };
  }, []);
  async function downloadTools() {
    setError("");
    setProgress(0);
    setDownload("loading");
    const controller = new AbortController();
    downloadRef.current = controller;
    try {
      await downloadRecognitionTools(controller.signal, (value) => {
        if (mountedRef.current) setProgress(value);
      });
      if (mountedRef.current) setDownload("ready");
    } catch (failure) {
      if (!mountedRef.current) return;
      setDownload("missing");
      setError(
        controller.signal.aborted
          ? "Download cancelled. The scripted avatar and communication tools are still available."
          : failure instanceof Error
            ? failure.message
            : "Recognition tools could not be downloaded.",
      );
    } finally {
      if (downloadRef.current === controller) downloadRef.current = null;
    }
  }

  async function start() {
    if (download !== "ready") return;
    setError("");
    setConfirmation("");
    await startTracker();
  }
  const megabytes = (
    labAssets.files.reduce((sum, file) => sum + file.bytes, 0) / 1_000_000
  ).toFixed(1);
  return (
    <>
      <div className="simulation-disclaimer lab-disclaimer">
        <Icon name="shield" />
        <div>
          <strong>Experimental sample — Not Clinically Validated</strong>
          <span>
            Two handshapes only. No words, sentences, clinical interpretation,
            or treatment advice. The avatar is a scripted illustration awaiting
            Deaf-led review.
          </span>
        </div>
      </div>
      <section
        className="lab-download"
        aria-label="Optional recognition download"
      >
        <Icon name={download === "ready" ? "offline" : "download"} size={25} />
        <div>
          <h2>
            {download === "ready"
              ? "Recognition tools downloaded"
              : "An optional on-device toolkit"}
          </h2>
          <p>
            {download === "ready"
              ? `${megabytes} MB saved in this browser. ${offlineReady ? "Recognition assets are available offline." : "Production offline caching must be ready for offline recognition."}`
              : `${megabytes} MB of local model and runtime files. Core communication cards and the scripted avatar do not need this download.`}
          </p>
          {download === "loading" && (
            <p role="status">
              Downloading recognition files: {progress} of{" "}
              {labAssets.files.length}. No camera is active.
            </p>
          )}
        </div>
        {download === "loading" ? (
          <button
            className="btn btn-outline btn-small"
            onClick={() => downloadRef.current?.abort()}
          >
            Cancel download
          </button>
        ) : download === "ready" ? (
          <button
            className="text-button"
            onClick={async () => {
              stop();
              try {
                await caches.delete(labAssets.cacheName);
                setDownload("missing");
                setError("");
              } catch {
                setError(
                  "The optional download could not be removed. You can remove it through this browser’s site-storage settings.",
                );
              }
            }}
          >
            Remove downloaded tools
          </button>
        ) : (
          <button
            className="btn btn-outline btn-small"
            disabled={download === "checking"}
            onClick={downloadTools}
          >
            {download === "checking"
              ? "Checking local files…"
              : "Download recognition tools"}
          </button>
        )}
      </section>
      {!online && download !== "ready" && (
        <p className="notice">
          Connect once to download the optional recognition tools. The scripted
          avatar sample remains available offline after the app is cached.
        </p>
      )}
      {error && (
        <p className="lab-error" role="alert">
          {error}
        </p>
      )}
      <a href="#avatar-title" className="subtle-link lab-avatar-jump">
        Try the scripted avatar without a camera{" "}
        <Icon name="arrow-right" size={17} />
      </a>
      <div className="lab-grid">
        <section className="card lab-panel" aria-labelledby="recognition-title">
          <header>
            <div>
              <span className="eyebrow">01 · OBSERVE & REVIEW</span>
              <h2 id="recognition-title">Live handshape study</h2>
            </div>
            <Badge tone="gray">L / Y ONLY</Badge>
          </header>
          <div
            className={`lab-camera ${camera === "running" ? "lab-camera-active" : ""}`}
          >
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              aria-label="Local handshape camera preview; no recording"
            />
            <canvas ref={overlayRef} aria-hidden="true" />
            {camera !== "running" && (
              <div className="lab-camera-placeholder">
                <Icon name="camera" size={35} />
                <h3>
                  {camera === "starting"
                    ? "Starting local tracking…"
                    : "Your camera starts with your choice."}
                </h3>
                <p>
                  {camera === "starting"
                    ? trackerStatus === "permission"
                      ? "Waiting for your camera permission. Nothing is recorded."
                      : `Loading the ${loadStage === "model" ? "hand model" : "local runtime"} on this device, then your browser asks for camera permission.`
                    : "Frames are processed on this device and discarded. No recording, upload, or microphone."}
                </p>
              </div>
            )}
            {camera === "running" && (
              <span className="lab-camera-label">
                <Icon name="lock" size={14} />
                ON-DEVICE · MIRRORED PREVIEW · {handCount}{" "}
                {handCount === 1 ? "HAND" : "HANDS"}
              </span>
            )}
          </div>
          <div className="lab-camera-actions">
            {camera === "idle" ? (
              <button
                className="btn btn-primary"
                disabled={download !== "ready"}
                onClick={start}
              >
                <Icon name="camera" size={17} />
                Enable camera & handshape matching
              </button>
            ) : (
              <button className="btn btn-outline" onClick={stop}>
                <Icon name="x" size={17} />
                {camera === "starting"
                  ? "Cancel camera start"
                  : "Stop camera & tracking"}
              </button>
            )}
          </div>
          <div className="lab-candidate" role="status" aria-live="polite">
            <span className="eyebrow">EXPERIMENTAL GEOMETRY MATCH</span>
            <h3>Candidate handshape: {candidate ?? "Unknown"}</h3>
            <p>{trackingMessage}</p>
            {lowPerformance && (
              <p className="lab-performance-note">
                This device is processing frames slowly, so tracking now samples
                fewer frames per second.
              </p>
            )}
          </div>
          <div className="lab-review-controls">
            <button
              className="btn btn-primary btn-small"
              disabled={!candidate}
              onClick={() => {
                if (!candidate) return;
                setLetter(candidate);
                setConfirmation(
                  `You selected handshape ${candidate}. The avatar shows its scripted pose; this is not a verified ASL translation.`,
                );
              }}
            >
              Confirm & preview handshape
            </button>
            <button
              className="btn btn-outline btn-small"
              disabled={!candidate}
              onClick={() => {
                stableRef.current = { ...emptyHandshape };
                rejectedUntilRef.current = performance.now() + 2000;
                setCandidate(null);
                setConfirmation(
                  "Candidate cleared. Reposition your hand, or choose a scripted pose below.",
                );
              }}
            >
              That isn’t my handshape
            </button>
          </div>
          {confirmation && (
            <p className="lab-confirmation" role="status">
              {confirmation}
            </p>
          )}
          <p className="lab-method">
            MediaPipe estimates hand landmarks. Original geometry rules look for
            L-like and Y-like shapes. These rules can be wrong and do not assess
            language, palm orientation, or clinical understanding. No accuracy
            score is claimed.
          </p>
        </section>
        <section className="card lab-panel" aria-labelledby="avatar-title">
          <header>
            <div>
              <span className="eyebrow">02 · A SCRIPTED OUTPUT SAMPLE</span>
              <h2 id="avatar-title">Avatar pose study</h2>
            </div>
            <Badge tone="amber">UNREVIEWED</Badge>
          </header>
          <div
            className="avatar-letter-choice"
            role="group"
            aria-label="Scripted avatar handshape"
          >
            <span>Choose a fixed pose</span>
            {(["L", "Y"] as const).map((item) => (
              <button
                key={item}
                aria-pressed={letter === item}
                onClick={() => setLetter(item)}
              >
                Handshape {item}
              </button>
            ))}
          </div>
          <AvatarSample letter={letter} />
          <p className="lab-method">
            This original 3D mannequin follows two authored finger poses. It
            does not interpret clinician text or generate ASL grammar, motion,
            or facial expression. Choosing a pose never changes the live
            recognition result.
          </p>
        </section>
      </div>
      <section className="lab-protocol" aria-labelledby="lab-protocol-title">
        <div>
          <span className="eyebrow">WHAT THIS SAMPLE CAN TELL US</span>
          <h2 id="lab-protocol-title">
            Test the interaction. Keep the scope visible.
          </h2>
        </div>
        <ol>
          <li>
            <strong>Try a supported handshape.</strong>
            <p>
              {sampleLetters.L.instruction} For Y, extend the thumb and little
              finger instead.
            </p>
          </li>
          <li>
            <strong>Review the candidate.</strong>
            <p>
              Wait for a stable match, confirm it yourself, or reject it.
              Unknown shapes remain unknown.
            </p>
          </li>
          <li>
            <strong>Inspect the pose sample.</strong>
            <p>
              Replay the fixed pose, slow it down, or change the view.
              Reduced-motion preferences are respected.
            </p>
          </li>
        </ol>
        <p>
          Handshape matching and avatar illustrations have not been validated
          with Deaf ASL users. Low light, occlusion, camera angle, hand
          differences, and device performance may cause failures. The clinical
          workspace continues to use scripted cards and qualified human
          escalation.
        </p>
        <Link href="/communication/" className="subtle-link">
          Return to the communication workspace{" "}
          <Icon name="arrow-right" size={17} />
        </Link>
      </section>
      <p className="lab-credits">
        Technical references:{" "}
        <a
          href="https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker"
          target="_blank"
          rel="noreferrer"
        >
          MediaPipe hand landmarks{" "}
          <span className="sr-only">(opens in a new tab)</span>
        </a>{" "}
        ·{" "}
        <a
          href="https://www.lifeprint.com/asl101/fingerspelling/abc.htm"
          target="_blank"
          rel="noreferrer"
        >
          ASL University manual-alphabet reference{" "}
          <span className="sr-only">(opens in a new tab)</span>
        </a>
        . These links require internet access. No third-party signing video or
        illustration is copied into this lab.
      </p>
    </>
  );
}
