"use client";
import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import Link from "next/link";
import { useApp } from "./app-provider";
import { Badge, Icon } from "./ui";
import { useHandTracker, type TrackerResult } from "./use-hand-tracker";
import { useRecognitionSetup } from "./use-recognition-config";
import { SigningAvatarPanel, type SignRequest } from "./signing-avatar-panel";
import {
  SignRecognitionPanel,
  type SignSubmission,
} from "./sign-recognition-panel";
import {
  EntryCard,
  FingerspellingReadout,
  ModelInfoPanel,
} from "./recognition-parts";
import {
  classifyHand,
  emptySpeller,
  handFeatures,
  spelledText,
  stepSpeller,
  type LetterDecision,
  type StaticHandModel,
} from "@/lib/asl/fingerspelling";
import { avatarAvailability } from "@/lib/asl/avatar";
import { SequenceRecorder } from "@/lib/asl/landmark-sequence";
import { cacheLocalModel } from "@/lib/asl/local-recognition";
import type {
  createFingerspellingProvider,
  createLocalModelProvider,
} from "@/lib/asl/provider-registry";
import {
  conversationReducer,
  emptyConversation,
  inConversation,
  phaseForError,
  phaseLabels,
  type WorkspacePhase,
} from "@/lib/asl/recognition-state";
import {
  RecognitionError,
  type ConsentState,
  type ProcessingStatus,
  type ProviderAvailability,
  type VideoClip,
} from "@/lib/asl/types";
import {
  emptyHandshape,
  steadyHandshape,
  type SampleLetter,
} from "@/lib/handshapes";
import { detectRisk, type RiskTopic } from "@/lib/scenarios";

const CAPTURE_MS = 3000;
let entryCounter = 0;
const nextId = () => `entry-${Date.now().toString(36)}-${++entryCounter}`;

const availabilityTone = (a?: ProviderAvailability) =>
  a?.state === "available"
    ? "teal"
    : a?.state === "needs-download"
      ? "amber"
      : "gray";
const availabilityText = (a?: ProviderAvailability) =>
  !a
    ? "Checking…"
    : a.state === "available"
      ? "Available"
      : a.state === "needs-download"
        ? "Download needed"
        : a.state === "not-configured"
          ? "Not configured"
          : a.state === "offline"
            ? "Offline"
            : a.state === "simulated-outage"
              ? "Demo outage"
              : a.state === "unsupported-browser"
                ? "Unsupported browser"
                : "Unavailable";

function pickRecorderType() {
  if (typeof MediaRecorder === "undefined") return null;
  for (const type of [
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/webm",
    "video/mp4",
  ])
    if (MediaRecorder.isTypeSupported?.(type)) return type;
  return null;
}

export function RecognitionWorkspace() {
  const { online, simulatedOffline, setSimulatedOffline, requestInterpreter } =
    useApp();
  const setup = useRecognitionSetup();
  const { config, availability, manager } = setup;
  const [providerId, setProviderId] = useState("unavailable");
  const [cameraConsent, setCameraConsent] = useState(false);
  const [phase, setPhase] = useState<WorkspacePhase>("camera-off");
  const [detail, setDetail] = useState(
    "Choose a recognition mode. The camera stays off until you start it.",
  );
  const [conversation, dispatch] = useReducer(
    conversationReducer,
    emptyConversation,
  );
  const [capturing, setCapturing] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [clip, setClip] = useState<(VideoClip & { url: string }) | null>(null);
  const [uploadConsent, setUploadConsent] = useState(false);
  const [liveHint, setLiveHint] = useState("");
  const [liveCandidate, setLiveCandidate] = useState<SampleLetter | null>(null);
  const [draft, setDraft] = useState("");
  const [speak, setSpeak] = useState(false);
  const [signRequest, setSignRequest] = useState<SignRequest>(null);
  const [fsModel, setFsModel] = useState<StaticHandModel | null>(null);
  const [fsDecision, setFsDecision] = useState<LetterDecision | null>(null);
  const [fsProgress, setFsProgress] = useState(0);
  const [fsText, setFsText] = useState("");
  const [fsModelMs, setFsModelMs] = useState(0);
  const [photo, setPhoto] = useState<{ blob: Blob; url: string } | null>(null);
  const [photoConsent, setPhotoConsent] = useState(false);
  const providerRef = useRef("unavailable");
  const fsModelRef = useRef<StaticHandModel | null>(null);
  const spellerRef = useRef({ ...emptySpeller });
  const letterScoresRef = useRef<{ letter: string; score: number }[]>([]);
  const recorderRef = useRef(new SequenceRecorder());
  const capturingRef = useRef(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const stableRef = useRef({ ...emptyHandshape });
  const captureTimer = useRef(0);
  const provider = setup.registry.get(providerId);
  const descriptor = provider.descriptor;
  const providerAvailability = availability[providerId];
  const isCloud = descriptor.capabilities.location === "cloud";
  const needsTracking =
    descriptor.capabilities.input === "landmark-stream" ||
    descriptor.capabilities.input === "landmark-sequence";
  const isFingerspelling = providerId === "fingerspelling";
  const isSigns = providerId === "asl-signs";
  const isPhoto = descriptor.capabilities.input === "still-image";
  const escalated = conversation.escalation !== null;

  const onFrame = useCallback((message: TrackerResult) => {
    if (capturingRef.current)
      recorderRef.current.push({
        t: message.timestamp,
        hands: message.hands.map((hand) => ({
          handedness: hand.handedness,
          handednessScore: hand.handednessScore,
          image: hand.image,
          world: hand.world,
        })),
      });
    const now = performance.now();
    const model = fsModelRef.current;
    if (providerRef.current === "fingerspelling" && model) {
      const hand = message.hands.length === 1 ? message.hands[0] : null;
      const features = hand
        ? handFeatures(hand.image, message.frameWidth, message.frameHeight)
        : null;
      const decision = features ? classifyHand(model, features) : null;
      const step = stepSpeller(spellerRef.current, {
        letter: decision?.letter ?? null,
        handPresent: message.handCount > 0,
        t: message.timestamp,
      });
      spellerRef.current = step.state;
      if (step.committed && decision)
        letterScoresRef.current.push({
          letter: step.committed,
          score: decision.score,
        });
      setFsDecision(decision);
      setFsProgress(step.state.progress);
      if (decision) setFsModelMs(decision.inferenceMs);
      setFsText(spelledText(step.state));
      return;
    }
    setLiveHint(message.handCount === 1 && !message.letter ? message.hint : "");
    const step = steadyHandshape(stableRef.current, message.letter, now);
    stableRef.current = step.state;
    setLiveCandidate(step.candidate);
  }, []);
  const {
    status: trackerStatus,
    paused,
    pause,
    resume,
    averageMs,
    loadStage,
    error: trackerError,
    tracking,
    handCount,
    lowPerformance,
    videoRef,
    overlayRef,
    streamRef,
    start: startTracker,
    stop: stopTracker,
  } = useHandTracker({ onFrame });
  const cameraRunning = trackerStatus === "running";

  const announce = useCallback((next: WorkspacePhase, text: string) => {
    setPhase(next);
    setDetail(text);
  }, []);

  // Live camera/tracking state is derived during render (never via effects).
  const camera: { phase: WorkspacePhase; text: string } =
    trackerStatus === "loading"
      ? {
          phase: "model-loading",
          text:
            loadStage === "model"
              ? "Loading the on-device hand model…"
              : "Loading the on-device runtime…",
        }
      : trackerStatus === "permission"
        ? {
            phase: "permission-required",
            text: "Waiting for camera permission in your browser. Nothing is recorded.",
          }
        : trackerStatus === "running" && !needsTracking
          ? {
              phase: "camera-ready",
              text: "Camera ready. Record a short clip, review it, then decide whether to send it.",
            }
          : trackerStatus === "running"
            ? tracking === "tracking"
              ? isFingerspelling
                ? {
                    phase: fsDecision?.letter ? "letter-detected" : "tracking",
                    text: fsDecision?.letter
                      ? `Fingerspelled letter ${fsDecision.letter} detected (model output).`
                      : `${handCount === 2 ? "Both hands" : "One hand"} tracked on this device.`,
                  }
                : liveCandidate && providerId === "experimental-handshape"
                  ? {
                      phase: "handshape-detected",
                      text: `Experimental ${liveCandidate}-like handshape held steady. Capture to add it for review.`,
                    }
                  : {
                      phase: "tracking",
                      text: `${handCount === 2 ? "Both hands" : "One hand"} tracked on this device.${providerId === "experimental-handshape" && liveHint ? ` ${liveHint}` : ""}`,
                    }
              : tracking === "tracking-lost"
                ? {
                    phase: "tracking-lost",
                    text: "Tracking lost. Bring your hands back into the frame.",
                  }
                : {
                    phase: "no-hands",
                    text: "No hands detected. Move your hands into the frame.",
                  }
            : trackerError
              ? { phase: "error", text: trackerError }
              : { phase: "camera-off", text: "Camera is off." };

  const discardClip = useCallback(() => {
    setClip((current) => {
      if (current) URL.revokeObjectURL(current.url);
      return null;
    });
    setUploadConsent(false);
  }, []);

  const discardPhoto = useCallback(() => {
    setPhoto((current) => {
      if (current) URL.revokeObjectURL(current.url);
      return null;
    });
    setPhotoConsent(false);
  }, []);

  const resetSpelling = useCallback(() => {
    spellerRef.current = { ...emptySpeller };
    letterScoresRef.current = [];
    setFsText("");
    setFsDecision(null);
    setFsProgress(0);
  }, []);

  const stopEverything = useCallback(() => {
    window.clearTimeout(captureTimer.current);
    capturingRef.current = false;
    recorderRef.current.clear();
    if (mediaRecorderRef.current?.state === "recording")
      mediaRecorderRef.current.stop();
    mediaRecorderRef.current = null;
    manager.cancel();
    stopTracker();
    setCapturing(false);
    setLiveCandidate(null);
    setFsDecision(null);
    stableRef.current = { ...emptyHandshape };
    announce(
      "camera-off",
      "Camera stopped. All camera tracks were released. Nothing was saved.",
    );
  }, [manager, stopTracker, announce]);

  useEffect(() => () => window.clearTimeout(captureTimer.current), []);
  useEffect(
    () => () => {
      if (clip) URL.revokeObjectURL(clip.url);
    },
    [clip],
  );
  useEffect(
    () => () => {
      if (photo) URL.revokeObjectURL(photo.url);
    },
    [photo],
  );

  function changeProvider(id: string) {
    if (cameraRunning || trackerStatus !== "idle") stopEverything();
    discardClip();
    discardPhoto();
    resetSpelling();
    setProviderId(id);
    providerRef.current = id;
    if (id === "fingerspelling" && !fsModelRef.current)
      (
        setup.registry.get("fingerspelling") as ReturnType<
          typeof createFingerspellingProvider
        >
      )
        .model()
        .then((model) => {
          fsModelRef.current = model;
          setFsModel(model);
        })
        .catch((failure) =>
          announce(
            "error",
            failure instanceof Error
              ? failure.message
              : "The fingerspelling model could not be loaded.",
          ),
        );
    const next = setup.registry.get(id);
    const a = availability[id];
    if (next.descriptor.mode === "unavailable")
      announce(
        "unavailable",
        "Recognition is off. Nothing will be interpreted. Use typing, scripted cards, or a qualified interpreter.",
      );
    else if (a && a.state !== "available")
      announce(
        a.state === "offline" || a.state === "simulated-outage"
          ? "offline"
          : "unavailable",
        "detail" in a ? a.detail : "Unavailable.",
      );
    else
      announce(
        "camera-off",
        `${next.descriptor.label} selected. Start the camera when you are ready.`,
      );
  }

  async function startCamera() {
    if (!cameraConsent) {
      announce("permission-required", "Please agree to camera use first.");
      return;
    }
    const started = await startTracker({ track: needsTracking });
    if (started)
      announce(
        "camera-ready",
        isFingerspelling
          ? "Camera on. Fingerspell one letter at a time; each letter is added after a steady hold."
          : isPhoto
            ? "Camera on. Take a photo when ready; nothing is sent until you review and consent."
            : "Camera on. Nothing is recorded or sent unless you choose to.",
      );
  }

  async function runRecognition(request: Parameters<typeof manager.run>[1]) {
    setProcessing(true);
    announce(
      "processing",
      isCloud
        ? `Sending to ${descriptor.thirdParty?.name ?? "the provider"} through the secure proxy…`
        : "Recognising on this device…",
    );
    const started = performance.now();
    const took = () => `${Math.round(performance.now() - started)} ms`;
    try {
      const outcome = await manager.run(
        providerId,
        request,
        { online, simulatedOffline },
        (status: ProcessingStatus) => {
          if (status.phase === "uploading")
            announce("processing", "Uploading after your consent…");
          if (status.phase === "polling")
            announce(
              "processing",
              `Waiting for the provider (check ${status.attempt})…`,
            );
        },
      );
      if (outcome.result.outcome === "unknown") {
        announce(
          "unknown",
          `Unknown — nothing was recognised with enough certainty (${took()}). Nothing was added. Try again, type, or request an interpreter.`,
        );
        return;
      }
      dispatch({
        type: "recognized",
        id: nextId(),
        result: outcome.result,
        risk: outcome.risk,
      });
      if (outcome.risk)
        announce(
          "interpreter-recommended",
          `${outcome.risk} detected in the recognised text. Automated recognition is paused; a qualified interpreter is recommended.`,
        );
      else
        announce(
          "completed",
          `Machine output ready for your review (${took()}). Only output you confirm or correct is added to the conversation.`,
        );
    } catch (failure) {
      const error =
        failure instanceof RecognitionError
          ? failure
          : new RecognitionError("provider-error", "Recognition failed.");
      announce(
        error.code === "cancelled"
          ? cameraRunning
            ? "camera-ready"
            : "camera-off"
          : phaseForError(error.code),
        error.code === "cancelled"
          ? "Recognition cancelled. Nothing was added."
          : `${error.message} No result was displayed, and no scripted text was substituted.`,
      );
    } finally {
      setProcessing(false);
    }
  }

  function captureLandmarks() {
    if (!cameraRunning || capturingRef.current) return;
    recorderRef.current.clear();
    capturingRef.current = true;
    setCapturing(true);
    announce(
      "capturing",
      "Capturing hand landmarks for 3 seconds. Sign once, then hold still.",
    );
    captureTimer.current = window.setTimeout(() => {
      capturingRef.current = false;
      setCapturing(false);
      const sequence = recorderRef.current.finish();
      runRecognition({
        kind: "landmark-sequence",
        sequence,
        consent: { camera: true, thirdPartyUpload: null },
      });
    }, CAPTURE_MS);
  }

  function recordClip() {
    const stream = streamRef.current;
    const type = pickRecorderType();
    if (!stream || !type) {
      announce(
        "error",
        "This browser cannot record a video clip. Nothing was recorded.",
      );
      return;
    }
    discardClip();
    const chunks: Blob[] = [];
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(stream, {
        mimeType: type,
        videoBitsPerSecond: 1_000_000,
      });
    } catch {
      announce("error", "Video recording could not start in this browser.");
      return;
    }
    mediaRecorderRef.current = recorder;
    const started = performance.now();
    recorder.ondataavailable = (event) => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onstop = () => {
      window.clearTimeout(captureTimer.current);
      setCapturing(false);
      if (mediaRecorderRef.current !== recorder) return; // stopped by camera shutdown
      mediaRecorderRef.current = null;
      const blob = new Blob(chunks, { type: type.split(";")[0] });
      chunks.length = 0;
      setClip({
        blob,
        mimeType: blob.type,
        durationMs: performance.now() - started,
        url: URL.createObjectURL(blob),
      });
      setUploadConsent(false);
      announce(
        "awaiting-consent",
        "Clip recorded and kept only in this page. Review it, then send it or discard it.",
      );
    };
    recorder.start(250);
    setCapturing(true);
    announce(
      "capturing",
      `Recording up to ${config.maxClipSeconds} seconds. Video only; no audio.`,
    );
    captureTimer.current = window.setTimeout(() => {
      if (recorder.state === "recording") recorder.stop();
    }, config.maxClipSeconds * 1000);
  }

  function sendClip() {
    if (!clip || !uploadConsent) return;
    const consent: ConsentState = {
      camera: cameraConsent,
      thirdPartyUpload: { provider: descriptor.id, grantedAt: Date.now() },
    };
    const toSend = clip;
    // Consent is per clip: clear the clip and consent as soon as it is submitted.
    setClip(null);
    setUploadConsent(false);
    runRecognition({ kind: "video-clip", clip: toSend, consent }).finally(() =>
      URL.revokeObjectURL(toSend.url),
    );
  }

  function takePhoto() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    discardPhoto();
    const canvas = document.createElement("canvas");
    // Downscale to at most 640 px wide to minimise the upload.
    const scale = Math.min(1, 640 / video.videoWidth);
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    canvas
      .getContext("2d")
      ?.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(
      (blob) => {
        canvas.width = canvas.height = 0;
        if (!blob) {
          announce("error", "The photo could not be captured.");
          return;
        }
        setPhoto({ blob, url: URL.createObjectURL(blob) });
        setPhotoConsent(false);
        announce(
          "awaiting-consent",
          "Photo taken and kept only in this page. Review it, then send or discard it.",
        );
      },
      "image/jpeg",
      0.85,
    );
  }

  function sendPhoto() {
    if (!photo || !photoConsent) return;
    const toSend = photo;
    setPhoto(null);
    setPhotoConsent(false);
    runRecognition({
      kind: "still-image",
      image: toSend.blob,
      consent: {
        camera: cameraConsent,
        thirdPartyUpload: { provider: descriptor.id, grantedAt: Date.now() },
      },
    }).finally(() => URL.revokeObjectURL(toSend.url));
  }

  function sendSpelling() {
    const text = spelledText(spellerRef.current).trim();
    if (!text) return;
    const letters = letterScoresRef.current.slice();
    resetSpelling();
    runRecognition({
      kind: "fingerspelling",
      text,
      letters,
      consent: { camera: cameraConsent, thirdPartyUpload: null },
    });
  }

  function editSpelling(change: "space" | "backspace") {
    const state = spellerRef.current;
    if (change === "space") {
      if (!state.current) return;
      spellerRef.current = {
        ...state,
        words: [...state.words, state.current],
        current: "",
        lastCommitted: null,
      };
    } else if (state.current) {
      spellerRef.current = {
        ...state,
        current: state.current.slice(0, -1),
        lastCommitted: null,
      };
      letterScoresRef.current.pop();
    } else if (state.words.length) {
      const words = state.words.slice();
      const last = words.pop() ?? "";
      spellerRef.current = { ...state, words, current: last };
    }
    setFsText(spelledText(spellerRef.current));
  }

  function submitSigns(submission: SignSubmission) {
    runRecognition({
      kind: "sign-sequence",
      english: submission.english,
      glosses: submission.glosses,
      minProbability: submission.minProbability,
      userWritten: submission.userWritten,
      modelVersion: submission.modelVersion,
      consent: { camera: true, thirdPartyUpload: null },
    });
  }

  async function saveModelOffline() {
    const local = setup.registry.get("local-model") as ReturnType<
      typeof createLocalModelProvider
    >;
    try {
      const { manifest, weightsUrl } = await local.model();
      await cacheLocalModel(
        config.localModelManifestUrl!,
        weightsUrl,
        manifest.id,
        manifest.version,
      );
      announce(
        "camera-off",
        `Model ${manifest.id}@${manifest.version} saved in this browser for offline use.`,
      );
    } catch (failure) {
      announce(
        "error",
        failure instanceof Error
          ? failure.message
          : "The model could not be saved for offline use.",
      );
    }
  }

  function speakText(text: string) {
    if (typeof speechSynthesis === "undefined") return;
    speechSynthesis.cancel();
    speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  }

  function escalate(risk: RiskTopic) {
    dispatch({ type: "escalate", risk });
    announce(
      "interpreter-recommended",
      `${risk} is high-risk. Automated recognition and machine signing are paused. Request a qualified interpreter.`,
    );
  }

  function sendProviderText(event: React.FormEvent) {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;
    const risk = detectRisk(text);
    const id = nextId();
    dispatch({ type: "provider-text", id, text, risk });
    setDraft("");
    if (risk) escalate(risk);
    else if (speak) speakText(text);
  }

  const avatarState = avatarAvailability(
    config,
    { online, simulatedOffline },
    setup.proxyProduction,
  );
  const canRecognize =
    providerAvailability?.state === "available" &&
    descriptor.mode !== "unavailable" &&
    !escalated;
  const busy = processing || capturing;

  return (
    <div className="workspace recognition-workspace">
      <div className="simulation-disclaimer">
        <Icon name="shield" size={19} />
        <div>
          <strong>Experimental — Not Clinically Validated</strong>
          <span>
            Separate from the scripted scenarios. Results come only from the
            mode you choose and are shown exactly as returned. Nothing is
            translated when recognition is off. Qualified interpretation is
            required for clinical discussion.
          </span>
        </div>
        <Badge tone="amber">RESEARCH PROTOTYPE</Badge>
      </div>

      <div className="scenario-toolbar">
        <fieldset className="mode-selector">
          <legend>Recognition mode</legend>
          {setup.registry.list().map((item) => (
            <label
              key={item.descriptor.id}
              className={`mode-option ${providerId === item.descriptor.id ? "selected" : ""}`}
            >
              <input
                type="radio"
                name="recognition-mode"
                value={item.descriptor.id}
                checked={providerId === item.descriptor.id}
                onChange={() => changeProvider(item.descriptor.id)}
                disabled={busy}
              />
              <span>
                <strong>{item.descriptor.label}</strong>
                <small>{item.descriptor.summary}</small>
                <span className="mode-meta">
                  <Badge
                    tone={availabilityTone(availability[item.descriptor.id])}
                  >
                    {item.descriptor.mode === "unavailable"
                      ? "Off · nothing interpreted"
                      : availabilityText(availability[item.descriptor.id])}
                  </Badge>
                  <span>
                    {item.descriptor.capabilities.location === "cloud"
                      ? "Cloud · third party"
                      : "On this device"}
                  </span>
                </span>
              </span>
            </label>
          ))}
        </fieldset>
        <div className="mode-tools">
          <button
            className="btn btn-outline btn-small"
            onClick={() => setup.refresh()}
            disabled={setup.checking}
          >
            <Icon name="refresh" size={15} />
            {setup.checking ? "Checking providers…" : "Recheck providers"}
          </button>
          <button
            className={`btn btn-small ${simulatedOffline ? "btn-amber" : "btn-outline"}`}
            onClick={() => setSimulatedOffline(!simulatedOffline)}
            aria-pressed={simulatedOffline}
          >
            <Icon name={simulatedOffline ? "wifi" : "offline"} size={16} />
            {simulatedOffline ? "Restore demo connection" : "Simulate outage"}
          </button>
        </div>
      </div>

      {!isSigns && (
        <ModelInfoPanel
          descriptor={descriptor}
          availability={providerAvailability}
          fingerspelling={fsModel}
          health={setup.health}
        />
      )}

      {(!online || simulatedOffline) && (
        <div className="workspace-offline" role="status">
          <Icon name="offline" />
          <div>
            <strong>
              {simulatedOffline
                ? "Simulated outage — browser network unchanged"
                : "Offline — cloud recognition and signing avatars are unavailable"}
            </strong>
            <p>
              On-device modes keep working once their files are downloaded. No
              request is queued or sent later.
            </p>
          </div>
        </div>
      )}

      <div className="live-status" role="status" aria-live="polite">
        <span className={`live-phase phase-${phase}`}>
          {phaseLabels[phase]}
        </span>
        <span>{detail}</span>
      </div>

      {escalated && (
        <div className="safety-stop" role="alert">
          <span className="safety-stop-icon">
            <Icon name="shield" size={27} />
          </span>
          <div>
            <Badge tone="amber">HUMAN INTERPRETER RECOMMENDED</Badge>
            <h3>This conversation needs a qualified interpreter.</h3>
            <p>
              {conversation.escalation} is outside what automated recognition or
              machine signing may handle. Recognition and signing are paused.
              Written English remains available.
            </p>
            <small>
              For an urgent situation, use your clinic’s or local emergency
              service’s accessible process. This app does not contact anyone.
            </small>
          </div>
          <button className="btn btn-primary" onClick={requestInterpreter}>
            Request Qualified Interpreter
            <Icon name="users" size={18} />
          </button>
        </div>
      )}

      {isSigns && (
        <SignRecognitionPanel
          variant="workspace"
          disabled={escalated}
          busy={processing}
          onSubmit={submitSigns}
          onToolsChanged={() => setup.refresh()}
        />
      )}

      <div className="workspace-grid">
        <section
          className="communication-panel patient-panel"
          aria-labelledby="live-patient-title"
        >
          <header>
            <span className="panel-person-icon">
              <Icon name="hand" />
            </span>
            <div>
              <h2 id="live-patient-title">Patient</h2>
              <p>
                {descriptor.capabilities.location === "cloud"
                  ? "Clip sent to cloud only with your consent"
                  : "Processed on this device"}
              </p>
            </div>
            <Badge tone={isCloud ? "amber" : "teal"}>
              {isCloud ? "CLOUD" : "ON-DEVICE"}
            </Badge>
          </header>

          {!isSigns && (
            <>
              <div
                className={`lab-camera live-camera ${cameraRunning ? "lab-camera-active" : ""}`}
              >
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  aria-label="Live camera preview, mirrored; not recorded unless you record a clip"
                />
                <canvas ref={overlayRef} aria-hidden="true" />
                {!cameraRunning && (
                  <div className="lab-camera-placeholder">
                    <Icon name="camera" size={35} />
                    <h3>
                      {trackerStatus === "idle"
                        ? "Camera is off."
                        : phaseLabels[camera.phase]}
                    </h3>
                    <p>
                      {descriptor.mode === "unavailable"
                        ? "Recognition is off. Choose a mode above to use the camera."
                        : needsTracking
                          ? "Hand landmarks are computed on this device. Frames are discarded after processing."
                          : "You can record a short clip. It stays in this page until you choose to send or discard it."}
                    </p>
                  </div>
                )}
                {cameraRunning && (
                  <span className="lab-camera-label">
                    <Icon name="lock" size={14} />
                    {needsTracking
                      ? `ON-DEVICE · ${handCount} ${handCount === 1 ? "HAND" : "HANDS"}`
                      : "LOCAL PREVIEW"}
                    {capturing ? " · CAPTURING" : ""}
                  </span>
                )}
              </div>

              <p className="camera-state" role="status">
                <span className={`live-phase phase-${camera.phase}`}>
                  {phaseLabels[camera.phase]}
                </span>
                <span>{camera.text}</span>
              </p>
              <div className="live-controls">
                {descriptor.mode !== "unavailable" && (
                  <label className="consent-check">
                    <input
                      type="checkbox"
                      checked={cameraConsent}
                      onChange={(event) => {
                        setCameraConsent(event.target.checked);
                        if (!event.target.checked) stopEverything();
                      }}
                    />
                    <span>
                      I agree to turn on my camera for this session. Video stays
                      on this device unless I choose to send a specific clip.
                    </span>
                  </label>
                )}
                <div className="live-buttons">
                  {trackerStatus === "idle" ? (
                    <button
                      className="btn btn-primary"
                      disabled={!canRecognize || !cameraConsent}
                      onClick={startCamera}
                    >
                      <Icon name="camera" size={17} />
                      Start camera
                    </button>
                  ) : (
                    <button
                      className="btn btn-outline"
                      onClick={stopEverything}
                    >
                      <Icon name="x" size={17} />
                      {trackerStatus === "running"
                        ? "Stop camera now"
                        : "Cancel camera start"}
                    </button>
                  )}
                  {cameraRunning && needsTracking && !isFingerspelling && (
                    <button
                      className="btn btn-primary"
                      disabled={busy || !canRecognize || paused}
                      onClick={captureLandmarks}
                    >
                      <Icon name="hand" size={17} />
                      {capturing ? "Capturing…" : "Capture sign (3 s)"}
                    </button>
                  )}
                  {cameraRunning && needsTracking && (
                    <button
                      className="btn btn-outline"
                      aria-pressed={paused}
                      onClick={paused ? resume : pause}
                    >
                      <Icon name={paused ? "play" : "pause"} size={17} />
                      {paused ? "Resume recognition" : "Pause recognition"}
                    </button>
                  )}
                  {cameraRunning && isPhoto && (
                    <button
                      className="btn btn-primary"
                      disabled={busy || !canRecognize}
                      onClick={takePhoto}
                    >
                      <Icon name="camera" size={17} />
                      Take photo
                    </button>
                  )}
                  {cameraRunning &&
                    !needsTracking &&
                    !isPhoto &&
                    (capturing ? (
                      <button
                        className="btn btn-primary"
                        onClick={() => mediaRecorderRef.current?.stop()}
                      >
                        Stop recording
                      </button>
                    ) : (
                      <button
                        className="btn btn-primary"
                        disabled={busy || !canRecognize}
                        onClick={recordClip}
                      >
                        <Icon name="video" size={17} />
                        Record clip (max {config.maxClipSeconds} s)
                      </button>
                    ))}
                  {processing && (
                    <button
                      className="btn btn-outline"
                      onClick={() => manager.cancel()}
                    >
                      Cancel recognition
                    </button>
                  )}
                </div>
                {!canRecognize &&
                  descriptor.mode !== "unavailable" &&
                  providerAvailability &&
                  providerAvailability.state !== "available" && (
                    <p className="live-unavailable">
                      {"detail" in providerAvailability
                        ? providerAvailability.detail
                        : ""}
                      {providerAvailability.state === "needs-download" && (
                        <>
                          {" "}
                          <Link href="/sample-lab/">
                            Open the sample lab to download the on-device tools.
                          </Link>
                        </>
                      )}
                    </p>
                  )}
                {providerId === "local-model" &&
                  providerAvailability?.state === "available" &&
                  config.localModelManifestUrl && (
                    <button className="text-button" onClick={saveModelOffline}>
                      <Icon name="download" size={15} />
                      Save this model for offline use
                    </button>
                  )}
                {lowPerformance && (
                  <p className="lab-performance-note">
                    This device is processing frames slowly; tracking samples
                    fewer frames per second.
                  </p>
                )}
              </div>
            </>
          )}
          {isFingerspelling && cameraRunning && (
            <div
              className="fingerspell-panel"
              aria-labelledby="fingerspell-title"
            >
              <h3 id="fingerspell-title" className="sr-only">
                Live fingerspelling
              </h3>
              <FingerspellingReadout
                decision={fsDecision}
                progress={fsProgress}
                text={fsText}
                handCount={handCount}
                paused={paused}
                latency={{ trackerMs: averageMs, modelMs: fsModelMs }}
              />
              <div className="live-buttons">
                <button
                  className="btn btn-primary"
                  disabled={!fsText.trim() || busy || escalated}
                  onClick={sendSpelling}
                >
                  <Icon name="check" size={17} />
                  Review this spelling
                </button>
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => editSpelling("space")}
                >
                  Add space
                </button>
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => editSpelling("backspace")}
                >
                  Delete last letter
                </button>
                <button
                  className="btn btn-outline btn-small"
                  onClick={resetSpelling}
                >
                  Clear spelling
                </button>
              </div>
              <p className="plain-note">
                Spell one letter at a time and hold each for about a second.
                Lower your hand to end a word. 24 static letters only (no J or
                Z). This is fingerspelling, not ASL sign or sentence
                translation.
              </p>
            </div>
          )}

          {photo && (
            <div className="clip-review" aria-labelledby="photo-review-title">
              <h3 id="photo-review-title">
                Review your photo before anything is sent
              </h3>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={photo.url}
                alt="The still photo you took, as it would be sent"
              />
              <p>
                {(photo.blob.size / 1e3).toFixed(0)} KB · JPEG. Not saved to
                disk or cached.
              </p>
              <label className="consent-check">
                <input
                  type="checkbox"
                  checked={photoConsent}
                  onChange={(event) => setPhotoConsent(event.target.checked)}
                />
                <span>
                  Send this one photo to <strong>Hugging Face</strong>, a
                  third-party cloud service, through the secure proxy. I
                  understand the result may be wrong.
                </span>
              </label>
              <div className="live-buttons">
                <button
                  className="btn btn-primary"
                  disabled={!photoConsent || !canRecognize}
                  onClick={sendPhoto}
                >
                  Send photo for recognition
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    discardPhoto();
                    announce(
                      "camera-ready",
                      "Photo discarded. Nothing was sent.",
                    );
                  }}
                >
                  Discard photo
                </button>
              </div>
            </div>
          )}

          {clip && (
            <div className="clip-review" aria-labelledby="clip-review-title">
              <h3 id="clip-review-title">
                Review your clip before anything is sent
              </h3>
              <video
                src={clip.url}
                controls
                playsInline
                muted
                aria-label="Your recorded clip as it would be sent (not mirrored), kept only in this page"
              />
              <p>
                {(clip.durationMs / 1000).toFixed(1)} s ·{" "}
                {(clip.blob.size / 1e6).toFixed(2)} MB · {clip.mimeType}. Not
                saved to disk or cached.
              </p>
              <label className="consent-check">
                <input
                  type="checkbox"
                  checked={uploadConsent}
                  onChange={(event) => setUploadConsent(event.target.checked)}
                />
                <span>
                  Send this one clip to{" "}
                  <strong>{descriptor.thirdParty?.name}</strong>, a third-party
                  cloud service, for ASL recognition. I understand the result
                  may be wrong.
                </span>
              </label>
              <div className="live-buttons">
                <button
                  className="btn btn-primary"
                  disabled={!uploadConsent || !canRecognize}
                  onClick={sendClip}
                >
                  Send clip for recognition
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => {
                    discardClip();
                    announce(
                      "camera-ready",
                      "Clip discarded. Nothing was sent.",
                    );
                  }}
                >
                  Discard clip
                </button>
              </div>
            </div>
          )}

          <div className="review-queue" aria-labelledby="review-title">
            <h3 id="review-title">Machine output awaiting your review</h3>
            {conversation.entries.filter(
              (entry) => entry.author === "patient" && !inConversation(entry),
            ).length === 0 ? (
              <p className="live-empty">
                Nothing to review. Recognised output appears here first; only
                what you confirm or correct is added to the conversation.
              </p>
            ) : (
              conversation.entries
                .filter(
                  (entry) =>
                    entry.author === "patient" && !inConversation(entry),
                )
                .slice(-4)
                .map((entry) => (
                  <EntryCard
                    key={entry.id}
                    entry={entry}
                    canSign={false}
                    onConfirm={() => {
                      dispatch({ type: "confirm", id: entry.id });
                      announce(
                        "completed",
                        "Confirmed and added to the conversation. Confirmation is your choice, not proof of understanding.",
                      );
                      if (speak) speakText(entry.text);
                    }}
                    onReject={() => {
                      dispatch({ type: "reject", id: entry.id });
                      announce(
                        "camera-ready",
                        "Rejected. It was not added to the conversation.",
                      );
                    }}
                    onCorrect={(text) => {
                      const risk = detectRisk(text);
                      dispatch({ type: "correct", id: entry.id, text, risk });
                      if (risk) escalate(risk);
                      else {
                        announce(
                          "completed",
                          "Your correction was added to the conversation.",
                        );
                        if (speak) speakText(text);
                      }
                    }}
                    onEditProvider={() => undefined}
                  />
                ))
            )}
          </div>

          <div className="patient-card-area live-patient-actions">
            <p className="plain-note">
              {isSigns
                ? "Sign mode reads one isolated sign at a time from a 250-sign vocabulary; phrases come from a fixed table. It does not translate sentences."
                : providerId === "fingerspelling"
                  ? "Fingerspelling mode reads static letters only — it does not recognise signs or translate sentences."
                  : providerId === "huggingface"
                    ? "One photo can only show a static handshape. The labels come from your Hugging Face model."
                    : descriptor.capabilities.granularity === "handshape"
                      ? "Mode 1 reads two handshapes only (L-like, Y-like). It is not a sign or sentence."
                      : descriptor.capabilities.granularity === "isolated-sign"
                        ? "Mode 2 returns one isolated sign from a closed vocabulary, never a sentence."
                        : descriptor.capabilities.granularity ===
                            "continuous-english"
                          ? "Mode 3 returns the provider’s English text for the clip. It can be wrong."
                          : ""}{" "}
              Your confirmation records your choice; it does not show that
              anyone understood.
            </p>
            <button
              className="text-button"
              onClick={() => {
                escalate("Patient choice");
                requestInterpreter();
              }}
            >
              <Icon name="users" size={16} />I would like a qualified
              interpreter
            </button>
          </div>
        </section>

        <section
          className="communication-panel provider-panel"
          aria-labelledby="live-provider-title"
        >
          <header>
            <span className="panel-person-icon provider-icon">
              <Icon name="clipboard" />
            </span>
            <div>
              <h2 id="live-provider-title">Care team</h2>
              <p>Provider · Plain-language written English</p>
            </div>
            <span className="caption-tag">CAPTIONS</span>
          </header>
          <div
            className="conversation-history live-log"
            role="log"
            aria-label="Experimental conversation history"
            aria-live="polite"
          >
            {conversation.entries.filter(inConversation).length === 0 && (
              <p className="live-empty">
                No messages yet. Patient messages appear here only after the
                patient confirms or corrects them.
              </p>
            )}
            {conversation.entries.filter(inConversation).map((entry) => (
              <EntryCard
                key={entry.id}
                entry={entry}
                canSign={avatarState.state === "available" && !escalated}
                onConfirm={() => undefined}
                onReject={() => undefined}
                onCorrect={() => undefined}
                onEditProvider={(text) => {
                  const risk = detectRisk(text);
                  dispatch({ type: "edit-provider", id: entry.id, text, risk });
                  if (risk) escalate(risk);
                }}
                onSpeak={
                  typeof speechSynthesis !== "undefined"
                    ? () => speakText(entry.text)
                    : undefined
                }
                onSign={
                  entry.author === "provider"
                    ? () =>
                        setSignRequest({
                          id: `${entry.id}-${Date.now()}`,
                          text: entry.text,
                        })
                    : undefined
                }
              />
            ))}
          </div>
          <form className="provider-form" onSubmit={sendProviderText}>
            <label htmlFor="live-provider-note">
              Provider message · plain language
            </label>
            <textarea
              id="live-provider-note"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Type a short, non-clinical message. No real patient information."
              rows={2}
              maxLength={500}
            />
            <div>
              <label className="consent-check compact">
                <input
                  type="checkbox"
                  checked={speak}
                  onChange={(event) => setSpeak(event.target.checked)}
                />
                <span>Read messages aloud (browser text-to-speech)</span>
              </label>
              <button
                className="btn btn-primary btn-small"
                type="submit"
                disabled={!draft.trim()}
              >
                Send message
                <Icon name="arrow-right" size={16} />
              </button>
            </div>
          </form>
          <SigningAvatarPanel
            config={config}
            availability={avatarState}
            request={signRequest}
            paused={escalated}
            onRisk={escalate}
          />
          <div className="workspace-bottom-note">
            <button
              className="text-button"
              onClick={() => {
                dispatch({ type: "clear" });
                setSignRequest(null);
                announce(
                  cameraRunning ? "camera-ready" : "camera-off",
                  "Conversation cleared from this page.",
                );
              }}
            >
              <Icon name="refresh" size={16} />
              Clear conversation
            </button>
            <button className="text-button" onClick={requestInterpreter}>
              <Icon name="users" size={16} />
              Request Qualified Interpreter
            </button>
          </div>
        </section>
      </div>
      <p className="safeguard-note">
        High-risk topics (medication, allergies, diagnosis, treatment, consent,
        emergency symptoms) are detected with simple English keywords in typed
        and recognised text. Detection can miss topics. When triggered,
        automated recognition and machine signing pause.
      </p>
    </div>
  );
}
