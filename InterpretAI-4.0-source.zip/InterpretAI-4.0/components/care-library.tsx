"use client";
import { useState } from "react";
import { careItems } from "@/lib/data";
import { Badge, Icon, type IconName } from "./ui";
export function CareLibrary() {
  const [filter, setFilter] = useState("All care");
  const [selected, setSelected] = useState<string>(careItems[0].id);
  const [completed, setCompleted] = useState<string[]>([]);
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const item = careItems.find((i) => i.id === selected) ?? careItems[0];
  const filtered =
    filter === "All care"
      ? careItems
      : careItems.filter((i) => i.category === filter);
  return (
    <>
      <div className="care-toolbar">
        <div className="filter-tabs" aria-label="Filter care examples">
          {[
            "All care",
            "Wellness",
            "Screening",
            "Vaccination",
            "Follow-up",
          ].map((f) => (
            <button
              key={f}
              aria-pressed={filter === f}
              className={filter === f ? "selected" : ""}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        <span className="plain-note">
          {completed.length} of 5 preparation plans completed · this session
        </span>
      </div>
      <div className="care-layout">
        <div className="care-list">
          {filtered.map((i) => (
            <button
              className={`care-select-card ${selected === i.id ? "selected" : ""}`}
              key={i.id}
              onClick={() => setSelected(i.id)}
              aria-pressed={selected === i.id}
            >
              <span className={`stat-icon ${i.color}`}>
                <Icon name={i.icon as IconName} />
              </span>
              <div>
                <Badge tone="gray">{i.category}</Badge>
                <h2>{i.title}</h2>
                <p>{i.date}</p>
              </div>
              {completed.includes(i.id) ? (
                <span
                  className="completed-care"
                  aria-label="Preparation complete"
                >
                  <Icon name="checks" />
                </span>
              ) : (
                <Icon name="chevron" size={19} />
              )}
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="empty-state">No examples in this category.</p>
          )}
        </div>
        <section
          className="card care-detail"
          aria-label={`${item.title} preparation`}
          key={item.id}
        >
          <div className="card-heading">
            <Badge tone={item.color}>
              {item.category.toUpperCase()} · EXAMPLE
            </Badge>
            <Icon name={item.icon as IconName} />
          </div>
          <h2>{item.title}</h2>
          <p>{item.detail}</p>
          <div className="asl-video-placeholder">
            <span>
              <Icon name="video" size={30} />
            </span>
            <strong>Human-reviewed ASL video</strong>
            <p>Resource placeholder · Not yet available</p>
            <small>No generated signing or translation is presented.</small>
          </div>
          <h3>Your visit preparation checklist</h3>
          <p className="plain-note">
            Keep track locally during this demo. Nothing is sent or stored.
          </p>
          <div className="checklist">
            {item.checklist.map((text, i) => (
              <label key={text}>
                <input
                  type="checkbox"
                  checked={!!checks[`${item.id}-${i}`]}
                  onChange={(e) =>
                    setChecks((v) => ({
                      ...v,
                      [`${item.id}-${i}`]: e.target.checked,
                    }))
                  }
                />
                <span>{text}</span>
              </label>
            ))}
          </div>
          <label className="field-label" htmlFor="care-support">
            Communication assistance preference
          </label>
          <select id="care-support" defaultValue="in-person">
            <option value="in-person">
              Qualified in-person ASL interpreter
            </option>
            <option value="video">Qualified video remote interpreter</option>
            <option value="discuss">
              Discuss accessible options with my clinic
            </option>
          </select>
          <p className="plain-note">
            A planning preference only; this does not arrange an interpreter.
          </p>
          <button
            className={`btn ${completed.includes(item.id) ? "btn-soft" : "btn-primary"} w-full`}
            disabled={
              !item.checklist.every((_, i) => checks[`${item.id}-${i}`])
            }
            onClick={() =>
              setCompleted((v) =>
                v.includes(item.id)
                  ? v.filter((id) => id !== item.id)
                  : [...v, item.id],
              )
            }
          >
            <Icon name="check" size={18} />
            {completed.includes(item.id)
              ? "Preparation complete — undo"
              : "Mark preparation complete"}
          </button>
          <p className="completion-note" role="status">
            {completed.includes(item.id)
              ? "Preparation complete for this fictional example."
              : "Check all preparation items to mark this plan complete."}
          </p>
        </section>
      </div>
    </>
  );
}
