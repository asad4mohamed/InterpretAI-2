"use client";
import {
  useCallback,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { useApp } from "./app-provider";
import { Badge, Icon } from "./ui";
import { useSignTracker } from "./use-sign-tracker";
import type { SignWorkerResponse } from "@/workers/sign-tracker.worker";
import {
  classifyHand,
  emptySpeller,
  handFeatures,
  loadFingerspellingModel,
  spelledText,
  stepSpeller,
  type LetterDecision,
  type StaticHandModel,
} from "@/lib/asl/fingerspelling";
import { parseLabels, parseMeta } from "@/lib/asl/signs/meta";
import {
  directionText,
  type LiveMovement,
  type MovementSummary,
} from "@/lib/asl/signs/movement";
import {
  PHRASE_PATTERNS,
  TARGET_COVERAGE,
  TARGET_PHRASES,
  matchPhrase,
  phraseCoverage,
} from "@/lib/asl/signs/phrases";
import { decodeReplay, type ReplayClip } from "@/lib/asl/signs/replay";
import type { FrameStatus } from "@/lib/asl/signs/segmenter";
import {
  emptySequence,
  glossLine,
  guessesFor,
  sequenceReducer,
  sequenceResolved,
  type Guess,
  type SequenceAction,
  type SequenceState,
  type SignToken,
} from "@/lib/asl/signs/sequence";
import {
  parseVocabulary,
  type Vocabulary,
  type VocabularyEntry,
} from "@/lib/asl/signs/vocabulary";
import {
  downloadSignTools,
  signAssets,
  signDownloadBytes,
  signToolsCached,
} from "@/lib/sign-cache";
import { detectRisk, type RiskTopic } from "@/lib/scenarios";

export type SignSubmission = {
  english: string;
  glosses: string[];
  /** Lowest calibrated probability among model-recognised signs. */
  minProbability: number | null;
  patternIds: string[];
  userWritten: boolean;
  modelVersion: string;
};

const statusText: Record<FrameStatus, string> = {
  nothing: "No one in view",
  "no-hands": "Person in view · no hands",
  crowded: "More than one person · recognition paused",
  partial: "Shoulders out of frame · step back a little",
  ok: "Hands and upper body tracked",
};

type Phase =
  | "off"
  | "loading"
  | "ready"
  | "watching"
  | "signing"
  | "recognised"
  | "not-sure"
  | "paused"
  | "replaying";

const phaseText: Record<Phase, string> = {
  off: "Engine off",
  loading: "Loading on-device engine",
  ready: "Engine ready · camera off",
  watching: "Watching for a sign",
  signing: "Sign in progress",
  recognised: "Sign recognised",
  "not-sure": "Not sure",
  paused: "Paused",
  replaying: "Replaying a dataset clip",
};

const pct = (p: number) => `${Math.round(p * 100)}%`;
let tokenCounter = 0;
const nextToken = () => `sign-${Date.now().toString(36)}-${++tokenCounter}`;

function Trajectory({ movement }: { movement: MovementSummary }) {
  const pts = movement.trajectory;
  if (pts.length < 2) return null;
  const xs = pts.map((p) => p.x);
  const ys = pts.map((p) => p.y);
  const minX = Math.min(...xs);
  const minY = Math.min(...ys);
  const span = Math.max(Math.max(...xs) - minX, Math.max(...ys) - minY, 0.3);
  const path = pts
    .map((p, i) => {
      const x = 6 + ((p.x - minX) / span) * 48;
      const y = 6 + ((p.y - minY) / span) * 48;
      return `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  const last = pts[pts.length - 1]!;
  return (
    <svg
      className="sign-trajectory"
      viewBox="0 0 60 60"
      role="img"
      aria-label={`Hand path, ${directionText[movement.direction]}`}
    >
      <path
        d={path}
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <circle
        cx={6 + ((last.x - minX) / span) * 48}
        cy={6 + ((last.y - minY) / span) * 48}
        r="3.5"
        fill="currentColor"
      />
    </svg>
  );
}

function describeMovement(m: MovementSummary) {
  return `${m.dominant === "right" ? "Right" : "Left"} hand${m.twoHanded ? " (two-handed)" : ""}, ${directionText[m.direction]}, ${m.pathLength.toFixed(1)} shoulder widths, ${m.startRegion === "unknown" ? "" : `started near the ${m.startRegion}, `}${(m.durationMs / 1000).toFixed(1)} s`;
}

function GuessBars({ top, label }: { top: Guess[]; label: string }) {
  return (
    <ol className="sign-guesses" aria-label={label}>
      {top.map((g) => (
        <li key={g.label}>
          <span className="sign-guess-gloss">{g.gloss}</span>
          <span className="sign-guess-bar" aria-hidden="true">
            <span style={{ width: pct(g.probability) }} />
          </span>
          <span className="sign-guess-value">{pct(g.probability)}</span>
        </li>
      ))}
    </ol>
  );
}

function VocabularyBrowser({ vocabulary }: { vocabulary: Vocabulary }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const categories = useMemo(
    () => [...new Set(vocabulary.signs.map((s) => s.category))].sort(),
    [vocabulary],
  );
  const q = query.trim().toLowerCase();
  const shown = vocabulary.signs.filter(
    (s) =>
      (category === "all" || s.category === category) &&
      (!q ||
        s.gloss.toLowerCase().includes(q) ||
        s.english.toLowerCase().includes(q)),
  );
  const count = (r: VocabularyEntry["reliability"]) =>
    vocabulary.signs.filter((s) => s.reliability === r).length;
  return (
    <details className="model-info sign-vocab">
      <summary>
        <span>
          Supported signs ({vocabulary.classes}) — only these can be recognised
        </span>
        <Icon name="down" size={16} />
      </summary>
      <div className="sign-vocab-body">
        <p className="plain-note">
          Accuracy is top-1 on {vocabulary.heldOutSigners.length} signers who
          were never used in training (measured by the model’s authors; not
          re-run here). Reliability: {count("high")} high (≥75%),{" "}
          {count("medium")} medium (50–74%), {count("low")} low (&lt;50%). Signs
          outside this list are never output.
        </p>
        <div className="sign-vocab-filters">
          <label>
            <span>Search</span>
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. water"
            />
          </label>
          <label>
            <span>Category</span>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="all">All categories</option>
              {categories.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <span className="sign-vocab-count" role="status">
            {shown.length} shown
          </span>
        </div>
        <div
          className="sign-vocab-table"
          tabIndex={0}
          role="region"
          aria-label="Supported signs table"
        >
          <table>
            <thead>
              <tr>
                <th scope="col">ASL gloss</th>
                <th scope="col">English meaning</th>
                <th scope="col">Category</th>
                <th scope="col">Held-out accuracy</th>
                <th scope="col">Notes</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((s) => (
                <tr key={s.id}>
                  <th scope="row">{s.gloss}</th>
                  <td>{s.english}</td>
                  <td>{s.category}</td>
                  <td>
                    <span className={`sign-rel sign-rel-${s.reliability}`}>
                      {pct(s.heldOutTop1)} · {s.reliability}
                    </span>
                  </td>
                  <td>
                    {s.confusedWith.length > 0 && (
                      <>
                        Confused with{" "}
                        {s.confusedWith
                          .map(
                            (c) =>
                              vocabulary.signs.find(
                                (v) => v.modelLabel === c.sign,
                              )?.gloss ?? c.sign,
                          )
                          .join(", ")}
                        .{" "}
                      </>
                    )}
                    {s.variantsNote}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </details>
  );
}

type PanelState = { vocabulary: Vocabulary | null; seq: SequenceState };
type PanelAction =
  SequenceAction | { type: "vocabulary"; vocabulary: Vocabulary };

function panelReducer(state: PanelState, action: PanelAction): PanelState {
  if (action.type === "vocabulary")
    return { ...state, vocabulary: action.vocabulary };
  if (!state.vocabulary) return state;
  return {
    ...state,
    seq: sequenceReducer(state.vocabulary)(state.seq, action),
  };
}

export function SignRecognitionPanel({
  variant,
  disabled = false,
  busy = false,
  onSubmit,
  onToolsChanged,
}: {
  variant: "standalone" | "workspace";
  /** Called after the optional files were downloaded (re-check availability). */
  onToolsChanged?: () => void;
  /** True while a safety escalation is active (recognition paused). */
  disabled?: boolean;
  busy?: boolean;
  /** Workspace: send the phrase to the review queue. */
  onSubmit?: (submission: SignSubmission) => void;
}) {
  const { requestInterpreter } = useApp();
  const [consent, setConsent] = useState(false);
  const [cached, setCached] = useState<boolean | null>(null);
  const [download, setDownload] = useState<{
    done: number;
    total: number;
  } | null>(null);
  const [downloadError, setDownloadError] = useState("");
  const [vocabulary, setVocabulary] = useState<Vocabulary | null>(null);
  const [vocabError, setVocabError] = useState("");
  const [phase, setPhase] = useState<Phase>("off");
  const [frameStatus, setFrameStatus] = useState<FrameStatus | null>(null);
  const [movement, setMovement] = useState<LiveMovement | null>(null);
  const [hands, setHands] = useState(0);
  const [lastResult, setLastResult] = useState<{
    top: Guess[];
    kind: "sign" | "not-sure" | "nothing";
    reason?: string;
    inferenceMs: number;
    movement: MovementSummary | null;
    frames: number;
    endReason: string;
  } | null>(null);
  const [announcement, setAnnouncement] = useState("");
  const [workerError, setWorkerError] = useState("");
  const [draft, setDraft] = useState("");
  const [draftEdited, setDraftEdited] = useState(false);
  const [confirmed, setConfirmed] = useState<
    { id: string; text: string; glosses: string }[]
  >([]);
  const [escalation, setEscalation] = useState<RiskTopic | null>(null);
  const [clips, setClips] = useState<ReplayClip[] | null>(null);
  const [replayingId, setReplayingId] = useState<string | null>(null);
  const [fsOn, setFsOn] = useState(false);
  const [fsModel, setFsModel] = useState<StaticHandModel | null>(null);
  const [fsDecision, setFsDecision] = useState<LetterDecision | null>(null);
  const [fsText, setFsText] = useState("");
  const vocabRef = useRef<Vocabulary | null>(null);
  const [{ seq: sequence }, dispatchPanel] = useReducer(panelReducer, {
    vocabulary: null,
    seq: emptySequence,
  });
  const dispatch = useCallback(
    (action: SequenceAction) => dispatchPanel(action),
    [],
  );
  const fsRef = useRef({
    on: false,
    model: null as StaticHandModel | null,
    speller: { ...emptySpeller },
  });
  const lastMoveRef = useRef(0);
  const lastStatusRef = useRef<FrameStatus | null>(null);
  const stopped = disabled || escalation !== null;

  // Vocabulary: small, precached, validated against the model's labels.
  useEffect(() => {
    let cancelled = false;
    Promise.all([
      fetch(signAssets.modelMeta).then((r) => r.json()),
      fetch(signAssets.labels).then((r) => r.json()),
      fetch(signAssets.vocabulary).then((r) => r.json()),
    ])
      .then(([metaRaw, labelsRaw, vocabRaw]) => {
        const meta = parseMeta(metaRaw);
        const labels = parseLabels(labelsRaw, meta.classes);
        const vocab = parseVocabulary(vocabRaw, labels);
        const missing = phraseCoverage(labels.map((l) => l.sign));
        if (missing.length)
          throw new Error(
            `Phrase table references unknown signs: ${missing.join(", ")}`,
          );
        if (cancelled) return;
        vocabRef.current = vocab;
        dispatchPanel({ type: "vocabulary", vocabulary: vocab });
        setVocabulary(vocab);
      })
      .catch((failure) => {
        if (!cancelled)
          setVocabError(
            failure instanceof Error
              ? failure.message
              : "The sign vocabulary could not be loaded.",
          );
      });
    signToolsCached()
      .then((value) => !cancelled && setCached(value))
      .catch(() => !cancelled && setCached(false));
    return () => {
      cancelled = true;
    };
  }, []);

  const onEvent = useCallback(
    (message: SignWorkerResponse) => {
      if (message.type === "frame") {
        // Replay frames (no camera image) do not describe the camera view.
        if (message.frameWidth === 0) return;
        if (message.status !== lastStatusRef.current) {
          lastStatusRef.current = message.status;
          setFrameStatus(message.status);
        }
        const now = performance.now();
        if (now - lastMoveRef.current > 150) {
          lastMoveRef.current = now;
          setMovement(message.movement);
          setHands(message.hands.length);
        }
        const fs = fsRef.current;
        if (fs.on && fs.model) {
          const hand = message.hands.length === 1 ? message.hands[0] : null;
          const features =
            hand && message.frameWidth > 0
              ? handFeatures(
                  hand.image.map((p) => ({ x: p.x, y: p.y, z: 0 })),
                  message.frameWidth,
                  message.frameHeight,
                )
              : null;
          const decision = features ? classifyHand(fs.model, features) : null;
          const step = stepSpeller(fs.speller, {
            letter: decision?.letter ?? null,
            handPresent: message.hands.length > 0,
            t: message.t,
          });
          fs.speller = step.state;
          setFsDecision(decision);
          setFsText(spelledText(step.state));
        }
        return;
      }
      if (message.type === "signing") {
        if (!fsRef.current.on)
          setPhase((p) => (p === "replaying" ? p : "signing"));
        return;
      }
      if (message.type === "discarded") {
        dispatch({ type: "discarded" });
        setPhase((p) => (p === "replaying" ? p : "watching"));
        return;
      }
      if (message.type === "error") {
        setWorkerError(message.message);
        return;
      }
      if (message.type === "result") {
        if (fsRef.current.on) return; // spelling mode: segments are not signs
        const vocab = vocabRef.current;
        if (!vocab) return;
        const top = guessesFor(message.decision, vocab);
        setLastResult({
          top,
          kind: message.decision.kind,
          reason: message.decision.reason,
          inferenceMs: message.inferenceMs,
          movement: message.movement,
          frames: message.frames,
          endReason: message.endReason,
        });
        dispatch({
          type: "result",
          id: nextToken(),
          result: {
            decision: message.decision,
            startT: message.startT,
            endT: message.endT,
            endReason: message.endReason,
            movement: message.movement,
          },
        });
        setDraftEdited(false);
        if (message.decision.kind === "sign" && top[0]) {
          setPhase((p) => (p === "replaying" ? p : "recognised"));
          setAnnouncement(
            `Recognised ${top[0].gloss}, ${pct(top[0].probability)}. Review it in the sign history.`,
          );
        } else if (message.decision.kind === "not-sure") {
          setPhase((p) => (p === "replaying" ? p : "not-sure"));
          setAnnouncement(
            message.decision.reason === "partial"
              ? "Not sure: your shoulders were out of frame. Choose one of the guesses or remove it."
              : "Not sure. Choose one of the guesses or remove it.",
          );
        }
      }
    },
    [dispatch],
  );

  const {
    status: trackerStatus,
    loadStage,
    error: trackerError,
    paused,
    pause,
    resume,
    averageMs,
    lowPerformance,
    engine,
    videoRef,
    overlayRef,
    start: startTracker,
    stop: stopTracker,
    replay,
  } = useSignTracker({ onEvent });
  const running = trackerStatus === "running";
  const engineLoaded =
    trackerStatus === "ready" || running || trackerStatus === "permission";

  const effectivePhase: Phase =
    trackerStatus === "loading"
      ? "loading"
      : replayingId
        ? "replaying"
        : running
          ? paused
            ? "paused"
            : phase === "off" || phase === "ready" || phase === "loading"
              ? "watching"
              : phase
          : engineLoaded
            ? "ready"
            : "off";

  const match = matchPhrase(sequence.tokens);
  const suggestions = match.kind === "matched" ? match.suggestions : [];
  const shownDraft = draftEdited ? draft : (suggestions[0] ?? "");
  const resolved = sequenceResolved(sequence);

  async function startDownload() {
    setDownloadError("");
    const controller = new AbortController();
    try {
      setDownload({ done: 0, total: signAssets.files.length });
      await downloadSignTools(controller.signal, (done, total) =>
        setDownload({ done, total }),
      );
      setCached(true);
      onToolsChanged?.();
      setAnnouncement(
        "Sign recognition files downloaded and verified. They now work offline.",
      );
    } catch (failure) {
      setDownloadError(
        failure instanceof Error ? failure.message : "Download failed.",
      );
    } finally {
      setDownload(null);
    }
  }

  async function startCamera() {
    if (!consent || stopped) return;
    setWorkerError("");
    const ok = await startTracker();
    if (ok) {
      setPhase("watching");
      setAnnouncement(
        "Camera on. Sign one word at a time; lower your hands or pause briefly between signs.",
      );
    }
  }

  function stopAll() {
    stopTracker();
    setPhase("off");
    setFrameStatus(null);
    lastStatusRef.current = null;
    setMovement(null);
    setHands(0);
    setReplayingId(null);
    setAnnouncement(
      "Camera stopped and engine closed. All camera tracks were released. Nothing was saved.",
    );
  }

  async function loadClips() {
    if (clips) return clips;
    const response = await fetch("/models/asl-signs-v1/heldout-clips.json");
    const decoded = decodeReplay(await response.json()).clips;
    setClips(decoded);
    return decoded;
  }

  async function playClip(clip: ReplayClip) {
    if (stopped) return;
    setWorkerError("");
    setReplayingId(clip.id);
    setAnnouncement(
      `Replaying a real held-out clip. The model is not told which sign it is.`,
    );
    try {
      await replay(
        clip.frames.map((f) => new Float32Array(f)),
        clip.fps,
      );
    } catch (failure) {
      setWorkerError(
        failure instanceof Error ? failure.message : "Replay failed.",
      );
    } finally {
      setReplayingId(null);
      setPhase(running ? "watching" : "ready");
    }
  }

  async function toggleSpelling(on: boolean) {
    setFsOn(on);
    fsRef.current.on = on;
    fsRef.current.speller = { ...emptySpeller };
    setFsText("");
    setFsDecision(null);
    if (on && !fsRef.current.model) {
      try {
        const model = await loadFingerspellingModel();
        fsRef.current.model = model;
        setFsModel(model);
      } catch {
        setWorkerError("The fingerspelling model could not be loaded.");
      }
    }
  }

  function addSpelledWord() {
    const text = spelledText(fsRef.current.speller).trim();
    if (!text) return;
    dispatch({ type: "spelled", id: nextToken(), text, t: performance.now() });
    fsRef.current.speller = { ...emptySpeller };
    setFsText("");
    setDraftEdited(false);
    setAnnouncement(`Added fingerspelled word #${text.toUpperCase()}.`);
  }

  function confirmPhrase() {
    const english = shownDraft.trim();
    if (!english || !resolved || !vocabulary) return;
    const signs = sequence.tokens.filter(
      (t): t is Extract<SignToken, { kind: "sign" }> => t.kind === "sign",
    );
    const submission: SignSubmission = {
      english,
      glosses: sequence.tokens.map((t) =>
        t.kind === "uncertain" ? "?" : t.gloss,
      ),
      minProbability: signs.length
        ? Math.min(...signs.map((s) => s.probability))
        : null,
      patternIds:
        match.kind === "matched" ? match.patterns.map((p) => p.id) : [],
      userWritten: draftEdited || match.kind !== "matched",
      modelVersion: engine?.modelVersion ?? "asl-signs-v1",
    };
    if (variant === "workspace") {
      onSubmit?.(submission);
      setAnnouncement(
        "Sent to “Machine output awaiting your review”. Nothing is in the conversation until you confirm it there.",
      );
    } else {
      const risk = detectRisk(english);
      setConfirmed((list) => [
        ...list,
        { id: nextToken(), text: english, glosses: glossLine(sequence.tokens) },
      ]);
      if (risk) {
        setEscalation(risk);
        if (running) pause();
        setAnnouncement(
          `${risk} detected. Recognition is paused; a qualified interpreter is recommended.`,
        );
      } else
        setAnnouncement(
          `Confirmed: “${english}”. Your confirmation records your choice; it does not prove understanding.`,
        );
    }
    dispatch({ type: "clear" });
    setDraft("");
    setDraftEdited(false);
  }

  function rejectPhrase() {
    dispatch({ type: "clear" });
    setDraft("");
    setDraftEdited(false);
    setAnnouncement("Rejected. Nothing was added.");
  }

  const canUseEngine = cached === true && !stopped;
  const downloadMb = (signDownloadBytes / 1e6).toFixed(1);

  return (
    <div className={`sign-panel sign-panel-${variant}`}>
      <div className="sign-status-bar" role="status" aria-live="polite">
        <div>
          <span className="sign-status-label">Recognition</span>
          <span className={`live-phase sign-phase-${effectivePhase}`}>
            {phaseText[effectivePhase]}
          </span>
        </div>
        <div>
          <span className="sign-status-label">Camera</span>
          <span>
            {running
              ? paused
                ? "On · paused (nothing processed)"
                : "On · processed on this device"
              : trackerStatus === "permission"
                ? "Waiting for permission"
                : "Off"}
          </span>
        </div>
        <div>
          <span className="sign-status-label">Tracking</span>
          <span>{running && frameStatus ? statusText[frameStatus] : "—"}</span>
        </div>
        <div>
          <span className="sign-status-label">Movement</span>
          <span className="sign-movement">
            <span
              className={`sign-movement-dot ${running && movement?.moving ? "moving" : ""}`}
              aria-hidden="true"
            />
            {running && movement
              ? movement.moving
                ? `Moving ${directionText[movement.direction]}`
                : hands
                  ? "Holding still"
                  : "No hands"
              : "—"}
          </span>
        </div>
        <div>
          <span className="sign-status-label">Model</span>
          <span>
            {engine
              ? `${engine.classes} signs · on device`
              : cached
                ? "Downloaded · not loaded"
                : "Not downloaded"}
          </span>
        </div>
      </div>
      <p className="sr-only" aria-live="polite">
        {announcement}
      </p>

      {escalation && (
        <div className="safety-stop" role="alert">
          <span className="safety-stop-icon">
            <Icon name="shield" size={27} />
          </span>
          <div>
            <Badge tone="amber">HUMAN INTERPRETER RECOMMENDED</Badge>
            <h3>{escalation} needs a qualified interpreter.</h3>
            <p>
              Sign recognition is paused. This prototype must not be used for
              this topic.
            </p>
          </div>
          <div className="sign-escalation-actions">
            <button className="btn btn-primary" onClick={requestInterpreter}>
              Request Qualified Interpreter
              <Icon name="users" size={18} />
            </button>
            <button
              className="btn btn-outline btn-small"
              onClick={() => setEscalation(null)}
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      <div className="sign-grid">
        <section
          className="communication-panel sign-camera-panel"
          aria-labelledby={`sign-camera-${variant}`}
        >
          <header>
            <span className="panel-person-icon">
              <Icon name="hand" />
            </span>
            <div>
              <h2 id={`sign-camera-${variant}`}>Continuous sign recognition</h2>
              <p>
                On-device · 250 isolated signs · sign-by-sign, not sentences
              </p>
            </div>
            <Badge tone="teal">ON-DEVICE</Badge>
          </header>

          <div
            className={`lab-camera live-camera ${running ? "lab-camera-active" : ""}`}
          >
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              aria-label="Live camera preview, mirrored; never recorded"
            />
            <canvas ref={overlayRef} aria-hidden="true" />
            {!running && (
              <div className="lab-camera-placeholder">
                <Icon name="camera" size={35} />
                <h3>
                  {trackerStatus === "loading"
                    ? `Loading ${loadStage === "landmarker" ? "the body and hand landmarker" : loadStage === "model" ? "the sign model" : "the runtime"}…`
                    : trackerStatus === "permission"
                      ? "Waiting for camera permission…"
                      : "Camera is off."}
                </h3>
                <p>
                  Hands, upper body and lip shape are tracked on this device.
                  Frames are discarded after use.
                </p>
              </div>
            )}
            {running && (
              <span className="lab-camera-label">
                <Icon name="lock" size={14} />
                ON-DEVICE · {hands} {hands === 1 ? "HAND" : "HANDS"}
                {paused ? " · PAUSED" : ""}
              </span>
            )}
          </div>

          <div className="live-controls">
            {cached === false && (
              <div className="sign-download">
                <p>
                  <strong>One-time download needed ({downloadMb} MB).</strong>{" "}
                  Google’s MediaPipe Holistic landmarker, ONNX Runtime and the
                  sign model are stored in this browser after a size and SHA-256
                  check, then work offline. Nothing about you is sent.
                </p>
                <button
                  className="btn btn-primary"
                  onClick={startDownload}
                  disabled={download !== null}
                >
                  <Icon name="download" size={17} />
                  {download
                    ? `Downloading ${download.done}/${download.total}…`
                    : "Download sign recognition"}
                </button>
                {downloadError && (
                  <p className="live-unavailable" role="alert">
                    {downloadError}
                  </p>
                )}
              </div>
            )}
            <label className="consent-check">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => {
                  setConsent(e.target.checked);
                  if (!e.target.checked && running) stopAll();
                }}
              />
              <span>
                I agree to turn on my camera for this session. Video and
                landmarks stay on this device and are not saved.
              </span>
            </label>
            <div className="live-buttons">
              {!running &&
              trackerStatus !== "permission" &&
              trackerStatus !== "loading" ? (
                <button
                  className="btn btn-primary"
                  disabled={!consent || !canUseEngine}
                  onClick={startCamera}
                >
                  <Icon name="camera" size={17} />
                  Start camera
                </button>
              ) : (
                <button className="btn btn-outline" onClick={stopAll}>
                  <Icon name="x" size={17} />
                  {running ? "Stop camera now" : "Cancel"}
                </button>
              )}
              {running && (
                <button
                  className="btn btn-outline"
                  aria-pressed={paused}
                  onClick={paused ? resume : pause}
                  disabled={stopped && !paused}
                >
                  <Icon name={paused ? "play" : "pause"} size={17} />
                  {paused ? "Resume recognition" : "Pause recognition"}
                </button>
              )}
              {running && (
                <label className="consent-check compact sign-spell-toggle">
                  <input
                    type="checkbox"
                    checked={fsOn}
                    onChange={(e) => toggleSpelling(e.target.checked)}
                  />
                  <span>Fingerspell a word instead (24 static letters)</span>
                </label>
              )}
            </div>
            {(trackerError || workerError || vocabError) && (
              <p className="live-unavailable" role="alert">
                {trackerError || workerError || vocabError}
              </p>
            )}
            {stopped && (
              <p className="live-unavailable">
                Recognition is paused while a safety escalation is active.
              </p>
            )}
            {lowPerformance && (
              <p className="lab-performance-note">
                This device is processing frames slowly ({averageMs} ms per
                frame); fewer frames per sign lower accuracy.
              </p>
            )}
          </div>

          {fsOn && running && (
            <div
              className="fingerspell-panel"
              aria-label="Fingerspelling a word"
            >
              <p className="sign-spell-readout">
                <span className="sign-spell-letter">
                  {fsDecision?.letter ?? "·"}
                </span>
                <span>
                  Spelled: <strong>{fsText || "—"}</strong>
                  {fsModel ? "" : " (loading letter model…)"}
                </span>
              </p>
              <div className="live-buttons">
                <button
                  className="btn btn-primary btn-small"
                  disabled={!fsText.trim()}
                  onClick={addSpelledWord}
                >
                  Add #{fsText.trim().toUpperCase() || "WORD"} to the sequence
                </button>
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => {
                    fsRef.current.speller = { ...emptySpeller };
                    setFsText("");
                  }}
                >
                  Clear letters
                </button>
              </div>
            </div>
          )}

          <div
            className="sign-current"
            aria-labelledby={`sign-current-${variant}`}
          >
            <h3 id={`sign-current-${variant}`}>Latest model output</h3>
            {!lastResult ? (
              <p className="live-empty">
                Nothing yet. A sign is read when your hands move and then pause
                or drop. Each sign gives one result.
              </p>
            ) : (
              <div className="sign-current-body">
                <div>
                  <p className="sign-current-gloss">
                    {lastResult.kind === "sign"
                      ? lastResult.top[0]?.gloss
                      : "Not sure"}
                    {lastResult.kind === "sign" && lastResult.top[0] && (
                      <small> “{lastResult.top[0].english}”</small>
                    )}
                  </p>
                  <GuessBars
                    top={lastResult.top}
                    label="Top three guesses with calibrated probability"
                  />
                  <p className="plain-note">
                    Calibrated probability (temperature-scaled on held-out
                    signers). Below {pct(0.29)} the model says “Not sure”.{" "}
                    {lastResult.frames} frames · model {lastResult.inferenceMs}{" "}
                    ms
                    {running ? ` · tracking ${averageMs} ms/frame` : ""}.
                  </p>
                </div>
                {lastResult.movement && (
                  <div className="sign-movement-summary">
                    <Trajectory movement={lastResult.movement} />
                    <p>{describeMovement(lastResult.movement)}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        <section
          className="communication-panel sign-sequence-panel"
          aria-labelledby={`sign-history-${variant}`}
        >
          <header>
            <span className="panel-person-icon provider-icon">
              <Icon name="message" />
            </span>
            <div>
              <h2 id={`sign-history-${variant}`}>Sign history and phrase</h2>
              <p>
                Review every sign · nothing is sent without your confirmation
              </p>
            </div>
          </header>

          <div className="sign-history">
            <div className="sign-history-head">
              <h3>Recognised signs, in order</h3>
              <div className="live-buttons">
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => dispatch({ type: "undo" })}
                  disabled={sequence.tokens.length === 0}
                >
                  <Icon name="undo" size={15} />
                  Undo last sign
                </button>
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => dispatch({ type: "clear" })}
                  disabled={sequence.tokens.length === 0}
                >
                  <Icon name="trash" size={15} />
                  Clear all
                </button>
              </div>
            </div>
            {sequence.tokens.length === 0 ? (
              <p className="live-empty">No signs yet.</p>
            ) : (
              <ol
                className="sign-tokens"
                aria-label="Recognised signs, in order"
              >
                {sequence.tokens.map((token, i) => (
                  <li
                    key={token.id}
                    className={`sign-token sign-token-${token.kind}`}
                  >
                    <span className="sign-token-index">{i + 1}</span>
                    <div className="sign-token-main">
                      {token.kind === "uncertain" ? (
                        <>
                          <strong>Not sure</strong>
                          <span className="plain-note">
                            {token.reason === "partial"
                              ? "Shoulders were out of frame."
                              : "Below the confidence threshold."}{" "}
                            Pick the right sign or remove it:
                          </span>
                          <span className="sign-token-choices">
                            {token.top.map((g) => (
                              <button
                                key={g.label}
                                className="btn btn-outline btn-small"
                                onClick={() =>
                                  dispatch({
                                    type: "choose",
                                    id: token.id,
                                    label: g.label,
                                  })
                                }
                              >
                                {g.gloss} ({pct(g.probability)})
                              </button>
                            ))}
                          </span>
                        </>
                      ) : token.kind === "spelled" ? (
                        <>
                          <strong>{token.gloss}</strong>
                          <span className="plain-note">
                            Fingerspelled with the letter model
                          </span>
                        </>
                      ) : (
                        <>
                          <strong>
                            {token.gloss} <small>“{token.english}”</small>
                          </strong>
                          <span className="plain-note">
                            {token.userChosen ? "Chosen by you" : "Model"} ·{" "}
                            {pct(token.probability)}
                            {token.reliability === "low"
                              ? " · low-reliability sign"
                              : ""}
                            {token.top.length > 1 && !token.userChosen
                              ? ` · next: ${token.top[1]!.gloss} ${pct(token.top[1]!.probability)}`
                              : ""}
                          </span>
                          {token.top.length > 1 && (
                            <details className="sign-token-alt">
                              <summary>Change to another guess</summary>
                              <span className="sign-token-choices">
                                {token.top
                                  .filter((g) => g.label !== token.label)
                                  .map((g) => (
                                    <button
                                      key={g.label}
                                      className="btn btn-outline btn-small"
                                      onClick={() =>
                                        dispatch({
                                          type: "choose",
                                          id: token.id,
                                          label: g.label,
                                        })
                                      }
                                    >
                                      {g.gloss} ({pct(g.probability)})
                                    </button>
                                  ))}
                              </span>
                            </details>
                          )}
                        </>
                      )}
                    </div>
                    <button
                      className="text-button"
                      aria-label={`Remove sign ${i + 1}`}
                      onClick={() => dispatch({ type: "remove", id: token.id })}
                    >
                      <Icon name="x" size={15} />
                    </button>
                  </li>
                ))}
              </ol>
            )}
            {sequence.merged > 0 && (
              <p className="plain-note">
                {sequence.merged} repeated segment
                {sequence.merged === 1 ? "" : "s"} of the same sign merged (one
                sign with a pause, not two).
              </p>
            )}
          </div>

          <div
            className="sign-phrase"
            aria-labelledby={`sign-phrase-${variant}`}
          >
            <h3 id={`sign-phrase-${variant}`}>Phrase suggestion</h3>
            <p className="sign-gloss-line">
              <span>ASL glosses:</span>{" "}
              <strong>
                {sequence.tokens.length ? glossLine(sequence.tokens) : "—"}
              </strong>
            </p>
            {match.kind === "uncertain" && (
              <p className="live-unavailable">
                {match.count} uncertain sign{match.count === 1 ? "" : "s"}:
                choose a guess or remove it before a phrase can be suggested.
              </p>
            )}
            {match.kind === "unsupported" && (
              <p className="live-unavailable">
                No supported phrase pattern for <strong>{match.glosses}</strong>
                . The app does not translate other combinations. You can write
                your own English below, or undo signs.
              </p>
            )}
            {match.kind === "matched" && (
              <div
                className="sign-suggestions"
                role="group"
                aria-label="English suggestions"
              >
                {suggestions.map((s) => (
                  <button
                    key={s}
                    className={`btn btn-small ${shownDraft === s ? "btn-primary" : "btn-outline"}`}
                    onClick={() => {
                      setDraft(s);
                      setDraftEdited(true);
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            )}
            {match.kind === "matched" && match.patterns.some((p) => p.note) && (
              <p className="plain-note">
                {match.patterns.find((p) => p.note)?.note}
              </p>
            )}
            <label className="sign-draft">
              <span>
                English to{" "}
                {variant === "workspace" ? "send for review" : "confirm"}{" "}
                (editable)
              </span>
              <textarea
                rows={2}
                maxLength={200}
                value={shownDraft}
                disabled={sequence.tokens.length === 0}
                onChange={(e) => {
                  setDraft(e.target.value);
                  setDraftEdited(true);
                }}
              />
            </label>
            <div className="live-buttons">
              <button
                className="btn btn-primary"
                disabled={
                  !shownDraft.trim() ||
                  !resolved ||
                  stopped ||
                  busy ||
                  sequence.tokens.length === 0
                }
                onClick={confirmPhrase}
              >
                <Icon name="check" size={17} />
                {variant === "workspace"
                  ? "Review this phrase"
                  : "Confirm phrase"}
              </button>
              <button
                className="btn btn-outline"
                disabled={sequence.tokens.length === 0}
                onClick={rejectPhrase}
              >
                Reject
              </button>
            </div>
            <p className="plain-note">
              Suggestions come from a small fixed table of{" "}
              {PHRASE_PATTERNS.length} patterns, not from translation. Word
              order, facial grammar and context are not understood.
            </p>
          </div>

          {variant === "standalone" && (
            <div className="sign-confirmed">
              <h3>Confirmed in this session</h3>
              {confirmed.length === 0 ? (
                <p className="live-empty">
                  Nothing confirmed. Confirmed phrases stay on this page only.
                </p>
              ) : (
                <ul>
                  {confirmed.map((c) => (
                    <li key={c.id}>
                      <strong>{c.text}</strong>
                      <span className="plain-note">{c.glosses}</span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="plain-note">
                For a two-way conversation with a care team, use{" "}
                <Link href="/communication/">
                  Communication → Experimental live recognition → ASL signs
                </Link>
                .
              </p>
            </div>
          )}
          <button
            className="text-button"
            onClick={() => {
              setEscalation("Patient choice");
              if (running) pause();
              requestInterpreter();
            }}
          >
            <Icon name="users" size={16} />I would like a qualified interpreter
          </button>
        </section>
      </div>

      <section
        className="sign-replay"
        aria-labelledby={`sign-replay-${variant}`}
      >
        <h3 id={`sign-replay-${variant}`}>
          No camera? Replay real held-out clips
        </h3>
        <p className="plain-note">
          {running ? "Stop the camera to replay clips. " : ""}Six real landmark
          recordings from signers the model never trained on (Google – Isolated
          Sign Language Recognition, Kaggle asl-signs, CC BY 4.0). Only
          landmarks are bundled: no faces, no video. They run through the same
          on-device pipeline; the model is not told the answer.
        </p>
        <div className="live-buttons">
          {clips === null ? (
            <button
              className="btn btn-outline btn-small"
              disabled={!canUseEngine}
              onClick={() =>
                loadClips().catch(() =>
                  setWorkerError("The replay clips could not be loaded."),
                )
              }
            >
              <Icon name="play" size={15} />
              Show replay clips
            </button>
          ) : (
            clips.map((clip) => (
              <button
                key={clip.id}
                className="btn btn-outline btn-small"
                disabled={!canUseEngine || replayingId !== null || running}
                onClick={() => playClip(clip)}
                aria-busy={replayingId === clip.id}
              >
                <Icon name="play" size={15} />
                Replay clip {clip.id.replace("asl-", "")}
              </button>
            ))
          )}
        </div>
        {clips && (
          <p className="plain-note">
            Clip labels are hidden on purpose. The answers are:{" "}
            {clips.map((c) => c.sign?.toUpperCase()).join(", ")} (in button
            order).
          </p>
        )}
      </section>

      {vocabulary && <VocabularyBrowser vocabulary={vocabulary} />}

      <details className="model-info">
        <summary>
          <span>About this model — what it can and cannot do</span>
          <Icon name="down" size={16} />
        </summary>
        <dl>
          <div>
            <dt>Model</dt>
            <dd>
              asl-signs-v1: GestureSign transformer (MIT), version
              default-2fc9038cc4, 1.40 M parameters, ONNX, run with ONNX Runtime
              Web (WebAssembly) on this device.
            </dd>
          </div>
          <div>
            <dt>Input</dt>
            <dd>
              Up to 64 frames at 30 fps of MediaPipe Holistic landmarks: both
              hands, 11 upper-body points and 40 lip points, made body-relative
              (shoulders), plus frame-to-frame velocity. Left- and right-handed
              signing are canonicalised.
            </dd>
          </div>
          <div>
            <dt>Training data</dt>
            <dd>
              Google – Isolated Sign Language Recognition (Kaggle asl-signs,
              PopSign), CC BY 4.0: about 94,000 clips of 250 signs from 21
              signers; split by signer.
            </dd>
          </div>
          <div>
            <dt>Held-out evaluation (by the model’s authors)</dt>
            <dd>
              72.1% top-1, 88.1% top-5 on 14,396 clips from 3 signers never used
              in training or model selection. Re-checked here only on 6 bundled
              clips (5 of 6 correct). Not validated with Deaf users of this app.
            </dd>
          </div>
          <div>
            <dt>Unknown-sign rejection</dt>
            <dd>
              Temperature-calibrated probability (T = 0.88); below 29% the
              result is “Not sure” and must be resolved by you. Signs with
              shoulders out of frame are also “Not sure”. A sign outside the
              vocabulary can still be mistaken for a supported one — always
              review.
            </dd>
          </div>
          <div>
            <dt>Intended use (model authors)</dt>
            <dd>
              Its authors state it is for learning and demonstrating sign
              recognition and should not be used where a misrecognised sign
              could matter, such as accessibility-critical communication.
              InterpretAI therefore uses it only as a research prototype: every
              sign is reviewed, high-risk topics stop automation, and a
              qualified interpreter is always available.
            </dd>
          </div>
          <div>
            <dt>Privacy</dt>
            <dd>
              Frames and landmarks stay in this browser. Face points are used
              only as lip-shape input inside the worker; they are never shown,
              stored or used to identify anyone.
            </dd>
          </div>
        </dl>
        <ul className="capability-chips" aria-label="Capabilities">
          <li className="yes">
            <Icon name="check" size={13} /> 250 isolated signs
          </li>
          <li className="yes">
            <Icon name="check" size={13} /> Sign-by-sign sequences
          </li>
          <li className="yes">
            <Icon name="check" size={13} /> Movement over time
          </li>
          <li className="yes">
            <Icon name="check" size={13} /> Works offline after download
          </li>
          <li className="no">Sentence translation</li>
          <li className="no">Grammar, facial expressions, classifiers</li>
          <li className="no">Clinically validated</li>
        </ul>
      </details>

      <details className="model-info">
        <summary>
          <span>Short phrases: what is supported</span>
          <Icon name="down" size={16} />
        </summary>
        <div
          className="sign-vocab-table"
          tabIndex={0}
          role="region"
          aria-label="Phrase coverage table"
        >
          <table>
            <thead>
              <tr>
                <th scope="col">Target phrase</th>
                <th scope="col">Status</th>
                <th scope="col">How</th>
              </tr>
            </thead>
            <tbody>
              {TARGET_PHRASES.map((phrase) => (
                <tr key={phrase}>
                  <th scope="row">{phrase}</th>
                  <td>
                    <Badge
                      tone={
                        TARGET_COVERAGE[phrase].status === "supported"
                          ? "teal"
                          : TARGET_COVERAGE[phrase].status === "partial"
                            ? "amber"
                            : "gray"
                      }
                    >
                      {TARGET_COVERAGE[phrase].status.toUpperCase()}
                    </Badge>
                  </td>
                  <td>{TARGET_COVERAGE[phrase].detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
    </div>
  );
}
