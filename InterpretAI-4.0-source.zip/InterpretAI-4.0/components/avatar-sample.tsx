"use client";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./ui";
import { sampleLetters, type SampleLetter } from "@/lib/handshapes";
import type { createAvatarScene } from "./avatar-scene";

export function AvatarSample({ letter }: { letter: SampleLetter }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<ReturnType<typeof createAvatarScene> | null>(null);
  const currentLetter = useRef(letter);
  const [view, setView] = useState("front");
  const [speed, setSpeed] = useState(1);
  const [status, setStatus] = useState("Preparing the local 3D pose sample…");
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    currentLetter.current = letter;
    sceneRef.current?.pose(letter);
  }, [letter]);
  useEffect(() => {
    let active = true;
    import("./avatar-scene")
      .then(({ createAvatarScene }) => {
        if (!active || !canvasRef.current) return;
        sceneRef.current = createAvatarScene(canvasRef.current);
        sceneRef.current.pose(currentLetter.current);
        setReady(true);
        setStatus(
          "Original, scripted 3D pose illustration ready. Not human-reviewed ASL.",
        );
      })
      .catch(() => {
        if (!active) return;
        setFailed(true);
        setStatus(
          "3D rendering is unavailable in this browser. The text pose guide and other tools remain available.",
        );
      });
    return () => {
      active = false;
      sceneRef.current?.dispose();
      sceneRef.current = null;
    };
  }, []);
  return (
    <>
      <div className="avatar-stage">
        <canvas
          ref={canvasRef}
          role="img"
          aria-label={`Scripted avatar pose illustration for the ${letter} handshape; not reviewed ASL instruction`}
          hidden={failed}
        />
        {failed && (
          <div className="avatar-fallback">
            <Icon name="hand" size={45} />
            <strong>Pose guide: {letter}</strong>
            <p>{sampleLetters[letter].instruction}</p>
          </div>
        )}
        <span className="avatar-stage-label">SCRIPTED POSE · UNREVIEWED</span>
      </div>
      <p className="lab-pose-description">
        <strong>Handshape {letter}</strong>
        {sampleLetters[letter].instruction}
      </p>
      <div className="avatar-controls">
        <button
          className="btn btn-outline btn-small"
          disabled={!ready}
          onClick={() => {
            sceneRef.current?.pose(letter, true, speed);
            setStatus(
              "Pose transition played. Reduced-motion settings show the final pose immediately.",
            );
          }}
        >
          <Icon name="play" size={16} />
          Play pose transition
        </button>
        <label>
          Playback speed
          <select
            value={speed}
            disabled={!ready}
            onChange={(event) => setSpeed(Number(event.target.value))}
          >
            <option value={1}>Normal</option>
            <option value={0.5}>Slow</option>
          </select>
        </label>
        <label>
          Avatar view
          <select
            value={view}
            disabled={!ready}
            onChange={(event) => {
              setView(event.target.value);
              sceneRef.current?.view(event.target.value === "angled");
            }}
          >
            <option value="front">Front</option>
            <option value="angled">Angled</option>
          </select>
        </label>
      </div>
      <p className="lab-render-status" role="status">
        {status}
      </p>
    </>
  );
}
