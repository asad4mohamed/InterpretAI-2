"use client";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Badge, Icon } from "./ui";
type AppContextValue = {
  online: boolean;
  simulatedOffline: boolean;
  setSimulatedOffline: (value: boolean) => void;
  offlineReady: boolean;
  cacheError: boolean;
  requestInterpreter: () => void;
  openInfo: (title: string, text: string) => void;
};
const AppContext = createContext<AppContextValue | null>(null);
export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error("AppProvider is required");
  return value;
}
export function AppProvider({ children }: { children: ReactNode }) {
  const [online, setOnline] = useState(true);
  const [simulatedOffline, setSimulatedOffline] = useState(false);
  const [offlineReady, setOfflineReady] = useState(false);
  const [cacheError, setCacheError] = useState(false);
  const [modal, setModal] = useState<"interpreter" | "info" | null>(null);
  const [info, setInfo] = useState({ title: "", text: "" });
  const [mode, setMode] = useState("in-person");
  const [submitted, setSubmitted] = useState(false);
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      const onMessage = (event: MessageEvent) => {
        if (event.data?.type === "OFFLINE_READY") setOfflineReady(true);
      };
      navigator.serviceWorker.addEventListener("message", onMessage);
      navigator.serviceWorker
        .register("/sw.js")
        .then(async () => {
          const registration = await navigator.serviceWorker.ready;
          registration.active?.postMessage({ type: "CHECK_READY" });
        })
        .catch(() => setCacheError(true));
      return () => {
        window.removeEventListener("online", sync);
        window.removeEventListener("offline", sync);
        navigator.serviceWorker.removeEventListener("message", onMessage);
      };
    }
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);
  useEffect(() => {
    if (modal) dialogRef.current?.showModal();
    else dialogRef.current?.close();
  }, [modal]);
  const requestInterpreter = () => {
    setSubmitted(false);
    setModal("interpreter");
  };
  return (
    <AppContext.Provider
      value={{
        online,
        simulatedOffline,
        setSimulatedOffline,
        offlineReady,
        cacheError,
        requestInterpreter,
        openInfo: (title, text) => {
          setInfo({ title, text });
          setModal("info");
        },
      }}
    >
      {children}
      <dialog
        ref={dialogRef}
        onCancel={() => setModal(null)}
        onClick={(e) => {
          if (e.target === e.currentTarget) setModal(null);
        }}
        aria-labelledby="dialog-title"
        className="modal"
      >
        <button
          className="icon-button modal-close"
          onClick={() => setModal(null)}
          aria-label="Close dialog"
        >
          <Icon name="x" />
        </button>
        {modal === "interpreter" ? (
          <>
            <div className="modal-symbol">
              <Icon name={submitted ? "checks" : "users"} size={28} />
            </div>
            <Badge tone="amber">Simulated request · No booking</Badge>
            <h2 id="dialog-title">
              {submitted
                ? "Your choice comes first."
                : "Request a qualified interpreter"}
            </h2>
            {submitted ? (
              <>
                <p role="status">
                  Your fictional{" "}
                  {mode === "in-person" ? "in-person" : "video remote"} request
                  is complete for this demonstration. No request was sent, and
                  no interpreter has been booked.
                </p>
                <div className="notice">
                  <Icon name="info" />
                  <p>
                    For a real visit, contact your clinic through its actual
                    interpreter request process.{" "}
                    {!online || simulatedOffline
                      ? "Remote interpretation is unavailable in this offline demonstration."
                      : "The clinic must confirm availability and arrangements."}
                  </p>
                </div>
                <button
                  className="btn btn-primary w-full"
                  onClick={() => setModal(null)}
                >
                  Return to my experience
                  <Icon name="arrow-right" />
                </button>
                <button
                  className="text-button"
                  onClick={() => setSubmitted(false)}
                >
                  Try another request
                </button>
              </>
            ) : (
              <>
                <p>
                  You decide how to communicate. Explore the options below, then
                  try the fictional request workflow.
                </p>
                <fieldset className="interpreter-options">
                  <legend className="sr-only">Interpreter preference</legend>
                  {[
                    [
                      "in-person",
                      "In-person interpreter",
                      "A qualified ASL interpreter at your clinic.",
                      "users",
                    ],
                    [
                      "video",
                      "Video remote interpreter",
                      "A qualified interpreter over a stable video connection.",
                      "video",
                    ],
                  ].map(([value, title, desc, icon]) => (
                    <label
                      key={value}
                      className={`choice-card ${mode === value ? "selected" : ""}`}
                    >
                      <input
                        type="radio"
                        name="interpreter"
                        value={value}
                        checked={mode === value}
                        onChange={() => setMode(value)}
                      />
                      <Icon name={icon as "users" | "video"} size={23} />
                      <span>
                        <strong>{title}</strong>
                        <small>{desc}</small>
                      </span>
                    </label>
                  ))}
                </fieldset>
                {(!online || simulatedOffline) && (
                  <div className="notice">
                    <Icon name="offline" />
                    <p>
                      Offline: this form is a local simulation. Video
                      interpretation and sending a real request require
                      connectivity.
                    </p>
                  </div>
                )}
                <p className="rights-statement">
                  InterpretAI does not replace your right to effective
                  communication or appropriate qualified interpretation.
                </p>
                <button
                  className="btn btn-primary w-full"
                  onClick={() => setSubmitted(true)}
                >
                  Try simulated request
                  <Icon name="arrow-right" />
                </button>
              </>
            )}
          </>
        ) : (
          <>
            <div className="modal-symbol">
              <Icon name="info" size={28} />
            </div>
            <h2 id="dialog-title">{info.title}</h2>
            <p>{info.text}</p>
            <button className="btn btn-primary" onClick={() => setModal(null)}>
              Got it
              <Icon name="check" />
            </button>
          </>
        )}
      </dialog>
    </AppContext.Provider>
  );
}
