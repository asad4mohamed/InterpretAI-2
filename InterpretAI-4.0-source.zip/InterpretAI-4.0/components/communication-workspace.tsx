"use client";
import Link from "next/link";
import { useEffect, useReducer, useRef, useState } from "react";
import { useApp } from "./app-provider";
import { Badge, Icon } from "./ui";
import {
  detectRisk,
  initialState,
  scenarioFor,
  scenarioReducer,
  scenarios,
} from "@/lib/scenarios";
import { cameraConstraints, stopStream } from "@/lib/camera";
export function CommunicationWorkspace({
  initialScenario = "check-in",
  compact = false,
}: {
  initialScenario?: string;
  compact?: boolean;
}) {
  const [state, dispatch] = useReducer(scenarioReducer, {
    ...initialState,
    scenarioId: scenarioFor(initialScenario).id,
  });
  const {
    online,
    simulatedOffline,
    setSimulatedOffline,
    offlineReady,
    requestInterpreter,
  } = useApp();
  const [draft, setDraft] = useState("");
  const [notes, setNotes] = useState<string[]>([]);
  const [correction, setCorrection] = useState(false);
  const [status, setStatus] = useState("");
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraPending, setCameraPending] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mountedRef = useRef(true);
  const cameraRequestRef = useRef(0);
  const scenario = scenarioFor(state.scenarioId);
  const step = scenario.steps[state.index];
  const confirmed = state.confirmed.includes(state.index);
  const complete = state.index === scenario.steps.length - 1 && !state.stopped;
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      stopStream(streamRef.current);
    };
  }, []);
  useEffect(() => {
    if (cameraOn && videoRef.current)
      videoRef.current.srcObject = streamRef.current;
  }, [cameraOn]);
  function stopCamera() {
    cameraRequestRef.current++;
    stopStream(streamRef.current);
    streamRef.current = null;
    setCameraOn(false);
    setCameraPending(false);
  }
  async function startCamera() {
    setCameraError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError(
        "Camera preview is unavailable in this browser. All scripted cards still work.",
      );
      return;
    }
    const request = ++cameraRequestRef.current;
    setCameraPending(true);
    try {
      const stream =
        await navigator.mediaDevices.getUserMedia(cameraConstraints);
      if (!mountedRef.current || request !== cameraRequestRef.current) {
        stopStream(stream);
        return;
      }
      streamRef.current = stream;
      setCameraOn(true);
    } catch {
      if (mountedRef.current && request === cameraRequestRef.current)
        setCameraError(
          "Camera access was declined or unavailable. Continue with the scripted communication cards.",
        );
    } finally {
      if (mountedRef.current && request === cameraRequestRef.current)
        setCameraPending(false);
    }
  }
  function reset(id?: string) {
    dispatch(id ? { type: "select", id } : { type: "restart" });
    setDraft("");
    setNotes([]);
    setCorrection(false);
    setStatus("Scenario reset. Ready to begin.");
  }
  function sendNote(e: React.FormEvent) {
    e.preventDefault();
    if (!draft.trim() || state.stopped) return;
    const risk = detectRisk(draft);
    if (risk) {
      dispatch({ type: "stop", risk });
      setStatus("Conversation paused. Qualified interpretation is required.");
    } else {
      setNotes((v) => [...v, draft.trim()]);
      setStatus(
        "Provider note added as written English. No ASL translation was performed.",
      );
    }
    setDraft("");
  }
  return (
    <div className={`workspace ${compact ? "workspace-compact" : ""}`}>
      <div className="simulation-disclaimer">
        <Icon name="shield" size={19} />
        <div>
          <strong>Simulated — Not Clinically Validated</strong>
          <span>
            Scripted demonstration only. Camera input is never interpreted.
            Clinical discussion requires appropriate qualified interpretation.
          </span>
        </div>
        <Badge tone="amber">RESEARCH PROTOTYPE</Badge>
      </div>
      <div className="scenario-toolbar">
        <div className="scenario-selector">
          <label htmlFor={compact ? "demo-scenario" : "scenario"}>
            Select Scenario
          </label>
          <select
            id={compact ? "demo-scenario" : "scenario"}
            value={state.scenarioId}
            onChange={(e) => reset(e.target.value)}
          >
            {scenarios.map((s) => (
              <option key={s.id} value={s.id}>
                {s.letter}. {s.title}
              </option>
            ))}
          </select>
        </div>
        <button
          className={`btn btn-small ${simulatedOffline ? "btn-amber" : "btn-outline"}`}
          onClick={() => setSimulatedOffline(!simulatedOffline)}
          aria-pressed={simulatedOffline}
        >
          <Icon name={simulatedOffline ? "wifi" : "offline"} size={16} />
          {simulatedOffline ? "Restore demo connection" : "Simulate outage"}
        </button>
      </div>
      {!compact && (
        <p className="workspace-lab-link">
          <Icon name="hand" size={17} />
          <Link href="/sample-lab/">
            Try the separate handshape & avatar sample lab
          </Link>
          <span>Two handshapes only · no clinical translation</span>
        </p>
      )}
      {(simulatedOffline || !online) && (
        <div className="workspace-offline" role="status">
          <Icon name="offline" />
          <div>
            <strong>
              {simulatedOffline
                ? "Simulated outage — browser network unchanged"
                : "Offline Mode — Prevalidated communication tools remain available."}
            </strong>
            <p>
              {offlineReady
                ? "Cached scenarios remain available. "
                : "Current scenarios are available in this loaded page. "}
              Live VRI and sending interpreter requests are unavailable in this
              demonstration.
            </p>
          </div>
        </div>
      )}
      <div className="workspace-grid">
        <section
          className="communication-panel patient-panel"
          aria-labelledby="patient-panel-title"
        >
          <header>
            <span className="panel-person-icon">
              <Icon name="hand" />
            </span>
            <div>
              <h2 id="patient-panel-title">Patient</h2>
              <p>Patient · ASL-first communication</p>
            </div>
            <Badge>Patient confirmation required</Badge>
          </header>
          <div className={`camera-preview ${cameraOn ? "camera-active" : ""}`}>
            {cameraOn ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  aria-label="Local camera preview — no interpretation"
                />
                <span className="camera-local-label">
                  <Icon name="lock" size={13} />
                  Local preview only
                </span>
                <button
                  className="btn btn-white btn-small camera-stop"
                  onClick={stopCamera}
                >
                  <Icon name="x" size={15} />
                  Stop camera
                </button>
              </>
            ) : (
              <>
                <span className="camera-symbol">
                  <Icon name="camera" size={32} />
                </span>
                <h3>Camera preview is optional.</h3>
                <p>
                  Preview stays on this device.
                  <br />
                  Never recorded, uploaded, or translated.
                </p>
                <button
                  className="btn btn-white btn-small"
                  onClick={startCamera}
                  disabled={cameraPending}
                >
                  <Icon name="camera" size={16} />
                  {cameraPending
                    ? "Waiting for permission…"
                    : "Enable local camera preview"}
                </button>
                {cameraPending && (
                  <button className="text-button" onClick={stopCamera}>
                    Cancel camera request
                  </button>
                )}
              </>
            )}
          </div>
          {cameraError && (
            <p role="status" className="camera-error">
              {cameraError}
            </p>
          )}
          <div className="patient-card-area">
            <div className="mini-heading">
              <span>SCRIPTED COMMUNICATION CARD</span>
              <Icon name="message" size={16} />
            </div>
            <Badge tone="gray">Simulation / Prevalidated Example</Badge>
            {step.purpose === "teach-back" && (
              <aside
                className="teach-back-note"
                aria-label="Teach-back practice"
              >
                <Icon name="message" size={19} />
                <div>
                  <h3>Teach-back practice</h3>
                  <p>{step.hint}</p>
                </div>
              </aside>
            )}
            <p className="patient-phrase">
              {step.speaker === "patient"
                ? `“${step.text}”`
                : "“I use ASL. Please communicate with me in an accessible way.”"}
            </p>
            <p className="plain-note">
              English text placeholder for a future human-reviewed ASL card. No
              ASL video or clinical validation is claimed.
            </p>
            <div className="confirmation-actions">
              <button
                disabled={
                  state.stopped || step.speaker !== "patient" || !step.confirm
                }
                className={`btn ${confirmed ? "btn-soft" : "btn-primary"}`}
                onClick={() => {
                  dispatch({ type: "confirm" });
                  setCorrection(false);
                  setStatus("You confirmed this scripted message.");
                }}
              >
                <Icon name="check" size={18} />
                {confirmed ? "Message confirmed" : "Yes, that’s my message"}
              </button>
              <button
                disabled={
                  state.stopped || step.speaker !== "patient" || !step.confirm
                }
                className="btn btn-outline"
                onClick={() => {
                  dispatch({ type: "correct" });
                  setCorrection(true);
                  setStatus(
                    "Message not confirmed. Please choose a correction.",
                  );
                }}
              >
                Correct
              </button>
            </div>
            {correction && (
              <div className="correction-box">
                <strong>Choose how to correct this message.</strong>
                <p>
                  This message has not been confirmed. You can repeat the
                  example or ask for qualified interpretation.
                </p>
                <button
                  className="btn btn-outline btn-small"
                  onClick={() => {
                    setCorrection(false);
                    setStatus(
                      "Example repeated. Confirm only if it matches your message.",
                    );
                  }}
                >
                  Repeat this example
                </button>
                <button className="text-button" onClick={requestInterpreter}>
                  I would like a qualified interpreter
                </button>
              </div>
            )}
          </div>
        </section>
        <section
          className="communication-panel provider-panel"
          aria-labelledby="provider-panel-title"
        >
          <header>
            <span className="panel-person-icon provider-icon">
              <Icon name="clipboard" />
            </span>
            <div>
              <h2 id="provider-panel-title">Care team</h2>
              <p>Provider · Written English</p>
            </div>
            <span className="caption-tag">CAPTIONS</span>
          </header>
          <div
            className="conversation-history"
            role="log"
            aria-label="Scripted conversation history"
            aria-live="polite"
          >
            {scenario.steps.slice(0, state.index + 1).map((message, i) => (
              <div
                className={`conversation-entry entry-${message.speaker} ${message.risk ? "entry-risk" : ""}`}
                key={`${scenario.id}-${i}`}
              >
                <div className="conversation-meta">
                  <span>
                    {message.speaker === "patient"
                      ? "Jordan · Patient"
                      : message.speaker === "provider"
                        ? "Care team"
                        : "InterpretAI · Demo guidance"}
                  </span>
                  <span>0{i + 1}</span>
                </div>
                <p>{message.text}</p>
                {message.speaker !== "system" && (
                  <small>Simulation / Prevalidated Example</small>
                )}
                {state.confirmed.includes(i) && (
                  <span className="confirmed-label">
                    <Icon name="checks" size={13} />
                    Patient confirmed
                  </span>
                )}
              </div>
            ))}
            {notes.map((note, i) => (
              <div
                className="conversation-entry entry-provider"
                key={`note-${i}`}
              >
                <div className="conversation-meta">
                  <span>Care team · Local note</span>
                </div>
                <p>{note}</p>
                <small>Written English only · Not translated</small>
              </div>
            ))}
          </div>
          <form className="provider-form" onSubmit={sendNote}>
            <label htmlFor={compact ? "demo-note" : "provider-note"}>
              Provider note · demo text only
            </label>
            <textarea
              id={compact ? "demo-note" : "provider-note"}
              value={draft}
              disabled={state.stopped}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Type a non-clinical message. No real patient information."
              rows={2}
              maxLength={500}
            />
            <div>
              <small>Stays in this page. No ASL translation.</small>
              <button
                className="btn btn-primary btn-small"
                type="submit"
                disabled={!draft.trim() || state.stopped}
              >
                Add note
                <Icon name="arrow-right" size={16} />
              </button>
            </div>
          </form>
        </section>
      </div>
      {state.stopped && (
        <div className="safety-stop" role="alert">
          <span className="safety-stop-icon">
            <Icon name="shield" size={27} />
          </span>
          <div>
            <Badge tone="amber">CONVERSATION PAUSED</Badge>
            <h3>
              {state.risk === "Patient choice"
                ? "Your choice is respected."
                : "This conversation needs a qualified interpreter."}
            </h3>
            <p>
              {state.risk === "Patient choice"
                ? "You asked for qualified human interpretation. The scenario will not continue."
                : `${state.risk} is outside this prototype’s scope. The scenario has stopped; no clinical interpretation or advice is provided.`}
            </p>
            <small>
              For a real urgent situation, use your clinic’s or local emergency
              service’s accessible communication process. This app does not
              contact anyone.
            </small>
          </div>
          <button className="btn btn-primary" onClick={requestInterpreter}>
            Request Qualified Interpreter
            <Icon name="users" size={18} />
          </button>
        </div>
      )}
      <div className="scenario-controls">
        <div>
          <span className="eyebrow">
            SCENARIO {scenario.letter} <span>·</span> STEP {state.index + 1} OF{" "}
            {scenario.steps.length}
          </span>
          <strong>{scenario.title}</strong>
          <div className="step-dots" aria-hidden="true">
            {scenario.steps.map((_, i) => (
              <span className={i <= state.index ? "filled" : ""} key={i} />
            ))}
          </div>
        </div>
        <div className="control-buttons">
          <button className="text-button" onClick={() => reset()}>
            <Icon name="refresh" size={16} />
            Restart
          </button>
          <button
            className="btn btn-outline"
            disabled={state.index === 0 || state.stopped}
            onClick={() => {
              dispatch({ type: "back" });
              setCorrection(false);
            }}
          >
            <Icon name="arrow-left" size={17} />
            Back
          </button>
          <button
            className="btn btn-primary"
            disabled={
              state.stopped || complete || (!!step.confirm && !confirmed)
            }
            onClick={() => {
              dispatch({ type: "next" });
              setCorrection(false);
              setStatus("");
            }}
          >
            {complete ? "Example complete" : "Next"}
            <Icon name={complete ? "check" : "arrow-right"} size={17} />
          </button>
        </div>
      </div>
      <div className="workspace-bottom-note">
        <span role="status">
          {status ||
            (step.confirm && !confirmed && !state.stopped
              ? "Confirm or correct the patient card before continuing."
              : "Move through each scripted example at your own pace.")}
        </span>
        <button className="text-button" onClick={requestInterpreter}>
          <Icon name="users" size={16} />
          Request Qualified Interpreter
        </button>
      </div>
      <p className="safeguard-note">
        Safety safeguard: fixed scenarios and simple English keywords only. It
        can miss high-risk topics, does not understand ASL, and is not a
        clinical safety system.
      </p>
    </div>
  );
}
