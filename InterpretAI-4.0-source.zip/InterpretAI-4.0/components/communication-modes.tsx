"use client";
import { useEffect, useRef, useState } from "react";
import { CommunicationWorkspace } from "./communication-workspace";
import { RecognitionWorkspace } from "./recognition-workspace";
import { Icon } from "./ui";

const tabs = [
  {
    id: "scripted",
    label: "Scripted scenarios",
    note: "Simulated · prevalidated examples",
  },
  {
    id: "live",
    label: "Experimental live recognition",
    note: "Real providers only · may be unavailable",
  },
] as const;
type TabId = (typeof tabs)[number]["id"];

/**
 * Keeps scripted scenarios and experimental live recognition strictly
 * separate. Only one panel is mounted at a time, so there is never more than
 * one camera stream on this page.
 */
export function CommunicationModes() {
  const [active, setActive] = useState<TabId>("scripted");
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  useEffect(() => {
    // Deep link: /communication/#live opens the experimental workspace.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (window.location.hash === "#live") setActive("live");
  }, []);
  const select = (id: TabId, focus = false) => {
    setActive(id);
    history.replaceState(
      null,
      "",
      id === "live" ? "#live" : window.location.pathname,
    );
    if (focus) refs.current[tabs.findIndex((t) => t.id === id)]?.focus();
  };
  return (
    <>
      <div className="mode-tabs" role="tablist" aria-label="Communication mode">
        {tabs.map((tab, index) => (
          <button
            key={tab.id}
            ref={(element) => {
              refs.current[index] = element;
            }}
            role="tab"
            id={`tab-${tab.id}`}
            aria-selected={active === tab.id}
            aria-controls={`panel-${tab.id}`}
            tabIndex={active === tab.id ? 0 : -1}
            className={active === tab.id ? "active" : ""}
            onClick={() => select(tab.id)}
            onKeyDown={(event) => {
              if (
                !["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)
              )
                return;
              event.preventDefault();
              const next =
                event.key === "Home"
                  ? 0
                  : event.key === "End"
                    ? tabs.length - 1
                    : (index +
                        (event.key === "ArrowRight" ? 1 : -1) +
                        tabs.length) %
                      tabs.length;
              select(tabs[next].id, true);
            }}
          >
            <Icon name={tab.id === "live" ? "hand" : "message"} size={17} />
            <span>
              {tab.label}
              <small>{tab.note}</small>
            </span>
          </button>
        ))}
      </div>
      <div
        role="tabpanel"
        id={`panel-${active}`}
        aria-labelledby={`tab-${active}`}
      >
        {active === "scripted" ? (
          <CommunicationWorkspace />
        ) : (
          <RecognitionWorkspace />
        )}
      </div>
    </>
  );
}
