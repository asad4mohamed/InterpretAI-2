import * as THREE from "three";
import { sampleLetters, type SampleLetter } from "@/lib/handshapes";

export function createAvatarScene(canvas: HTMLCanvasElement) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0xeff2eb);
  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-1.5, 1.5, 2.5, 0, 0.01, 30);
  const skin = new THREE.MeshStandardMaterial({
    color: 0xc99e7d,
    roughness: 0.85,
  });
  const shirt = new THREE.MeshStandardMaterial({
    color: 0x16384c,
    roughness: 0.95,
  });
  const dark = new THREE.MeshStandardMaterial({
    color: 0x263b40,
    roughness: 1,
  });
  scene.add(new THREE.HemisphereLight(0xffffff, 0x99a68d, 2.7));
  const light = new THREE.DirectionalLight(0xffffff, 3.5);
  light.position.set(-3, 4, 5);
  scene.add(light);
  const body = new THREE.Group();
  scene.add(body);
  function sphere(
    parent: THREE.Object3D,
    position: number[],
    scale: number[],
    material: THREE.Material,
  ) {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 28, 20), material);
    mesh.position.fromArray(position);
    mesh.scale.fromArray(scale);
    parent.add(mesh);
    return mesh;
  }
  function segment(
    parent: THREE.Object3D,
    from: THREE.Vector3,
    to: THREE.Vector3,
    radius: number,
    material: THREE.Material,
  ) {
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.9, radius, from.distanceTo(to), 16),
      material,
    );
    mesh.position.copy(from).add(to).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      to.clone().sub(from).normalize(),
    );
    parent.add(mesh);
  }
  sphere(body, [0, 0.84, 0], [0.44, 0.61, 0.24], shirt);
  sphere(body, [0, 1.51, 0], [0.09, 0.18, 0.09], skin);
  sphere(body, [0, 1.86, 0.01], [0.23, 0.285, 0.205], skin);
  sphere(body, [0, 2.055, -0.025], [0.23, 0.125, 0.195], dark);
  for (const x of [-0.075, 0.075])
    sphere(body, [x, 1.9, 0.198], [0.012, 0.014, 0.008], dark);
  sphere(body, [0, 1.84, 0.214], [0.025, 0.032, 0.027], skin);
  sphere(body, [0, 1.755, 0.192], [0.046, 0.004, 0.005], dark);
  segment(
    body,
    new THREE.Vector3(-0.34, 1.23, 0),
    new THREE.Vector3(-0.7, 0.94, 0.04),
    0.105,
    shirt,
  );
  segment(
    body,
    new THREE.Vector3(-0.7, 0.94, 0.04),
    new THREE.Vector3(-0.7, 1.4, 0.27),
    0.063,
    skin,
  );
  sphere(body, [-0.7, 0.94, 0.04], [0.072, 0.072, 0.072], skin);
  segment(
    body,
    new THREE.Vector3(0.34, 1.23, 0),
    new THREE.Vector3(0.59, 0.79, 0.03),
    0.1,
    shirt,
  );
  segment(
    body,
    new THREE.Vector3(0.59, 0.79, 0.03),
    new THREE.Vector3(0.47, 0.38, 0.1),
    0.063,
    skin,
  );
  sphere(body, [0.47, 0.3, 0.1], [0.07, 0.12, 0.045], skin);
  const hand = new THREE.Group();
  hand.position.set(-0.7, 1.4, 0.27);
  hand.scale.setScalar(1.3);
  body.add(hand);
  sphere(hand, [0, 0.15, 0], [0.15, 0.17, 0.055], skin);
  const fingerJoints: THREE.Group[][] = [];
  function finger(x: number, y: number, lengths: number[], radius: number) {
    let parent: THREE.Object3D = hand;
    const joints: THREE.Group[] = [];
    lengths.forEach((length, index) => {
      const joint = new THREE.Group();
      joint.position.set(
        index === 0 ? x : 0,
        index === 0 ? y : lengths[index - 1],
        0.01,
      );
      if (index > 0) joint.position.z = 0;
      parent.add(joint);
      sphere(joint, [0, 0, 0], [radius, radius, radius], skin);
      segment(
        joint,
        new THREE.Vector3(),
        new THREE.Vector3(0, length, 0),
        radius,
        skin,
      );
      if (index === lengths.length - 1)
        sphere(
          joint,
          [0, length, 0],
          [radius * 0.9, radius * 0.9, radius * 0.9],
          skin,
        );
      joints.push(joint);
      parent = joint;
    });
    fingerJoints.push(joints);
  }
  finger(-0.12, 0.09, [0.095, 0.073], 0.031);
  finger(-0.095, 0.275, [0.095, 0.075, 0.06], 0.025);
  finger(-0.025, 0.29, [0.105, 0.08, 0.065], 0.026);
  finger(0.045, 0.275, [0.095, 0.075, 0.06], 0.024);
  finger(0.108, 0.245, [0.075, 0.055, 0.047], 0.021);
  let frame = 0;
  let disposed = false;
  let selected: SampleLetter = "L";
  const render = () => {
    if (!disposed) renderer.render(scene, camera);
  };
  function applyPose(amount: number) {
    fingerJoints.forEach((joints, index) => {
      const extended = sampleLetters[selected].extended.includes(index)
        ? amount
        : 0;
      const curl = 1 - extended;
      if (index === 0) {
        joints[0].rotation.z = -0.95 + extended * 2.1;
        joints[0].rotation.x = 0.1;
        joints[1].rotation.x = curl * 0.8;
      } else {
        joints[0].rotation.x = curl * 0.95;
        joints[1].rotation.x = curl * 1.4;
        joints[2].rotation.x = curl * 1.0;
      }
    });
    render();
  }
  function pose(letter: SampleLetter, animate = false, speed = 1) {
    selected = letter;
    cancelAnimationFrame(frame);
    if (
      !animate ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      applyPose(1);
      return;
    }
    const start = performance.now();
    function tick(now: number) {
      if (disposed) return;
      const progress = Math.min((now - start) / (1100 / speed), 1);
      applyPose(progress * progress * (3 - 2 * progress));
      if (progress < 1) frame = requestAnimationFrame(tick);
    }
    frame = requestAnimationFrame(tick);
  }
  function resize() {
    const width = Math.max(canvas.clientWidth, 1);
    const height = Math.max(canvas.clientHeight, 1);
    renderer.setSize(width, height, false);
    const halfHeight = 1.25;
    camera.left = (-halfHeight * width) / height;
    camera.right = (halfHeight * width) / height;
    camera.top = halfHeight;
    camera.bottom = -halfHeight;
    camera.position.set(-0.1, 1.23, 5);
    camera.lookAt(-0.1, 1.23, 0);
    camera.updateProjectionMatrix();
    render();
  }
  const observer = new ResizeObserver(resize);
  observer.observe(canvas);
  resize();
  pose("L");
  return {
    pose,
    view: (angled: boolean) => {
      body.rotation.y = angled ? 0.42 : 0;
      render();
    },
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) object.geometry.dispose();
      });
      skin.dispose();
      shirt.dispose();
      dark.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
    },
  };
}
