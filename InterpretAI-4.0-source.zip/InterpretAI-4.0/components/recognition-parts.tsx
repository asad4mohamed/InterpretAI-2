"use client";
import { useState } from "react";
import { Badge, Icon } from "./ui";
import type { ConversationEntry } from "@/lib/asl/recognition-state";
import type {
  ConfidenceReport,
  ProviderAvailability,
  ProviderDescriptor,
} from "@/lib/asl/types";
import type { StaticHandModel, LetterDecision } from "@/lib/asl/fingerspelling";
import type { ProxyHealth } from "@/lib/asl/sign-speak";

export function confidenceText(report?: ConfidenceReport) {
  if (!report || report.kind === "none") return "No confidence value";
  const value =
    report.value <= 1 && report.value >= 0
      ? `${Math.round(report.value * 100)}%`
      : String(report.value);
  return report.kind === "provider-reported"
    ? `Provider-reported score ${value}`
    : report.kind === "calibrated-probability"
      ? `Lowest sign probability ${value} (calibrated on held-out signers)`
      : `Model score ${value} (not calibrated)`;
}

export const sourceLabels: Record<ConversationEntry["source"], string> = {
  "asl-signs": "Sign model (250 signs) + phrase table · on-device",
  "experimental-handshape": "Experimental handshape rules · on-device",
  fingerspelling: "Fingerspelling model · on-device",
  "local-model": "Local trained model · on-device",
  "sign-speak": "Sign-Speak API · cloud",
  huggingface: "Hugging Face model · cloud",
  typed: "Typed text",
  system: "InterpretAI",
};

export const statusLabels: Record<ConversationEntry["status"], string> = {
  "pending-review": "Awaiting patient review",
  confirmed: "Patient confirmed this is what they signed",
  rejected: "Patient rejected — not their message",
  corrected: "Corrected by the patient",
  sent: "Sent as written English",
  escalated: "High-risk — qualified interpreter required",
};

/* ---------- Capability matrix ---------- */

const capabilityRows = [
  ["tracking", "Hand tracking"],
  ["handshape", "Handshape"],
  ["fingerspelling", "Fingerspelling"],
  ["isolated-sign", "Isolated signs"],
  ["sentence", "Sentence translation"],
] as const;

export function capabilitiesFor(descriptor: ProviderDescriptor) {
  const g = descriptor.capabilities.granularity;
  const tracking =
    descriptor.capabilities.input === "landmark-stream" ||
    descriptor.capabilities.input === "landmark-sequence";
  return {
    tracking,
    handshape: g === "handshape",
    fingerspelling: g === "fingerspelling",
    "isolated-sign": g === "isolated-sign",
    sentence: g === "continuous-english",
  } as Record<(typeof capabilityRows)[number][0], boolean>;
}

/* ---------- Model information panel ---------- */

type ModelFacts = {
  model: string;
  vocabulary: string;
  input: string;
  offline: string;
  limitations: string;
};

function factsFor(
  descriptor: ProviderDescriptor,
  fingerspelling: StaticHandModel | null,
  health: ProxyHealth | null,
): ModelFacts {
  switch (descriptor.id) {
    case "fingerspelling":
      return {
        model: fingerspelling
          ? `${fingerspelling.id} v${fingerspelling.version} — dense MLP trained by InterpretAI`
          : "interpretai-asl-fingerspelling v1.0.0 (loading…)",
        vocabulary: fingerspelling
          ? `${fingerspelling.vocabulary.length} static letters: ${fingerspelling.vocabulary.join(" ")}. J and Z (movement) are not supported.`
          : "24 static letters (A–Y without J)",
        input:
          "One hand's 21 MediaPipe landmarks per frame, read live; letters commit after a steady hold.",
        offline:
          "Works offline once the app and the hand-tracking tools are cached.",
        limitations: fingerspelling
          ? `Held-out ${Math.round((fingerspelling.evaluation.metrics.heldOutTop1 ?? 0) * 100)}% (same dataset); ${Math.round((fingerspelling.evaluation.metrics.externalTop1 ?? 0) * 100)}% on 24 photos of one unseen signer. Not signer-independent. Similar letters (P/Q, T/S, M/N, A/S/E) are confused. Not ASL signs or sentences.`
          : "See the model card.",
      };
    case "experimental-handshape":
      return {
        model: "Hand-written geometry rules (no trained model)",
        vocabulary: "2 handshapes: L-like, Y-like",
        input: "One hand's landmarks over a 3-second capture.",
        offline: "Works offline once the hand-tracking tools are cached.",
        limitations:
          "A technical demonstration of tracking. Not ASL recognition.",
      };
    case "local-model":
      return {
        model: "Supplied by you — none bundled",
        vocabulary: "Defined by the supplied model's manifest",
        input:
          "3-second two-hand landmark sequence (interpretai.landmarks.v1).",
        offline: "Works offline after “Save this model for offline use”.",
        limitations:
          "Requires a documented, evaluated isolated-sign model. See LOCAL-RECOGNITION.md.",
      };
    case "sign-speak":
      return {
        model: "Sign-Speak SLR (provider-hosted)",
        vocabulary: "Open vocabulary, defined by the provider",
        input:
          "A short reviewed video clip (≤ 10 s), sent after per-clip consent.",
        offline: "Not available offline.",
        limitations:
          "Accuracy not evaluated by InterpretAI. Requires an approved API key on the proxy.",
      };
    case "huggingface":
      return {
        model: health?.huggingFace.modelId
          ? `${health.huggingFace.modelId} via ${health.huggingFace.target === "dedicated-endpoint" ? "Dedicated Inference Endpoint" : "HF Inference provider"}`
          : health?.huggingFace.target === "dedicated-endpoint"
            ? "Dedicated Inference Endpoint (model set on the endpoint)"
            : "Not configured",
        vocabulary:
          "Whatever labels the configured image-classification model returns",
        input:
          "ONE still photo, sent after per-photo consent. A photo can only show a static handshape.",
        offline: "Not available offline.",
        limitations:
          "Single-image models cannot read movement, signs, or sentences. Scores come from the model and are not verified.",
      };
    default:
      return {
        model: "None",
        vocabulary: "None",
        input: "None",
        offline: "—",
        limitations: "Nothing is interpreted.",
      };
  }
}

export function ModelInfoPanel({
  descriptor,
  availability,
  fingerspelling,
  health,
}: {
  descriptor: ProviderDescriptor;
  availability?: ProviderAvailability;
  fingerspelling: StaticHandModel | null;
  health: ProxyHealth | null;
}) {
  const facts = factsFor(descriptor, fingerspelling, health);
  const caps = capabilitiesFor(descriptor);
  return (
    <details className="model-info" open>
      <summary>
        <span>About this mode</span>
        <Badge tone={availability?.state === "available" ? "teal" : "gray"}>
          {availability
            ? availability.state === "available"
              ? "READY"
              : availability.state.toUpperCase().replace("-", " ")
            : "CHECKING"}
        </Badge>
      </summary>
      <dl>
        <div>
          <dt>Provider</dt>
          <dd>{descriptor.label}</dd>
        </div>
        <div>
          <dt>Model</dt>
          <dd>{facts.model}</dd>
        </div>
        <div>
          <dt>Supported vocabulary</dt>
          <dd>{facts.vocabulary}</dd>
        </div>
        <div>
          <dt>Input</dt>
          <dd>{facts.input}</dd>
        </div>
        <div>
          <dt>Processing</dt>
          <dd>
            {descriptor.capabilities.location === "cloud"
              ? `Cloud — ${descriptor.thirdParty?.name ?? "third party"}, through the secure proxy`
              : descriptor.mode === "unavailable"
                ? "None"
                : "On this device"}
          </dd>
        </div>
        <div>
          <dt>Status</dt>
          <dd>
            {availability
              ? availability.state === "available"
                ? "Ready"
                : availability.detail
              : "Checking…"}
          </dd>
        </div>
        <div>
          <dt>Offline</dt>
          <dd>{facts.offline}</dd>
        </div>
        <div>
          <dt>Known limitations</dt>
          <dd>{facts.limitations}</dd>
        </div>
      </dl>
      <ul
        className="capability-chips"
        aria-label="What this mode can and cannot do"
      >
        {capabilityRows.map(([key, label]) => (
          <li key={key} className={caps[key] ? "yes" : "no"}>
            <Icon name={caps[key] ? "check" : "x"} size={13} />
            {label}
            <span className="sr-only">
              {caps[key] ? ": supported" : ": not supported"}
            </span>
          </li>
        ))}
      </ul>
    </details>
  );
}

/* ---------- Live fingerspelling readout ---------- */

const reasonText: Record<LetterDecision["reason"], string> = {
  accepted: "Hold steady to add this letter.",
  "low-score": "Not sure — adjust your handshape.",
  ambiguous: "Could be more than one letter — adjust your handshape.",
  "unfamiliar-shape": "Not a supported letter shape.",
  "no-hand": "Show one hand to the camera.",
};

export function FingerspellingReadout({
  decision,
  progress,
  text,
  handCount,
  paused,
  latency,
}: {
  decision: LetterDecision | null;
  progress: number;
  text: string;
  handCount: number;
  paused: boolean;
  latency: { trackerMs: number; modelMs: number };
}) {
  const message = paused
    ? "Paused — the camera is on but frames are not processed."
    : handCount === 0
      ? reasonText["no-hand"]
      : handCount > 1
        ? "Two hands visible — fingerspell with one hand."
        : decision
          ? decision.letter && progress >= 1
            ? "Added. Change or lower your hand for the next letter."
            : reasonText[decision.reason]
          : "Starting…";
  return (
    <div className="fingerspell-readout">
      <div className="fingerspell-letter" aria-hidden="true">
        {decision?.letter ?? "—"}
        <span
          className="fingerspell-progress"
          style={{ transform: `scaleX(${decision?.letter ? progress : 0})` }}
        />
      </div>
      <div className="fingerspell-text">
        <span className="eyebrow">SPELLED SO FAR (MACHINE OUTPUT)</span>
        <p aria-live="polite">{text || <em>Nothing yet</em>}</p>
        <small>{message}</small>
        <small className="latency">
          Tracking {latency.trackerMs} ms/frame · Letter model{" "}
          {latency.modelMs.toFixed(2)} ms
        </small>
      </div>
    </div>
  );
}

/* ---------- Review / conversation entry ---------- */

export function EntryCard({
  entry,
  onConfirm,
  onReject,
  onCorrect,
  onEditProvider,
  onSpeak,
  onSign,
  canSign,
}: {
  entry: ConversationEntry;
  onConfirm: () => void;
  onReject: () => void;
  onCorrect: (text: string) => void;
  onEditProvider: (text: string) => void;
  onSpeak?: () => void;
  onSign?: () => void;
  canSign: boolean;
}) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(entry.text);
  const isPatient = entry.author === "patient";
  return (
    <div
      className={`conversation-entry entry-${entry.author} ${entry.risk ? "entry-risk" : ""} ${entry.status === "rejected" ? "entry-rejected" : ""}`}
    >
      <div className="conversation-meta">
        <span>{isPatient ? "Patient" : "Care team"}</span>
        <span>{sourceLabels[entry.source]}</span>
      </div>
      <p className={entry.author === "provider" ? "provider-large" : undefined}>
        {entry.status === "rejected" ? <s>{entry.text}</s> : entry.text}
      </p>
      {entry.correctedFrom && (
        <small>
          {isPatient ? "Originally recognised as" : "Edited from"}: “
          {entry.correctedFrom}”
        </small>
      )}
      <small>
        {statusLabels[entry.status]}
        {isPatient && entry.source !== "typed"
          ? ` · ${confidenceText(entry.confidence)}`
          : ""}
        {entry.modelVersion ? ` · ${entry.modelVersion}` : ""}
      </small>
      {isPatient && entry.status === "pending-review" && !editing && (
        <div className="entry-actions">
          <button className="btn btn-primary btn-small" onClick={onConfirm}>
            <Icon name="check" size={15} />
            Yes, that’s what I signed
          </button>
          <button
            className="btn btn-outline btn-small"
            onClick={() => {
              setValue(entry.text);
              setEditing(true);
            }}
          >
            Correct
          </button>
          <button className="btn btn-outline btn-small" onClick={onReject}>
            That’s not what I signed
          </button>
        </div>
      )}
      {!isPatient && !editing && (
        <div className="entry-actions">
          {onSpeak && (
            <button className="text-button" onClick={onSpeak}>
              Read aloud
            </button>
          )}
          <button
            className="text-button"
            onClick={() => {
              setValue(entry.text);
              setEditing(true);
            }}
          >
            Edit message
          </button>
          {onSign && entry.status === "sent" && (
            <button
              className="text-button"
              onClick={onSign}
              disabled={!canSign}
            >
              Show in signing avatar
            </button>
          )}
        </div>
      )}
      {editing && (
        <form
          className="entry-correction"
          onSubmit={(event) => {
            event.preventDefault();
            if (!value.trim()) return;
            if (isPatient) onCorrect(value);
            else onEditProvider(value);
            setEditing(false);
          }}
        >
          <label htmlFor={`edit-${entry.id}`}>
            {isPatient ? "Type what you meant" : "Edit your message"}
          </label>
          <input
            id={`edit-${entry.id}`}
            value={value}
            maxLength={isPatient ? 300 : 500}
            onChange={(event) => setValue(event.target.value)}
          />
          <button
            className="btn btn-primary btn-small"
            type="submit"
            disabled={!value.trim()}
          >
            {isPatient ? "Save correction" : "Save edit"}
          </button>
          <button
            className="text-button"
            type="button"
            onClick={() => setEditing(false)}
          >
            Cancel
          </button>
        </form>
      )}
    </div>
  );
}
