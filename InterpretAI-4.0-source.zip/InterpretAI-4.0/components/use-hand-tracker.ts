"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { handConnections } from "@/lib/handshapes";
import {
  cameraConstraints,
  cameraMessages,
  classifyCameraError,
  cameraSupport,
  isLowPerformance,
  nextFrameInterval,
  stopStream,
  trackingState,
  updateAverage,
  type TrackingState,
} from "@/lib/camera";
import type {
  TrackerRequest,
  TrackerResponse,
} from "@/workers/hand-tracker.worker";

export type TrackerResult = Extract<TrackerResponse, { type: "result" }>;
export type TrackerStatus = "idle" | "loading" | "permission" | "running";
export type LoadStage = "worker" | "runtime" | "model" | null;

/**
 * One camera + one MediaPipe worker per mounted surface, with identical
 * lifecycle rules everywhere:
 *  - nothing starts until `start()` is called by an explicit user action;
 *  - `stop()`, unmount, and hiding the tab terminate the worker and stop
 *    every media track;
 *  - late permission grants after a cancel are stopped immediately;
 *  - frames are processed in a worker, one at a time, with adaptive pacing.
 */
export function useHandTracker({
  onFrame,
}: {
  onFrame?: (result: TrackerResult) => void;
} = {}) {
  const [status, setStatus] = useState<TrackerStatus>("idle");
  const [loadStage, setLoadStage] = useState<LoadStage>(null);
  const [error, setError] = useState("");
  const [tracking, setTracking] = useState<TrackingState>("no-hands");
  const [handCount, setHandCount] = useState(0);
  const [lowPerformance, setLowPerformance] = useState(false);
  const [paused, setPaused] = useState(false);
  const [averageMs, setAverageMs] = useState(0);
  const pausedRef = useRef(false);
  const lastStatsRef = useRef(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workerRef = useRef<Worker | null>(null);
  const initializationRef = useRef<((reason: Error) => void) | null>(null);
  const requestRef = useRef(0);
  const frameRef = useRef(0);
  const inFlightRef = useRef(false);
  const mountedRef = useRef(true);
  const averageRef = useRef(0);
  const lastSeenRef = useRef<number | null>(null);
  const onFrameRef = useRef(onFrame);
  useEffect(() => {
    onFrameRef.current = onFrame;
  }, [onFrame]);

  const clearOverlay = () => {
    const overlay = overlayRef.current;
    overlay?.getContext("2d")?.clearRect(0, 0, overlay.width, overlay.height);
  };

  const stop = useCallback(() => {
    requestRef.current++;
    initializationRef.current?.(
      new DOMException("Camera start cancelled.", "AbortError"),
    );
    initializationRef.current = null;
    cancelAnimationFrame(frameRef.current);
    workerRef.current?.terminate();
    workerRef.current = null;
    stopStream(streamRef.current);
    streamRef.current = null;
    inFlightRef.current = false;
    averageRef.current = 0;
    lastSeenRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    clearOverlay();
    if (mountedRef.current) {
      setStatus("idle");
      setLoadStage(null);
      setTracking("no-hands");
      setHandCount(0);
      setLowPerformance(false);
      setPaused(false);
      setAverageMs(0);
    }
    pausedRef.current = false;
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    const visibility = () => {
      if (document.hidden) stop();
    };
    document.addEventListener("visibilitychange", visibility);
    return () => {
      mountedRef.current = false;
      stop();
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [stop]);

  const draw = (result: TrackerResult) => {
    const canvas = overlayRef.current;
    const video = videoRef.current;
    if (!canvas || !video || !video.videoWidth) return;
    if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth;
    if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    if (!context) return;
    context.clearRect(0, 0, canvas.width, canvas.height);
    for (const hand of result.hands) {
      context.strokeStyle = hand.handedness === "Right" ? "#85e3ce" : "#f2c46d";
      context.fillStyle = "#ffffff";
      context.lineWidth = 3;
      for (const [from, to] of handConnections) {
        const a = hand.image[from];
        const b = hand.image[to];
        if (!a || !b) continue;
        context.beginPath();
        context.moveTo(a.x * canvas.width, a.y * canvas.height);
        context.lineTo(b.x * canvas.width, b.y * canvas.height);
        context.stroke();
      }
      for (const point of hand.image) {
        context.beginPath();
        context.arc(
          point.x * canvas.width,
          point.y * canvas.height,
          3,
          0,
          Math.PI * 2,
        );
        context.fill();
      }
    }
  };

  const fail = useCallback(
    (message: string) => {
      stop();
      if (mountedRef.current) setError(message);
    },
    [stop],
  );

  const start = useCallback(
    async ({ track = true }: { track?: boolean } = {}) => {
      setError("");
      const unsupported = cameraSupport();
      if (
        unsupported ||
        (track && (!window.Worker || !window.createImageBitmap))
      ) {
        setError(
          unsupported === "insecure"
            ? cameraMessages.insecure
            : "Live hand tracking is unavailable in this browser. Try a current Chrome or Edge browser on HTTPS or localhost. Scripted tools still work.",
        );
        return false;
      }
      const request = ++requestRef.current;
      setStatus(track ? "loading" : "permission");
      setLoadStage(track ? "worker" : null);
      try {
        if (track) {
          const worker = new Worker("/lab-engine/hand-tracker.mjs", {
            type: "module",
          });
          workerRef.current = worker;
          await new Promise<void>((resolve, reject) => {
            const timeout = window.setTimeout(
              () =>
                reject(
                  new Error(
                    "The local tracker took too long to initialize. Retry, or use the scripted tools.",
                  ),
                ),
              40000,
            );
            const finish = (failure?: Error) => {
              clearTimeout(timeout);
              initializationRef.current = null;
              if (failure) reject(failure);
              else resolve();
            };
            initializationRef.current = (reason) => finish(reason);
            worker.onerror = () => {
              if (request !== requestRef.current) return;
              const reason = new Error(
                "The local tracker could not run in this browser. Scripted tools remain available.",
              );
              if (initializationRef.current) finish(reason);
              else fail(reason.message);
            };
            worker.onmessage = (event: MessageEvent<TrackerResponse>) => {
              if (!mountedRef.current || request !== requestRef.current) return;
              const message = event.data;
              if (message.type === "progress") {
                setLoadStage(message.stage);
                return;
              }
              if (message.type === "ready") {
                finish();
                return;
              }
              if (message.type === "error") {
                if (initializationRef.current)
                  finish(new Error(message.message));
                else fail(message.message);
                return;
              }
              inFlightRef.current = false;
              const now = performance.now();
              averageRef.current = updateAverage(
                averageRef.current,
                message.processingMs,
              );
              if (message.handCount > 0) lastSeenRef.current = now;
              setTracking(
                trackingState(message.handCount, lastSeenRef.current, now),
              );
              setHandCount(message.handCount);
              setLowPerformance(isLowPerformance(averageRef.current));
              if (now - lastStatsRef.current > 500) {
                lastStatsRef.current = now;
                setAverageMs(Math.round(averageRef.current));
              }
              draw(message);
              onFrameRef.current?.(message);
            };
            worker.postMessage({
              type: "initialize",
              origin: window.location.origin,
            } satisfies TrackerRequest);
          });
        }
        if (request !== requestRef.current || !mountedRef.current) return false;
        setStatus("permission");
        setLoadStage(null);
        const stream =
          await navigator.mediaDevices.getUserMedia(cameraConstraints);
        if (request !== requestRef.current || !mountedRef.current) {
          stopStream(stream);
          return false;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (!video) throw new Error("The local preview could not be opened.");
        video.srcObject = stream;
        await video.play();
        if (request !== requestRef.current || !mountedRef.current) return false;
        setStatus("running");
        if (!track) return true;
        let lastFrame = 0;
        let lastVideoTime = -1;
        const processFrame = (now: number) => {
          if (request !== requestRef.current || !streamRef.current) return;
          if (
            video.readyState >= 2 &&
            !document.hidden &&
            !pausedRef.current &&
            !inFlightRef.current &&
            now - lastFrame >= nextFrameInterval(averageRef.current) &&
            video.currentTime !== lastVideoTime
          ) {
            lastFrame = now;
            lastVideoTime = video.currentTime;
            inFlightRef.current = true;
            createImageBitmap(video)
              .then((image) => {
                if (request !== requestRef.current || !workerRef.current) {
                  image.close();
                  return;
                }
                workerRef.current.postMessage(
                  {
                    type: "frame",
                    image,
                    timestamp: performance.now(),
                  } satisfies TrackerRequest,
                  [image],
                );
              })
              .catch(() => {
                if (request === requestRef.current)
                  fail(
                    "The camera frame could not be processed. Restart the camera or use the scripted tools.",
                  );
              });
          }
          frameRef.current = requestAnimationFrame(processFrame);
        };
        frameRef.current = requestAnimationFrame(processFrame);
        return true;
      } catch (failure) {
        if (request !== requestRef.current || !mountedRef.current) return false;
        const kind = classifyCameraError(failure);
        fail(
          kind !== "unknown" && failure instanceof DOMException
            ? cameraMessages[kind]
            : failure instanceof Error
              ? failure.message
              : cameraMessages.unknown,
        );
        return false;
      }
    },
    [fail],
  );

  /** Pause frame processing without releasing the camera. */
  const pause = useCallback(() => {
    pausedRef.current = true;
    setPaused(true);
  }, []);
  const resume = useCallback(() => {
    pausedRef.current = false;
    setPaused(false);
  }, []);

  return {
    status,
    paused,
    pause,
    resume,
    averageMs,
    loadStage,
    error,
    setError,
    tracking,
    handCount,
    lowPerformance,
    videoRef,
    overlayRef,
    streamRef,
    start,
    stop,
  };
}
