"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "./app-provider";
import { defaultConfig, loadPublicConfig } from "@/lib/asl/config";
import {
  createDefaultRegistry,
  describeAvailability,
} from "@/lib/asl/provider-registry";
import { RecognitionManager } from "@/lib/asl/recognition-manager";
import { fetchProxyHealth, type ProxyHealth } from "@/lib/asl/sign-speak";
import type {
  ProviderAvailability,
  PublicRecognitionConfig,
} from "@/lib/asl/types";
import { recognitionToolsCached } from "@/lib/lab-cache";
import { signToolsCached } from "@/lib/sign-cache";

/** Loads public config, builds the provider registry and tracks availability. */
export function useRecognitionSetup() {
  const { online, simulatedOffline } = useApp();
  const [config, setConfig] = useState<PublicRecognitionConfig>(defaultConfig);
  const [configLoaded, setConfigLoaded] = useState(false);
  const [availability, setAvailability] = useState<
    Record<string, ProviderAvailability>
  >({});
  const [proxyProduction, setProxyProduction] = useState<boolean | null>(null);
  const [health, setHealth] = useState<ProxyHealth | null>(null);
  const [checking, setChecking] = useState(true);
  const [toolsReady, setToolsReady] = useState(false);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    loadPublicConfig().then((value) => {
      if (!mounted.current) return;
      setConfig(value);
      setConfigLoaded(true);
    });
    return () => {
      mounted.current = false;
    };
  }, []);

  const registry = useMemo(
    () =>
      createDefaultRegistry(
        config,
        recognitionToolsCached,
        undefined,
        signToolsCached,
      ),
    [config],
  );
  const manager = useMemo(() => new RecognitionManager(registry), [registry]);
  useEffect(() => () => manager.cancel(), [manager]);

  const refreshId = useRef(0);
  const refresh = useCallback(async () => {
    // Overlapping checks (e.g. page load and a just-finished download): only
    // the most recent one may update the displayed availability.
    const id = ++refreshId.current;
    setChecking(true);
    const context = { online, simulatedOffline };
    const [result, health, tools] = await Promise.all([
      describeAvailability(registry, context),
      config.proxyUrl && online
        ? fetchProxyHealth(config.proxyUrl)
        : Promise.resolve(null),
      recognitionToolsCached().catch(() => false),
    ]);
    if (!mounted.current || id !== refreshId.current) return;
    setAvailability(result);
    setProxyProduction(health ? health.signSpeak.production : null);
    setHealth(health);
    setToolsReady(tools);
    setChecking(false);
  }, [registry, config.proxyUrl, online, simulatedOffline]);

  useEffect(() => {
    if (!configLoaded) return;
    // Availability must be re-evaluated when config or connectivity change.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    refresh();
  }, [configLoaded, refresh]);

  return {
    config,
    configLoaded,
    registry,
    manager,
    availability,
    proxyProduction,
    health,
    checking,
    toolsReady,
    refresh,
  };
}
