"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useApp } from "./app-provider";
import { Brand, Icon, type IconName, PrototypeNote } from "./ui";
const nav: { href: string; label: string; icon: IconName }[] = [
  { href: "/dashboard/", label: "My overview", icon: "dashboard" },
  { href: "/communication/", label: "Communication", icon: "message" },
  { href: "/signs/", label: "Sign recognition", icon: "waves" },
  { href: "/preventive-care/", label: "Preventive care", icon: "heart" },
  { href: "/resources/", label: "ASL resources", icon: "book" },
  { href: "/preferences/", label: "My preferences", icon: "settings" },
];
const explore: { href: string; label: string; icon: IconName }[] = [
  { href: "/safety/", label: "Safety & patient rights", icon: "shield" },
  { href: "/research/", label: "Research & impact", icon: "activity" },
  { href: "/sample-lab/", label: "ASL sample lab", icon: "hand" },
  { href: "/demo/", label: "Competition demo", icon: "monitor" },
];
export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { online, offlineReady, cacheError, requestInterpreter, openInfo } =
    useApp();
  const [mobileOpen, setMobileOpen] = useState(false);
  const sidebarRef = useRef<HTMLElement>(null);
  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    sidebarRef.current?.querySelector<HTMLElement>("a, button")?.focus();
    return () => {
      document.body.style.overflow = overflow;
      previous?.focus();
    };
  }, [mobileOpen]);
  const current =
    [...nav, ...explore].find((n) => pathname.startsWith(n.href.slice(0, -1)))
      ?.label ?? "Patient experience";
  return (
    <div className="app-shell">
      <a href="#main" className="skip-link">
        Skip to main content
      </a>
      <aside
        ref={sidebarRef}
        className={`sidebar ${mobileOpen ? "mobile-open" : ""}`}
        aria-label="Main navigation"
        role={mobileOpen ? "dialog" : undefined}
        aria-modal={mobileOpen ? true : undefined}
        onKeyDown={(event) => {
          if (!mobileOpen) return;
          if (event.key === "Escape") {
            event.preventDefault();
            setMobileOpen(false);
          }
          if (event.key === "Tab") {
            const controls = sidebarRef.current?.querySelectorAll<HTMLElement>(
              "a, button:not(:disabled)",
            );
            if (!controls?.length) return;
            const first = controls[0];
            const last = controls[controls.length - 1];
            if (event.shiftKey && document.activeElement === first) {
              event.preventDefault();
              last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
              event.preventDefault();
              first.focus();
            }
          }
        }}
      >
        <div className="sidebar-brand">
          <Link href="/">
            <Brand />
          </Link>
          <button
            className="icon-button mobile-only"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation"
          >
            <Icon name="x" />
          </button>
        </div>
        <div className="workspace-switch">
          <span className="workspace-initials">JM</span>
          <span>
            Jordan Morgan<small>Fictional patient</small>
          </span>
        </div>
        <div className="sidebar-scroll">
          <div className="nav-label">MY HEALTHCARE</div>
          <nav>
            {nav.map((n) => (
              <Link
                href={n.href}
                key={n.href}
                onClick={() => setMobileOpen(false)}
                className={`nav-link ${pathname === n.href || pathname === n.href.slice(0, -1) ? "active" : ""}`}
                aria-current={
                  pathname === n.href || pathname === n.href.slice(0, -1)
                    ? "page"
                    : undefined
                }
              >
                <Icon name={n.icon} />
                {n.label}
                {n.href.includes("communication") && (
                  <span className="nav-dot" />
                )}
              </Link>
            ))}
          </nav>
          <div className="nav-label explore-label">EXPLORE INTERPRETAI</div>
          <nav>
            {explore.map((n) => (
              <Link
                key={n.href}
                href={n.href}
                onClick={() => setMobileOpen(false)}
                className={`nav-link ${pathname === n.href || pathname === n.href.slice(0, -1) ? "active" : ""}`}
                aria-current={
                  pathname === n.href || pathname === n.href.slice(0, -1)
                    ? "page"
                    : undefined
                }
              >
                <Icon name={n.icon} />
                {n.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="sidebar-bottom">
          <div className="choice-panel">
            <Icon name="users" size={22} />
            <h3>Need an interpreter?</h3>
            <p>Choose qualified human interpretation at any point.</p>
            <button
              onClick={requestInterpreter}
              className="btn btn-white btn-small"
            >
              Request Qualified Interpreter
              <Icon name="arrow-right" size={15} />
            </button>
          </div>
          <div className="sidebar-foot">
            <Icon name="lock" size={14} />
            <span>No account. No tracking.</span>
          </div>
        </div>
      </aside>
      {mobileOpen && (
        <button
          className="sidebar-backdrop"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <div className="app-content" inert={mobileOpen}>
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-button mobile-only"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
              aria-expanded={mobileOpen}
            >
              <Icon name="menu" />
            </button>
            <span className="breadcrumb-home">Patient workspace</span>
            <Icon name="chevron" size={14} />
            <strong>{current}</strong>
          </div>
          <div className="topbar-actions">
            <span
              className={`network-label ${online ? "" : "is-offline"}`}
              role="status"
            >
              <span className="status-dot" />
              {online ? "Online" : "Offline"}
            </span>
            <span className="topbar-divider" />
            <button
              className="icon-button notifications-button"
              aria-label="View reminders"
              onClick={() =>
                openInfo(
                  "You’re all caught up",
                  "Your fictional care reminders appear on My overview. These reminders are examples, not a personalized medical schedule.",
                )
              }
            >
              <Icon name="bell" />
              <span />
            </button>
            <Link
              className="profile-avatar"
              href="/preferences/"
              aria-label="JM — Jordan’s preferences"
            >
              JM
            </Link>
          </div>
        </header>
        {!online && (
          <div className="offline-banner" role="status">
            <Icon name="offline" />
            Offline Mode — Prevalidated communication tools remain available.
            {!offlineReady && (
              <span>
                Previously cached pages only; full download not confirmed.
              </span>
            )}
          </div>
        )}
        <main id="main" className="main-content" tabIndex={-1}>
          {children}
          <footer className="app-footer">
            <PrototypeNote />
            <div>
              <span>
                <Icon name="lock" size={13} /> No account. No tracking. Your
                choice.
              </span>
              <span className="cache-state">
                <Icon name={offlineReady ? "check" : "download"} size={14} />
                {offlineReady
                  ? "Offline toolkit ready"
                  : cacheError
                    ? "Offline download unavailable"
                    : process.env.NODE_ENV !== "production"
                      ? "Offline caching available in production build"
                      : "Preparing offline toolkit…"}
              </span>
            </div>
          </footer>
        </main>
        <button className="mobile-interpreter" onClick={requestInterpreter}>
          <Icon name="users" size={18} />
          Request Qualified Interpreter
        </button>
      </div>
    </div>
  );
}
