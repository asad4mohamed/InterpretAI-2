"use client";
import { useEffect, useRef, useState } from "react";
import { Badge, Icon } from "./ui";
import {
  avatarDescriptors,
  checkAvatarText,
  createHandTalk,
  produceSignSpeakVideo,
  type HandTalkApi,
} from "@/lib/asl/avatar";
import type { RiskTopic } from "@/lib/scenarios";
import {
  RecognitionError,
  type ProviderAvailability,
  type PublicRecognitionConfig,
} from "@/lib/asl/types";

export type SignRequest = { id: string; text: string } | null;

/**
 * Optional machine-generated signing output. English text always stays
 * visible; signing is labelled as unvalidated; high-risk text is refused and
 * routed to a qualified interpreter.
 */
export function SigningAvatarPanel({
  config,
  availability,
  request,
  paused,
  onRisk,
}: {
  config: PublicRecognitionConfig;
  availability: ProviderAvailability;
  request: SignRequest;
  paused: boolean;
  onRisk: (risk: RiskTopic) => void;
}) {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [shownText, setShownText] = useState("");
  const [handTalkReady, setHandTalkReady] = useState(false);
  const [speed, setSpeed] = useState<"normal" | "slow" | "fast">("normal");
  const videoRef = useRef<HTMLVideoElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const handTalkRef = useRef<HandTalkApi | null>(null);
  const lastRequest = useRef<string | null>(null);
  const provider =
    config.avatarProvider === "none"
      ? null
      : avatarDescriptors[config.avatarProvider];
  const available = availability.state === "available" && !!provider;

  useEffect(
    () => () => {
      abortRef.current?.abort();
      handTalkRef.current?.disable().catch(() => undefined);
    },
    [],
  );
  useEffect(
    () => () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    },
    [videoUrl],
  );

  useEffect(() => {
    if (!request || request.id === lastRequest.current || !provider) return;
    lastRequest.current = request.id;
    const check = checkAvatarText(request.text, provider);
    const run = async () => {
      if (!check.ok) {
        setStatus(check.reason);
        if (check.risk) onRisk(check.risk);
        return;
      }
      if (!available || paused) {
        setStatus(
          paused
            ? "Machine signing is paused while a qualified interpreter is recommended."
            : "Signing avatar unavailable. The English text remains visible.",
        );
        return;
      }
      setBusy(true);
      setShownText(check.text);
      try {
        if (provider.id === "sign-speak") {
          abortRef.current?.abort();
          const controller = new AbortController();
          abortRef.current = controller;
          setStatus("Requesting machine-generated signing video…");
          const blob = await produceSignSpeakVideo(
            config,
            check.text,
            controller.signal,
          );
          setVideoUrl(URL.createObjectURL(blob));
          setStatus(
            "Machine-generated signing video ready. It has not been reviewed for accuracy.",
          );
        } else {
          if (!handTalkRef.current) {
            setStatus("Loading the Hand Talk signing avatar…");
            handTalkRef.current = await createHandTalk(
              config.handTalkToken ?? "",
              "#handtalk-avatar",
            );
            setHandTalkReady(true);
          }
          setStatus(
            "Hand Talk is signing the message. Machine-generated; not reviewed.",
          );
          await handTalkRef.current.translate(check.text);
        }
      } catch (failure) {
        setStatus(
          failure instanceof RecognitionError
            ? failure.code === "cancelled"
              ? "Signing request cancelled."
              : failure.message
            : "The signing avatar could not play this message. The English text remains visible.",
        );
      } finally {
        setBusy(false);
      }
    };
    run();
  }, [request, provider, available, paused, config, onRisk]);

  return (
    <section
      className="avatar-provider"
      aria-labelledby="avatar-provider-title"
    >
      <div className="mini-heading">
        <span id="avatar-provider-title">OPTIONAL SIGNING AVATAR</span>
        <Badge tone={available ? "amber" : "gray"}>
          {available ? "MACHINE-GENERATED · UNVALIDATED" : "NOT CONNECTED"}
        </Badge>
      </div>
      {!available ? (
        <p className="avatar-provider-note">
          {availability.state === "available"
            ? "No signing provider selected."
            : "detail" in availability
              ? availability.detail
              : ""}{" "}
          Messages stay as readable English text. The sample-lab mannequin is a
          separate scripted pose study, not a signing avatar.
        </p>
      ) : (
        <>
          <p className="avatar-provider-note">
            {provider?.label}. Output is produced by a third party, has not been
            reviewed by Deaf ASL experts for this app, and must not be used for
            clinical instructions. Up to {provider?.maxChars} characters.
          </p>
          {provider?.id === "sign-speak" && videoUrl && (
            <div className="avatar-provider-stage">
              <video
                ref={videoRef}
                src={videoUrl}
                controls
                autoPlay
                playsInline
                aria-label={`Machine-generated signing of: ${shownText}`}
              />
              <p className="avatar-caption">
                <strong>English:</strong> {shownText}
              </p>
              <button
                className="btn btn-outline btn-small"
                onClick={() => {
                  const video = videoRef.current;
                  if (!video) return;
                  video.currentTime = 0;
                  video.play().catch(() => undefined);
                }}
              >
                <Icon name="refresh" size={15} />
                Replay signing
              </button>
            </div>
          )}
          {provider?.id === "handtalk" && (
            <div className="avatar-provider-stage">
              <div id="handtalk-avatar" className="handtalk-host" />
              {shownText && (
                <p className="avatar-caption">
                  <strong>English:</strong> {shownText}
                </p>
              )}
              {handTalkReady && (
                <div className="avatar-controls">
                  <button
                    className="btn btn-outline btn-small"
                    onClick={() => handTalkRef.current?.pause()}
                  >
                    Pause
                  </button>
                  <button
                    className="btn btn-outline btn-small"
                    onClick={() => handTalkRef.current?.resume()}
                  >
                    Resume
                  </button>
                  <button
                    className="btn btn-outline btn-small"
                    onClick={() =>
                      handTalkRef.current?.stop().catch(() => undefined)
                    }
                  >
                    Stop
                  </button>
                  <button
                    className="btn btn-outline btn-small"
                    onClick={() =>
                      handTalkRef.current?.repeat().catch(() => undefined)
                    }
                  >
                    Replay
                  </button>
                  <label>
                    Signing speed
                    <select
                      value={speed}
                      onChange={(event) => {
                        const value = event.target.value as typeof speed;
                        setSpeed(value);
                        handTalkRef.current?.changeAnimationSpeed(value);
                      }}
                    >
                      <option value="normal">Normal</option>
                      <option value="slow">Slow</option>
                      <option value="fast">Fast</option>
                    </select>
                  </label>
                </div>
              )}
            </div>
          )}
          {busy && provider?.id === "sign-speak" && (
            <button
              className="text-button"
              onClick={() => abortRef.current?.abort()}
            >
              Cancel signing request
            </button>
          )}
        </>
      )}
      {status && (
        <p className="avatar-provider-status" role="status">
          {status}
        </p>
      )}
    </section>
  );
}
