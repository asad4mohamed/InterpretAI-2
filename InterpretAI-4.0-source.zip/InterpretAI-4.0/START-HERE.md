# InterpretAI 4.0 — start here

Your language. Your care. Your choice.

A Deaf-centered healthcare communication research prototype. Simulated — Not
Clinically Validated. It does NOT translate ASL sentences. Real recognition:

- NEW: continuous, on-device recognition of 250 ISOLATED ASL SIGNS (one sign
  at a time) with movement tracking, a reviewable sign history, and a small
  fixed table of short phrases. Model trained by GestureSign (MIT) on Google's
  asl-signs data (CC BY 4.0): 72.1% top-1 on 3 signers never seen in training.
- ASL fingerspelling (24 static letters), from 3.0.

## 1. macOS: install and run (copy and paste into Terminal)

    cd ~/Downloads
    unzip InterpretAI-4.0-source.zip
    cd InterpretAI-4.0
    npm install
    npm run build
    npm run start

Open http://127.0.0.1:3000 in Chrome. Keep Terminal open; Ctrl+C stops it.
Next time:  cd ~/Downloads/InterpretAI-4.0 && npm run start
Port busy (EADDRINUSE):  lsof -ti:3000,8787 | xargs kill

The first build needs internet once: it downloads Google's MediaPipe hand
model (7.8 MB) and Holistic model (13.7 MB) and checks their SHA-256.

## 2. Windows: install and run (PowerShell)

    cd $HOME\Downloads
    Expand-Archive InterpretAI-4.0-source.zip -DestinationPath .
    cd InterpretAI-4.0
    npm install
    npm run build
    npm run start

Open http://127.0.0.1:3000 in Chrome or Edge. Next time you can double-click
Start-InterpretAI.cmd (it serves the existing build). Port busy:
    Get-NetTCPConnection -LocalPort 3000 | % { Stop-Process -Id $_.OwningProcess }

Requires Node.js 22 or later (https://nodejs.org). Windows was not tested by
us; the commands are the standard npm ones and the build script has a Windows
code path from 3.0.

## 3. Try sign recognition (new)

1. Click "Sign recognition" in the sidebar (or Communication → Experimental
   live recognition → "ASL signs, continuous").
2. Click "Download sign recognition" (47.7 MB, once; works offline after).
3. No camera? "Show replay clips" plays 6 real recordings of signers the model
   never saw. Each result appears in "Recognised signs, in order".
4. With a camera: tick the consent box → Start camera. Stand back so your
   head and both shoulders are visible. Sign ONE word, then pause or lower
   your hands. Repeat for the next word.
5. Check the history (pick a guess for any "Not sure", Undo, remove), edit
   the suggested English, then Confirm (or Reject).
6. Supported signs: open "Supported signs (250)". Phrase support: open
   "Short phrases: what is supported", or read docs/PHRASES.md.

Use Chrome or Edge. Safari is untested.

## 4. Fingerspelling (from 3.0)

ASL sample lab → "Download recognition tools" (21.8 MB, once) → Communication
→ Experimental live recognition → "ASL fingerspelling". Hold each letter
~1 second; no J or Z. It is also available inside sign mode
("Fingerspell a word instead").

## 5. Optional cloud providers (credentials stay on your computer's proxy)

    cp .env.example .env.local      (Windows: copy .env.example .env.local)
    # edit .env.local, then:
    npm run proxy                   # in one terminal
    npm run start                   # in another

Never paste keys into chat, and never commit .env.local.
Guides: docs/API-INTEGRATION.md and docs/MODEL-SELECTION.md.

## 6. Tests, evaluation, development

    npm run lint && npm run typecheck && npm test
    npm run test:setup && npm run test:e2e
    npm run eval:signs -- --data-dir <folder with Kaggle asl-signs>   # full model evaluation
    npm run dev                                                      # no offline cache

## 7. What is real vs simulated

docs/AUDIT-4.0.md (requirement-by-requirement audit and release verdict),
docs/MODEL-CARD-SIGNS.md, docs/DATASET-SIGNS.md, docs/PHRASES.md,
docs/KNOWN-LIMITATIONS.md, docs/TEST-RESULTS.md, docs/WEBCAM-MANUAL-TEST.md.

All patients are fictional. Interpreter requests are simulated and contact no
one. Do not enter real health information. Not HIPAA assessed. Qualified human
interpretation remains essential.
