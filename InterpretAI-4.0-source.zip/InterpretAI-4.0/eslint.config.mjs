import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
export default defineConfig([
  ...nextVitals,
  ...nextTs,
  globalIgnores([
    ".next/**",
    "out/**",
    "work/**",
    "outputs/**",
    "interpret.ai/**",
    "next-env.d.ts",
    "public/sw.js",
    "public/lab-assets/**",
    "public/lab-engine/**",
    "public/sign-assets/**",
    "public/sign-engine/**",
    "playwright-report/**",
    "test-results/**",
  ]),
]);
