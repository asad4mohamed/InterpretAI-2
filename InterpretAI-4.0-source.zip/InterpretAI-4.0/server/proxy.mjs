#!/usr/bin/env node
/**
 * InterpretAI optional secure proxy for Sign-Speak.
 *
 * Why it exists: Next.js static export has no runtime server routes, and a
 * private API key must never be shipped in browser JavaScript. This small,
 * dependency-free Node server holds SIGN_SPEAK_API_KEY and forwards only the
 * two documented operations InterpretAI uses:
 *
 *   POST {base}/recognize-sign   (+ GET {base}/recognize-sign/{batch_id})
 *   POST {base}/produce-sign     (+ GET {base}/produce-sign/{batch_id})
 *
 * Endpoint paths, the X-api-key header, the request fields, and the
 * 202 + batch_id polling pattern are taken from Sign-Speak's official
 * @sign-speak/react-sdk 0.7.3 source (see docs/API-INTEGRATION.md).
 *
 * Privacy: request bodies, video, text and upstream responses are never
 * logged or written to disk. Only method, route, status and duration are
 * logged. Responses carry Cache-Control: no-store.
 */
import http from "node:http";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { pathToFileURL } from "node:url";

const VIDEO_TYPES = new Set(["video/webm", "video/mp4"]);

/** @param {Record<string, string | undefined>} [env] */
export function readConfig(env = process.env) {
  const number = (value, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? n : fallback;
  };
  return {
    apiKey: env.SIGN_SPEAK_API_KEY?.trim() || null,
    apiBase: (
      env.SIGN_SPEAK_API_BASE?.trim() || "https://api.sign-speak.com"
    ).replace(/\/$/, ""),
    recognitionModel: env.SIGN_SPEAK_RECOGNITION_MODEL?.trim() || "SLR.2.sm",
    host: env.PROXY_HOST?.trim() || "127.0.0.1",
    port: number(env.PROXY_PORT, 8787),
    allowedOrigins: (
      env.PROXY_ALLOWED_ORIGINS || "http://127.0.0.1:3000,http://localhost:3000"
    )
      .split(",")
      .map((o) => o.trim())
      .filter(Boolean),
    maxUploadBytes: number(env.PROXY_MAX_UPLOAD_BYTES, 8_000_000),
    maxTextChars: number(env.PROXY_MAX_TEXT_CHARS, 500),
    upstreamTimeoutMs: number(env.PROXY_UPSTREAM_TIMEOUT_MS, 40_000),
    rateLimitPerMinute: number(env.PROXY_RATE_LIMIT_PER_MINUTE, 20),
    pendingTtlMs: 10 * 60_000,
    // Hugging Face (server-side only). A Dedicated Inference Endpoint URL
    // takes precedence; otherwise the HF Inference provider route for a model.
    hfToken: env.HF_TOKEN?.trim() || null,
    hfModelId: validModelId(env.HF_ASL_MODEL_ID?.trim()),
    hfEndpointUrl: validHttpsUrl(env.HF_ASL_ENDPOINT_URL?.trim()),
    hfRouterBase: (
      env.HF_ROUTER_BASE?.trim() || "https://router.huggingface.co"
    ).replace(/\/$/, ""),
    hfMaxImageBytes: number(env.HF_MAX_IMAGE_BYTES, 2_000_000),
  };
}

function validModelId(value) {
  return value && /^[\w.-]{1,96}\/[\w.-]{1,96}$/.test(value) ? value : null;
}
function validHttpsUrl(value) {
  if (!value) return null;
  try {
    const url = new URL(value);
    // HTTPS for real endpoints; loopback HTTP only for local testing/mocks.
    if (
      url.protocol === "https:" ||
      (url.protocol === "http:" &&
        ["127.0.0.1", "localhost"].includes(url.hostname))
    )
      return url.href.replace(/\/$/, "");
  } catch {
    // invalid
  }
  return null;
}
export function hfStatus(config) {
  const target = config.hfEndpointUrl
    ? "dedicated-endpoint"
    : config.hfModelId
      ? "hf-inference"
      : null;
  return {
    configured: !!config.hfToken && !!target,
    tokenSet: !!config.hfToken,
    target,
    modelId: config.hfModelId,
  };
}
const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function sniffVideoType(bytes) {
  if (bytes.length > 12 && bytes.toString("ascii", 4, 8) === "ftyp")
    return "video/mp4";
  if (bytes.length > 4 && bytes.readUInt32BE(0) === 0x1a45dfa3)
    return "video/webm";
  return null;
}

async function readBody(req, limit) {
  const declared = Number(req.headers["content-length"]);
  if (Number.isFinite(declared) && declared > limit)
    throw new HttpError(413, "too-large", `Upload exceeds ${limit} bytes.`);
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit)
      throw new HttpError(413, "too-large", `Upload exceeds ${limit} bytes.`);
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function upstreamError(status) {
  if (status === 401 || status === 403)
    return new HttpError(
      401,
      "auth-failed",
      "Sign-Speak rejected the configured API key.",
    );
  if (status === 429)
    return new HttpError(
      429,
      "rate-limited",
      "Sign-Speak rate limit or quota reached.",
    );
  if (status >= 400 && status < 500)
    return new HttpError(
      400,
      "provider-rejected",
      `Sign-Speak rejected the request (HTTP ${status}).`,
    );
  return new HttpError(
    502,
    "provider-error",
    `Sign-Speak returned HTTP ${status}.`,
  );
}

export function createProxyServer(
  config = readConfig(),
  { fetcher = fetch, log = console.log } = {},
) {
  const pending = new Map(); // opaque requestId -> { kind, batchId, expires }
  const hits = new Map(); // ip -> timestamps
  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [id, entry] of pending)
      if (entry.expires < now) pending.delete(id);
    for (const [ip, list] of hits)
      if (!list.some((t) => now - t < 60_000)) hits.delete(ip);
  }, 60_000);
  sweep.unref();

  const upstream = async (path, init) => {
    const headers = {
      "X-api-key": config.apiKey,
      ...(init.body ? { "Content-Type": "application/json" } : {}),
    };
    try {
      return await fetcher(`${config.apiBase}${path}`, {
        ...init,
        headers,
        signal: AbortSignal.timeout(config.upstreamTimeoutMs),
      });
    } catch (failure) {
      if (failure?.name === "TimeoutError" || failure?.name === "AbortError")
        throw new HttpError(
          504,
          "timeout",
          "Sign-Speak did not respond in time.",
        );
      throw new HttpError(502, "network", "Sign-Speak could not be reached.");
    }
  };

  const remember = (kind, batchId) => {
    if (typeof batchId !== "string" || !batchId || batchId.length > 256)
      throw new HttpError(
        502,
        "invalid-response",
        "Sign-Speak returned 202 without a batch_id.",
      );
    const requestId = randomUUID();
    pending.set(requestId, {
      kind,
      batchId,
      expires: Date.now() + config.pendingTtlMs,
    });
    return requestId;
  };

  const json = (res, status, body) => {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
    });
    res.end(JSON.stringify(body));
  };

  async function relayRecognition(res, response, requestId) {
    let data;
    try {
      data = await response.json();
    } catch {
      throw new HttpError(
        502,
        "invalid-response",
        "Sign-Speak returned an unreadable response.",
      );
    }
    if (response.status === 202) {
      const id = requestId ?? remember("recognize", data?.batch_id);
      return json(res, 202, { status: "pending", requestId: id });
    }
    if (requestId) pending.delete(requestId);
    return json(res, 200, { status: "completed", result: data });
  }

  async function relayVideo(res, response, requestId) {
    if (response.status === 202) {
      if (requestId) return json(res, 202, { status: "pending", requestId });
      let data;
      try {
        data = await response.json();
      } catch {
        throw new HttpError(
          502,
          "invalid-response",
          "Sign-Speak returned 202 without JSON.",
        );
      }
      return json(res, 202, {
        status: "pending",
        requestId: remember("produce", data?.batch_id),
      });
    }
    const bytes = Buffer.from(await response.arrayBuffer());
    if (!bytes.length) {
      if (requestId) return json(res, 202, { status: "pending", requestId });
      throw new HttpError(
        502,
        "invalid-response",
        "Sign-Speak returned an empty video.",
      );
    }
    if (requestId) pending.delete(requestId);
    const declared = (response.headers.get("content-type") || "")
      .split(";")[0]
      .trim();
    const type = declared.startsWith("video/")
      ? declared
      : sniffVideoType(bytes) || declared || "application/octet-stream";
    res.writeHead(200, {
      "Content-Type": type,
      "Content-Length": bytes.length,
    });
    res.end(bytes);
  }

  /**
   * Hugging Face image classification. Documented contract: POST raw image
   * bytes with "Authorization: Bearer <token>"; response is an array of
   * { label, score }. Sent only with a per-image consent header.
   */
  async function classifyImage(req, res) {
    if (req.method !== "POST") throw new HttpError(405, "method", "Use POST.");
    const status = hfStatus(config);
    if (!status.tokenSet)
      throw new HttpError(
        503,
        "not-configured",
        "HF_TOKEN is not set on the proxy.",
      );
    if (!status.target)
      throw new HttpError(
        503,
        "not-configured",
        "Set HF_ASL_ENDPOINT_URL or HF_ASL_MODEL_ID on the proxy.",
      );
    if (req.headers["x-interpretai-consent"] !== "huggingface")
      throw new HttpError(
        428,
        "consent-required",
        "Per-image consent header missing; nothing was forwarded.",
      );
    const type = String(req.headers["content-type"] || "")
      .split(";")[0]
      .trim()
      .toLowerCase();
    if (!IMAGE_TYPES.has(type))
      throw new HttpError(
        415,
        "unsupported-type",
        "Send image/jpeg, image/png or image/webp.",
      );
    const image = await readBody(req, config.hfMaxImageBytes);
    if (!image.length) throw new HttpError(400, "empty", "Empty upload.");
    const target =
      config.hfEndpointUrl ??
      `${config.hfRouterBase}/hf-inference/models/${config.hfModelId}`;
    const call = async () => {
      try {
        return await fetcher(target, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${config.hfToken}`,
            "Content-Type": type,
            Accept: "application/json",
          },
          body: image,
          signal: AbortSignal.timeout(config.upstreamTimeoutMs),
        });
      } catch (failure) {
        if (failure?.name === "TimeoutError" || failure?.name === "AbortError")
          throw new HttpError(
            504,
            "timeout",
            "Hugging Face did not respond in time.",
          );
        throw new HttpError(
          502,
          "network",
          "Hugging Face could not be reached.",
        );
      }
    };
    try {
      let response = await call();
      // Retry rule: one retry when the model is loading (HTTP 503).
      if (response.status === 503) {
        let wait = 2;
        try {
          const body = await response.json();
          if (Number.isFinite(body?.estimated_time)) wait = body.estimated_time;
        } catch {
          // no JSON body
        }
        await sleep(Math.min(8, Math.max(1, wait)) * 1000);
        response = await call();
      }
      if (response.status === 401 || response.status === 403)
        throw new HttpError(
          401,
          "auth-failed",
          "Hugging Face rejected HF_TOKEN.",
        );
      if (response.status === 404 || response.status === 410)
        throw new HttpError(
          404,
          "model-unavailable",
          "This model is not served at the configured Hugging Face target. Deploy it on a Dedicated Inference Endpoint and set HF_ASL_ENDPOINT_URL.",
        );
      if (response.status === 429)
        throw new HttpError(
          429,
          "rate-limited",
          "Hugging Face rate limit or quota reached.",
        );
      if (response.status === 503)
        throw new HttpError(
          503,
          "model-loading",
          "The Hugging Face model is still loading. Try again shortly.",
        );
      if (!response.ok)
        throw new HttpError(
          502,
          "provider-error",
          `Hugging Face returned HTTP ${response.status}.`,
        );
      let data;
      try {
        data = await response.json();
      } catch {
        throw new HttpError(
          502,
          "invalid-response",
          "Hugging Face returned an unreadable response.",
        );
      }
      // Some endpoints wrap results as [[...]] for batched input.
      if (Array.isArray(data) && data.length === 1 && Array.isArray(data[0]))
        data = data[0];
      if (
        !Array.isArray(data) ||
        !data.every(
          (item) =>
            item &&
            typeof item.label === "string" &&
            typeof item.score === "number" &&
            Number.isFinite(item.score),
        )
      )
        throw new HttpError(
          502,
          "invalid-response",
          "Hugging Face returned an unexpected response shape.",
        );
      return json(res, 200, {
        status: "completed",
        model:
          status.target === "dedicated-endpoint"
            ? (config.hfModelId ?? "dedicated-endpoint")
            : config.hfModelId,
        target: status.target,
        result: data.slice(0, 5).map(({ label, score }) => ({ label, score })),
      });
    } finally {
      image.fill(0);
    }
  }

  const routes = async (req, res, url) => {
    if (req.method === "GET" && url.pathname === "/health")
      return json(res, 200, {
        ok: true,
        signSpeak: {
          recognition: !!config.apiKey,
          production: !!config.apiKey,
        },
        huggingFace: hfStatus(config),
      });
    if (url.pathname === "/v1/hf/classify-image")
      return classifyImage(req, res);
    const match = url.pathname.match(
      /^\/v1\/sign-speak\/(recognize|produce)(?:\/([\w-]{1,128}))?$/,
    );
    if (!match) throw new HttpError(404, "not-found", "Unknown route.");
    const [, kind, id] = match;
    if (!config.apiKey)
      throw new HttpError(
        503,
        "not-configured",
        "SIGN_SPEAK_API_KEY is not set on the proxy.",
      );

    if (id) {
      if (req.method !== "GET")
        throw new HttpError(405, "method", "Use GET to poll.");
      const entry = pending.get(id);
      if (!entry || entry.kind !== kind)
        throw new HttpError(
          404,
          "unknown-request",
          "Unknown or expired request.",
        );
      const path = `/${kind === "recognize" ? "recognize-sign" : "produce-sign"}/${encodeURIComponent(entry.batchId)}`;
      const response = await upstream(path, { method: "GET" });
      if (!response.ok && response.status !== 202)
        throw upstreamError(response.status);
      return kind === "recognize"
        ? relayRecognition(res, response, id)
        : relayVideo(res, response, id);
    }

    if (req.method !== "POST") throw new HttpError(405, "method", "Use POST.");
    if (kind === "recognize") {
      if (req.headers["x-interpretai-consent"] !== "sign-speak")
        throw new HttpError(
          428,
          "consent-required",
          "Per-clip consent header missing; nothing was forwarded.",
        );
      const type = String(req.headers["content-type"] || "")
        .split(";")[0]
        .trim()
        .toLowerCase();
      if (!VIDEO_TYPES.has(type))
        throw new HttpError(
          415,
          "unsupported-type",
          "Send video/webm or video/mp4.",
        );
      const video = await readBody(req, config.maxUploadBytes);
      if (!video.length) throw new HttpError(400, "empty", "Empty upload.");
      const response = await upstream("/recognize-sign", {
        method: "POST",
        body: JSON.stringify({
          payload: video.toString("base64"),
          single_recognition_mode: true,
          request_class: "BLOCKING",
          model: config.recognitionModel,
        }),
      });
      video.fill(0); // drop our copy of the clip promptly
      if (!response.ok && response.status !== 202)
        throw upstreamError(response.status);
      return relayRecognition(res, response);
    }
    const type = String(req.headers["content-type"] || "")
      .split(";")[0]
      .trim()
      .toLowerCase();
    if (type !== "application/json")
      throw new HttpError(415, "unsupported-type", "Send JSON.");
    let body;
    try {
      body = JSON.parse((await readBody(req, 16_000)).toString("utf8"));
    } catch (failure) {
      if (failure instanceof HttpError) throw failure;
      throw new HttpError(400, "bad-json", "Invalid JSON.");
    }
    const english =
      typeof body?.english === "string" ? body.english.trim() : "";
    if (!english) throw new HttpError(400, "empty", "english is required.");
    if (english.length > config.maxTextChars)
      throw new HttpError(
        400,
        "too-long",
        `english exceeds ${config.maxTextChars} characters.`,
      );
    const response = await upstream("/produce-sign", {
      method: "POST",
      body: JSON.stringify({
        english,
        request_class: "BLOCKING",
        resolution: 512,
      }),
    });
    if (!response.ok && response.status !== 202)
      throw upstreamError(response.status);
    return relayVideo(res, response);
  };

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    const url = new URL(req.url || "/", "http://proxy.local");
    const origin = req.headers.origin;
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("Vary", "Origin");
    try {
      if (origin) {
        if (!config.allowedOrigins.includes(origin))
          throw new HttpError(403, "origin", "Origin not allowed.");
        res.setHeader("Access-Control-Allow-Origin", origin);
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader(
          "Access-Control-Allow-Headers",
          "Content-Type, X-InterpretAI-Consent",
        );
        res.setHeader("Access-Control-Max-Age", "600");
      }
      if (req.method === "OPTIONS") {
        res.writeHead(204);
        return res.end();
      }
      if (url.pathname !== "/health") {
        const ip = req.socket.remoteAddress || "unknown";
        const now = Date.now();
        const list = (hits.get(ip) || []).filter((t) => now - t < 60_000);
        if (list.length >= config.rateLimitPerMinute)
          throw new HttpError(
            429,
            "rate-limited",
            "Too many requests to the proxy. Wait a minute.",
          );
        list.push(now);
        hits.set(ip, list);
      }
      await routes(req, res, url);
    } catch (failure) {
      const error =
        failure instanceof HttpError
          ? failure
          : new HttpError(500, "internal", "Proxy error.");
      if (!res.headersSent)
        json(res, error.status, {
          error: { code: error.code, message: error.message },
        });
      else res.destroy();
    } finally {
      const route = url.pathname.replace(
        /^(\/v1\/sign-speak\/(?:recognize|produce))\/.+$/,
        "$1/:id",
      );
      log(`${req.method} ${route} ${res.statusCode} ${Date.now() - started}ms`);
    }
  });
  server.on("close", () => clearInterval(sweep));
  return server;
}

const isMain =
  process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  for (const file of [".env.local", ".env"])
    if (existsSync(file)) process.loadEnvFile(file);
  const config = readConfig();
  const server = createProxyServer(config);
  server.listen(config.port, config.host, () => {
    console.log(
      `InterpretAI secure proxy on http://${config.host}:${config.port}`,
    );
    console.log(
      config.apiKey
        ? "Sign-Speak key loaded from the server environment (never sent to browsers)."
        : "SIGN_SPEAK_API_KEY is not set: /health reports Sign-Speak as not configured.",
    );
    const hf = hfStatus(config);
    console.log(
      hf.configured
        ? `Hugging Face token loaded (server-side only); target: ${hf.target === "dedicated-endpoint" ? "Dedicated Inference Endpoint" : "HF Inference provider, model " + hf.modelId}.`
        : `Hugging Face not configured (${hf.tokenSet ? "set HF_ASL_ENDPOINT_URL or HF_ASL_MODEL_ID" : "HF_TOKEN not set"}).`,
    );
    console.log(`Allowed browser origins: ${config.allowedOrigins.join(", ")}`);
  });
}
